# Pending Signal Re-evaluation Report

## 1. 概要

* 生成日時JST: 2026-06-18 08:46:31 JST
* データソース: sheets
* 対象SIGNALS件数: 108
* 再評価対象件数: 37
* closed化した件数: 7
* no_entry継続件数: 3
* open継続件数: 27
* missed_opportunity件数: 0
* Sheets保存: 実行
* Sheets保存成功件数: 33
* Sheets重複スキップ件数: 4
* Sheets保存warning: なし

## 2. 決着したシグナル

| signal_id | asset | side | rank | previous_outcome | outcome | r_multiple | error_type |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_DXY_LONG_TREND | DXY | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B |  | win_tp1 | 1.087 | target_reached |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260605_DXY_LONG_TREND | DXY | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B |  | win_tp1 | 1.087 | target_reached |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B |  | loss_sl | -1.0 | stop_loss |

## 3. 未決着継続

| signal_id | asset | side | rank | outcome | mfe_r | mae_r | bars_checked |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | open_unresolved | 0.7176 | -0.7126 | 9 |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | open_unresolved | 0.7176 | -0.7126 | 9 |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 0.0295 | -0.3517 | 10 |
| 20260605_DXY_LONG_A-Momentum | DXY | LONG | B | open_unresolved | 0.2447 | -0.2883 | 8 |
| 20260605_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.7325 | -0.0407 | 8 |
| 20260605_US10Y_LONG_A-Pullback | US10Y | LONG | B | open_unresolved | 0.1602 | -0.5451 | 6 |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.7836 | -0.0124 | 8 |
| 20260608_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.7917 | -0.008 | 7 |
| 20260608_US10Y_LONG_B-Watch | US10Y | LONG | B | open_unresolved | 0.0821 | -0.688 | 5 |
| 20260609_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 0.0965 | -0.3064 | 8 |
| 20260609_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.0498 | -0.1436 | 6 |
| 20260609_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 0.6912 | -0.2116 | 6 |
| 20260610_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.067 | -0.437 | 5 |
| 20260611_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 0.4828 | -0.0392 | 4 |
| 20260612_WTI_SHORT_B-Watch | WTI | SHORT | B | no_entry | 0.3941 | 0.0947 | 3 |
| 20260614_NASDAQ_LONG_A-Pullback | NASDAQ | LONG | B | open_unresolved | 0.384 | -0.0335 | 3 |
| 20260614_SPX_LONG_A-Pullback | SPX | LONG | B | open_unresolved | 0.386 | -0.0124 | 3 |
| 20260614_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 0.2433 | -0.0239 | 3 |
| 20260615_NASDAQ_LONG_B-Watch | NASDAQ | LONG | B | open_unresolved | -0.0209 | -0.2963 | 2 |
| 20260615_SPX_LONG_B-Watch | SPX | LONG | B | no_entry | -0.0846 | -0.2577 | 2 |

## 4. 取り逃し候補

取り逃し候補はありません。

## 5. No Trade再評価

No Trade再評価は実行していません。

## 6. 注意

* このレポートは実売買ではありません。
* Tactical Swing OS が過去に出した判断の仮想評価です。
* 価格データの欠損や市場休場により、評価が遅れる場合があります。
* append-only運用でEVALUATIONSへ追記する場合、分析側では最新評価行を採用する必要があります。
