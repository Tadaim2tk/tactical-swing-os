# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-11 08:16:09 JST
取得日時（UTC）: 2026-06-10 23:16:09 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.31
headline件数: 75

## 見出し

- [CNBC Markets] U.S. military begins strikes on 'multiple targets' in Iran at Trump's direction (未分類)
- [CNBC Markets] Oracle beats on earnings, but stock drops on plans to raise another $20 billion (SPX|NASDAQ)
- [CNBC Markets] Analysis: Trump said he loves inflation. Why that should be music to Kevin Warsh's ears (US10Y|DXY)
- [CNBC Markets] Trump keeps saying an Iran deal is close. Markets keep believing it (未分類)
- [CNBC Markets] Trump says 'I love the inflation' after consumer price index hits 3-year high (WTI)
- [CNBC Markets] USDA's Rollins called screwworm a 'little pest' amid U.S. spread. Last year, she called it 'terrifying' (未分類)
- [CNBC Markets] Oil prices rise after Trump says U.S. will attack Iran 'very hard' (WTI)
- [CNBC Markets] Wall Street needs a crash course in the token economy ahead of AI IPOs. SpaceX offers a preview (SPX)
- [CNBC Markets] Trump says U.S. secretly moved more than 100 million barrels of oil through Strait of Hormuz (WTI)
- [CNBC Markets] College sticker prices top $100,000 at 16 schools — but many students pay significantly less (未分類)
- [CNBC Markets] World Cup travel boost hasn't materialized for U.S. businesses — yet (未分類)
- [CNBC Markets] Unique SpaceX IPO is hedging challenge for Wall Street: 'What are you going to do, short NASA?' (SPX)
- [CNBC Markets] Bisignano says Social Security Administration's phone helpline wait times have reached a record low (未分類)
- [CNBC Markets] Volatility surge has trader eyeing one 'stable' stock (VIX)
- [CNBC Markets] Citigroup shares outperform down market after Trump endorsement (SPX)
- [CNBC Markets] As gold's tumble continues, traders bet the pain may last for two more years (BTC|GOLD)
- [CNBC Markets] Sen. Warren calls on SEC to delay SpaceX IPO, flagging concerns about valuation and governance (未分類)
- [CNBC Markets] Starbucks stock is a bright spot in Wednesday's bleak market. Here's why (未分類)
- [CNBC Markets] Trump signs $70 billion immigration funding bill after months of delay (未分類)
- [CNBC Markets] Here's the inflation breakdown for May 2026 — in one chart (未分類)
- [CNBC Markets] Company that bet big on Trump-backed crypto says its fortunes have improved (BTC)
- [CNBC Markets] Amazon trucking expansion sparks freight stock sell-off (未分類)
- [CNBC Markets] Bill Gates tells House panel 'I should have never met' with Jeffrey Epstein (未分類)
- [CNBC Markets] Trump doubles down on Pulte for DNI, as Congress eyes short-term patch for foreign surveillance law (未分類)
- [CNBC Markets] SpaceX primed for double-digit pop on first day, if 'perps' trading is any guide (BTC)
- [CNBC Markets] Humaniod robotics company raises up to $1.4 billion from Nvidia, Amazon and others (未分類)
- [CNBC Markets] Palantir's Karp says businesses are 'unhappy' with the frontier AI labs (未分類)
- [CNBC Markets] Trump says Iran will 'pay the price' and claims they have 'taken too long' to agree to a deal (未分類)
- [CNBC Markets] Regulators' proposed prediction markets rules ban trading on terrorism, assassinations (未分類)
- [CNBC Markets] Private credit lenders say their big software bet faces an AI reckoning — but not a ‘SaaSpocalypse' (VIX)
- [MarketWatch Top Stories] Micron, Intel drag the tech sector into a new bearish phase. Will the correction last this time? (NASDAQ|VIX)
- [MarketWatch Top Stories] Oracle’s stock slides after earnings, as the steep price of AI spooks investors (SPX|NASDAQ)
- [MarketWatch Top Stories] Bitcoin bulls are still around. These charts show they just moved on to hotter markets. (BTC)
- [MarketWatch Top Stories] Why Nike saw its stock downgraded a day before the World Cup’s kickoff (未分類)
- [MarketWatch Top Stories] Sports betting is taking a bite out of gamblers’ grocery budgets, new research suggests (未分類)
- [MarketWatch Top Stories] Worried that big IPOs will torpedo the stock market? These factors suggest otherwise. (SPX)
- [MarketWatch Top Stories] ‘It will not bring you happiness’: I have advice for your single, childless 62-year-old multimillionaire reader (未分類)
- [MarketWatch Top Stories] My plumber charged $160 to fix the cistern on my toilet — but created another problem. Do I pay again? (WTI)
- [MarketWatch Top Stories] Social Security is facing a 22% cliff — 4 ways to build an income stream Washington can’t touch (未分類)
- [MarketWatch Top Stories] ‘I feel like I’m living a lie’: My husband and I pretend we’re strapped for cash in front of friends. Is that bad? (未分類)
- [CoinDesk] Privacy returns to focus as Ethereum developers explore new token standards (BTC)
- [CoinDesk] BlackRock and Fidelity are quietly turning bitcoin ETFs into a two-firm market (BTC)
- [CoinDesk] Coinbase-backed Stand With Crypto calls on members to campaign against banks blocking digital asset transactions (BTC)
- [CoinDesk] Crypto Long & Short: Who answers the 3am call when DeFi breaks? (BTC)
- [CoinDesk] Netomi CEO says $5 trillion AI customer experience market could boost stablecoin demand (SPX)
- [CoinDesk] The quantum clock is ticking: it's Bitcoin's problem, not Ethereum's (BTC)
- [CoinDesk] Mastercard prepares for a future where AI agents make payments (BTC)
- [CoinDesk] Kalshi now requires users to reveal employers as it fights insider trading and market manipulation (未分類)
- [CoinDesk] Prediction markets get first U.S. rule proposal as CFTC pursues contract reviews (未分類)
- [CoinDesk] Michael Saylor gets into public debate over claims that Strategy's latest share sale was dilutive (BTC|US10Y)
