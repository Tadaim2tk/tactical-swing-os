# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-11 08:16:10 JST
生成日時（UTC）: 2026-06-10 23:16:10 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.31
ニュース市場バイアス: risk_off
ニュース矛盾スコア: 18.47
主要テーマ: gold_safe_haven, geopolitical_risk, inflation_pressure, risk_off
日本語要約: 金安全資産需要、地政学リスク、インフレ圧力が優勢で、ニュース面では慎重姿勢が強い状態です。
ニュースモード: ニュースはリスクオフ寄り / 地政学リスク材料あり

## スコア

- risk_on_news_score: 18.47
- risk_off_news_score: 92.33
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 100.0
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 36.93
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 100.0
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 36.93
- news_confidence: 100.0

## Top News Drivers

- U.S. military begins strikes on 'multiple targets' in Iran at Trump's direction (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Analysis: Trump said he loves inflation. Why that should be music to Kevin Warsh's ears (地政学リスク / インフレ圧力 / 金安全資産需要 / リスクオフ要因 / 金利圧力候補)
- Trump keeps saying an Iran deal is close. Markets keep believing it (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Trump says 'I love the inflation' after consumer price index hits 3-year high (地政学リスク / インフレ圧力 / 金安全資産需要 / リスクオフ要因 / 金利圧力候補)
- Oil prices rise after Trump says U.S. will attack Iran 'very hard' (地政学リスク / インフレ圧力 / リスクオフ要因 / 金利圧力候補)
- Sen. Warren calls on SEC to delay SpaceX IPO, flagging concerns about valuation and governance (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Here's the inflation breakdown for May 2026 — in one chart (地政学リスク / インフレ圧力 / 金安全資産需要 / リスクオフ要因 / 金利圧力候補)
- Private credit lenders say their big software bet faces an AI reckoning — but not a ‘SaaSpocalypse' (地政学リスク / リスクオフ要因 / 金安全資産需要)
- Micron, Intel drag the tech sector into a new bearish phase. Will the correction last this time? (リスクオフ要因)
- BlackRock and Fidelity are quietly turning bitcoin ETFs into a two-firm market (暗号資産流動性 / 中銀ハト派)
