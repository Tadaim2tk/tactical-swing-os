# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-14 07:39:56 JST
生成日時（UTC）: 2026-07-13 22:39:56 UTC
headline件数: 73
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.36
ニュース市場バイアス: risk_off
ニュース矛盾スコア: 18.48
主要テーマ: geopolitical_risk, risk_off, gold_safe_haven
日本語要約: 地政学リスク、リスクオフ要因、金安全資産需要が優勢で、ニュース面では慎重姿勢が強い状態です。
ニュースモード: ニュースはリスクオフ寄り / 金利圧力材料あり / 地政学リスク材料あり

## スコア

- risk_on_news_score: 18.48
- risk_off_news_score: 92.4
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 36.96
- gold_safe_haven_news_score: 73.92
- oil_supply_risk_news_score: 18.48
- crypto_liquidity_news_score: 36.96
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 36.96
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 36.96
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Trump proposes 20% toll on cargo through Strait of Hormuz; restarts Iran blockade (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Waller says Fed shouldn't 'fight the last war' on inflation but warns hikes still possible (地政学リスク / インフレ圧力 / 金安全資産需要 / リスクオフ要因 / 金利圧力候補)
- A July rate hike from the Fed? The odds are rising (金利圧力候補 / 中銀タカ派)
- Big banks poised to report booming revenue propelled by SpaceX IPO, Iran war volatility (地政学リスク / リスクオン要因 / 金安全資産需要 / リスクオフ要因)
- SpaceX’s stock threatens to fall below the IPO price. Do investors face a ‘crisis’ if it does? (リスクオフ要因)
- You don’t have to be rich to be financially independent. Here’s how to take control of your money. (リスクオフ要因)
- Micron and other chip stocks feel the pain of imported volatility — blame SK Hynix (リスクオフ要因)
- Binance.US CEO says exchange is rebuilding, eyes return to 20% U.S. market share (暗号資産流動性)
- Bitcoin panic-selling may be ending as sellers' profit margins disappear (暗号資産流動性)
- Profit-taking, MidEast hostilities drag crypto lower after bullish week (地政学リスク / 原油供給リスク / リスクオフ要因)
