# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-14 07:39:54 JST
取得日時（UTC）: 2026-07-13 22:39:54 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.36
headline件数: 73

## 見出し

- [CNBC Markets] Trump proposes 20% toll on cargo through Strait of Hormuz; restarts Iran blockade (WTI)
- [CNBC Markets] South Carolina governor taps Lindsey Graham's sister to serve as interim senator (未分類)
- [CNBC Markets] Judge says Trump sued IRS for 'improper purpose'; refers his lawyer to bar (未分類)
- [CNBC Markets] Trump to claim declassified intel reveals 2020 election interference: MS NOW (未分類)
- [CNBC Markets] Chipotle is opening its first restaurant in Mexico (NASDAQ)
- [CNBC Markets] UN maritime agency opposes Hormuz transit fees after Trump demands protection money (未分類)
- [CNBC Markets] Paramount, WBD hit with lawsuit from 12 states, including California, to block merger (未分類)
- [CNBC Markets] The 10 best state economies in America in 2026 (未分類)
- [CNBC Markets] The 10 worst state economies in America in 2026 (未分類)
- [CNBC Markets] Waller says Fed shouldn't 'fight the last war' on inflation but warns hikes still possible (US10Y|DXY)
- [CNBC Markets] 3 things you need to know about cyclospora (未分類)
- [CNBC Markets] Trump administration urges banks to scrutinize lending to immigrants without work authorization (US10Y|DXY)
- [CNBC Markets] SpaceX stock sinks for a second-straight day, nearing $135 IPO price (NASDAQ)
- [CNBC Markets] A July rate hike from the Fed? The odds are rising (WTI|US10Y|DXY)
- [CNBC Markets] Traders are betting on a comeback quarter for Netflix (BTC|SPX|NASDAQ)
- [CNBC Markets] Trump calls for Congress to pass Clarity Act crypto bill to honor Lindsey Graham (BTC)
- [CNBC Markets] A toxic stew drags stocks lower as we look at what can get the AI trade back on track (SPX)
- [CNBC Markets] Big banks poised to report booming revenue propelled by SpaceX IPO, Iran war volatility (SPX|VIX)
- [CNBC Markets] Meta's Louisiana data center investment to reach $50 billion, aided by generous tax incentives (未分類)
- [CNBC Markets] Kalshi launches 'Pro' product for users trading multiple markets at same time, perpetual futures (未分類)
- [CNBC Markets] Burnout, frustration and heartbreak: Amazon layoffs take their toll in saturated job market (未分類)
- [CNBC Markets] Graham’s death complicates myriad GOP goals in Congress (未分類)
- [CNBC Markets] Elon Musk and Sam Altman spar on X after Apple files OpenAI lawsuit (未分類)
- [CNBC Markets] AI is changing older workers' careers, research finds — here's how (未分類)
- [CNBC Markets] TSMC, the world's largest contract chipmaker, reports 68% surge in June revenue (SPX|NASDAQ)
- [CNBC Markets] McConnell provides health update after long unexplained absence; says he suffered fall, pneumonia (未分類)
- [CNBC Markets] Chinese EV makers are outpacing U.S. automakers in overseas investments (未分類)
- [CNBC Markets] Who will replace Lindsey Graham in the Senate? (未分類)
- [MarketWatch Top Stories] Why a borrowing binge by investors is a warning sign for the stock market (SPX)
- [MarketWatch Top Stories] SpaceX’s stock threatens to fall below the IPO price. Do investors face a ‘crisis’ if it does? (未分類)
- [MarketWatch Top Stories] The U.S. is maxing out its strategic oil reserves as Trump vows to control the Strait of Hormuz (WTI)
- [MarketWatch Top Stories] Sandisk’s stock is plunging, but some analysts are getting even more bullish (未分類)
- [MarketWatch Top Stories] Lindsey Graham died from a rare heart condition. Here’s how to know if you’re at risk. (未分類)
- [MarketWatch Top Stories] You don’t have to be rich to be financially independent. Here’s how to take control of your money. (未分類)
- [MarketWatch Top Stories] Stock pickers know they can’t outsmart the market. That doesn’t stop them from trying. (未分類)
- [MarketWatch Top Stories] Billionaires are loading up on these superior stocks. Why it pays to follow their money. (SPX)
- [MarketWatch Top Stories] Micron and other chip stocks feel the pain of imported volatility — blame SK Hynix (SPX|NASDAQ|VIX)
- [MarketWatch Top Stories] Global oil prices top $83 a barrel, logging biggest jump in 6 years after Trump reimposes Strait of Hormuz blockade (WTI)
- [CoinDesk] Binance.US CEO says exchange is rebuilding, eyes return to 20% U.S. market share (未分類)
- [CoinDesk] Franklin Crypto CIO says crypto prices are disconnected from fundamentals (BTC)
- [CoinDesk] TeraWulf CEO: 'Not All Megawatts Are Created Equally' in AI Race (BTC)
- [CoinDesk] Trump's crypto riches loom over Clarity Act talks to ban conflicts for U.S. officials (BTC)
- [CoinDesk] Mizuho says Circle bank approval doesn't solve USDC growth, stablecoin competition risks (未分類)
- [CoinDesk] Bitcoin panic-selling may be ending as sellers' profit margins disappear (BTC)
- [CoinDesk] Strategy pauses its Bitcoin buying spree to hoard a massive $3 billion cash cushion (BTC)
- [CoinDesk] Robinhood built a blockchain for tokenized stocks. Memecoins took over (SPX)
- [CoinDesk] Bolivia weighs adding Tether's USDT to its national payments system (BTC)
- [CoinDesk] UK Treasury report on tokenization cites Ripple as convergence model (US10Y|DXY)
- [CoinDesk] Tom Lee's BitMine ether holdings rise to 5.77 million tokens, or 4.8% of total supply (BTC|US10Y|DXY)
- [CoinDesk] Wall Street transfer agents lobby SEC, warning that third-party tokens pose risks to market integrity (SPX)
