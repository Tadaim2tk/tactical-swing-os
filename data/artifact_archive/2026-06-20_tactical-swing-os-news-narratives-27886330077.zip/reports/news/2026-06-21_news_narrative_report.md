# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-21 07:51:49 JST
生成日時（UTC）: 2026-06-20 22:51:49 UTC
headline件数: 61
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.29
ニュース市場バイアス: risk_off
ニュース矛盾スコア: 0.0
主要テーマ: risk_off, geopolitical_risk
日本語要約: リスクオフ要因、地政学リスクが優勢で、ニュース面では慎重姿勢が強い状態です。
ニュースモード: ニュースはリスクオフ寄り / 地政学リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 100.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 18.57
- gold_safe_haven_news_score: 55.72
- oil_supply_risk_news_score: 18.57
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 37.15
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 18.57
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Memory crisis hits such extremes that 'even Apple can't be safe' (リスクオフ要因)
- Massive bonuses for South Korea's chip workers puts central bank on inflation alert (インフレ圧力 / 金利圧力候補)
- Fedspeak vs. war deal: Here are the things that drove this week's stock market (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Russia threatens escalation after Ukraine hits Moscow with largest-ever drone attack (地政学リスク / リスクオフ要因)
- Why Japan's $70 billion-plus intervention and a rate hike didn't prop up the yen more (金利圧力候補 / 中銀タカ派)
- U.S. opens tariff probe targeting Germany’s drug pricing policies (インフレ圧力 / 金利圧力候補)
- U.S.-Iran deal in photos: ships in the Strait of Hormuz, daily life in Tehran (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
- Indian IT stocks slump up to 7% as Accenture cuts revenue outlook, fueling fresh concerns over sector growth (リスクオフ要因)
- Scared to spend your retirement money? Here’s one way to get over the fear of running out. (リスクオフ要因)
- Digital credit market hit by huge selloff as Strive CEO blames leverage liquidations (リスクオフ要因)
