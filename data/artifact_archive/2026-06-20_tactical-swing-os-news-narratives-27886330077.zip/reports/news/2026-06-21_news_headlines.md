# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-21 07:51:48 JST
取得日時（UTC）: 2026-06-20 22:51:48 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.29
headline件数: 61

## 見出し

- [CNBC Markets] Iran reportedly closes Strait of Hormuz again, casting shadow over nuclear talks (未分類)
- [CNBC Markets] AI buildout gives tech investors new reasons to watch bond market (NASDAQ|US10Y|DXY)
- [CNBC Markets] The budget airline model in the U.S. is running out of runway (未分類)
- [CNBC Markets] Bitcoin's future as revolutionary as the smartphone, according to CoinDesk (BTC)
- [CNBC Markets] SNAP restrictions could change what shoppers buy — and food giants are watching (未分類)
- [CNBC Markets] Musk's SpaceX stake is worth over $1 trillion. Here are the other billionaire shareholders (SPX)
- [CNBC Markets] Memory crisis hits such extremes that 'even Apple can't be safe' (未分類)
- [CNBC Markets] In photos: Star-studded crowd gathers to celebrate the Obama Presidential Center dedication (未分類)
- [CNBC Markets] 'Fun dads' get 5 things right about parenting that many people forget—'they're worth borrowing' this Father's Day, says expert (SPX)
- [CNBC Markets] DOJ rebuffs judge's request to put in writing it won't move forward with 'anti-weaponization' fund (未分類)
- [CNBC Markets] Massive bonuses for South Korea's chip workers puts central bank on inflation alert (NASDAQ)
- [CNBC Markets] Fedspeak vs. war deal: Here are the things that drove this week's stock market (SPX|US10Y|DXY)
- [CNBC Markets] The riskiest SpaceX stock trade of all had a big first week (BTC)
- [CNBC Markets] NetJets' first fatal crash kills influential Texas VC founder (NASDAQ)
- [CNBC Markets] Struggling to find a job? Try looking in Nevada (未分類)
- [CNBC Markets] Bob Iger reflects on 10 years of Shanghai Disneyland as it defies the Chinese pullback (未分類)
- [CNBC Markets] Homeowners tapped $47 billion in equity in the first quarter. What to consider before you borrow (未分類)
- [CNBC Markets] Russia threatens escalation after Ukraine hits Moscow with largest-ever drone attack (未分類)
- [CNBC Markets] India's largest telecom and digital service Jio Platforms files for IPO (未分類)
- [CNBC Markets] Jio Platforms eyes low-orbit satellite rollout as Starlink awaits India launch (未分類)
- [CNBC Markets] Why Japan's $70 billion-plus intervention and a rate hike didn't prop up the yen more (USDJPY)
- [CNBC Markets] U.S. opens tariff probe targeting Germany’s drug pricing policies (未分類)
- [CNBC Markets] 29-year-old making $250k in tech went 'undercover' at a coffee chain before opening her own matcha cafe (NASDAQ)
- [CNBC Markets] UK gilt yields jump as borrowing rises and PM Starmer faces leadership challenge (US10Y|DXY)
- [CNBC Markets] What this biotech's volatile stock price tells you about the weight loss market right now (NASDAQ)
- [CNBC Markets] U.S.-Iran deal in photos: ships in the Strait of Hormuz, daily life in Tehran (未分類)
- [CNBC Markets] Yen slides past 161 against the dollar, nearing 40-year low and reviving intervention bets (USDJPY|DXY)
- [CNBC Markets] Indian IT stocks slump up to 7% as Accenture cuts revenue outlook, fueling fresh concerns over sector growth (SPX)
- [CNBC Markets] MSCI isn't done with Indonesia yet: new report signals continued concerns over market transparency (未分類)
- [MarketWatch Top Stories] ‘Money can make you happy’: My wife and I have no heirs, but we’re making the world a better place by giving it away (未分類)
- [MarketWatch Top Stories] Scared to spend your retirement money? Here’s one way to get over the fear of running out. (VIX)
- [MarketWatch Top Stories] You’re going to pay tax on RMDs — there’s no way around it. Or is there? (未分類)
- [MarketWatch Top Stories] Social Security is looking at a $500-a-month cut. Could a new bipartisan commission make a difference? (未分類)
- [MarketWatch Top Stories] Inside the push to weaken Washington’s toughest financial watchdog (未分類)
- [MarketWatch Top Stories] We read the Social Security and Medicare trustees reports. If you’re not worried, you should be. (未分類)
- [MarketWatch Top Stories] Want to splurge on travel in retirement? Here’s how to plan for it. (未分類)
- [MarketWatch Top Stories] I’m 73 and living 100% off dividends from my stocks. How can I create even more income? (SPX)
- [MarketWatch Top Stories] The one-page pledge that forces your financial adviser to put you first (未分類)
- [MarketWatch Top Stories] Three powerful forces are draining family wealth — and your estate plan is completely unprepared (未分類)
- [CoinDesk] AI is making crypto security cheaper, faster and harder to ignore (BTC)
- [CoinDesk] How STRC lost its par: The timeline behind Strategy's preferred-stock meltdown (BTC|US10Y)
- [CoinDesk] Schwab to join prediction markets race with S&P 500 event-based options: WSJ (BTC|SPX)
- [CoinDesk] GoMining challenges Jack Dorsey's Square with payments system designed around bitcoin (BTC)
- [CoinDesk] Franklin Templeton proposes new ETFs that turn corporate dividends into bitcoin (BTC)
- [CoinDesk] Smart-contract and DeFi coins lead losses as bitcoin wilts for 4th straight day (BTC)
- [CoinDesk] Digital credit market hit by huge selloff as Strive CEO blames leverage liquidations (VIX)
- [CoinDesk] Microsoft found malware that hijacks crypto wallets and spreads through USB sticks (BTC)
- [CoinDesk] XRP falls 3% after losing $1.15 support as breakout attempt fades (未分類)
- [CoinDesk] Live markets: Bitcoin under pressure as Saylor comments on STRC selloff (BTC|VIX)
- [CoinDesk] Bitcoin traders load up on bearish bets all the way down to $52,000 (BTC|VIX)
