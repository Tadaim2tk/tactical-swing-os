# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-19 08:55:50 JST
生成日時（UTC）: 2026-06-18 23:55:50 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.84
ニュース市場バイアス: neutral
ニュース矛盾スコア: 19.17
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立

## スコア

- risk_on_news_score: 19.17
- risk_off_news_score: 19.17
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 19.17
- oil_supply_risk_news_score: 19.17
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 0.0
- inflation_pressure_news_score: 57.5
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Japan core inflation holds steady in May, matching expectations despite energy price concerns (インフレ圧力 / 金利圧力候補)
- Markets are set for a much more hawkish Warsh Fed than expected (インフレ圧力 / 金利圧力候補)
- OPEC chief dismisses IEA supply glut forecast as 'critical' Strait of Hormuz reopens (原油供給リスク / 金安全資産需要)
- Wall Street recovers from Fed slump, and the next step for Amazon's AI chip ambitions (リスクオフ要因)
- Intel gains 10% after Trump says company will partner with Apple on U.S. chip design (リスクオン要因)
- Women have better retirement savings habits but lower 401(k) balances than men, Vanguard finds (インフレ圧力 / 金利圧力候補)
