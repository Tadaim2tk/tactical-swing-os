# Portfolio Layer

## 1. 概要

- 生成日時JST: 2026-06-19 08:56:19 JST
- portfolio_status: active
- candidate assets: 2
- defensive assets: 1
- offensive assets: 0
- cash candidate: 0.5433
- average confidence: 0.5403
- portfolio concentration: 0.24
- risk concentration: 0.0
- recommended exposure: 0.4567
- recommended next action: human_review_allocations
- requires_human_approval: true
- weights_json_updated: false
- patch_applied: false
- generate_signal_updated: false
- orders_created: false

## 2. Top Allocation Candidates

| asset | allocation_score | portfolio_weight_candidate | confidence | risk_class | risk_role | latest_rank | latest_side | rationale |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| USDJPY | 60.7 | 0.24 | 0.4967 | medium | balanced |  |  | signal data unavailable; evaluation avg_r=1.09 win_rate=1.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| GOLD | 54.81 | 0.2167 | 0.58 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=0.35 win_rate=1.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| BTC | 36.56 | 0.0 | 0.5633 | high | offensive |  |  | signal data unavailable; evaluation avg_r=-0.43 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| WTI | 41.88 | 0.0 | 0.63 | high | offensive |  |  | signal data unavailable; evaluation avg_r=0.24 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| NASDAQ | 41.14 | 0.0 | 0.58 | high | offensive |  |  | signal data unavailable; evaluation avg_r=0.14 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| ETH | 40.0 | 0.0 | 0.35 | high | offensive |  |  | signal data unavailable; evaluation rows unavailable; meta learning unavailable; auto calibration rows=0; human override rows=0; proposal impact unavailable; market snapshot unavailable |
| SPX | 40.33 | 0.0 | 0.58 | medium | offensive |  |  | signal data unavailable; evaluation avg_r=0.04 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| VIX | 40.16 | 0.0 | 0.5467 | high | defensive |  |  | signal data unavailable; evaluation avg_r=0.02 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| DXY | 38.27 | 0.0 | 0.5467 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=-0.22 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| US10Y | 34.78 | 0.0 | 0.53 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=-0.65 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |

## 3. Risk Concentration

- high risk weight candidate: 0.0
- portfolio concentration: 0.24
- cash ratio candidate: 0.5433

## 4. 注意事項

- Portfolio Layerは配分候補を生成するだけです
- 自動売買・自動発注・自動リバランスは行いません
- weights.jsonは更新しません
- generate_signal.pyは変更しません
- Google Sheetsへの書き込みは行いません
- すべての候補は人間承認が必須です
