# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-28 07:44:59 JST
生成日時（UTC）: 2026-06-27 22:44:59 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.14
ニュース市場バイアス: neutral
ニュース矛盾スコア: 36.93
主要テーマ: inflation_pressure
日本語要約: インフレ圧力はありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 金利圧力材料あり / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 36.93
- risk_off_news_score: 55.4
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 36.93
- gold_safe_haven_news_score: 18.47
- oil_supply_risk_news_score: 36.93
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 55.4
- inflation_pressure_news_score: 100.0
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 18.47
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- The memory shortage shaking Apple and Microsoft is 'existential crisis' for smaller players (リスクオフ要因)
- U.S. military attacks Iranian targets after commercial tanker hit in the Strait of Hormuz (原油供給リスク)
- Why investors may want to prioritize bond markets outside the U.S. (インフレ圧力 / 金利圧力候補)
- Trading in these two ETFs suggests inflation fears are overblown (インフレ圧力 / 金利圧力候補)
- The AI trade cooled and oil sank. A closer look at Wall Street's volatile week (インフレ圧力 / 金利圧力候補)
- U.S. crude oil falls below $70, resuming losses after attack on cargo ship near Oman (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
- Trump eases pressure on Fed Chairman Kevin Warsh as inflation tops 4% (インフレ圧力 / 金利圧力候補)
- Trump threatens 100% tariffs on countries putting 'Digital Services Tax on American Companies' (インフレ圧力 / 金利圧力候補)
- Minneapolis Fed President Neel Kashkari says he expects a rate hike this year (インフレ圧力 / 金利圧力候補 / 中銀タカ派)
- This disease is more expensive than cancer and heart disease combined. And it’s only going to get worse. (リスクオフ要因)
