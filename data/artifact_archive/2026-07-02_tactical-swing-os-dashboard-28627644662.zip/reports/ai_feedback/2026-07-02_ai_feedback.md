# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-07-03 08:18:17 JST
Actions実行時刻（UTC）: 2026-07-02 23:18:17 UTC
対象日: 2026-07-02
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立
- ニュースモード: ニュースのリスク方向は中立
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 41.6
- risk_off: 34.01
- dollar: 34.86
- rate: 34.78
- volatility: 48.21
- news_confidence: 86.0
- シグナル整合性: aligned=0, conflicted=1, neutral=8, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 41.6 | 34.01 | 34.86 | 34.78 | 33.93 | 35.85 | 48.21 | 92.78 |
| DXY | 51.21 | 48.59 | 49.8 | 49.69 | 48.47 | 51.22 | 48.21 | 92.78 |
| GOLD | 51.21 | 48.59 | 49.8 | 49.69 | 48.47 | 51.22 | 48.21 | 92.78 |
| NASDAQ | 51.21 | 48.59 | 49.8 | 49.69 | 48.47 | 51.22 | 48.21 | 92.78 |
| SPX | 51.21 | 48.59 | 49.8 | 49.69 | 48.47 | 51.22 | 48.21 | 92.78 |
| US10Y | 51.21 | 48.59 | 49.8 | 49.69 | 48.47 | 51.22 | 48.21 | 92.78 |
| USDJPY | 51.21 | 48.59 | 49.8 | 49.69 | 48.47 | 51.22 | 48.21 | 92.78 |
| VIX | 51.21 | 48.59 | 49.8 | 49.69 | 48.47 | 51.22 | 48.21 | 92.78 |
| WTI | 51.21 | 48.59 | 49.8 | 49.69 | 48.47 | 51.22 | 48.21 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260702_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260702_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260702_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260702_GOLD_NONE_NO_TRADE | GOLD | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260702_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | NO_TRADE | momentum_negative|atr_too_high|rr_too_low|range_middle|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260702_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_negative|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260702_US10Y_LONG_A-Pullback | US10Y | LONG | B | WATCH | trend_up|ma_alignment_bull|momentum_negative|pullback_to_ma20 | conflicted | -15 | US10Yは金利上昇圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260702_VIX_NONE_NO_TRADE | VIX | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low|overextended | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260702_WTI_SHORT_B-Watch | WTI | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold | neutral | -3 | WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立
- top_news_drivers: Trump bought Apple, Nvidia and other tech giants before tariff reversal fueled rebound

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-07-02T23:18:17,2026-07-03 08:18:17 JST,2026-07-02 23:18:17 UTC,2026-07-02,USDJPY,20260702_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,41.6,34.01,34.86,34.78,33.93,35.85,48.21,92.78,86.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-02T23:18:17,2026-07-03 08:18:17 JST,2026-07-02 23:18:17 UTC,2026-07-02,BTC,20260702_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rr_too_low,neutral,0,41.6,34.01,34.86,34.78,33.93,35.85,48.21,92.78,86.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-02T23:18:17,2026-07-03 08:18:17 JST,2026-07-02 23:18:17 UTC,2026-07-02,DXY,20260702_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rr_too_low,neutral,0,41.6,34.01,34.86,34.78,33.93,35.85,48.21,92.78,86.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-02T23:18:17,2026-07-03 08:18:17 JST,2026-07-02 23:18:17 UTC,2026-07-02,GOLD,20260702_GOLD_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rr_too_low,neutral,0,41.6,34.01,34.86,34.78,33.93,35.85,48.21,92.78,86.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,GOLD NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-02T23:18:17,2026-07-03 08:18:17 JST,2026-07-02 23:18:17 UTC,2026-07-02,NASDAQ,20260702_NASDAQ_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|atr_too_high|rr_too_low|range_middle|pullback_to_ma20,neutral,0,41.6,34.01,34.86,34.78,33.93,35.85,48.21,92.78,86.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,NASDAQ NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-02T23:18:17,2026-07-03 08:18:17 JST,2026-07-02 23:18:17 UTC,2026-07-02,SPX,20260702_SPX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_negative|rr_too_low,neutral,0,41.6,34.01,34.86,34.78,33.93,35.85,48.21,92.78,86.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,SPX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-02T23:18:17,2026-07-03 08:18:17 JST,2026-07-02 23:18:17 UTC,2026-07-02,US10Y,20260702_US10Y_LONG_A-Pullback,LONG,B,WATCH,trend_up|ma_alignment_bull|momentum_negative|pullback_to_ma20,conflicted,-15,41.6,34.01,34.86,34.78,33.93,35.85,48.21,92.78,86.0,market_proxy_plus_news,,,context_warning,US10Yは金利上昇圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,US10Y LONG は市場文脈と衝突。明日はrank/entry条件を慎重化する仮説。,False,sheets_evaluations,False,True
2026-07-02T23:18:17,2026-07-03 08:18:17 JST,2026-07-02 23:18:17 UTC,2026-07-02,VIX,20260702_VIX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low|overextended,neutral,0,41.6,34.01,34.86,34.78,33.93,35.85,48.21,92.78,86.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,VIX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-02T23:18:17,2026-07-03 08:18:17 JST,2026-07-02 23:18:17 UTC,2026-07-02,WTI,20260702_WTI_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold,neutral,-3,41.6,34.01,34.86,34.78,33.93,35.85,48.21,92.78,86.0,market_proxy_plus_news,,,context_neutral,WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,WTI SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-07-02T23:18:17",
  "generated_at_jst": "2026-07-03 08:18:17 JST",
  "generated_at_utc": "2026-07-02 23:18:17 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-07-02",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立",
  "top_news_drivers": [
    {
      "title": "Trump bought Apple, Nvidia and other tech giants before tariff reversal fueled rebound",
      "source": "CNBC Markets",
      "matched_assets": "NASDAQ",
      "matched_rules": "risk_on_news_score:rebound|inflation_pressure_news_score:tariff",
      "driver_tags": "risk_on|inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / リスクオン要因 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/07/02/trump-aapl-nvda-tariffs-disclosures.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 41.6,
      "risk_off_score": 34.01,
      "dollar_strength_score": 34.86,
      "rate_pressure_score": 34.78,
      "gold_safe_haven_score": 33.93,
      "oil_supply_risk_proxy_score": 35.06,
      "crypto_liquidity_score": 35.85,
      "equity_momentum_score": 36.06,
      "volatility_stress_score": 48.21,
      "narrative_confidence": 92.78,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 19.17,
      "risk_off_news_score": 0.0,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 0.0,
      "oil_supply_risk_news_score": 0.0,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 0.0,
      "inflation_pressure_news_score": 19.17,
      "recession_risk_news_score": 0.0,
      "news_confidence": 86.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 51.21,
      "risk_off_score": 48.59,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.69,
      "gold_safe_haven_score": 48.47,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.22,
      "equity_momentum_score": 51.52,
      "volatility_stress_score": 48.21,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.5463,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 51.21,
      "risk_off_score": 48.59,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.69,
      "gold_safe_haven_score": 48.47,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.22,
      "equity_momentum_score": 51.52,
      "volatility_stress_score": 48.21,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0483,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 51.21,
      "risk_off_score": 48.59,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.69,
      "gold_safe_haven_score": 48.47,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.22,
      "equity_momentum_score": 51.52,
      "volatility_stress_score": 48.21,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1733,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 51.21,
      "risk_off_score": 48.59,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.69,
      "gold_safe_haven_score": 48.47,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.22,
      "equity_momentum_score": 51.52,
      "volatility_stress_score": 48.21,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1495,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 51.21,
      "risk_off_score": 48.59,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.69,
      "gold_safe_haven_score": 48.47,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.22,
      "equity_momentum_score": 51.52,
      "volatility_stress_score": 48.21,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.3997,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 51.21,
      "risk_off_score": 48.59,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.69,
      "gold_safe_haven_score": 48.47,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.22,
      "equity_momentum_score": 51.52,
      "volatility_stress_score": 48.21,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0197,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 51.21,
      "risk_off_score": 48.59,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.69,
      "gold_safe_haven_score": 48.47,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.22,
      "equity_momentum_score": 51.52,
      "volatility_stress_score": 48.21,
      "narrative_confidence": 92.78,
      "asset_change_pct": -5.2786,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 51.21,
      "risk_off_score": 48.59,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.69,
      "gold_safe_haven_score": 48.47,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.22,
      "equity_momentum_score": 51.52,
      "volatility_stress_score": 48.21,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1023,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260702_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260702_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260702_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260702_GOLD_NONE_NO_TRADE",
      "asset": "GOLD",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260702_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|atr_too_high|rr_too_low|range_middle|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260702_SPX_NONE_NO_TRADE",
      "asset": "SPX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_negative|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260702_US10Y_LONG_A-Pullback",
      "asset": "US10Y",
      "side": "LONG",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_negative|pullback_to_ma20",
      "narrative_alignment": "conflicted",
      "narrative_alignment_score": -15,
      "narrative_comment": "US10Yは金利上昇圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260702_VIX_NONE_NO_TRADE",
      "asset": "VIX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260702_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": -3,
      "narrative_comment": "WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
