# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-08 08:14:00 JST
Actions実行時刻（UTC）: 2026-06-07 23:14:00 UTC
対象日: 2026-06-07
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティ警戒 / ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 38.33
- ナラティブ入力: market_proxy_plus_news
- risk_on: 42.09
- risk_off: 58.11
- dollar: 35.05
- rate: 35.64
- volatility: 60.76
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=1, neutral=6, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 42.09 | 58.11 | 35.05 | 35.64 | 66.43 | 30.79 | 60.76 | 100.0 |
| BTC | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| DXY | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| GOLD | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| NASDAQ | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| SPX | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| US10Y | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| USDJPY | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| VIX | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| WTI | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260607_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260607_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative | conflicted | -54 | GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260607_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260607_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260607_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260607_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- VIX上昇中の株価指数LONGは慎重化し、entry条件を厳格化する候補。
- ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり
- top_news_drivers: Fragile ceasefire in jeopardy as Iran reportedly fires missiles at Israel, Inflation inside the electronics you buy may soon become a bit more sticky, U.S. confirms second Texas screwworm case, Canada restricts livestock imports, U.S. stock futures dip, oil prices surge as new attacks threaten the cease-fire with Iran, S&P 500 sees $1.8 trillion wipeout, Nasdaq tallies biggest point drop on record: What investors need to know about Friday’s selloff

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically
2026-06-07T23:14:00,2026-06-08 08:14:00 JST,2026-06-07 23:14:00 UTC,2026-06-07,BTC,20260607_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low,neutral,0,42.09,58.11,35.05,35.64,66.43,30.79,60.76,100.0,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False
2026-06-07T23:14:00,2026-06-08 08:14:00 JST,2026-06-07 23:14:00 UTC,2026-06-07,DXY,20260607_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low,neutral,0,42.09,58.11,35.05,35.64,66.43,30.79,60.76,100.0,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False
2026-06-07T23:14:00,2026-06-08 08:14:00 JST,2026-06-07 23:14:00 UTC,2026-06-07,GOLD,20260607_GOLD_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative,conflicted,-54,42.09,58.11,35.05,35.64,66.43,30.79,60.76,100.0,100.0,market_proxy_plus_news,,,context_warning,GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,GOLD SHORT は市場文脈と衝突。明日はrank/entry条件を慎重化する仮説。,False
2026-06-07T23:14:00,2026-06-08 08:14:00 JST,2026-06-07 23:14:00 UTC,2026-06-07,NASDAQ,20260607_NASDAQ_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low,neutral,0,42.09,58.11,35.05,35.64,66.43,30.79,60.76,100.0,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,NASDAQ NONE は中立。テクニカル優先だが、文脈変化を監視。,False
2026-06-07T23:14:00,2026-06-08 08:14:00 JST,2026-06-07 23:14:00 UTC,2026-06-07,SPX,20260607_SPX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low,neutral,0,42.09,58.11,35.05,35.64,66.43,30.79,60.76,100.0,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,SPX NONE は中立。テクニカル優先だが、文脈変化を監視。,False
2026-06-07T23:14:00,2026-06-08 08:14:00 JST,2026-06-07 23:14:00 UTC,2026-06-07,USDJPY,20260607_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low,neutral,0,42.09,58.11,35.05,35.64,66.43,30.79,60.76,100.0,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False
2026-06-07T23:14:00,2026-06-08 08:14:00 JST,2026-06-07 23:14:00 UTC,2026-06-07,WTI,20260607_WTI_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low,neutral,0,42.09,58.11,35.05,35.64,66.43,30.79,60.76,100.0,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,WTI NONE は中立。テクニカル優先だが、文脈変化を監視。,False

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-07T23:14:00",
  "generated_at_jst": "2026-06-08 08:14:00 JST",
  "generated_at_utc": "2026-06-07 23:14:00 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-07",
  "data_source": "Google Sheets",
  "market_mode_summary": "リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティ警戒 / ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "top_news_drivers": [
    {
      "title": "Fragile ceasefire in jeopardy as Iran reportedly fires missiles at Israel",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "geopolitical_risk_news_score:missile",
      "driver_tags": "geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/07/iran-fires-missiles-israel-ceasefire-strains.html"
    },
    {
      "title": "Inflation inside the electronics you buy may soon become a bit more sticky",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "inflation_pressure_news_score:inflation",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/06/07/inflation-iran-war-consumer-economy-electronics.html"
    },
    {
      "title": "U.S. confirms second Texas screwworm case, Canada restricts livestock imports",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/06/us-confirms-second-texas-screwworm-case.html"
    },
    {
      "title": "U.S. stock futures dip, oil prices surge as new attacks threaten the cease-fire with Iran",
      "source": "MarketWatch Top Stories",
      "matched_assets": "WTI|SPX|NASDAQ|VIX",
      "matched_rules": "risk_on_news_score:rally|risk_off_news_score:selloff|gold_safe_haven_news_score:war|geopolitical_risk_news_score:war|geopolitical_risk_news_score:attack",
      "driver_tags": "risk_on|risk_off|gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオフ要因 / リスクオン要因",
      "link": "https://www.marketwatch.com/story/u-s-stock-futures-slide-oil-prices-surge-as-new-attacks-threaten-the-cease-fire-with-iran-6e433c90?mod=mw_rss_topstories"
    },
    {
      "title": "S&P 500 sees $1.8 trillion wipeout, Nasdaq tallies biggest point drop on record: What investors need to know about Friday’s selloff",
      "source": "MarketWatch Top Stories",
      "matched_assets": "SPX|NASDAQ|VIX",
      "matched_rules": "risk_off_news_score:selloff",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.marketwatch.com/story/s-p-500-sees-1-8-trillion-wipeout-nasdaq-tallies-biggest-point-drop-on-record-heres-what-investors-need-to-know-about-fridays-selloff-4eb7b490?mod=mw_rss_topstories"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 42.09,
      "risk_off_score": 58.11,
      "dollar_strength_score": 35.05,
      "rate_pressure_score": 35.64,
      "gold_safe_haven_score": 66.43,
      "oil_supply_risk_proxy_score": 34.98,
      "crypto_liquidity_score": 30.79,
      "equity_momentum_score": 28.55,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 38.33,
      "risk_off_news_score": 57.5,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 57.5,
      "oil_supply_risk_news_score": 0.0,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 100.0,
      "inflation_pressure_news_score": 19.17,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "BTC",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": 3.6038,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "DXY",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.002,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.1057,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.4663,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.2579,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": 1.5447,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.1412,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": 35.5388,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.043,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260607_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260607_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260607_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative",
      "narrative_alignment": "conflicted",
      "narrative_alignment_score": -54,
      "narrative_comment": "GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260607_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260607_SPX_NONE_NO_TRADE",
      "asset": "SPX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260607_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260607_WTI_NONE_NO_TRADE",
      "asset": "WTI",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "VIX上昇中の株価指数LONGは慎重化し、entry条件を厳格化する候補。",
    "ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
