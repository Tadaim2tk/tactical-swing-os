# Shadow Weight Impact（週次昇格判断の材料）

## 1. 概要

- 生成日時JST: 2026-07-09 15:22:55 JST
- weights_status: **approved** / version: v0-identity
- identity weights: true
- 本日のシグナル数: 9（actionable: 1）
- rank変化: 0 / action変化: 0
- |Δstrength| 平均: 0.0 / 最大: 0.0
- 再構成不一致（recon_base_rank != base_rank）: 0

現在の approved weights は **identity（全1.0）ベースライン**。weighted == base が構成上成立し、差分ゼロが正常。実差分の比較を始めるには、非identityの候補weightsを人間承認PRで models/approved_weights.json に昇格させる。

## 2. 昇格判断の材料

- 累積比較数（actionable, version=v0-identity）: **12 / 30**
- 昇格判断に足るサンプル: **未到達**
- 統計ゲート判定: **blocked**
    - insufficient_comparisons: 12 < 30
  - insufficient_outcome_samples: 8 < 30
  - zero_difference: base と weighted の結果に差が無く、weights 変更を正当化できない
- ゲート仕様: n>=30 / t検定 p<=0.05 かつ平均R差>0 /
  DSR>=0.95（SPEC-SG-001 / SPEC-DSR-001 と同一の統計基準）。
  **単発観測・小標本の後知恵では weights を動かせない。**
- 昇格の手続き: ゲート通過後も自動適用はない。候補weightsを `models/approved_weights.json` に反映し
  `models/weight_versions/` にスナップショットを置く**人間承認PR**を出す。
  実推奨（active）への反映はさらに別の人間承認PRが必要。

## 3. 本日の差分（rank変化 or |Δstrength|>0、上位20件）

_差分なし_

## 4. 安全条件

- これは shadow 記録であり、実推奨（results/signals.csv の既存列）には影響しない。
- affects_live_recommendation=false / weights_json_updated=false / patch_applied=false。
- 実売買・発注・XM/証券会社操作は行わない。昇格判断は人間が行う。
