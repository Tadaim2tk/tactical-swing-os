# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-20 07:39:39 JST
生成日時（UTC）: 2026-06-19 22:39:39 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.68
ニュース市場バイアス: risk_off
ニュース矛盾スコア: 0.0
主要テーマ: geopolitical_risk, risk_off, gold_safe_haven, inflation_pressure
日本語要約: 地政学リスク、リスクオフ要因、金安全資産需要が優勢で、ニュース面では慎重姿勢が強い状態です。
ニュースモード: ニュースはリスクオフ寄り / 金利圧力材料あり / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 92.33
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 36.93
- gold_safe_haven_news_score: 92.33
- oil_supply_risk_news_score: 36.93
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 73.87
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 18.47
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Oil tanker traffic in Strait of Hormuz jumps after U.S. and Iran implement deal to open sea lane (原油供給リスク)
- Memory crisis hits such extremes that 'even Apple can't be safe' (リスクオフ要因)
- Trump claims Iran deal is 'unconditional surrender,' says his power has 'no limits': Axios (金安全資産需要)
- Russia threatens escalation after Ukraine hits Moscow with largest-ever drone attack (地政学リスク / リスクオフ要因)
- Hormuz relief may not ease the economic toll that's already 'baked in,' analysts warn (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Fedspeak vs. war deal: Here are the things that drove this week's stock market (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Why Japan's $70 billion-plus intervention and a rate hike didn't prop up the yen more (金利圧力候補 / 中銀タカ派)
- U.S. opens tariff probe targeting Germany’s drug pricing policies (インフレ圧力 / 金利圧力候補)
- U.S.-Iran deal in photos: ships in the Strait of Hormuz, daily life in Tehran (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
- Indian IT stocks slump up to 7% as Accenture cuts revenue outlook, fueling fresh concerns over sector growth (リスクオフ要因)
