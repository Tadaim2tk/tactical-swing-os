# Tactical Swing OS Monthly Calibration

## 1. 月次結論

翌月モードは「通常」、最大日次リスクは 0.5% です。データ不足。

## 2. 月次サマリー

| month_start | month_end | total_signals | closed_signals | pending_signals | skipped_signals | win_rate | profit_factor | total_r | average_r | max_win_r | max_loss_r | best_asset | worst_asset | best_rank | worst_rank | best_side | worst_side | next_month_mode | max_daily_risk_pct | weight_change_summary | rule_change_1 | rule_change_2 | rule_change_3 | evaluation_source | latest_evaluations_available | fallback_used |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-05-17 | 2026-06-15 | 81 | 5 | 16 | 5 | 0.2 | 0.2717 | -2.913 | -0.5826 | 1.087 | -1.0 | GOLD | BTC | A | B | SHORT | LONG | 通常 | 0.5 | 変更提案なし | closed評価10件未満のため自動適用しない | Entry/SL/Rank判定の見直し | データ不足 | latest_evaluations | True | False |

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 3. 資産別較正

| asset | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BTC | 11 | 1 | 0.0 | -1.0 | -1.0 | -1.0 | 0.99 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=1 < 30) |
| DXY | 9 | 1 | 0.0 | -1.0 | -1.0 | -1.0 | 0.99 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=1 < 30) |
| GOLD | 10 | 1 | 1.0 | 1.087 | 1.087 | 1.087 | 0.99 | False | 1.087 | 1.087 | 0.0 | データ不足 (n=1 < 30) |
| NASDAQ | 9 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| SPX | 9 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| US10Y | 8 | 1 | 0.0 | -1.0 | -1.0 | -1.0 | 0.98 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=1 < 30) |
| USDJPY | 10 | 1 | 0.0 | -1.0 | -1.0 | -1.0 | 1.0 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=1 < 30) |
| VIX | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| WTI | 9 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

## 4. Rank別較正

| rank | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| B | 25 | 5 | 0.2 | -2.913 | -0.5826 | -0.582 | 4.95 | False | 1.087 | -1.0 | 0.0 | データ不足 (n=5 < 30) |
| NO_TRADE | 56 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

## 5. Side別較正

| side | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| LONG | 11 | 3 | 0.0 | -3.0 | -1.0 | -1.0 | 2.97 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=3 < 30) |
| SHORT | 14 | 2 | 0.5 | 0.087 | 0.0435 | 0.0435 | 1.98 | False | 1.087 | -1.0 | 0.0 | データ不足 (n=2 < 30) |
| NONE | 56 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

## 6. レジーム別較正 (SPEC-RD-001)

| regime | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| UPTREND | 27 | 3 | 0.0 | -3.0 | -1.0 | -1.0 | 2.97 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=3 < 30) |
| DOWNTREND | 30 | 2 | 0.5 | 0.087 | 0.0435 | 0.0435 | 1.98 | False | 1.087 | -1.0 | 0.0 | データ不足 (n=2 < 30) |
| RANGE | 24 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| UNKNOWN | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

- decayed_avg_r: 半減期90日の指数減衰加重平均R(直近の成績ほど重い)
- effective_n: 減衰後の実効サンプル数
- decay_divergence: True = 全期間平均と直近加重平均の符号が逆。レジームシフトの兆候として人間が確認すること

decay_divergenceは検出されていません。

## 7. ナラティブ信頼性 (SPEC-NQ-001)

| narrative_alignment | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| aligned | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| conflicted | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| neutral | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| insufficient_data | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

- 整合判定はシグナル発生時点に記録された値のみを使用(追記専用・後知恵バイアス防止)
- 重み変更提案はSPEC-SG-001と同一ゲート(n>=30, p<0.05, 増加はSharpe>0.5)に従う

ナラティブ優位性検定: データ不足 (aligned n=0, conflicted n=0, 必要数: 各30)。判定保留。

## 8. 翌月の暫定モード

- next_month_mode: 通常
- max_daily_risk_pct: 0.5

## 9. 重み変更案

変更提案なし

## 10. 据え置き理由

weights.jsonは初期値のまま据え置きます。今回の出力は提案のみで、自動更新は行いません。

## 11. データ不足の注意

closed評価が30件未満、または統計的有意性(p < 0.05)が確認できない区分には、重み変更を提案しません。weights.jsonの自動適用は引き続き行いません。(SPEC-SG-001)

## 12. Reason Code較正メモ

reason_code分析は未生成です。別artifact生成後に月次較正メモへ反映されます。

### strong_positive reason_codes

_該当なし_

### strong_negative reason_codes

_該当なし_

## 13. MONTHLY_CALIBRATION_LOG CSV

```csv
month_start,month_end,total_signals,closed_signals,pending_signals,skipped_signals,win_rate,profit_factor,total_r,average_r,max_win_r,max_loss_r,best_asset,worst_asset,best_rank,worst_rank,best_side,worst_side,next_month_mode,max_daily_risk_pct,weight_change_summary,rule_change_1,rule_change_2,rule_change_3,evaluation_source,latest_evaluations_available,fallback_used
2026-05-17,2026-06-15,81,5,16,5,0.2,0.2717,-2.913,-0.5826,1.087,-1.0,GOLD,BTC,A,B,SHORT,LONG,通常,0.5,変更提案なし,closed評価10件未満のため自動適用しない,Entry/SL/Rank判定の見直し,データ不足,latest_evaluations,True,False
```

## 14. MONTHLY_CALIBRATION_LOG JSON

```json
[
  {
    "month_start": "2026-05-17",
    "month_end": "2026-06-15",
    "total_signals": 81,
    "closed_signals": 5,
    "pending_signals": 16,
    "skipped_signals": 5,
    "win_rate": 0.2,
    "profit_factor": 0.2717,
    "total_r": -2.913,
    "average_r": -0.5826,
    "max_win_r": 1.087,
    "max_loss_r": -1.0,
    "best_asset": "GOLD",
    "worst_asset": "BTC",
    "best_rank": "A",
    "worst_rank": "B",
    "best_side": "SHORT",
    "worst_side": "LONG",
    "next_month_mode": "通常",
    "max_daily_risk_pct": 0.5,
    "weight_change_summary": "変更提案なし",
    "rule_change_1": "closed評価10件未満のため自動適用しない",
    "rule_change_2": "Entry/SL/Rank判定の見直し",
    "rule_change_3": "データ不足",
    "evaluation_source": "latest_evaluations",
    "latest_evaluations_available": true,
    "fallback_used": false,
    "asset_calibration": [
      {
        "asset": "BTC",
        "signals": 11,
        "closed": 1,
        "win_rate": 0.0,
        "total_r": -1.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 0.99,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "asset": "DXY",
        "signals": 9,
        "closed": 1,
        "win_rate": 0.0,
        "total_r": -1.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 0.99,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "asset": "GOLD",
        "signals": 10,
        "closed": 1,
        "win_rate": 1.0,
        "total_r": 1.087,
        "average_r": 1.087,
        "decayed_avg_r": 1.087,
        "effective_n": 0.99,
        "decay_divergence": false,
        "best_r": 1.087,
        "worst_r": 1.087,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "asset": "NASDAQ",
        "signals": 9,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "SPX",
        "signals": 9,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "US10Y",
        "signals": 8,
        "closed": 1,
        "win_rate": 0.0,
        "total_r": -1.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 0.98,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "asset": "USDJPY",
        "signals": 10,
        "closed": 1,
        "win_rate": 0.0,
        "total_r": -1.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 1.0,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "asset": "VIX",
        "signals": 6,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "WTI",
        "signals": 9,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "rank_calibration": [
      {
        "rank": "A",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "rank": "B",
        "signals": 25,
        "closed": 5,
        "win_rate": 0.2,
        "total_r": -2.913,
        "average_r": -0.5826,
        "decayed_avg_r": -0.582,
        "effective_n": 4.95,
        "decay_divergence": false,
        "best_r": 1.087,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=5 < 30)"
      },
      {
        "rank": "NO_TRADE",
        "signals": 56,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "side_calibration": [
      {
        "side": "LONG",
        "signals": 11,
        "closed": 3,
        "win_rate": 0.0,
        "total_r": -3.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 2.97,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=3 < 30)"
      },
      {
        "side": "SHORT",
        "signals": 14,
        "closed": 2,
        "win_rate": 0.5,
        "total_r": 0.087,
        "average_r": 0.0435,
        "decayed_avg_r": 0.0435,
        "effective_n": 1.98,
        "decay_divergence": false,
        "best_r": 1.087,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=2 < 30)"
      },
      {
        "side": "NONE",
        "signals": 56,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "regime_calibration": [
      {
        "regime": "UPTREND",
        "signals": 27,
        "closed": 3,
        "win_rate": 0.0,
        "total_r": -3.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 2.97,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=3 < 30)"
      },
      {
        "regime": "DOWNTREND",
        "signals": 30,
        "closed": 2,
        "win_rate": 0.5,
        "total_r": 0.087,
        "average_r": 0.0435,
        "decayed_avg_r": 0.0435,
        "effective_n": 1.98,
        "decay_divergence": false,
        "best_r": 1.087,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=2 < 30)"
      },
      {
        "regime": "RANGE",
        "signals": 24,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "regime": "UNKNOWN",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "narrative_calibration": [
      {
        "narrative_alignment": "aligned",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "narrative_alignment": "conflicted",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "narrative_alignment": "neutral",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "narrative_alignment": "insufficient_data",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "narrative_edge": {
      "aligned_n": 0,
      "conflicted_n": 0,
      "aligned_avg_r": 0.0,
      "conflicted_avg_r": 0.0,
      "mean_diff": 0.0,
      "t_stat": 0.0,
      "p_value": 1.0,
      "welch_df": 0.0,
      "verdict": "insufficient_data"
    },
    "decay_half_life_days": 90,
    "proposed_weight_changes": {
      "asset": [
        {
          "asset": "BTC",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=1 < 30)"
        },
        {
          "asset": "DXY",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=1 < 30)"
        },
        {
          "asset": "GOLD",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=1 < 30)"
        },
        {
          "asset": "NASDAQ",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "SPX",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "US10Y",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=1 < 30)"
        },
        {
          "asset": "USDJPY",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=1 < 30)"
        },
        {
          "asset": "VIX",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "WTI",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        }
      ],
      "rank": [
        {
          "rank": "A",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "rank": "B",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=5 < 30)"
        },
        {
          "rank": "NO_TRADE",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        }
      ],
      "side": [
        {
          "side": "LONG",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=3 < 30)"
        },
        {
          "side": "SHORT",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=2 < 30)"
        },
        {
          "side": "NONE",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        }
      ]
    }
  }
]
```
