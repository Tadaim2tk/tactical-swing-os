# Tactical Swing OS Reason Code Analysis

## 1. 結論

reason_codesの有効性を集計しました。

対象期間: 2026-05-17 - 2026-06-15

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. reason_codes 上位プラス要因

_該当なし_

## 3. reason_codes 上位マイナス要因

| reason_code | signals_count | evaluated_count | win_count | loss_count | no_entry_count | missed_opportunity_count | win_rate | total_r | average_r | median_r | best_r | worst_r | average_mfe_r | average_mae_r | rank_a_count | rank_b_count | no_trade_count | recommended_action_trade_count | recommended_action_watch_count | recommended_action_no_trade_count | reliability_label |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ma_alignment_bull | 21 | 5 | 0 | 0 | 0 | 0 | 0.0 | -0.7984 | -0.2661 | -0.237 | -0.224 | -0.3374 | 0.1231 | -0.3869 | 0 | 5 | 16 | 0 | 5 | 16 | negative |
| trend_up | 21 | 5 | 0 | 0 | 0 | 0 | 0.0 | -0.7984 | -0.2661 | -0.237 | -0.224 | -0.3374 | 0.1231 | -0.3869 | 0 | 5 | 16 | 0 | 5 | 16 | negative |

## 4. no_trade_reason 分析

| no_trade_reason | count | no_trade_correct_count | no_trade_missed_count | missed_opportunity_count | average_mfe_r | average_r | assessment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rr_too_low | 36 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |
| low_volatility | 10 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |

## 5. 取り逃し候補

_該当なし_

## 6. 改善候補

| reason_code | signals_count | evaluated_count | win_count | loss_count | no_entry_count | missed_opportunity_count | win_rate | total_r | average_r | median_r | best_r | worst_r | average_mfe_r | average_mae_r | rank_a_count | rank_b_count | no_trade_count | recommended_action_trade_count | recommended_action_watch_count | recommended_action_no_trade_count | reliability_label |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ma_alignment_bull | 21 | 5 | 0 | 0 | 0 | 0 | 0.0 | -0.7984 | -0.2661 | -0.237 | -0.224 | -0.3374 | 0.1231 | -0.3869 | 0 | 5 | 16 | 0 | 5 | 16 | negative |
| trend_up | 21 | 5 | 0 | 0 | 0 | 0 | 0.0 | -0.7984 | -0.2661 | -0.237 | -0.224 | -0.3374 | 0.1231 | -0.3869 | 0 | 5 | 16 | 0 | 5 | 16 | negative |

## 7. データ不足の注意

reason_codeごとの評価件数が5件未満の場合は `insufficient_data` とし、weights.jsonは自動更新しません。

## 8. REASON_CODE_ANALYSIS CSV

```csv
reason_code,signals_count,evaluated_count,win_count,loss_count,no_entry_count,missed_opportunity_count,win_rate,total_r,average_r,median_r,best_r,worst_r,average_mfe_r,average_mae_r,rank_a_count,rank_b_count,no_trade_count,recommended_action_trade_count,recommended_action_watch_count,recommended_action_no_trade_count,reliability_label
momentum_negative,29,11,0,0,1,0,0.0,0.1677,0.0168,0.0476,0.401,-0.3484,0.339,-0.1008,0,11,18,0,11,18,neutral
ma_alignment_bear,23,11,0,0,1,0,0.0,0.1677,0.0168,0.0476,0.401,-0.3484,0.339,-0.1008,0,11,12,0,11,12,neutral
trend_down,23,11,0,0,1,0,0.0,0.1677,0.0168,0.0476,0.401,-0.3484,0.339,-0.1008,0,11,12,0,11,12,neutral
rr_too_low,46,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,46,0,0,46,insufficient_data
atr_too_low,10,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,10,0,0,10,insufficient_data
pullback_to_ma20,9,2,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,2,7,0,2,7,insufficient_data
rsi_overbought,7,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,7,0,0,7,insufficient_data
atr_too_high,5,1,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,1,4,0,1,4,insufficient_data
breakout_down,6,5,0,0,1,0,0.0,-0.0253,-0.0063,0.0476,0.2279,-0.3484,0.309,-0.083,0,5,1,0,5,1,neutral
rsi_oversold,11,4,0,0,0,0,0.0,-0.3932,-0.0983,-0.2229,0.401,-0.3484,0.1564,-0.263,0,4,7,0,4,7,insufficient_data
overextended,9,4,0,0,0,0,0.0,-0.3695,-0.1232,-0.249,0.2279,-0.3484,0.1174,-0.2264,0,4,5,0,4,5,insufficient_data
breakout_up,6,1,0,0,0,0,0.0,-0.237,-0.237,-0.237,-0.237,-0.237,0.1269,-0.2691,0,1,5,0,1,5,insufficient_data
risk_penalty_high,1,1,0,0,0,0,0.0,-0.249,-0.249,-0.249,-0.249,-0.249,0.0295,-0.2523,0,1,0,0,1,0,insufficient_data
momentum_positive,29,4,0,0,0,0,0.0,-0.7984,-0.2661,-0.237,-0.224,-0.3374,0.1231,-0.3869,0,4,25,0,4,25,insufficient_data
ma_alignment_bull,21,5,0,0,0,0,0.0,-0.7984,-0.2661,-0.237,-0.224,-0.3374,0.1231,-0.3869,0,5,16,0,5,16,negative
trend_up,21,5,0,0,0,0,0.0,-0.7984,-0.2661,-0.237,-0.224,-0.3374,0.1231,-0.3869,0,5,16,0,5,16,negative
range_middle,11,2,0,0,0,0,0.0,-0.5614,-0.2807,-0.2807,-0.224,-0.3374,0.1212,-0.4459,0,2,9,0,2,9,insufficient_data
```

## 9. REASON_CODE_ANALYSIS JSON

```json
{
  "start_date": "2026-05-17",
  "end_date": "2026-06-15",
  "reason_code_summary": [
    {
      "reason_code": "momentum_negative",
      "signals_count": 29,
      "evaluated_count": 11,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.1677,
      "average_r": 0.0168,
      "median_r": 0.0476,
      "best_r": 0.401,
      "worst_r": -0.3484,
      "average_mfe_r": 0.339,
      "average_mae_r": -0.1008,
      "rank_a_count": 0,
      "rank_b_count": 11,
      "no_trade_count": 18,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 11,
      "recommended_action_no_trade_count": 18,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "ma_alignment_bear",
      "signals_count": 23,
      "evaluated_count": 11,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.1677,
      "average_r": 0.0168,
      "median_r": 0.0476,
      "best_r": 0.401,
      "worst_r": -0.3484,
      "average_mfe_r": 0.339,
      "average_mae_r": -0.1008,
      "rank_a_count": 0,
      "rank_b_count": 11,
      "no_trade_count": 12,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 11,
      "recommended_action_no_trade_count": 12,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_down",
      "signals_count": 23,
      "evaluated_count": 11,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.1677,
      "average_r": 0.0168,
      "median_r": 0.0476,
      "best_r": 0.401,
      "worst_r": -0.3484,
      "average_mfe_r": 0.339,
      "average_mae_r": -0.1008,
      "rank_a_count": 0,
      "rank_b_count": 11,
      "no_trade_count": 12,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 11,
      "recommended_action_no_trade_count": 12,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rr_too_low",
      "signals_count": 46,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 46,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 46,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "atr_too_low",
      "signals_count": 10,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 10,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 10,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "pullback_to_ma20",
      "signals_count": 9,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 2,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 2,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "rsi_overbought",
      "signals_count": 7,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "atr_too_high",
      "signals_count": 5,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 4,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 4,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "breakout_down",
      "signals_count": 6,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.0253,
      "average_r": -0.0063,
      "median_r": 0.0476,
      "best_r": 0.2279,
      "worst_r": -0.3484,
      "average_mfe_r": 0.309,
      "average_mae_r": -0.083,
      "rank_a_count": 0,
      "rank_b_count": 5,
      "no_trade_count": 1,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 5,
      "recommended_action_no_trade_count": 1,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rsi_oversold",
      "signals_count": 11,
      "evaluated_count": 4,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.3932,
      "average_r": -0.0983,
      "median_r": -0.2229,
      "best_r": 0.401,
      "worst_r": -0.3484,
      "average_mfe_r": 0.1564,
      "average_mae_r": -0.263,
      "rank_a_count": 0,
      "rank_b_count": 4,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 4,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "overextended",
      "signals_count": 9,
      "evaluated_count": 4,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.3695,
      "average_r": -0.1232,
      "median_r": -0.249,
      "best_r": 0.2279,
      "worst_r": -0.3484,
      "average_mfe_r": 0.1174,
      "average_mae_r": -0.2264,
      "rank_a_count": 0,
      "rank_b_count": 4,
      "no_trade_count": 5,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 4,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "breakout_up",
      "signals_count": 6,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.237,
      "average_r": -0.237,
      "median_r": -0.237,
      "best_r": -0.237,
      "worst_r": -0.237,
      "average_mfe_r": 0.1269,
      "average_mae_r": -0.2691,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 5,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "risk_penalty_high",
      "signals_count": 1,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.249,
      "average_r": -0.249,
      "median_r": -0.249,
      "best_r": -0.249,
      "worst_r": -0.249,
      "average_mfe_r": 0.0295,
      "average_mae_r": -0.2523,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "momentum_positive",
      "signals_count": 29,
      "evaluated_count": 4,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.7984,
      "average_r": -0.2661,
      "median_r": -0.237,
      "best_r": -0.224,
      "worst_r": -0.3374,
      "average_mfe_r": 0.1231,
      "average_mae_r": -0.3869,
      "rank_a_count": 0,
      "rank_b_count": 4,
      "no_trade_count": 25,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 4,
      "recommended_action_no_trade_count": 25,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 21,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.7984,
      "average_r": -0.2661,
      "median_r": -0.237,
      "best_r": -0.224,
      "worst_r": -0.3374,
      "average_mfe_r": 0.1231,
      "average_mae_r": -0.3869,
      "rank_a_count": 0,
      "rank_b_count": 5,
      "no_trade_count": 16,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 5,
      "recommended_action_no_trade_count": 16,
      "reliability_label": "negative"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 21,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.7984,
      "average_r": -0.2661,
      "median_r": -0.237,
      "best_r": -0.224,
      "worst_r": -0.3374,
      "average_mfe_r": 0.1231,
      "average_mae_r": -0.3869,
      "rank_a_count": 0,
      "rank_b_count": 5,
      "no_trade_count": 16,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 5,
      "recommended_action_no_trade_count": 16,
      "reliability_label": "negative"
    },
    {
      "reason_code": "range_middle",
      "signals_count": 11,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.5614,
      "average_r": -0.2807,
      "median_r": -0.2807,
      "best_r": -0.224,
      "worst_r": -0.3374,
      "average_mfe_r": 0.1212,
      "average_mae_r": -0.4459,
      "rank_a_count": 0,
      "rank_b_count": 2,
      "no_trade_count": 9,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 2,
      "recommended_action_no_trade_count": 9,
      "reliability_label": "insufficient_data"
    }
  ],
  "no_trade_reason_summary": [
    {
      "no_trade_reason": "rr_too_low",
      "count": 36,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    },
    {
      "no_trade_reason": "low_volatility",
      "count": 10,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    }
  ],
  "top_positive_reasons": [],
  "top_negative_reasons": [
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 21,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.7984,
      "average_r": -0.2661,
      "median_r": -0.237,
      "best_r": -0.224,
      "worst_r": -0.3374,
      "average_mfe_r": 0.1231,
      "average_mae_r": -0.3869,
      "rank_a_count": 0,
      "rank_b_count": 5,
      "no_trade_count": 16,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 5,
      "recommended_action_no_trade_count": 16,
      "reliability_label": "negative"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 21,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.7984,
      "average_r": -0.2661,
      "median_r": -0.237,
      "best_r": -0.224,
      "worst_r": -0.3374,
      "average_mfe_r": 0.1231,
      "average_mae_r": -0.3869,
      "rank_a_count": 0,
      "rank_b_count": 5,
      "no_trade_count": 16,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 5,
      "recommended_action_no_trade_count": 16,
      "reliability_label": "negative"
    }
  ],
  "over_filtering_candidates": [],
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 26,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "notes": [
    "reason_code単位のweights自動更新はまだ行いません。",
    "insufficient_data reason_codes: 11"
  ]
}
```
