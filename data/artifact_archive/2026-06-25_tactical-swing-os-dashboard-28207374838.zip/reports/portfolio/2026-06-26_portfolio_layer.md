# Portfolio Layer

## 1. 概要

- 生成日時JST: 2026-06-26 08:39:13 JST
- portfolio_status: active
- candidate assets: 2
- defensive assets: 1
- offensive assets: 0
- cash candidate: 0.52
- average confidence: 0.582
- portfolio concentration: 0.24
- risk concentration: 0.0
- recommended exposure: 0.48
- recommended next action: human_review_allocations
- requires_human_approval: true
- weights_json_updated: false
- patch_applied: false
- generate_signal_updated: false
- orders_created: false

## 2. Top Allocation Candidates

| asset | allocation_score | portfolio_weight_candidate | confidence | risk_class | risk_role | latest_rank | latest_side | rationale |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GOLD | 55.04 | 0.24 | 0.6633 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=0.38 win_rate=1.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| USDJPY | 60.7 | 0.24 | 0.4967 | medium | balanced |  |  | signal data unavailable; evaluation avg_r=1.09 win_rate=1.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| BTC | 38.51 | 0.0 | 0.5967 | high | offensive |  |  | signal data unavailable; evaluation avg_r=-0.19 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| WTI | 42.08 | 0.0 | 0.6967 | high | offensive |  |  | signal data unavailable; evaluation avg_r=0.26 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| NASDAQ | 37.95 | 0.0 | 0.6467 | high | offensive |  |  | signal data unavailable; evaluation avg_r=-0.26 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| ETH | 40.0 | 0.0 | 0.35 | high | offensive |  |  | signal data unavailable; evaluation rows unavailable; meta learning unavailable; auto calibration rows=0; human override rows=0; proposal impact unavailable; market snapshot unavailable |
| SPX | 37.37 | 0.0 | 0.63 | medium | offensive |  |  | signal data unavailable; evaluation avg_r=-0.33 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| VIX | 37.45 | 0.0 | 0.58 | high | defensive |  |  | signal data unavailable; evaluation avg_r=-0.32 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| DXY | 40.77 | 0.0 | 0.5967 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=0.10 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| US10Y | 35.64 | 0.0 | 0.5633 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=-0.54 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |

## 3. Risk Concentration

- high risk weight candidate: 0.0
- portfolio concentration: 0.24
- cash ratio candidate: 0.52

## 4. 注意事項

- Portfolio Layerは配分候補を生成するだけです
- 自動売買・自動発注・自動リバランスは行いません
- weights.jsonは更新しません
- generate_signal.pyは変更しません
- Google Sheetsへの書き込みは行いません
- すべての候補は人間承認が必須です
