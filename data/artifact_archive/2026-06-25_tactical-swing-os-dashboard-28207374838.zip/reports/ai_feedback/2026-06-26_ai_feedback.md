# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-26 08:38:49 JST
Actions実行時刻（UTC）: 2026-06-25 23:38:49 UTC
対象日: 2026-06-26
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースはリスクオン寄り
- ニュースモード: ニュースはリスクオン寄り
- ニュース市場バイアス: risk_on
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 57.37
- risk_off: 35.74
- dollar: 34.97
- rate: 34.85
- volatility: 51.47
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=1, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 57.37 | 35.74 | 34.97 | 34.85 | 40.5 | 34.38 | 51.47 | 93.86 |
| DXY | 49.1 | 51.06 | 49.96 | 49.78 | 51.29 | 49.12 | 51.47 | 92.78 |
| GOLD | 49.1 | 51.06 | 49.96 | 49.78 | 51.29 | 49.12 | 51.47 | 92.78 |
| NASDAQ | 49.1 | 51.06 | 49.96 | 49.78 | 51.29 | 49.12 | 51.47 | 92.78 |
| SPX | 49.1 | 51.06 | 49.96 | 49.78 | 51.29 | 49.12 | 51.47 | 92.78 |
| US10Y | 49.1 | 51.06 | 49.96 | 49.78 | 51.29 | 49.12 | 51.47 | 92.78 |
| USDJPY | 49.1 | 51.06 | 49.96 | 49.78 | 51.29 | 49.12 | 51.47 | 92.78 |
| VIX | 49.1 | 51.06 | 49.96 | 49.78 | 51.29 | 49.12 | 51.47 | 92.78 |
| WTI | 49.1 | 51.06 | 49.96 | 49.78 | 51.29 | 49.12 | 51.47 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260626_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: リスクオン要因が優勢で、ニュース面ではリスク選好がやや強い状態です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースはリスクオン寄り
- top_news_drivers: Iran behind attack on cargo vessel near Oman in Strait of Hormuz, U.S. official tells MS NOW, Chicago Fed President Goolsbee says inflation is too high; Williams sees price pressures easing, Core inflation rate hit 3.4% in May, highest since October 2023, Fed’s preferred gauge shows, Wendy's turns lower as meme rally fails to extend to a second day, Iraq piles pressure on OPEC over quota dispute after UAE exit

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-25T23:38:49,2026-06-26 08:38:49 JST,2026-06-25 23:38:49 UTC,2026-06-26,USDJPY,20260626_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,57.37,35.74,34.97,34.85,40.5,34.38,51.47,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: リスクオン要因が優勢で、ニュース面ではリスク選好がやや強い状態です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-25T23:38:49",
  "generated_at_jst": "2026-06-26 08:38:49 JST",
  "generated_at_utc": "2026-06-25 23:38:49 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-26",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースはリスクオン寄り",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースはリスクオン寄り",
  "top_news_drivers": [
    {
      "title": "Iran behind attack on cargo vessel near Oman in Strait of Hormuz, U.S. official tells MS NOW",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "geopolitical_risk_news_score:attack",
      "driver_tags": "geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/25/iran-ghalibaf-trump-us-farm-products-assets.html"
    },
    {
      "title": "Chicago Fed President Goolsbee says inflation is too high; Williams sees price pressures easing",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "inflation_pressure_news_score:inflation|central_bank_dovish_score:easing",
      "driver_tags": "inflation_pressure|central_bank_dovish",
      "driver_summary_ja": "インフレ圧力 / 中銀ハト派 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/06/25/chicago-fed-president-goolsbee-says-inflation-is-too-high-calls-warsh-a-serious-guy.html"
    },
    {
      "title": "Core inflation rate hit 3.4% in May, highest since October 2023, Fed’s preferred gauge shows",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "inflation_pressure_news_score:inflation",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/06/25/pce-inflation-report-may-2026-.html"
    },
    {
      "title": "Wendy's turns lower as meme rally fails to extend to a second day",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "risk_on_news_score:rally",
      "driver_tags": "risk_on",
      "driver_summary_ja": "リスクオン要因",
      "link": "https://www.cnbc.com/2026/06/25/wendys-shares-soar-for-a-second-day-as-retail-investors-pile-into-their-new-meme-darling.html"
    },
    {
      "title": "Iraq piles pressure on OPEC over quota dispute after UAE exit",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "oil_supply_risk_news_score:opec",
      "driver_tags": "oil_supply_risk",
      "driver_summary_ja": "原油供給リスク",
      "link": "https://www.cnbc.com/2026/06/25/iraq-opec-oil-supply-quota-exports-subdued.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 57.37,
      "risk_off_score": 35.74,
      "dollar_strength_score": 34.97,
      "rate_pressure_score": 34.85,
      "gold_safe_haven_score": 40.5,
      "oil_supply_risk_proxy_score": 40.79,
      "crypto_liquidity_score": 34.38,
      "equity_momentum_score": 39.87,
      "volatility_stress_score": 51.47,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 76.67,
      "risk_off_news_score": 0.0,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 0.0,
      "oil_supply_risk_news_score": 19.17,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 19.17,
      "geopolitical_risk_news_score": 19.17,
      "inflation_pressure_news_score": 38.33,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースはリスクオン寄り",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 49.1,
      "risk_off_score": 51.06,
      "dollar_strength_score": 49.96,
      "rate_pressure_score": 49.78,
      "gold_safe_haven_score": 51.29,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.12,
      "equity_momentum_score": 48.74,
      "volatility_stress_score": 51.47,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1535,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 49.1,
      "risk_off_score": 51.06,
      "dollar_strength_score": 49.96,
      "rate_pressure_score": 49.78,
      "gold_safe_haven_score": 51.29,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.12,
      "equity_momentum_score": 48.74,
      "volatility_stress_score": 51.47,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0593,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 49.1,
      "risk_off_score": 51.06,
      "dollar_strength_score": 49.96,
      "rate_pressure_score": 49.78,
      "gold_safe_haven_score": 51.29,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.12,
      "equity_momentum_score": 48.74,
      "volatility_stress_score": 51.47,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.2169,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 49.1,
      "risk_off_score": 51.06,
      "dollar_strength_score": 49.96,
      "rate_pressure_score": 49.78,
      "gold_safe_haven_score": 51.29,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.12,
      "equity_momentum_score": 48.74,
      "volatility_stress_score": 51.47,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0807,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 49.1,
      "risk_off_score": 51.06,
      "dollar_strength_score": 49.96,
      "rate_pressure_score": 49.78,
      "gold_safe_haven_score": 51.29,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.12,
      "equity_momentum_score": 48.74,
      "volatility_stress_score": 51.47,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.4533,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 49.1,
      "risk_off_score": 51.06,
      "dollar_strength_score": 49.96,
      "rate_pressure_score": 49.78,
      "gold_safe_haven_score": 51.29,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.12,
      "equity_momentum_score": 48.74,
      "volatility_stress_score": 51.47,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0216,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 49.1,
      "risk_off_score": 51.06,
      "dollar_strength_score": 49.96,
      "rate_pressure_score": 49.78,
      "gold_safe_haven_score": 51.29,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.12,
      "equity_momentum_score": 48.74,
      "volatility_stress_score": 51.47,
      "narrative_confidence": 92.78,
      "asset_change_pct": 4.307,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 49.1,
      "risk_off_score": 51.06,
      "dollar_strength_score": 49.96,
      "rate_pressure_score": 49.78,
      "gold_safe_haven_score": 51.29,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.12,
      "equity_momentum_score": 48.74,
      "volatility_stress_score": 51.47,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.098,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260626_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: リスクオン要因が優勢で、ニュース面ではリスク選好がやや強い状態です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
