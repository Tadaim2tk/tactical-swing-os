# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-26 08:38:47 JST
取得日時（UTC）: 2026-06-25 23:38:47 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.79
headline件数: 30

## 見出し

- [CNBC Markets] Iran behind attack on cargo vessel near Oman in Strait of Hormuz, U.S. official tells MS NOW (未分類)
- [CNBC Markets] ON Semiconductor strikes $7 billion deal for Synaptics in physical AI push (未分類)
- [CNBC Markets] Chicago Fed President Goolsbee says inflation is too high; Williams sees price pressures easing (US10Y|DXY)
- [CNBC Markets] Democrats probe Trump's troubled $16 million reflecting pool renovation (未分類)
- [CNBC Markets] Trump keeps turning Republican wins into loyalty tests — and political liabilities (未分類)
- [CNBC Markets] Supreme Court limits Roundup cancer suits against Bayer's Monsanto (未分類)
- [CNBC Markets] Judge says lawsuit against Trump DOJ 'anti-weaponization' fund will proceed (未分類)
- [CNBC Markets] GM reveals 2027 GMC Sierra pickup with new V-8 engines, redesigned styling (SPX|NASDAQ)
- [CNBC Markets] Luxury spending now driven by experiences and 'inheritourism' (未分類)
- [CNBC Markets] As Social Security faces trust fund depletion, some Washington lawmakers call for taxing high earners (未分類)
- [CNBC Markets] Microsoft lifts price of Xbox consoles due to soaring component costs (未分類)
- [CNBC Markets] JPMorgan names Doug Petno and Troy Rohrbaugh co-presidents as longtime exec Marianne Lake exits (未分類)
- [CNBC Markets] Judge blocks Trump's rule limiting federal student loans for certain grad school borrowers (US10Y|DXY)
- [CNBC Markets] Core inflation rate hit 3.4% in May, highest since October 2023, Fed’s preferred gauge shows (US10Y|DXY)
- [CNBC Markets] Bond ETF flows surge in hunt for yield: 'Market sniffing out something here,' says BlackRock exec (BTC|US10Y)
- [CNBC Markets] Wendy's turns lower as meme rally fails to extend to a second day (未分類)
- [CNBC Markets] Apple stock gets slammed on bigger Mac, iPad price hikes. Why it can weather the storm (未分類)
- [CNBC Markets] Chan Zuckerberg Initiative's Biohub to open new rare disease funding round (未分類)
- [CNBC Markets] Chevron says no quick fix for gas prices as Trump takes on Big Oil: ‘It’s going to take time’ (WTI)
- [CNBC Markets] TikTok and YouTube are reinventing sports viewership. Broadcasters are taking note (未分類)
- [CNBC Markets] GameStop’s CEO just sacrificed a $35 billion pay package. Here’s how it could impact his effort to buy eBay (未分類)
- [CNBC Markets] Trump pledges rapid U.S. response for Venezuela after historic earthquakes kill hundreds (未分類)
- [CNBC Markets] Iraq piles pressure on OPEC over quota dispute after UAE exit (WTI)
- [CNBC Markets] Darden Restaurants earnings beat estimates but Olive Garden growth weakens (SPX|NASDAQ)
- [CNBC Markets] U.S. giving topped $600 billion for the first time last year. Megadonors and bequests are to thank (未分類)
- [CNBC Markets] Iran warns ships it's 'unacceptable and dangerous' to transit the Strait of Hormuz without their approval (未分類)
- [CNBC Markets] Annuity options are growing in 401(k)s, but adoption remains limited (未分類)
- [CNBC Markets] Bitcoin is having a tough year. Traders are betting it's going to get worse (BTC)
- [CNBC Markets] Anthropic's latest hiring spree reveals where it's building AI data centers next (未分類)
- [CNBC Markets] Gold hovers around $4,000, silver holds below $60 — has the shimmer worn off the precious metal rally? (GOLD)
