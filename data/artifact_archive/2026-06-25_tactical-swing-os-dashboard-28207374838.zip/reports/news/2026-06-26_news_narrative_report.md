# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-26 08:38:48 JST
生成日時（UTC）: 2026-06-25 23:38:48 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.79
ニュース市場バイアス: risk_on
ニュース矛盾スコア: 0.0
主要テーマ: risk_on
日本語要約: リスクオン要因が優勢で、ニュース面ではリスク選好がやや強い状態です。
ニュースモード: ニュースはリスクオン寄り

## スコア

- risk_on_news_score: 76.67
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 0.0
- oil_supply_risk_news_score: 19.17
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 19.17
- geopolitical_risk_news_score: 19.17
- inflation_pressure_news_score: 38.33
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 19.17
- news_confidence: 100.0

## Top News Drivers

- Iran behind attack on cargo vessel near Oman in Strait of Hormuz, U.S. official tells MS NOW (地政学リスク / リスクオフ要因)
- Chicago Fed President Goolsbee says inflation is too high; Williams sees price pressures easing (インフレ圧力 / 中銀ハト派 / 金利圧力候補)
- Core inflation rate hit 3.4% in May, highest since October 2023, Fed’s preferred gauge shows (インフレ圧力 / 金利圧力候補)
- Wendy's turns lower as meme rally fails to extend to a second day (リスクオン要因)
- Iraq piles pressure on OPEC over quota dispute after UAE exit (原油供給リスク)
- Darden Restaurants earnings beat estimates but Olive Garden growth weakens (リスクオン要因 / 株式モメンタム)
- U.S. giving topped $600 billion for the first time last year. Megadonors and bequests are to thank (リスクオン要因)
- Gold hovers around $4,000, silver holds below $60 — has the shimmer worn off the precious metal rally? (リスクオン要因)
