# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-04 07:44:33 JST
生成日時（UTC）: 2026-07-03 22:44:33 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.46
ニュース市場バイアス: mixed
ニュース矛盾スコア: 55.4
主要テーマ: risk_on
日本語要約: リスクオン要因が目立ち、リスクオン材料とリスクオフ材料が混在しています。強弱材料が混在しており、方向感は限定的です。
ニュースモード: ニュースは混在 / 金利圧力材料あり / 地政学リスク材料あり

## スコア

- risk_on_news_score: 73.87
- risk_off_news_score: 55.4
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 36.93
- gold_safe_haven_news_score: 18.47
- oil_supply_risk_news_score: 18.47
- crypto_liquidity_news_score: 36.93
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 36.93
- inflation_pressure_news_score: 36.93
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 36.93
- central_bank_dovish_score: 18.47
- news_confidence: 100.0

## Top News Drivers

- 5 takeaways from President Donald Trump's interview with CNBC (金安全資産需要)
- Gold prices set for first weekly rise in a month as investors scale back Fed rate hike bets (金利圧力候補 / 中銀タカ派)
- Trump bought Apple, Nvidia and other tech giants before tariff reversal fueled rebound (インフレ圧力 / リスクオン要因 / 金利圧力候補)
- Live updates: Bitcoin rises above $62,000 as the red hot semiconductor trade starts to fade (暗号資産流動性)
- Ether and solana extend gains as a short squeeze lifts bitcoin toward $62,000 (リスクオン要因)
- Bitwise says STRC selloff signals crypto cycle nearing a bottom, not Strategy’s breaking point (リスクオフ要因)
- US Treasury sanctions over 100 ISIS-K crypto addresses that moved over $1.4 million (地政学リスク / 原油供給リスク / リスクオフ要因)
- JPMorgan says Strategy's bitcoin sales policy adds 'two-way risk' to crypto markets (リスクオフ要因)
- U.S. payroll growth slowed sharply in June, with only 57,000 jobs added (金利圧力候補 / 中銀タカ派)
- Warsh's comments set the stage for U.S. jobs data to ignite bitcoin, gold rally (リスクオン要因)
