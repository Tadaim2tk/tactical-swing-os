# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-11 08:43:52 JST
生成日時（UTC）: 2026-06-10 23:43:52 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.12
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: gold_safe_haven, geopolitical_risk, inflation_pressure
日本語要約: 金安全資産需要、地政学リスク、インフレ圧力はありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 19.17
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 100.0
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 95.83
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- U.S. military begins strikes on 'multiple targets' in Iran at Trump's direction (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Analysis: Trump said he loves inflation. Why that should be music to Kevin Warsh's ears (地政学リスク / インフレ圧力 / 金安全資産需要 / リスクオフ要因 / 金利圧力候補)
- Trump keeps saying an Iran deal is close. Markets keep believing it (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Trump says 'I love the inflation' after consumer price index hits 3-year high (地政学リスク / インフレ圧力 / 金安全資産需要 / リスクオフ要因 / 金利圧力候補)
- Oil prices rise after Trump says U.S. will attack Iran 'very hard' (地政学リスク / インフレ圧力 / リスクオフ要因 / 金利圧力候補)
- Sen. Warren calls on SEC to delay SpaceX IPO, flagging concerns about valuation and governance (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Here's the inflation breakdown for May 2026 — in one chart (地政学リスク / インフレ圧力 / 金安全資産需要 / リスクオフ要因 / 金利圧力候補)
- Private credit lenders say their big software bet faces an AI reckoning — but not a ‘SaaSpocalypse' (地政学リスク / リスクオフ要因 / 金安全資産需要)
