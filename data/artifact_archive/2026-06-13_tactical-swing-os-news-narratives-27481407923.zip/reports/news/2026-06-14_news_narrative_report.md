# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-14 07:47:21 JST
生成日時（UTC）: 2026-06-13 22:47:21 UTC
headline件数: 74
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.81
ニュース市場バイアス: neutral
ニュース矛盾スコア: 36.95
主要テーマ: geopolitical_risk, gold_safe_haven
日本語要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 36.95
- risk_off_news_score: 36.95
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 92.36
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 55.42
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 55.42
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 18.47
- news_confidence: 100.0

## Top News Drivers

- Trump says peace deal will be signed Sunday after Iran said it remains cautious on timing (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Social Security COLA for 2027 may jump to 4.7%, one estimate finds. This chart shows prices driving the increase (インフレ圧力 / 金利圧力候補)
- Moats vs. moonshots: The Warren Buffett-Elon Musk style debate (地政学リスク / 金安全資産需要 / リスクオフ要因)
- For Warsh as Fed chair, silence may be the point (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Call Kevin Warsh the Fed 'chairman' (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Judge blocks DOJ 'anti-weaponization' fund for longer, wants guarantee it’s dead (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Social Security’s COLA could be 4.7% in 2027 as inflation hits the highest level in 3 years (インフレ圧力 / 金利圧力候補)
- Bitcoin rises above $64,000 after Pakistan prime minister says Iran peace deal is near (リスクオン要因 / 暗号資産流動性)
- Top cryptographers can't agree on Bitcoin's biggest quantum question (地政学リスク / リスクオフ要因)
- Bitcoin steadies above $63,000 as its worst week in months got a late macro rescue (リスクオフ要因 / 中銀ハト派)
