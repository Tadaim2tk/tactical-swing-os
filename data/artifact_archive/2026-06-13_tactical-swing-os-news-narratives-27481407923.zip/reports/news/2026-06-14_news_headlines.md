# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-14 07:47:20 JST
取得日時（UTC）: 2026-06-13 22:47:20 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.81
headline件数: 74

## 見出し

- [CNBC Markets] Trump says peace deal will be signed Sunday after Iran said it remains cautious on timing (未分類)
- [CNBC Markets] From 10% chance of success to $2 trillion market cap: SpaceX's historic IPO (NASDAQ)
- [CNBC Markets] UAE denies 'false' reports of fund transfer to Iran (USDJPY|DXY)
- [CNBC Markets] Switzerland is voting on whether to cap its population at 10 million. Here's what to know (BTC)
- [CNBC Markets] Anthropic disables access to Fable 5 and Mythos 5 to comply with government directive (未分類)
- [CNBC Markets] SpaceX IPO sticks the landing. Here's what investors are saying about its epic first trading day (VIX)
- [CNBC Markets] Why TD Securities anticipates even bigger days ahead for SpaceX (未分類)
- [CNBC Markets] Social Security COLA for 2027 may jump to 4.7%, one estimate finds. This chart shows prices driving the increase (未分類)
- [CNBC Markets] Moats vs. moonshots: The Warren Buffett-Elon Musk style debate (未分類)
- [CNBC Markets] Drugmakers race to find a place in the next wave of obesity drugs (未分類)
- [CNBC Markets] New student loan plan comes with higher bills for many. Tax planning can help cut your payments (US10Y|DXY)
- [CNBC Markets] Rivian CEO taking different approach than Elon Musk for humanoid robotics company (未分類)
- [CNBC Markets] What drove the stock market last week — before and after SpaceX's historic IPO (未分類)
- [CNBC Markets] This 28-year-old paid off her law school loans selling stickers and coloring books (未分類)
- [CNBC Markets] New SpaceX millionaires are reinventing the business of managing large wealth (未分類)
- [CNBC Markets] Former Tesla board member says SpaceX needs to achieve 2 of its 3 moonshots to keep its valuation (未分類)
- [CNBC Markets] For Warsh as Fed chair, silence may be the point (US10Y|DXY)
- [CNBC Markets] Pirro's losses in Fed investigation should stay on the books, judge rules (US10Y|DXY)
- [CNBC Markets] Paramount-WBD merger wins approval from DOJ (未分類)
- [CNBC Markets] Small investors scrambled to get in on the SpaceX IPO, even as some believe the valuation is 'stupid' (SPX)
- [CNBC Markets] SpaceX market cap tops $2 trillion after shares of Elon Musk's rocket company gain 19% on debut (SPX|NASDAQ)
- [CNBC Markets] Top House Republican’s family investment poised to benefit from SpaceX IPO (未分類)
- [CNBC Markets] Call Kevin Warsh the Fed 'chairman' (US10Y|DXY)
- [CNBC Markets] As investors flock to SpaceX, one trader eyes a sleepy 'stealth' play (未分類)
- [CNBC Markets] Jim Cramer says it's not too late to buy SpaceX — under one condition (未分類)
- [CNBC Markets] SpaceX COO Shotwell says Tesla tie-up ‘might make Elon’s life a little easier’ (NASDAQ)
- [CNBC Markets] SpaceX 'proxies' plunge as real deal arrives: Here's where traders are buying the dip (SPX)
- [CNBC Markets] Judge blocks DOJ 'anti-weaponization' fund for longer, wants guarantee it’s dead (US10Y|DXY)
- [CNBC Markets] SpaceX’s Gwynne Shotwell had IPO doubts for years, now she has a message for investors (未分類)
- [MarketWatch Top Stories] Social Security is facing a 22% cliff — 4 ways to build an income stream Washington can’t touch (未分類)
- [MarketWatch Top Stories] Worried about a lower Social Security benefit? How to calculate the exact impact it will have on your retirement. (未分類)
- [MarketWatch Top Stories] Social Security benefits and costs are perfectly reasonable — no case exists for massive cuts (未分類)
- [MarketWatch Top Stories] Millions of grandparents are spending their retirements raising their grandkids — and it’s taking a financial toll (未分類)
- [MarketWatch Top Stories] The true national debt just hit $1 million per U.S. household (未分類)
- [MarketWatch Top Stories] Social Security’s COLA could be 4.7% in 2027 as inflation hits the highest level in 3 years (未分類)
- [MarketWatch Top Stories] My wife and I are 61. We have $2.2 million and expect $5,000 in Social Security benefits. Do we claim early? (未分類)
- [MarketWatch Top Stories] Social Security insolvency is ‘entirely solvable,’ says commissioner under Biden (未分類)
- [MarketWatch Top Stories] SpaceX IPO hype is massive — and the FOMO can ruin your retirement (未分類)
- [MarketWatch Top Stories] When a World Cup team loses, its country’s stock market also goes down. Here’s the weird reason why. (未分類)
- [CoinDesk] Crypto’s next billion-dollar hacker may move at superhuman speed (BTC|USDJPY|DXY)
- [CoinDesk] Here's what SpaceX's IPO means for its $1.3 billion bitcoin reserve (BTC|SPX|NASDAQ|US10Y|DXY)
- [CoinDesk] Stablecoins Were Meant to Disrupt Finance. Instead, They Became Idle Cash. (BTC)
- [CoinDesk] Bitcoin rises above $64,000 after Pakistan prime minister says Iran peace deal is near (BTC)
- [CoinDesk] Wall Street is moving past crypto pilots and deeper into Ethereum, says Etherealize founder (BTC|SPX)
- [CoinDesk] Tokenization mirrors the $20 trillion ETF boom as blockchain and AI converge, Ondo exec says (BTC)
- [CoinDesk] Perpetual futures could become crypto's next ETF moment (BTC)
- [CoinDesk] Saylor to Musk: Thanks to you, 25% of 'Mag8' firms now hold bitcoin (BTC)
- [CoinDesk] Crypto should adopt the best of centralization, says LMAX CEO (BTC)
- [CoinDesk] Ripple wants AI agents to pay in XRP and RLUSD. The market is still mostly USDC (未分類)
- [CoinDesk] Top cryptographers can't agree on Bitcoin's biggest quantum question (BTC)
