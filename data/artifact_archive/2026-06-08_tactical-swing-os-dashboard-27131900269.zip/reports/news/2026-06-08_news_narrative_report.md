# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-08 19:35:35 JST
生成日時（UTC）: 2026-06-08 10:35:35 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.98
ニュース市場バイアス: neutral
ニュース矛盾スコア: 19.17
主要テーマ: gold_safe_haven, geopolitical_risk
日本語要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 38.33
- risk_off_news_score: 19.17
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 95.83
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 95.83
- inflation_pressure_news_score: 38.33
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Bidding war erupts for world’s oldest bank as Italy’s Intesa gatecrashes BPM offer (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Foreign investors have dumped billions of dollars of Korean stocks this year despite record rally. Here's why (リスクオン要因)
- U.S. confirms second Texas screwworm case, Canada restricts livestock imports (地政学リスク / 金安全資産需要 / リスクオフ要因)
- 100 days of the Iran war: How global markets and the economy have been affected, in charts (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Inflation inside the electronics you buy may soon become a bit more sticky (インフレ圧力 / 金利圧力候補)
- Oil prices jump by the most in over a month as fresh attacks threaten the ceasefire with Iran (地政学リスク / リスクオフ要因 / リスクオン要因)
- U.S. inflation, European Central Bank rate decision: Crypto Week Ahead (インフレ圧力 / 金利圧力候補)
