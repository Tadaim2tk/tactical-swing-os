# Prediction Calibration (SPEC-BC-001)

## 1. 概要

- 生成日時JST: 2026-06-16 11:51:08 JST
- calibration_status: unavailable
- implied_probability_source: default (SPEC-BC-001 frozen)
- overall_brier: 0.0 / reference_brier: 0.0
- **Brier Skill Score: 0.0** (scored_n=0)
- overconfident: 0 / underconfident: 0 / well_calibrated: 0 / insufficient: 0
- 適用ゲート: SPEC-SG-001 (n>=30, alpha=0.05)
- weights_json_updated: false / requires_human_approval: true

## 2. Rank別キャリブレーション

該当なし

## 3. 読み方

- calibration_gap = 実際の的中率 - 暗黙的勝率。負で有意なら **overconfident** (AIは自信過剰)
- Brier Skill Score > 0 なら、Rank分けは「常に平均勝率を予測する」より情報量がある
- n >= 30 未満のRankは判定保留

## 4. 注意

- このレポートはAIの確信度を採点するだけです。weights.jsonは更新しません
- implied probabilityの変更は config/rank_implied_probability.json で人間が行います
- 実売買・発注は行いません
