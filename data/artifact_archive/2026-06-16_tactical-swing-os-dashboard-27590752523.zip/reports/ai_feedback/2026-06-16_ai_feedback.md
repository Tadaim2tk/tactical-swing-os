# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-16 11:50:47 JST
Actions実行時刻（UTC）: 2026-06-16 02:50:47 UTC
対象日: 2026-06-16
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースはリスクオフ寄り / 地政学リスク材料あり / 原油供給リスク材料あり
- ニュースモード: ニュースはリスクオフ寄り / 地政学リスク材料あり / 原油供給リスク材料あり
- ニュース市場バイアス: risk_off
- ニュース矛盾スコア: 19.17
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 41.18
- risk_off: 57.48
- dollar: 35.01
- rate: 35.16
- volatility: 48.94
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=1, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 41.18 | 57.48 | 35.01 | 35.16 | 64.28 | 35.44 | 48.94 | 93.86 |
| DXY | 50.61 | 49.26 | 50.02 | 50.23 | 48.97 | 50.63 | 48.94 | 92.78 |
| GOLD | 50.61 | 49.26 | 50.02 | 50.23 | 48.97 | 50.63 | 48.94 | 92.78 |
| NASDAQ | 50.61 | 49.26 | 50.02 | 50.23 | 48.97 | 50.63 | 48.94 | 92.78 |
| SPX | 50.61 | 49.26 | 50.02 | 50.23 | 48.97 | 50.63 | 48.94 | 92.78 |
| US10Y | 50.61 | 49.26 | 50.02 | 50.23 | 48.97 | 50.63 | 48.94 | 92.78 |
| USDJPY | 50.61 | 49.26 | 50.02 | 50.23 | 48.97 | 50.63 | 48.94 | 92.78 |
| VIX | 50.61 | 49.26 | 50.02 | 50.23 | 48.97 | 50.63 | 48.94 | 92.78 |
| WTI | 50.61 | 49.26 | 50.02 | 50.23 | 48.97 | 50.63 | 48.94 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260616_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスク、リスクオフ要因が優勢で、ニュース面では慎重姿勢が強い状態です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースはリスクオフ寄り / 地政学リスク材料あり / 原油供給リスク材料あり
- top_news_drivers: China economy weakens further in May as retail sales post first drop in over three years, The Iran deal came just in time as Strategic Petroleum Reserve hits lowest level since 1983, Trump trusts Fed Chair Kevin Warsh. It matters for more than interest rates, Warsh's Fed is likely to hold rates steady — what the leadership change could mean for your money, Sen. Warren asks Trump if administration plans to raise Social Security retirement age

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-16T02:50:47,2026-06-16 11:50:47 JST,2026-06-16 02:50:47 UTC,2026-06-16,USDJPY,20260616_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low,neutral,0,41.18,57.48,35.01,35.16,64.28,35.44,48.94,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスク、リスクオフ要因が優勢で、ニュース面では慎重姿勢が強い状態です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-16T02:50:47",
  "generated_at_jst": "2026-06-16 11:50:47 JST",
  "generated_at_utc": "2026-06-16 02:50:47 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-16",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースはリスクオフ寄り / 地政学リスク材料あり / 原油供給リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースはリスクオフ寄り / 地政学リスク材料あり / 原油供給リスク材料あり",
  "top_news_drivers": [
    {
      "title": "China economy weakens further in May as retail sales post first drop in over three years",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "risk_off_news_score:slump",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/16/china-economy-may-retail-sales-industrial-output-fixed-asset-investment-.html"
    },
    {
      "title": "The Iran deal came just in time as Strategic Petroleum Reserve hits lowest level since 1983",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "gold_safe_haven_news_score:war|oil_supply_risk_news_score:supply disruption|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|oil_supply_risk|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/15/iran-deal-came-in-time-as-strategic-petroleum-reserve-hits-lowest-level-since-1983.html"
    },
    {
      "title": "Trump trusts Fed Chair Kevin Warsh. It matters for more than interest rates",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/15/trump-warsh-fed-reshape.html"
    },
    {
      "title": "Warsh's Fed is likely to hold rates steady — what the leadership change could mean for your money",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/15/warsh-fed-interest-rates.html"
    },
    {
      "title": "Sen. Warren asks Trump if administration plans to raise Social Security retirement age",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/15/warren-trump-social-security-retirement-age.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 41.18,
      "risk_off_score": 57.48,
      "dollar_strength_score": 35.01,
      "rate_pressure_score": 35.16,
      "gold_safe_haven_score": 64.28,
      "oil_supply_risk_proxy_score": 46.61,
      "crypto_liquidity_score": 35.44,
      "equity_momentum_score": 35.57,
      "volatility_stress_score": 48.94,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 19.17,
      "risk_off_news_score": 76.67,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 100.0,
      "oil_supply_risk_news_score": 38.33,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 95.83,
      "inflation_pressure_news_score": 19.17,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースはリスクオフ寄り / 地政学リスク材料あり / 原油供給リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 50.61,
      "risk_off_score": 49.26,
      "dollar_strength_score": 50.02,
      "rate_pressure_score": 50.23,
      "gold_safe_haven_score": 48.97,
      "oil_supply_risk_proxy_score": 50.16,
      "crypto_liquidity_score": 50.63,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 48.94,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1266,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 50.61,
      "risk_off_score": 49.26,
      "dollar_strength_score": 50.02,
      "rate_pressure_score": 50.23,
      "gold_safe_haven_score": 48.97,
      "oil_supply_risk_proxy_score": 50.16,
      "crypto_liquidity_score": 50.63,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 48.94,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0762,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 50.61,
      "risk_off_score": 49.26,
      "dollar_strength_score": 50.02,
      "rate_pressure_score": 50.23,
      "gold_safe_haven_score": 48.97,
      "oil_supply_risk_proxy_score": 50.16,
      "crypto_liquidity_score": 50.63,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 48.94,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1297,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 50.61,
      "risk_off_score": 49.26,
      "dollar_strength_score": 50.02,
      "rate_pressure_score": 50.23,
      "gold_safe_haven_score": 48.97,
      "oil_supply_risk_proxy_score": 50.16,
      "crypto_liquidity_score": 50.63,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 48.94,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1508,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 50.61,
      "risk_off_score": 49.26,
      "dollar_strength_score": 50.02,
      "rate_pressure_score": 50.23,
      "gold_safe_haven_score": 48.97,
      "oil_supply_risk_proxy_score": 50.16,
      "crypto_liquidity_score": 50.63,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 48.94,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.3143,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 50.61,
      "risk_off_score": 49.26,
      "dollar_strength_score": 50.02,
      "rate_pressure_score": 50.23,
      "gold_safe_haven_score": 48.97,
      "oil_supply_risk_proxy_score": 50.16,
      "crypto_liquidity_score": 50.63,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 48.94,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0393,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 50.61,
      "risk_off_score": 49.26,
      "dollar_strength_score": 50.02,
      "rate_pressure_score": 50.23,
      "gold_safe_haven_score": 48.97,
      "oil_supply_risk_proxy_score": 50.16,
      "crypto_liquidity_score": 50.63,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 48.94,
      "narrative_confidence": 92.78,
      "asset_change_pct": -3.4565,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 50.61,
      "risk_off_score": 49.26,
      "dollar_strength_score": 50.02,
      "rate_pressure_score": 50.23,
      "gold_safe_haven_score": 48.97,
      "oil_supply_risk_proxy_score": 50.16,
      "crypto_liquidity_score": 50.63,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 48.94,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.4192,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260616_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスク、リスクオフ要因が優勢で、ニュース面では慎重姿勢が強い状態です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
