# Similar Narrative Cases（類似局面検索 v0）

## 1. 概要

- 基準日: 2026-07-08
- status: **ok**
- embedding provider: `tfidf_local` / 過去局面 6 日から上位 5 日を検索。

## 2. 類似局面と、その後の実リターン（5/10/20営業日）

| rank | similar_date | similarity | asset | +5d | +10d | +20d | status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 2026-07-07 | 0.6136 |  | — | — | — | no_price_data |
| 2 | 2026-06-16 | 0.6093 |  | — | — | — | no_price_data |
| 3 | 2026-07-04 | 0.594 |  | — | — | — | no_price_data |
| 4 | 2026-07-03 | 0.5788 |  | — | — | — | no_price_data |
| 5 | 2026-07-06 | 0.5594 |  | — | — | — | no_price_data |

## 3. 注意

- allowed_for_signal=true の record のみ・基準日より前の局面のみを検索（lookahead-safe）。
- この出力は表示・記録のみで、signal score には接続していない（connected_to_signal_score=false）。
- 実売買・発注は行わない。
