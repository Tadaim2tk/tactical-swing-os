# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-08 07:45:13 JST
生成日時（UTC）: 2026-07-07 22:45:13 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.49
ニュース市場バイアス: neutral
ニュース矛盾スコア: 18.47
主要テーマ: geopolitical_risk
日本語要約: 地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 55.4
- risk_off_news_score: 18.47
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 18.47
- gold_safe_haven_news_score: 36.93
- oil_supply_risk_news_score: 36.93
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 73.87
- inflation_pressure_news_score: 18.47
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 18.47
- news_confidence: 100.0

## Top News Drivers

- U.S. revokes Iran oil sales authorization after tanker attacks (地政学リスク / 原油供給リスク / リスクオフ要因)
- Trump renews Greenland threats at NATO summit, says U.S. could remove troops from Europe (リスクオフ要因)
- Traders on Kalshi think the Nasdaq-100 will end 2026 above 30,000, predicting a cooler second half of the year (地政学リスク / リスクオン要因 / 金安全資産需要 / リスクオフ要因)
- As chip sector takes it on the chin, traders bet on a big Nvidia rally (リスクオン要因)
- Crude prices rise as U.S. launches strikes on Iran shortly after canceling its license to sell oil (インフレ圧力 / 金利圧力候補)
- Bitcoin stalls as open interest decline raises questions about rally's staying power (リスクオン要因)
- Bitcoin's recent macro relief faces a challenge from Japanese interest rates (金利圧力候補)
- Bitcoin drops after a run at $64,000, shrugging off Strategy's $213 million BTC sale (地政学リスク / 中銀ハト派 / リスクオフ要因)
- Securitize eyes acquisitions with $400 million war chest after going public, CEO says (地政学リスク / 金安全資産需要 / リスクオフ要因)
