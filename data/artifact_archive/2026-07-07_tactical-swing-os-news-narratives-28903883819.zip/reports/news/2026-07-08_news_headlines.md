# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-08 07:45:11 JST
取得日時（UTC）: 2026-07-07 22:45:11 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.49
headline件数: 75

## 見出し

- [CNBC Markets] U.S. revokes Iran oil sales authorization after tanker attacks (WTI|US10Y|DXY)
- [CNBC Markets] U.S. resumes 'powerful strikes' on Iran after Hormuz Strait ship attacks, CENTCOM says (WTI)
- [CNBC Markets] Maine Senate race replacements circle amid pressure on Platner to drop out (未分類)
- [CNBC Markets] Netflix, Disney and YouTube interested in FIFA World Cup U.S. rights, package could reach $2 billion (BTC)
- [CNBC Markets] Trump renews Greenland threats at NATO summit, says U.S. could remove troops from Europe (未分類)
- [CNBC Markets] Meta enters AI image model race in bid to court advertisers and subscribers (未分類)
- [CNBC Markets] Mitch McConnell's health concerns grow amid 4th week in hospital with few details from aides (未分類)
- [CNBC Markets] Traders on Kalshi think the Nasdaq-100 will end 2026 above 30,000, predicting a cooler second half of the year (NASDAQ)
- [CNBC Markets] DeSantis-backed 'Stop WOKE' law meets appeals court block, teeing up possible Supreme Court fight (未分類)
- [CNBC Markets] Toyota to invest $3.6 billion to move Tacoma pickup truck production from Mexico to Texas (未分類)
- [CNBC Markets] Supreme Court's Kagan, Barrett to testify to House for budget request, a first since 2019 (未分類)
- [CNBC Markets] Judge blocks DOJ subpoena for names of 2020 Fulton County, Georgia, election workers (未分類)
- [CNBC Markets] As chip sector takes it on the chin, traders bet on a big Nvidia rally (BTC|SPX|NASDAQ)
- [CNBC Markets] Rivian stock falls 18% as company sells 75 million shares to raise capital (SPX)
- [CNBC Markets] Chinese lidar maker with Nvidia ties accused of being cyber risk for U.S. (NASDAQ)
- [CNBC Markets] Stellantis to sell small Fiat Topolino EV for $13,995 in U.S. (未分類)
- [CNBC Markets] Chip stocks sell off after Samsung earnings fall short of high AI bar (SPX|NASDAQ)
- [CNBC Markets] The implications of Amazon's $25B bond sale, and Microsoft's evolving AI model strategy (US10Y)
- [CNBC Markets] Trump ally Nigel Farage quits UK parliament amid finance scandal to fight special election (未分類)
- [CNBC Markets] Don't rely on AI for personal finance advice, study finds (未分類)
- [CNBC Markets] Amazon raising at least $25 billion in bond sale, won't issue more debt in 2026 (US10Y)
- [CNBC Markets] Trump arrives in Turkey as NATO is strained by Russian attacks, U.S. impatience (未分類)
- [CNBC Markets] Buy these quality, low-stress stocks for the summer, says Jefferies (SPX)
- [CNBC Markets] Billionaires John and Laura Arnold commit $2.6 million to study online sports betting risk (未分類)
- [CNBC Markets] Far more real estate agents now report seeing a balanced market, CNBC Housing Market Survey finds (未分類)
- [CNBC Markets] Graham Platner denies sex assault claim as Democrats urge him to quit Maine Senate race (未分類)
- [CNBC Markets] Trump Accounts are live. Here's how some families plan to use them (未分類)
- [CNBC Markets] World Cup in photos: Belgium beats U.S. 4-1 after Balogun controversy, Ronaldo exits (未分類)
- [CNBC Markets] Hanwha Ocean shares sink 23% as it loses bid to build Canada's next fleet of submarines (SPX)
- [CNBC Markets] Google backs nuclear fusion startup targeting Europe’s first commercial power plant (NASDAQ)
- [MarketWatch Top Stories] Micron’s stock falls as investors wonder if the memory market is near the top (未分類)
- [MarketWatch Top Stories] Adobe’s stock is temptingly cheap. Should investors bite? (未分類)
- [MarketWatch Top Stories] AI-related debt sells off sharply as Amazon looks to borrow another $25 billion (US10Y)
- [MarketWatch Top Stories] Tesla’s stock could rise 20% thanks to the potential for a SpaceX merger, analyst says (SPX)
- [MarketWatch Top Stories] Crude prices rise as U.S. launches strikes on Iran shortly after canceling its license to sell oil (WTI|US10Y|DXY)
- [MarketWatch Top Stories] Think the U.S. stock market is too heavily exposed to AI? It’s even worse abroad. (未分類)
- [MarketWatch Top Stories] GameStop investors clear the way for a fresh attempt at buying eBay (未分類)
- [MarketWatch Top Stories] ‘The money would have been life-changing’: My father told my grandmother to slash my inheritance. Is that fair? (未分類)
- [MarketWatch Top Stories] ‘I’ve plenty of time on my hands’: Advisers bombard me with offers of free steak dinners. Is it wrong to go for the food? (未分類)
- [MarketWatch Top Stories] Why highflying chip stocks are suddenly losing their luster (SPX|NASDAQ)
- [CoinDesk] BlackRock-backed Securitize slides 40% after SPAC debut despite tokenization boom (BTC)
- [CoinDesk] Crypto exchange Kraken is trying to become a bank in Europe (BTC)
- [CoinDesk] SpaceX IPO powers record $3.86 billion in tokenized equities trading in June (未分類)
- [CoinDesk] U.S. SEC to propose crypto rule as soon as this month to ease startups, fundraising (BTC)
- [CoinDesk] Analysts see more upside for SpaceX as post-IPO research begins (未分類)
- [CoinDesk] Vanguard opens search for digital assets leader in sign of evolving crypto strategy (BTC)
- [CoinDesk] AI trade loses steam as infrastructure boom faces reality check (SPX|NASDAQ)
- [CoinDesk] EDX Markets raises $76 million in funding round led by SBI Holdings (未分類)
- [CoinDesk] Former Tether investment chief is looking to sell part of his stake in the stablecoin giant: Bloomberg (BTC)
- [CoinDesk] Bitcoin, XRP draw Japanese firms as weak yen drives treasury diversification (BTC|USDJPY|US10Y|DXY)
