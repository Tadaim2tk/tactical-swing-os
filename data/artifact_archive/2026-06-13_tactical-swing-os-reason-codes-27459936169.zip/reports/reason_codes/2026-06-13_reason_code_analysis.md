# Tactical Swing OS Reason Code Analysis

## 1. 結論

reason_codesの有効性を集計しました。

対象期間: 2026-06-07 - 2026-06-13

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. reason_codes 上位プラス要因

_該当なし_

## 3. reason_codes 上位マイナス要因

_該当なし_

## 4. no_trade_reason 分析

| no_trade_reason | count | no_trade_correct_count | no_trade_missed_count | missed_opportunity_count | average_mfe_r | average_r | assessment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rr_too_low | 32 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |
| low_volatility | 8 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |

## 5. 取り逃し候補

_該当なし_

## 6. 改善候補

_該当なし_

## 7. データ不足の注意

reason_codeごとの評価件数が5件未満の場合は `insufficient_data` とし、weights.jsonは自動更新しません。

## 8. REASON_CODE_ANALYSIS CSV

```csv
reason_code,signals_count,evaluated_count,win_count,loss_count,no_entry_count,missed_opportunity_count,win_rate,total_r,average_r,median_r,best_r,worst_r,average_mfe_r,average_mae_r,rank_a_count,rank_b_count,no_trade_count,recommended_action_trade_count,recommended_action_watch_count,recommended_action_no_trade_count,reliability_label
momentum_negative,23,8,0,0,1,0,0.0,0.5679,0.0811,0.0851,0.287,-0.2511,0.3866,-0.0787,0,8,15,0,8,15,neutral
ma_alignment_bear,17,8,0,0,1,0,0.0,0.5679,0.0811,0.0851,0.287,-0.2511,0.3866,-0.0787,0,8,9,0,8,9,neutral
trend_down,17,8,0,0,1,0,0.0,0.5679,0.0811,0.0851,0.287,-0.2511,0.3866,-0.0787,0,8,9,0,8,9,neutral
rr_too_low,40,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,40,0,0,40,insufficient_data
atr_too_low,8,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,8,0,0,8,insufficient_data
pullback_to_ma20,6,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,6,0,0,6,insufficient_data
rsi_overbought,6,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,6,0,0,6,insufficient_data
atr_too_high,4,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,4,0,0,4,insufficient_data
breakout_up,4,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,4,0,0,4,insufficient_data
rsi_oversold,9,3,0,0,0,0,0.0,-0.0854,-0.0285,-0.0727,0.2384,-0.2511,0.1514,-0.2094,0,3,6,0,3,6,insufficient_data
overextended,7,2,0,0,0,0,0.0,-0.166,-0.083,-0.083,0.0851,-0.2511,0.0991,-0.1664,0,2,5,0,2,5,insufficient_data
breakout_down,4,3,0,0,0,0,0.0,-0.166,-0.083,-0.083,0.0851,-0.2511,0.0991,-0.1664,0,3,1,0,3,1,insufficient_data
momentum_positive,23,1,0,0,0,0,0.0,-0.3374,-0.3374,-0.3374,-0.3374,-0.3374,0.0821,-0.5098,0,1,22,0,1,22,insufficient_data
ma_alignment_bull,14,1,0,0,0,0,0.0,-0.3374,-0.3374,-0.3374,-0.3374,-0.3374,0.0821,-0.5098,0,1,13,0,1,13,insufficient_data
trend_up,14,1,0,0,0,0,0.0,-0.3374,-0.3374,-0.3374,-0.3374,-0.3374,0.0821,-0.5098,0,1,13,0,1,13,insufficient_data
range_middle,8,1,0,0,0,0,0.0,-0.3374,-0.3374,-0.3374,-0.3374,-0.3374,0.0821,-0.5098,0,1,7,0,1,7,insufficient_data
```

## 9. REASON_CODE_ANALYSIS JSON

```json
{
  "start_date": "2026-06-07",
  "end_date": "2026-06-13",
  "reason_code_summary": [
    {
      "reason_code": "momentum_negative",
      "signals_count": 23,
      "evaluated_count": 8,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.5679,
      "average_r": 0.0811,
      "median_r": 0.0851,
      "best_r": 0.287,
      "worst_r": -0.2511,
      "average_mfe_r": 0.3866,
      "average_mae_r": -0.0787,
      "rank_a_count": 0,
      "rank_b_count": 8,
      "no_trade_count": 15,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 8,
      "recommended_action_no_trade_count": 15,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "ma_alignment_bear",
      "signals_count": 17,
      "evaluated_count": 8,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.5679,
      "average_r": 0.0811,
      "median_r": 0.0851,
      "best_r": 0.287,
      "worst_r": -0.2511,
      "average_mfe_r": 0.3866,
      "average_mae_r": -0.0787,
      "rank_a_count": 0,
      "rank_b_count": 8,
      "no_trade_count": 9,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 8,
      "recommended_action_no_trade_count": 9,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_down",
      "signals_count": 17,
      "evaluated_count": 8,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.5679,
      "average_r": 0.0811,
      "median_r": 0.0851,
      "best_r": 0.287,
      "worst_r": -0.2511,
      "average_mfe_r": 0.3866,
      "average_mae_r": -0.0787,
      "rank_a_count": 0,
      "rank_b_count": 8,
      "no_trade_count": 9,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 8,
      "recommended_action_no_trade_count": 9,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rr_too_low",
      "signals_count": 40,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 40,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 40,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "atr_too_low",
      "signals_count": 8,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 8,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 8,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "pullback_to_ma20",
      "signals_count": 6,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 6,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 6,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "rsi_overbought",
      "signals_count": 6,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 6,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 6,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "atr_too_high",
      "signals_count": 4,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 4,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 4,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "breakout_up",
      "signals_count": 4,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 4,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 4,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "rsi_oversold",
      "signals_count": 9,
      "evaluated_count": 3,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.0854,
      "average_r": -0.0285,
      "median_r": -0.0727,
      "best_r": 0.2384,
      "worst_r": -0.2511,
      "average_mfe_r": 0.1514,
      "average_mae_r": -0.2094,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 6,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 6,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "overextended",
      "signals_count": 7,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.166,
      "average_r": -0.083,
      "median_r": -0.083,
      "best_r": 0.0851,
      "worst_r": -0.2511,
      "average_mfe_r": 0.0991,
      "average_mae_r": -0.1664,
      "rank_a_count": 0,
      "rank_b_count": 2,
      "no_trade_count": 5,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 2,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "breakout_down",
      "signals_count": 4,
      "evaluated_count": 3,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.166,
      "average_r": -0.083,
      "median_r": -0.083,
      "best_r": 0.0851,
      "worst_r": -0.2511,
      "average_mfe_r": 0.0991,
      "average_mae_r": -0.1664,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 1,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 1,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "momentum_positive",
      "signals_count": 23,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.3374,
      "average_r": -0.3374,
      "median_r": -0.3374,
      "best_r": -0.3374,
      "worst_r": -0.3374,
      "average_mfe_r": 0.0821,
      "average_mae_r": -0.5098,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 22,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 22,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 14,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.3374,
      "average_r": -0.3374,
      "median_r": -0.3374,
      "best_r": -0.3374,
      "worst_r": -0.3374,
      "average_mfe_r": 0.0821,
      "average_mae_r": -0.5098,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 13,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 13,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 14,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.3374,
      "average_r": -0.3374,
      "median_r": -0.3374,
      "best_r": -0.3374,
      "worst_r": -0.3374,
      "average_mfe_r": 0.0821,
      "average_mae_r": -0.5098,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 13,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 13,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "range_middle",
      "signals_count": 8,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.3374,
      "average_r": -0.3374,
      "median_r": -0.3374,
      "best_r": -0.3374,
      "worst_r": -0.3374,
      "average_mfe_r": 0.0821,
      "average_mae_r": -0.5098,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "insufficient_data"
    }
  ],
  "no_trade_reason_summary": [
    {
      "no_trade_reason": "rr_too_low",
      "count": 32,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    },
    {
      "no_trade_reason": "low_volatility",
      "count": 8,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    }
  ],
  "top_positive_reasons": [],
  "top_negative_reasons": [],
  "over_filtering_candidates": [],
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 23,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "notes": [
    "reason_code単位のweights自動更新はまだ行いません。",
    "insufficient_data reason_codes: 13"
  ]
}
```
