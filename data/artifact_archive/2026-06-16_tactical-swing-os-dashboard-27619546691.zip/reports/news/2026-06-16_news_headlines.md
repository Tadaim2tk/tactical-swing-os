# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-16 22:04:22 JST
取得日時（UTC）: 2026-06-16 13:04:22 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.2
headline件数: 30

## 見出し

- [CNBC Markets] SpaceX gains 5% in premarket trading after 20% spike on Monday (未分類)
- [CNBC Markets] Brent oil dips below $80 per barrel for first time since March (WTI)
- [CNBC Markets] Trump denies U.S. will put 'any money' into Iran, as he meets allies at G7 summit (未分類)
- [CNBC Markets] Kevin Warsh's Fed is not expected to make any change to rates for a while, according to CNBC Fed Survey (US10Y|DXY)
- [CNBC Markets] Trump turns his attention to Ukraine ahead of Iran deal: 'I’m going to do whatever I can’ (未分類)
- [CNBC Markets] How Elon Musk's second-in-command Gwynne Shotwell helped turn SpaceX into an IPO giant (未分類)
- [CNBC Markets] People in China are watching the World Cup differently this time (未分類)
- [CNBC Markets] How the Strait of Hormuz reopening could unfold if the U.S.-Iran deal is implemented (BTC|WTI)
- [CNBC Markets] Yum Brands sells Pizza Hut to private equity firm LongRange Capital and Yum China for $2.7 billion (未分類)
- [CNBC Markets] Nvidia plans to raise at least $20 billion in its first debt sale since start of AI boom (NASDAQ)
- [CNBC Markets] Treasury yields fall ahead of Kevin Warsh's first Fed meeting (US10Y|DXY)
- [CNBC Markets] CFTC chair Selig defends decision to approve ‘perps’ in U.S. (VIX)
- [CNBC Markets] Jim Cramer's top 10 things to watch in the stock market Tuesday (未分類)
- [CNBC Markets] Qualcomm CEO says AI agents will replace apps — as chip giant works on 40 new AI-powered devices (NASDAQ)
- [CNBC Markets] Bank of Japan hikes rates to 1%, highest since 1995, as yen and inflation worries take hold (USDJPY|US10Y|DXY)
- [CNBC Markets] Gavin Newsom says Trump ordered DOJ to investigate him and his wife (未分類)
- [CNBC Markets] Anthropic to meet with Trump administration over Mythos dispute (未分類)
- [CNBC Markets] To be America's Top State for Business in 2026, 'speed to market' wins (未分類)
- [CNBC Markets] Centene to offer buyouts to some employees as health insurer cuts costs (未分類)
- [CNBC Markets] Warsh's Fed is likely to hold rates steady — what the leadership change could mean for your money (US10Y|DXY)
- [CNBC Markets] Dick's Sporting Goods expanding Lids shops to 100 locations (未分類)
- [CNBC Markets] China economy weakens further in May as retail sales post first drop in over three years (未分類)
- [CNBC Markets] South Korean defense stocks surge on prospects for post-Iran-war sales boosts (SPX)
- [CNBC Markets] Biotech IPO revival faces competition from cash-rich big pharma buyers (NASDAQ)
- [CNBC Markets] Trump trusts Fed Chair Kevin Warsh. It matters for more than interest rates (US10Y|DXY)
- [CNBC Markets] Australia central bank warns hikes are not off the table as it keeps rates steady at 4.35% (US10Y|DXY)
- [CNBC Markets] Vance says 'a lot' of Iran deal details to figure out, but U.S. has 'all the cards' (未分類)
- [CNBC Markets] Wall Street's fear gauge tumbles as traders bid up SpaceX shares (SPX|VIX)
- [CNBC Markets] Fox to buy streaming device maker Roku for $22 billion (未分類)
- [CNBC Markets] Oil tumbles on US-Iran deal framework: How one trader is playing the move (BTC|WTI|SPX)
