# Latest Evaluations Report

## 1. 概要

* 生成日時JST: 2026-06-16 22:04:34 JST
* 入力行数: 0
* unique signal数: 0
* 最新評価行数: 0
* PENDING_REEVALUATIONS由来の最新評価数: 0
* EVALUATIONS由来の最新評価数: 0

## 2. 決着済み

決着済みの最新評価はありません。

## 3. 未決着

未決着の最新評価はありません。

## 4. 再評価履歴あり

再評価履歴ありのシグナルはありません。

## 5. 注意

* append-only履歴から最新行だけを選ぶ分析用ビューです。
* 元のEVALUATIONS / PENDING_REEVALUATIONSは削除しません。
* この評価は実売買ではありません。
* 自動発注は行いません。
