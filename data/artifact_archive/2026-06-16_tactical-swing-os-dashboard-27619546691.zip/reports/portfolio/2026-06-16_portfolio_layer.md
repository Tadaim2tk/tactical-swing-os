# Portfolio Layer

## 1. 概要

- 生成日時JST: 2026-06-16 22:04:40 JST
- portfolio_status: active
- candidate assets: 0
- defensive assets: 0
- offensive assets: 0
- cash candidate: 1.0
- average confidence: 0.458
- portfolio concentration: 0.0
- risk concentration: 0.0
- recommended exposure: 0.0
- recommended next action: hold_cash_and_review_inputs
- requires_human_approval: true
- weights_json_updated: false
- patch_applied: false
- generate_signal_updated: false
- orders_created: false

## 2. Top Allocation Candidates

| asset | allocation_score | portfolio_weight_candidate | confidence | risk_class | risk_role | latest_rank | latest_side | rationale |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| WTI | 40.0 | 0.0 | 0.47 | high | offensive |  |  | signal data unavailable; evaluation data unavailable; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| BTC | 40.0 | 0.0 | 0.47 | high | offensive |  |  | signal data unavailable; evaluation data unavailable; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| NASDAQ | 40.0 | 0.0 | 0.47 | high | offensive |  |  | signal data unavailable; evaluation data unavailable; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| USDJPY | 40.0 | 0.0 | 0.47 | medium | balanced |  |  | signal data unavailable; evaluation data unavailable; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| GOLD | 40.0 | 0.0 | 0.47 | defensive | defensive |  |  | signal data unavailable; evaluation data unavailable; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| ETH | 40.0 | 0.0 | 0.35 | high | offensive |  |  | signal data unavailable; evaluation data unavailable; meta learning unavailable; auto calibration rows=0; human override rows=0; proposal impact unavailable; market snapshot unavailable |
| SPX | 40.0 | 0.0 | 0.47 | medium | offensive |  |  | signal data unavailable; evaluation data unavailable; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| VIX | 40.0 | 0.0 | 0.47 | high | defensive |  |  | signal data unavailable; evaluation data unavailable; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| DXY | 40.0 | 0.0 | 0.47 | defensive | defensive |  |  | signal data unavailable; evaluation data unavailable; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| US10Y | 40.0 | 0.0 | 0.47 | defensive | defensive |  |  | signal data unavailable; evaluation data unavailable; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |

## 3. Risk Concentration

- high risk weight candidate: 0.0
- portfolio concentration: 0.0
- cash ratio candidate: 1.0

## 4. 注意事項

- Portfolio Layerは配分候補を生成するだけです
- 自動売買・自動発注・自動リバランスは行いません
- weights.jsonは更新しません
- generate_signal.pyは変更しません
- Google Sheetsへの書き込みは行いません
- すべての候補は人間承認が必須です
