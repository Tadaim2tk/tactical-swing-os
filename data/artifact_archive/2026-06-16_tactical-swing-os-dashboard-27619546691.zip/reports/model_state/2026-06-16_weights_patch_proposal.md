# Weights Patch Proposal

## 1. 概要

- 生成日時JST: 2026-06-16 22:04:38 JST
- audit_status: passed
- 入力提案件数: 39
- patch候補数: 0
- 除外件数: 39
- increase件数: 0
- decrease件数: 0
- add件数: 0
- update件数: 0
- weights.json更新: false
- patch適用: false
- 人間承認: 必須

## 2. patch候補

該当なし

## 3. 除外された提案

| proposal_id | category | target | exclusion_reason | audit_result | sample_count | confidence_level | proposal_direction | proposed_delta |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260616_asset_BTC_asset_weight_adjustment | asset | BTC | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_asset_DXY_asset_weight_adjustment | asset | DXY | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_asset_GOLD_asset_weight_adjustment | asset | GOLD | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_asset_NASDAQ_asset_weight_adjustment | asset | NASDAQ | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_asset_SPX_asset_weight_adjustment | asset | SPX | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_asset_US10Y_asset_weight_adjustment | asset | US10Y | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_asset_USDJPY_asset_weight_adjustment | asset | USDJPY | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_asset_VIX_asset_weight_adjustment | asset | VIX | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_asset_WTI_asset_weight_adjustment | asset | WTI | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_narrative_crypto_liquidity_narrative_weight_adjustment | narrative | crypto_liquidity | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_narrative_dollar_strength_narrative_weight_adjustment | narrative | dollar_strength | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_narrative_geopolitical_risk_narrative_weight_adjustment | narrative | geopolitical_risk | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_narrative_oil_supply_risk_narrative_weight_adjustment | narrative | oil_supply_risk | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_narrative_rate_pressure_narrative_weight_adjustment | narrative | rate_pressure | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_narrative_risk_off_narrative_weight_adjustment | narrative | risk_off | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_narrative_risk_on_narrative_weight_adjustment | narrative | risk_on | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_rank_A_rank_confidence_adjustment | rank | A | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_rank_B_rank_confidence_adjustment | rank | B | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_rank_NO_TRADE_rank_confidence_adjustment | rank | NO_TRADE | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_reason_code_breakout_down_reason_code_weight_adjustment | reason_code | breakout_down | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_reason_code_breakout_up_reason_code_weight_adjustment | reason_code | breakout_up | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_reason_code_low_volatility_reason_code_weight_adjustment | reason_code | low_volatility | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_reason_code_ma_alignment_bear_reason_code_weight_adjustment | reason_code | ma_alignment_bear | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_reason_code_ma_alignment_bull_reason_code_weight_adjustment | reason_code | ma_alignment_bull | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_reason_code_momentum_negative_reason_code_weight_adjustment | reason_code | momentum_negative | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_reason_code_momentum_positive_reason_code_weight_adjustment | reason_code | momentum_positive | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_reason_code_rr_too_low_reason_code_weight_adjustment | reason_code | rr_too_low | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_reason_code_rsi_overbought_reason_code_weight_adjustment | reason_code | rsi_overbought | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_reason_code_rsi_oversold_reason_code_weight_adjustment | reason_code | rsi_oversold | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_reason_code_trend_down_reason_code_weight_adjustment | reason_code | trend_down | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_reason_code_trend_up_reason_code_weight_adjustment | reason_code | trend_up | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_side_LONG_side_bias_adjustment | side | LONG | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_side_NONE_side_bias_adjustment | side | NONE | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_side_NO_TRADE_side_bias_adjustment | side | NO_TRADE | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_side_SHORT_side_bias_adjustment | side | SHORT | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_type_A-Momentum_setup_type_weight_adjustment | type | A-Momentum | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_type_A-Pullback_setup_type_weight_adjustment | type | A-Pullback | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_type_B-Watch_setup_type_weight_adjustment | type | B-Watch | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260616_type_NO_TRADE_setup_type_weight_adjustment | type | NO_TRADE | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |

## 4. 注意

- このファイルは適用候補であり、weights.jsonを更新しない
- 自動適用は禁止
- 人間確認後、別フェーズで明示的に適用する
- 実売買・発注は行わない
