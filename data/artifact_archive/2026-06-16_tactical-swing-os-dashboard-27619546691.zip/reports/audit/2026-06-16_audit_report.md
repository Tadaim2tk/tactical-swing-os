# Tactical Swing OS Audit Report v0.1

**Date:** 2026-06-16

## Data Integrity Score

**Status:** ✅ PASS

## Reasons

- No data integrity anomalies detected.

## Input Coverage

| item | value |
|---|---:|
| SIGNALS rows | 0 |
| EVALUATIONS rows | 0 |
| PENDING_REEVALUATIONS rows | 29 |
| LATEST_EVALUATIONS rows | 0 |
| latest summary input rows | 0 |
| latest summary unique signals | 0 |

## Duplicate Metrics

| item | value |
|---|---:|
| SIGNALS duplicate signal_id | 0 |
| EVALUATIONS duplicate signal_id | 0 |
| LATEST_EVALUATIONS duplicate signal_id | 0 |

## Label Metrics

| item | value |
|---|---:|
| Unique reason codes from SIGNALS | N/A |

## Status Metrics

| item | value |
|---|---|
| EVALUATIONS evaluation_status counts | N/A |
| LATEST_EVALUATIONS evaluation_status counts | N/A |
