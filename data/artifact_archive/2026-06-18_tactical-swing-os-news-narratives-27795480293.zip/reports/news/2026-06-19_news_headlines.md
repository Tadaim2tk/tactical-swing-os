# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-19 08:24:59 JST
取得日時（UTC）: 2026-06-18 23:24:59 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.65
headline件数: 75

## 見出し

- [CNBC Markets] The average SpaceX buyer post-IPO is almost under water after two-day slide (SPX)
- [CNBC Markets] Vance says U.S. isn’t giving Iran ‘a cent’ as he defends Trump peace deal (未分類)
- [CNBC Markets] Markets are set for a much more hawkish Warsh Fed than expected (US10Y|DXY)
- [CNBC Markets] Trump administration temporarily cuts student loan interest rates for borrowers on autopay (US10Y|DXY)
- [CNBC Markets] Amazon investigating engineers who criticized AI data center expansion (未分類)
- [CNBC Markets] U.S. Navy ends blockade of Iran's ports and coastal areas (未分類)
- [CNBC Markets] Waymo recalls about 3,900 robotaxis after some drove into 'freeway construction zones' (未分類)
- [CNBC Markets] Trump bid to fire Fed's Lisa Cook cost her more than $1M in legal, security costs: Filing (US10Y|DXY)
- [CNBC Markets] In photos: Star-studded crowd gathers to celebrate the Obama Presidential Center dedication (未分類)
- [CNBC Markets] Trump DNI pick Pulte poised to get access to U.S. intelligence despite congressional bid to thwart (未分類)
- [CNBC Markets] Bears step up bets against high-yield sector, shaking up bond traders (BTC|SPX|US10Y)
- [CNBC Markets] Three Saudi oil tankers carrying 6 million barrels cross Strait of Hormuz (WTI)
- [CNBC Markets] Kalshi traders see greater than 50% odds the Fed will hike rates this year (US10Y|DXY)
- [CNBC Markets] NBA to begin naming winning bids for Europe teams in the coming months, deputy commissioner says (未分類)
- [CNBC Markets] Gas prices fall below $4 per gallon as oil supply fears ease after Iran deal (WTI|VIX)
- [CNBC Markets] OPEC chief dismisses IEA supply glut forecast as 'critical' Strait of Hormuz reopens (WTI)
- [CNBC Markets] Analysis: Chairman Kevin Warsh’s task forces are the key to understanding the new Fed (US10Y|DXY)
- [CNBC Markets] Bonkers SpaceX stats that show how staggering the money movement has been (未分類)
- [CNBC Markets] Wall Street recovers from Fed slump, and the next step for Amazon's AI chip ambitions (SPX|NASDAQ|US10Y|DXY)
- [CNBC Markets] Intel gains 10% after Trump says company will partner with Apple on U.S. chip design (NASDAQ)
- [CNBC Markets] GOP Rep. Steil pushes bill curbing members of Congress from prediction market betting (未分類)
- [CNBC Markets] Here are the odds of SpaceX becoming the world's most valuable company (未分類)
- [CNBC Markets] Godfather of AI blasts Musk's xAI as 'failure,' says labs are risking a 'big bubble explosion' (未分類)
- [CNBC Markets] California’s counting on an IPO tax windfall. Several factors are complicating the equation (未分類)
- [CNBC Markets] Roy Cooper's North Carolina Senate race could help decide control of the next Congress (未分類)
- [CNBC Markets] Why this year's World Cup is happening at the perfect time for struggling Nike (未分類)
- [CNBC Markets] Retirement savers may own SpaceX — or soon will — and not even know it (BTC)
- [CNBC Markets] Women have better retirement savings habits but lower 401(k) balances than men, Vanguard finds (SPX|NASDAQ)
- [CNBC Markets] Obama Center launch brings Democratic political glitterati to Chicago ahead of crucial elections (未分類)
- [CNBC Markets] Hollister partners with Target to tap into $89 billion back-to-college shopping market (未分類)
- [MarketWatch Top Stories] I’m 55 and retiring in 6 years. Should I be switching to Roth 401(k) contributions now? (未分類)
- [MarketWatch Top Stories] Trump’s Iran agreement is a massive buy signal for stocks (SPX)
- [MarketWatch Top Stories] SpaceX is vastly more expensive than any stock in the S&P 500, fueled by ‘FOMO’ mentality (BTC|USDJPY|SPX|DXY)
- [MarketWatch Top Stories] Intel’s stock jumps 11% — even as analysts say new Apple chip deal might start small (NASDAQ)
- [MarketWatch Top Stories] Two big reasons Accenture’s stock is sliding in the wake of earnings (SPX|NASDAQ)
- [MarketWatch Top Stories] Micron’s stock is on the rise. Even Apple isn’t safe from ballooning memory-chip costs. (NASDAQ)
- [MarketWatch Top Stories] SpaceX options volume explodes as trading kicks off. Here is a low-risk strategy to play the massive surge. (未分類)
- [MarketWatch Top Stories] These stocks are in trouble after Fed Chair Kevin Warsh removed the market’s guardrails (SPX|US10Y|DXY)
- [MarketWatch Top Stories] Micron, other memory stocks are having their best year ever. Why do they still look so cheap? (SPX)
- [MarketWatch Top Stories] Dollar touches highest level in more than a year. Why this latest rally might be overdone. (USDJPY|US10Y|DXY)
- [CoinDesk] Ex-Celsius CEO Mashinsky gets U.S. CFTC ban in final resolution with regulator (BTC)
- [CoinDesk] U.S. agencies seek stablecoin customer-ID rules akin to banks in new GENIUS Act pitch (US10Y|DXY)
- [CoinDesk] Ethereum Foundation loses another key leader as co-executive director Hsiao-Wei Wang resigns (BTC)
- [CoinDesk] Crypto for Advisors: Trading the bitcoin cycle (BTC|VIX)
- [CoinDesk] Algorand unveils roadmap to achieve quantum resistance by 2028 (BTC)
- [CoinDesk] CoinDesk 20 performance update: Stellar (XLM) jumps 10% while index declines (未分類)
- [CoinDesk] Alchemy's AI-driven identity and payment service gains access to Visa network (未分類)
- [CoinDesk] Hive shares jumps 10% on $220m Canada sovereign AI infrastructure deal (BTC|SPX)
- [CoinDesk] The great rotation: Investors desert the Magnificent 7, crypto for AI bottlenecks (BTC|SPX|NASDAQ)
- [CoinDesk] Bitcoin's nemesis, the Dollar Index, is on the verge of a major breakout (BTC|USDJPY|DXY)
