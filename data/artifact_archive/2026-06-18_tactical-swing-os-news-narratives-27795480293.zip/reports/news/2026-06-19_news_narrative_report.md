# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-19 08:25:00 JST
生成日時（UTC）: 2026-06-18 23:25:00 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.65
ニュース市場バイアス: neutral
ニュース矛盾スコア: 18.47
主要テーマ: inflation_pressure
日本語要約: インフレ圧力はありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 金利圧力材料あり

## スコア

- risk_on_news_score: 55.4
- risk_off_news_score: 18.47
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 36.93
- gold_safe_haven_news_score: 55.4
- oil_supply_risk_news_score: 18.47
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 18.47
- inflation_pressure_news_score: 73.87
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Markets are set for a much more hawkish Warsh Fed than expected (インフレ圧力 / 金利圧力候補)
- OPEC chief dismisses IEA supply glut forecast as 'critical' Strait of Hormuz reopens (原油供給リスク / 金安全資産需要)
- Wall Street recovers from Fed slump, and the next step for Amazon's AI chip ambitions (リスクオフ要因)
- Intel gains 10% after Trump says company will partner with Apple on U.S. chip design (リスクオン要因)
- Women have better retirement savings habits but lower 401(k) balances than men, Vanguard finds (インフレ圧力 / 金利圧力候補)
- Trump’s Iran agreement is a massive buy signal for stocks (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Dollar touches highest level in more than a year. Why this latest rally might be overdone. (リスクオン要因)
- Aster popped over 10% on radical 'buyback and burn' upgrade. But gains were short-lived (金利圧力候補)
- Crypto market positioning is 'defensive and thin' after Fed, Marex analysts say (インフレ圧力 / 金利圧力候補)
- XRP slips 4% below $1.20 after breakout rally stalls near key resistance (リスクオン要因)
