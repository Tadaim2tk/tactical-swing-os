# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-09 08:06:54 JST
Actions実行時刻（UTC）: 2026-06-08 23:06:54 UTC
対象日: 2026-06-08
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオフ優勢 / ドルは中立 / 金利圧力は限定的 / ボラティリティ警戒
- ニュースモード: ニュースナラティブ未取得
- ニュース市場バイアス: insufficient_data
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_only
- 評価データソース: latest_evaluations
- latest_evaluations_available: True
- fallback_used: False
- risk_on: 43.7
- risk_off: 58.37
- dollar: 50.07
- rate: 50.91
- volatility: 60.76
- news_confidence: 0.0
- シグナル整合性: aligned=0, conflicted=1, neutral=6, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| BTC | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| DXY | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| GOLD | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| NASDAQ | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| SPX | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| US10Y | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| USDJPY | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| VIX | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |
| WTI | 43.7 | 58.37 | 50.07 | 50.91 | 60.62 | 43.99 | 60.76 | 100.0 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260607_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260607_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative | conflicted | -18 | GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 |
| 20260607_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260607_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260607_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260607_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
| 20260606_BTC_SHORT_TREND | BTC | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260606_BTC_SHORT_B-Watch | BTC | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |

## 5. 明日に向けた補正仮説

- VIX上昇中の株価指数LONGは慎重化し、entry条件を厳格化する候補。
- ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: False
- news_mode_summary: ニュースナラティブ未取得
- top_news_drivers: ニュースドライバーなし

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-08T23:06:54,2026-06-09 08:06:54 JST,2026-06-08 23:06:54 UTC,2026-06-08,BTC,20260607_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low,neutral,0,43.7,58.37,50.07,50.91,60.62,43.99,60.76,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-08T23:06:54,2026-06-09 08:06:54 JST,2026-06-08 23:06:54 UTC,2026-06-08,DXY,20260607_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low,neutral,0,43.7,58.37,50.07,50.91,60.62,43.99,60.76,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-08T23:06:54,2026-06-09 08:06:54 JST,2026-06-08 23:06:54 UTC,2026-06-08,GOLD,20260607_GOLD_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative,conflicted,-18,43.7,58.37,50.07,50.91,60.62,43.99,60.76,100.0,0.0,market_proxy_only,open_unresolved,,context_warning,GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。,GOLD SHORT は市場文脈と衝突。明日はrank/entry条件を慎重化する仮説。,False,latest_evaluations,True,False
2026-06-08T23:06:54,2026-06-09 08:06:54 JST,2026-06-08 23:06:54 UTC,2026-06-08,NASDAQ,20260607_NASDAQ_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low,neutral,0,43.7,58.37,50.07,50.91,60.62,43.99,60.76,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,NASDAQ NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-08T23:06:54,2026-06-09 08:06:54 JST,2026-06-08 23:06:54 UTC,2026-06-08,SPX,20260607_SPX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low,neutral,0,43.7,58.37,50.07,50.91,60.62,43.99,60.76,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,SPX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-08T23:06:54,2026-06-09 08:06:54 JST,2026-06-08 23:06:54 UTC,2026-06-08,USDJPY,20260607_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low,neutral,0,43.7,58.37,50.07,50.91,60.62,43.99,60.76,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-08T23:06:54,2026-06-09 08:06:54 JST,2026-06-08 23:06:54 UTC,2026-06-08,WTI,20260607_WTI_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low,neutral,0,43.7,58.37,50.07,50.91,60.62,43.99,60.76,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,WTI NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-08T23:06:54",
  "generated_at_jst": "2026-06-09 08:06:54 JST",
  "generated_at_utc": "2026-06-08 23:06:54 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-08",
  "data_source": "Google Sheets",
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 15,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "market_mode_summary": "リスクオフ優勢 / ドルは中立 / 金利圧力は限定的 / ボラティリティ警戒",
  "news_narrative_available": false,
  "news_mode_summary": "ニュースナラティブ未取得",
  "top_news_drivers": [],
  "narrative_source_mix": "market_proxy_only",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": null
    },
    {
      "asset": "BTC",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": 3.6038
    },
    {
      "asset": "DXY",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.002
    },
    {
      "asset": "GOLD",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.1057
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.4663
    },
    {
      "asset": "SPX",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.2579
    },
    {
      "asset": "US10Y",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": 1.5447
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.1412
    },
    {
      "asset": "VIX",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": 35.5388
    },
    {
      "asset": "WTI",
      "risk_on_score": 43.7,
      "risk_off_score": 58.37,
      "dollar_strength_score": 50.07,
      "rate_pressure_score": 50.91,
      "gold_safe_haven_score": 60.62,
      "oil_supply_risk_proxy_score": 49.97,
      "crypto_liquidity_score": 43.99,
      "equity_momentum_score": 40.79,
      "volatility_stress_score": 60.76,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.043
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260607_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260607_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260607_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative",
      "narrative_alignment": "conflicted",
      "narrative_alignment_score": -18,
      "narrative_comment": "GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。"
    },
    {
      "signal_id": "20260607_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260607_SPX_NONE_NO_TRADE",
      "asset": "SPX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260607_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260607_WTI_NONE_NO_TRADE",
      "asset": "WTI",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "signal_id": "20260606_BTC_SHORT_TREND",
      "asset": "BTC",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260606_BTC_SHORT_B-Watch",
      "asset": "BTC",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    }
  ],
  "improvement_hypotheses": [
    "VIX上昇中の株価指数LONGは慎重化し、entry条件を厳格化する候補。",
    "ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
