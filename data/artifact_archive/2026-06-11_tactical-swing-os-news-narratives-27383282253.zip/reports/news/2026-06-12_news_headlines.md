# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-12 08:11:18 JST
取得日時（UTC）: 2026-06-11 23:11:18 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.61
headline件数: 75

## 見出し

- [CNBC Markets] From startup to $1.8 trillion: The investors who took a chance on SpaceX now reap the rewards (未分類)
- [CNBC Markets] SpaceX cuts retail IPO allocation to low 20% range, source says (未分類)
- [CNBC Markets] Trump claims Iran war settled 'subject to finalization,' expects signing in 'next few days' (WTI)
- [CNBC Markets] Trump picks former SEC Chairman Jay Clayton as national intelligence director (未分類)
- [CNBC Markets] Warren questions SpaceX IPO oversight in new letter to stock indexes (未分類)
- [CNBC Markets] What energy insiders in DC are saying about oil prices and a possible Iran deal (WTI|SPX)
- [CNBC Markets] Gold slumps to 6-month low even as inflation fears rise. Here's why bullion is out of favor (GOLD|NASDAQ|VIX)
- [CNBC Markets] Oil tanker CEO sees Hormuz ship traffic quickly increasing if U.S. and Iran reach a deal (WTI)
- [CNBC Markets] Pirro's losses in Fed investigation should stay on the books, judge rules (US10Y|DXY)
- [CNBC Markets] SpaceX IPO won’t ‘break’ the bull market. But investors are worried about what comes next (SPX)
- [CNBC Markets] SpaceX soon-to-be millionaires are set to spend big on luxury homes, watches and private jet travel (SPX)
- [CNBC Markets] Ahead of SpaceX IPO, Elon Musk addresses ASML employees as part of push into chip manufacturing (NASDAQ)
- [CNBC Markets] Ex-Andreessen Horowitz partner slams his old firm, other VCs for 'political infiltration' around AI (未分類)
- [CNBC Markets] Iran threatens Elon Musk's companies in Middle East: Iranian state media (未分類)
- [CNBC Markets] Nearly 7 million student loan borrowers remain in defunct Biden-era payment plan: Trump official (未分類)
- [CNBC Markets] Healthy Returns: CVS Health executives on reducing healthcare's biggest pain points (NASDAQ)
- [CNBC Markets] SpaceX to close above $2 trillion market cap on its debut, prediction market traders say (未分類)
- [CNBC Markets] Eaton moves one step closer to becoming a cleaner bet on the AI boom (未分類)
- [CNBC Markets] OpenAI to acquire Ona to support its AI coding assistant, Codex (NASDAQ)
- [CNBC Markets] Coinbase launches tool to let AI agents manage trading and payments (BTC)
- [CNBC Markets] Waymo launches premier subscription tier for $29.99 a month, starting in select cities (未分類)
- [CNBC Markets] Trump administration appeals ruling blocking $100,000 H-1B fee (未分類)
- [CNBC Markets] Oracle shares tumble 11% on increased capital raise, cash concerns (SPX|NASDAQ)
- [CNBC Markets] Foreign surveillance program to expire Friday after House blocks extension (未分類)
- [CNBC Markets] Elections advertising spend for 2026 expected to reach record high, outpacing presidential years (未分類)
- [CNBC Markets] Some Pentagon workers ordered to shelter in place as air quality issue is investigated (未分類)
- [CNBC Markets] Wholesale prices rose 1.1% in May, more than expected, on surge in energy (未分類)
- [CNBC Markets] Baldwin, Khanna propose new direct foreign investment review board to probe Trump's deals (未分類)
- [CNBC Markets] DoorDash lets customers use photos, prompts to order food and book reservations in latest AI push (未分類)
- [CNBC Markets] SpaceX IPO is a ‘referendum’ on Musk, say market watchers (未分類)
- [MarketWatch Top Stories] Adobe is losing another top executive, and investors don’t like it (未分類)
- [MarketWatch Top Stories] The SpaceX IPO is drawing historic demand from foreign investors. But don’t expect a dollar-buying frenzy. (USDJPY|DXY)
- [MarketWatch Top Stories] We asked AI to predict the 2026 World Cup winner. It picked a team that’s never won. (未分類)
- [MarketWatch Top Stories] Foster children are getting their own version of ‘Trump accounts,’ but major questions remain (未分類)
- [MarketWatch Top Stories] Missed the rally in optical stocks? Coherent and Lumentum just got more attractive, according to J.P. Morgan. (SPX|VIX)
- [MarketWatch Top Stories] Micron’s stock rebounds after ‘healthy’ reset, and analysts see blue skies ahead (SPX)
- [MarketWatch Top Stories] Upcoming SpaceX IPO spawns leveraged ETFs for bullish and bearish bets on its stock (BTC)
- [MarketWatch Top Stories] SpaceX IPO hype is massive — and the FOMO can ruin your retirement (未分類)
- [MarketWatch Top Stories] S&P 500 indicators are breaking down — but this new buy signal is flashing green (SPX|VIX)
- [MarketWatch Top Stories] Oracle’s stock is seeing its worst run in a quarter-century as this key AI debate rages on (未分類)
- [CoinDesk] Elon Musk's SpaceX prices shares at $135, raising $75 billion in largest-ever IPO (SPX|NASDAQ)
- [CoinDesk] Coinbase launches AI agent accounts that can trade and spend on your behalf (BTC)
- [CoinDesk] Banking rails are moving past the 'stablecoin winner' narrative: Sygnum (BTC)
- [CoinDesk] Crypto for Advisors: Crypto ETFs (BTC)
- [CoinDesk] U.S. House bill would erect crypto-theft task force across law enforcement agencies (BTC)
- [CoinDesk] SpaceX stock is coming to Solana on the same day it lists on Nasdaq (SPX|NASDAQ)
- [CoinDesk] Canton Network developer raises $355 million to bring Wall Street onchain (USDJPY|SPX|DXY)
- [CoinDesk] Tether leads $1.4 billion funding round in German robotics company Neura (BTC)
- [CoinDesk] CoinDesk 20 performance update: Uniswap (UNI) gains 4.5% as all constituents rise (未分類)
- [CoinDesk] Citi opens new route into private markets with tokenized share offering (NASDAQ)
