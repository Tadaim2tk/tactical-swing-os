# Tactical Swing OS Reason Code Analysis

## 1. 結論

reason_codesの有効性を集計しました。

対象期間: 2026-06-21 - 2026-06-27

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. reason_codes 上位プラス要因

_該当なし_

## 3. reason_codes 上位マイナス要因

| reason_code | signals_count | evaluated_count | win_count | loss_count | no_entry_count | missed_opportunity_count | win_rate | total_r | average_r | median_r | best_r | worst_r | average_mfe_r | average_mae_r | rank_a_count | rank_b_count | no_trade_count | recommended_action_trade_count | recommended_action_watch_count | recommended_action_no_trade_count | reliability_label |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| atr_too_high | 12 | 5 | 0 | 0 | 0 | 0 | 0.0 | -2.2399 | -0.448 | -0.4277 | -0.3739 | -0.5168 | 0.1555 | -0.5347 | 0 | 5 | 7 | 0 | 5 | 7 | strong_negative |
| momentum_positive | 21 | 9 | 0 | 0 | 0 | 0 | 0.0 | -2.1013 | -0.2627 | -0.3909 | 0.1869 | -0.5168 | 0.1762 | -0.3694 | 0 | 9 | 12 | 0 | 9 | 12 | negative |
| pullback_to_ma20 | 14 | 6 | 0 | 0 | 2 | 0 | 0.0 | -1.2095 | -0.2419 | -0.3739 | 0.0 | -0.4277 | -0.3267 | -0.9459 | 0 | 6 | 8 | 0 | 6 | 8 | negative |
| trend_up | 19 | 11 | 0 | 0 | 2 | 0 | 0.0 | -2.1013 | -0.2101 | -0.2162 | 0.1869 | -0.5168 | -0.0709 | -0.6146 | 0 | 11 | 8 | 0 | 11 | 8 | negative |
| ma_alignment_bull | 19 | 11 | 0 | 0 | 2 | 0 | 0.0 | -2.1013 | -0.2101 | -0.2162 | 0.1869 | -0.5168 | -0.0709 | -0.6146 | 0 | 11 | 8 | 0 | 11 | 8 | negative |

## 4. no_trade_reason 分析

| no_trade_reason | count | no_trade_correct_count | no_trade_missed_count | missed_opportunity_count | average_mfe_r | average_r | assessment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rr_too_low | 20 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |
| low_volatility | 7 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |
| data_insufficient | 1 | 0 | 0 | 0 | 0.0 | 0.0 | insufficient_data |

## 5. 取り逃し候補

_該当なし_

## 6. 改善候補

| reason_code | signals_count | evaluated_count | win_count | loss_count | no_entry_count | missed_opportunity_count | win_rate | total_r | average_r | median_r | best_r | worst_r | average_mfe_r | average_mae_r | rank_a_count | rank_b_count | no_trade_count | recommended_action_trade_count | recommended_action_watch_count | recommended_action_no_trade_count | reliability_label |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ma_alignment_bull | 19 | 11 | 0 | 0 | 2 | 0 | 0.0 | -2.1013 | -0.2101 | -0.2162 | 0.1869 | -0.5168 | -0.0709 | -0.6146 | 0 | 11 | 8 | 0 | 11 | 8 | negative |
| trend_up | 19 | 11 | 0 | 0 | 2 | 0 | 0.0 | -2.1013 | -0.2101 | -0.2162 | 0.1869 | -0.5168 | -0.0709 | -0.6146 | 0 | 11 | 8 | 0 | 11 | 8 | negative |
| pullback_to_ma20 | 14 | 6 | 0 | 0 | 2 | 0 | 0.0 | -1.2095 | -0.2419 | -0.3739 | 0.0 | -0.4277 | -0.3267 | -0.9459 | 0 | 6 | 8 | 0 | 6 | 8 | negative |
| momentum_positive | 21 | 9 | 0 | 0 | 0 | 0 | 0.0 | -2.1013 | -0.2627 | -0.3909 | 0.1869 | -0.5168 | 0.1762 | -0.3694 | 0 | 9 | 12 | 0 | 9 | 12 | negative |
| atr_too_high | 12 | 5 | 0 | 0 | 0 | 0 | 0.0 | -2.2399 | -0.448 | -0.4277 | -0.3739 | -0.5168 | 0.1555 | -0.5347 | 0 | 5 | 7 | 0 | 5 | 7 | strong_negative |

## 7. データ不足の注意

reason_codeごとの評価件数が5件未満の場合は `insufficient_data` とし、weights.jsonは自動更新しません。

## 8. REASON_CODE_ANALYSIS CSV

```csv
reason_code,signals_count,evaluated_count,win_count,loss_count,no_entry_count,missed_opportunity_count,win_rate,total_r,average_r,median_r,best_r,worst_r,average_mfe_r,average_mae_r,rank_a_count,rank_b_count,no_trade_count,recommended_action_trade_count,recommended_action_watch_count,recommended_action_no_trade_count,reliability_label
atr_too_low,8,1,0,0,0,0,0.0,0.162,0.162,0.162,0.162,0.162,0.4504,-0.1366,1,0,7,1,0,7,insufficient_data
ma_alignment_bear,17,11,0,0,1,0,0.0,0.4455,0.0495,0.0087,0.1866,-0.1329,0.2473,-0.0635,1,10,6,1,10,6,neutral
trend_down,17,11,0,0,1,0,0.0,0.4455,0.0495,0.0087,0.1866,-0.1329,0.2473,-0.0635,1,10,6,1,10,6,neutral
rsi_overbought,10,3,0,0,0,0,0.0,0.1386,0.0462,0.0103,0.1869,-0.0586,0.2106,-0.0938,0,3,7,0,3,7,insufficient_data
breakout_up,3,3,0,0,0,0,0.0,0.1386,0.0462,0.0103,0.1869,-0.0586,0.2106,-0.0938,0,3,0,0,3,0,insufficient_data
momentum_negative,26,13,0,0,3,0,0.0,0.4455,0.0405,0.0034,0.1866,-0.1329,0.0098,-0.342,1,12,13,1,12,13,neutral
overextended,9,6,0,0,0,0,0.0,0.0882,0.0176,0.0034,0.176,-0.1329,0.1359,-0.0629,0,6,3,0,6,3,neutral
rsi_oversold,7,6,0,0,0,0,0.0,0.0882,0.0176,0.0034,0.176,-0.1329,0.1359,-0.0629,0,6,1,0,6,1,neutral
breakout_down,6,3,0,0,0,0,0.0,0.0027,0.0009,0.0034,0.1322,-0.1329,0.1121,-0.0725,0,3,3,0,3,3,insufficient_data
rr_too_low,27,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,27,0,0,27,insufficient_data
range_middle,13,3,0,0,2,0,0.0,0.0,0.0,0.0,0.0,0.0,-1.0593,-1.5954,0,3,10,0,3,10,insufficient_data
data_insufficient,1,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,1,0,0,1,insufficient_data
ma_alignment_bull,19,11,0,0,2,0,0.0,-2.1013,-0.2101,-0.2162,0.1869,-0.5168,-0.0709,-0.6146,0,11,8,0,11,8,negative
trend_up,19,11,0,0,2,0,0.0,-2.1013,-0.2101,-0.2162,0.1869,-0.5168,-0.0709,-0.6146,0,11,8,0,11,8,negative
pullback_to_ma20,14,6,0,0,2,0,0.0,-1.2095,-0.2419,-0.3739,0.0,-0.4277,-0.3267,-0.9459,0,6,8,0,6,8,negative
momentum_positive,21,9,0,0,0,0,0.0,-2.1013,-0.2627,-0.3909,0.1869,-0.5168,0.1762,-0.3694,0,9,12,0,9,12,negative
atr_too_high,12,5,0,0,0,0,0.0,-2.2399,-0.448,-0.4277,-0.3739,-0.5168,0.1555,-0.5347,0,5,7,0,5,7,strong_negative
```

## 9. REASON_CODE_ANALYSIS JSON

```json
{
  "start_date": "2026-06-21",
  "end_date": "2026-06-27",
  "reason_code_summary": [
    {
      "reason_code": "atr_too_low",
      "signals_count": 8,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.162,
      "average_r": 0.162,
      "median_r": 0.162,
      "best_r": 0.162,
      "worst_r": 0.162,
      "average_mfe_r": 0.4504,
      "average_mae_r": -0.1366,
      "rank_a_count": 1,
      "rank_b_count": 0,
      "no_trade_count": 7,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "ma_alignment_bear",
      "signals_count": 17,
      "evaluated_count": 11,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.4455,
      "average_r": 0.0495,
      "median_r": 0.0087,
      "best_r": 0.1866,
      "worst_r": -0.1329,
      "average_mfe_r": 0.2473,
      "average_mae_r": -0.0635,
      "rank_a_count": 1,
      "rank_b_count": 10,
      "no_trade_count": 6,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 10,
      "recommended_action_no_trade_count": 6,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_down",
      "signals_count": 17,
      "evaluated_count": 11,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.4455,
      "average_r": 0.0495,
      "median_r": 0.0087,
      "best_r": 0.1866,
      "worst_r": -0.1329,
      "average_mfe_r": 0.2473,
      "average_mae_r": -0.0635,
      "rank_a_count": 1,
      "rank_b_count": 10,
      "no_trade_count": 6,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 10,
      "recommended_action_no_trade_count": 6,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rsi_overbought",
      "signals_count": 10,
      "evaluated_count": 3,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.1386,
      "average_r": 0.0462,
      "median_r": 0.0103,
      "best_r": 0.1869,
      "worst_r": -0.0586,
      "average_mfe_r": 0.2106,
      "average_mae_r": -0.0938,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "breakout_up",
      "signals_count": 3,
      "evaluated_count": 3,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.1386,
      "average_r": 0.0462,
      "median_r": 0.0103,
      "best_r": 0.1869,
      "worst_r": -0.0586,
      "average_mfe_r": 0.2106,
      "average_mae_r": -0.0938,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "momentum_negative",
      "signals_count": 26,
      "evaluated_count": 13,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 3,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.4455,
      "average_r": 0.0405,
      "median_r": 0.0034,
      "best_r": 0.1866,
      "worst_r": -0.1329,
      "average_mfe_r": 0.0098,
      "average_mae_r": -0.342,
      "rank_a_count": 1,
      "rank_b_count": 12,
      "no_trade_count": 13,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 12,
      "recommended_action_no_trade_count": 13,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "overextended",
      "signals_count": 9,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0882,
      "average_r": 0.0176,
      "median_r": 0.0034,
      "best_r": 0.176,
      "worst_r": -0.1329,
      "average_mfe_r": 0.1359,
      "average_mae_r": -0.0629,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 3,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 3,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rsi_oversold",
      "signals_count": 7,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0882,
      "average_r": 0.0176,
      "median_r": 0.0034,
      "best_r": 0.176,
      "worst_r": -0.1329,
      "average_mfe_r": 0.1359,
      "average_mae_r": -0.0629,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 1,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 1,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "breakout_down",
      "signals_count": 6,
      "evaluated_count": 3,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0027,
      "average_r": 0.0009,
      "median_r": 0.0034,
      "best_r": 0.1322,
      "worst_r": -0.1329,
      "average_mfe_r": 0.1121,
      "average_mae_r": -0.0725,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 3,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 3,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "rr_too_low",
      "signals_count": 27,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 27,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 27,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "range_middle",
      "signals_count": 13,
      "evaluated_count": 3,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": -1.0593,
      "average_mae_r": -1.5954,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 10,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 10,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "data_insufficient",
      "signals_count": 1,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 1,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 1,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 19,
      "evaluated_count": 11,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -2.1013,
      "average_r": -0.2101,
      "median_r": -0.2162,
      "best_r": 0.1869,
      "worst_r": -0.5168,
      "average_mfe_r": -0.0709,
      "average_mae_r": -0.6146,
      "rank_a_count": 0,
      "rank_b_count": 11,
      "no_trade_count": 8,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 11,
      "recommended_action_no_trade_count": 8,
      "reliability_label": "negative"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 19,
      "evaluated_count": 11,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -2.1013,
      "average_r": -0.2101,
      "median_r": -0.2162,
      "best_r": 0.1869,
      "worst_r": -0.5168,
      "average_mfe_r": -0.0709,
      "average_mae_r": -0.6146,
      "rank_a_count": 0,
      "rank_b_count": 11,
      "no_trade_count": 8,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 11,
      "recommended_action_no_trade_count": 8,
      "reliability_label": "negative"
    },
    {
      "reason_code": "pullback_to_ma20",
      "signals_count": 14,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.2095,
      "average_r": -0.2419,
      "median_r": -0.3739,
      "best_r": 0.0,
      "worst_r": -0.4277,
      "average_mfe_r": -0.3267,
      "average_mae_r": -0.9459,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 8,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 8,
      "reliability_label": "negative"
    },
    {
      "reason_code": "momentum_positive",
      "signals_count": 21,
      "evaluated_count": 9,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -2.1013,
      "average_r": -0.2627,
      "median_r": -0.3909,
      "best_r": 0.1869,
      "worst_r": -0.5168,
      "average_mfe_r": 0.1762,
      "average_mae_r": -0.3694,
      "rank_a_count": 0,
      "rank_b_count": 9,
      "no_trade_count": 12,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 9,
      "recommended_action_no_trade_count": 12,
      "reliability_label": "negative"
    },
    {
      "reason_code": "atr_too_high",
      "signals_count": 12,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -2.2399,
      "average_r": -0.448,
      "median_r": -0.4277,
      "best_r": -0.3739,
      "worst_r": -0.5168,
      "average_mfe_r": 0.1555,
      "average_mae_r": -0.5347,
      "rank_a_count": 0,
      "rank_b_count": 5,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 5,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "strong_negative"
    }
  ],
  "no_trade_reason_summary": [
    {
      "no_trade_reason": "rr_too_low",
      "count": 20,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    },
    {
      "no_trade_reason": "low_volatility",
      "count": 7,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    },
    {
      "no_trade_reason": "data_insufficient",
      "count": 1,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "insufficient_data"
    }
  ],
  "top_positive_reasons": [],
  "top_negative_reasons": [
    {
      "reason_code": "atr_too_high",
      "signals_count": 12,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -2.2399,
      "average_r": -0.448,
      "median_r": -0.4277,
      "best_r": -0.3739,
      "worst_r": -0.5168,
      "average_mfe_r": 0.1555,
      "average_mae_r": -0.5347,
      "rank_a_count": 0,
      "rank_b_count": 5,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 5,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "strong_negative"
    },
    {
      "reason_code": "momentum_positive",
      "signals_count": 21,
      "evaluated_count": 9,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -2.1013,
      "average_r": -0.2627,
      "median_r": -0.3909,
      "best_r": 0.1869,
      "worst_r": -0.5168,
      "average_mfe_r": 0.1762,
      "average_mae_r": -0.3694,
      "rank_a_count": 0,
      "rank_b_count": 9,
      "no_trade_count": 12,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 9,
      "recommended_action_no_trade_count": 12,
      "reliability_label": "negative"
    },
    {
      "reason_code": "pullback_to_ma20",
      "signals_count": 14,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.2095,
      "average_r": -0.2419,
      "median_r": -0.3739,
      "best_r": 0.0,
      "worst_r": -0.4277,
      "average_mfe_r": -0.3267,
      "average_mae_r": -0.9459,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 8,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 8,
      "reliability_label": "negative"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 19,
      "evaluated_count": 11,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -2.1013,
      "average_r": -0.2101,
      "median_r": -0.2162,
      "best_r": 0.1869,
      "worst_r": -0.5168,
      "average_mfe_r": -0.0709,
      "average_mae_r": -0.6146,
      "rank_a_count": 0,
      "rank_b_count": 11,
      "no_trade_count": 8,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 11,
      "recommended_action_no_trade_count": 8,
      "reliability_label": "negative"
    },
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 19,
      "evaluated_count": 11,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -2.1013,
      "average_r": -0.2101,
      "median_r": -0.2162,
      "best_r": 0.1869,
      "worst_r": -0.5168,
      "average_mfe_r": -0.0709,
      "average_mae_r": -0.6146,
      "rank_a_count": 0,
      "rank_b_count": 11,
      "no_trade_count": 8,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 11,
      "recommended_action_no_trade_count": 8,
      "reliability_label": "negative"
    }
  ],
  "over_filtering_candidates": [],
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 71,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "notes": [
    "reason_code単位のweights自動更新はまだ行いません。",
    "insufficient_data reason_codes: 7"
  ]
}
```
