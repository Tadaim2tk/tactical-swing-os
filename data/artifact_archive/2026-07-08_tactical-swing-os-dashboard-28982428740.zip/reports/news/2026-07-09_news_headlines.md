# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-09 08:19:23 JST
取得日時（UTC）: 2026-07-08 23:19:23 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.3
headline件数: 30

## 見出し

- [CNBC Markets] U.S. military launches new Iran strikes as Trump says 'not sure' he wants deal (未分類)
- [CNBC Markets] SpaceX stock closes below debut price at $148 in two-day slide after Nasdaq-100 inclusion (NASDAQ)
- [CNBC Markets] McConnell health update demanded by Gov. Beshear as Senate vacancy questions grow (未分類)
- [CNBC Markets] Trump announces long-shot bid to get Supreme Court to rehear birthright citizenship case (未分類)
- [CNBC Markets] Fed officials were split on direction of interest rates at last meeting, minutes show (US10Y|DXY)
- [CNBC Markets] Judge orders E. Jean Carroll be paid $5 million in damages from Trump verdict (未分類)
- [CNBC Markets] Levi Strauss beats quarterly expectations, raises guidance and dividend (未分類)
- [CNBC Markets] Trump says he doesn't want anything to do with Spain: 'Cut off all trade' (未分類)
- [CNBC Markets] Trump pours cold water on NATO allies' united front (未分類)
- [CNBC Markets] Michael Burry bets on sportsbooks DraftKings and Flutter, sees prediction markets curbed by regulation (SPX)
- [CNBC Markets] Jim Cramer sees a big risk to the bull market resurfacing — and it's not the Iran war (未分類)
- [CNBC Markets] Meta is building its first big Canadian data center as AI expansion crosses the border (未分類)
- [CNBC Markets] Delta launches 'basic business' fares without lounge access, seat selection (未分類)
- [CNBC Markets] Oil prices jump more than 4% after Trump threatens to bomb Iran and reimpose naval blockade (WTI)
- [CNBC Markets] Fed meeting minutes to show 'family fight' over rates. The squabble could drag on for a while (US10Y|DXY)
- [CNBC Markets] Rivian tailspin hasn't shaken one trader's resolve (未分類)
- [CNBC Markets] Few bright spots in Wednesday's tough market — why Nvidia stock is one of them (未分類)
- [CNBC Markets] Trump loses latest appeals court bid to restore his name to Kennedy Center (未分類)
- [CNBC Markets] Waymo to start driverless rides in 4 more U.S. markets as expansion accelerates (US10Y|DXY)
- [CNBC Markets] Used EVs keep getting more expensive amid Iran war, high gas prices (未分類)
- [CNBC Markets] Delaying Social Security reform raises risks for bond markets and the economy, research finds (US10Y)
- [CNBC Markets] The American Dream is missing one key ingredient, says Harvard happiness expert: Without it, 'life is pretty grim' (未分類)
- [CNBC Markets] Bezos' Blue Origin valued at $130 billion in first outside fundraising round (未分類)
- [CNBC Markets] Apple commits $30 billion to Broadcom for U.S. chipmaking push (NASDAQ)
- [CNBC Markets] Healthy Returns: Employers aren't expanding coverage of GLP-1 obesity drugs — many are finding ways around it (未分類)
- [CNBC Markets] OpenAI to publicly release GPT-5.6, rolls out conversational AI models (未分類)
- [CNBC Markets] China warns about AI risks with Anthropic's Claude Code (未分類)
- [CNBC Markets] Weekly mortgage demand drops as rates remain stuck in a narrow range (US10Y|DXY)
- [CNBC Markets] Strait of Hormuz traffic won't return to normal until 2027 after latest setback, Kalshi traders predict (未分類)
- [MarketWatch Top Stories] Levi’s is finding new ways to win customers — by looking toward tops and ‘denim luxury’ (SPX)
