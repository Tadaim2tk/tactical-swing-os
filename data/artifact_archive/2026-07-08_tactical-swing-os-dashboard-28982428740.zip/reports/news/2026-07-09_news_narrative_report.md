# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-09 08:19:24 JST
生成日時（UTC）: 2026-07-08 23:19:24 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.3
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 38.33
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 38.33
- inflation_pressure_news_score: 0.0
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 92.0

## Top News Drivers

- Jim Cramer sees a big risk to the bull market resurfacing — and it's not the Iran war (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Used EVs keep getting more expensive amid Iran war, high gas prices (地政学リスク / 金安全資産需要 / リスクオフ要因)
