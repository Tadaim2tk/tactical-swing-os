# Portfolio Layer

## 1. 概要

- 生成日時JST: 2026-07-11 16:20:00 JST
- portfolio_status: active
- candidate assets: 2
- defensive assets: 1
- offensive assets: 0
- cash candidate: 0.4618
- average confidence: 0.769
- portfolio concentration: 0.2982
- risk concentration: 0.0
- recommended exposure: 0.5382
- recommended next action: human_review_allocations
- requires_human_approval: true
- weights_json_updated: false
- patch_applied: false
- generate_signal_updated: false
- orders_created: false

## 2. Top Allocation Candidates

| asset | allocation_score | portfolio_weight_candidate | confidence | risk_class | risk_role | latest_rank | latest_side | rationale |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GOLD | 52.8 | 0.2982 | 0.8433 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=0.10 win_rate=1.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| USDJPY | 52.32 | 0.24 | 0.81 | medium | balanced |  |  | signal data unavailable; evaluation avg_r=0.04 win_rate=1.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| BTC | 39.09 | 0.0 | 0.86 | high | offensive |  |  | signal data unavailable; evaluation avg_r=-0.11 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| WTI | 40.96 | 0.0 | 0.8267 | high | offensive |  |  | signal data unavailable; evaluation avg_r=0.12 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| NASDAQ | 39.59 | 0.0 | 0.8433 | high | offensive |  |  | signal data unavailable; evaluation avg_r=-0.05 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| ETH | 40.0 | 0.0 | 0.35 | high | offensive |  |  | signal data unavailable; evaluation rows unavailable; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| SPX | 40.36 | 0.0 | 0.8267 | medium | offensive |  |  | signal data unavailable; evaluation avg_r=0.04 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| VIX | 39.84 | 0.0 | 0.7433 | high | defensive |  |  | signal data unavailable; evaluation avg_r=-0.02 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| DXY | 39.88 | 0.0 | 0.8267 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=-0.02 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| US10Y | 39.98 | 0.0 | 0.76 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=-0.00 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |

## 3. Risk Concentration

- high risk weight candidate: 0.0
- portfolio concentration: 0.2982
- cash ratio candidate: 0.4618

## 4. 注意事項

- Portfolio Layerは配分候補を生成するだけです
- 自動売買・自動発注・自動リバランスは行いません
- weights.jsonは更新しません
- generate_signal.pyは変更しません
- Google Sheetsへの書き込みは行いません
- すべての候補は人間承認が必須です
