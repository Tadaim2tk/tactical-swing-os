# Tactical Swing OS Rule Update Proposals

## 1. 結論

ルール改善候補を生成しました。自動反映は行いません。

対象期間: 2026-05-18 - 2026-06-16

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. 高優先度の改善候補

_該当なし_

## 3. reason_codeを強める候補

_該当なし_

## 4. reason_codeを弱める候補

_該当なし_

## 5. no_trade_reasonの見直し候補

_該当なし_

## 6. asset / side / rank の見直し候補

_該当なし_

## 7. データ不足の項目

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-16T02:51:04 | 2026-05-18 | 2026-06-16 | 20260616_reason_code_reason_codes_data_insufficient | data_insufficient | reason_code | reason_codes | DATA_INSUFFICIENT | 0 | 0.0 | 0.0 | 0.0 | 0 | reason_code_analysisが未生成または空 | Phase 6以降のSIGNALS/EVALUATIONSを蓄積して再分析 | 十分な根拠が集まるまで判断を保留 | 少数サンプルでは誤判定しやすい | False | 4 | reason_code単位の提案なし |

## 8. 自動反映しない理由

- 実売買には使わない
- weights.jsonは自動更新しない
- generate_signal.pyは自動変更しない
- closed評価が30〜50件以上溜まるまでは提案のみ

## 9. 次に人間が確認すべき点

- HIGH / MEDIUM の提案が特定assetやsideに偏っていないか
- no_trade_reason緩和で低品質シグナルが増えないか
- reason_codeの成績が一時的な相場環境に依存していないか

## 10. RULE_UPDATE_PROPOSALS CSV

```csv
generated_at,period_start,period_end,proposal_id,proposal_type,target_type,target_name,proposal_strength,evidence_count,win_rate,average_r,total_r,missed_opportunity_count,current_behavior,proposed_change,expected_effect,risk_note,apply_automatically,priority,notes
2026-06-16T02:51:04,2026-05-18,2026-06-16,20260616_reason_code_reason_codes_data_insufficient,data_insufficient,reason_code,reason_codes,DATA_INSUFFICIENT,0,0.0,0.0,0.0,0,reason_code_analysisが未生成または空,Phase 6以降のSIGNALS/EVALUATIONSを蓄積して再分析,十分な根拠が集まるまで判断を保留,少数サンプルでは誤判定しやすい,False,4,reason_code単位の提案なし
```

## 11. RULE_UPDATE_PROPOSALS JSON

```json
{
  "generated_at": "2026-06-16T02:51:04",
  "period_start": "2026-05-18",
  "period_end": "2026-06-16",
  "summary": {
    "proposal_count": 1,
    "high_priority_count": 0,
    "data_insufficient_count": 1,
    "apply_automatically": false
  },
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 30,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "proposals": [
    {
      "generated_at": "2026-06-16T02:51:04",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_reason_codes_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "reason_codes",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "reason_code_analysisが未生成または空",
      "proposed_change": "Phase 6以降のSIGNALS/EVALUATIONSを蓄積して再分析",
      "expected_effect": "十分な根拠が集まるまで判断を保留",
      "risk_note": "少数サンプルでは誤判定しやすい",
      "apply_automatically": false,
      "priority": 4,
      "notes": "reason_code単位の提案なし"
    }
  ],
  "high_priority_proposals": [],
  "data_insufficient_items": [
    {
      "generated_at": "2026-06-16T02:51:04",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_reason_codes_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "reason_codes",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "reason_code_analysisが未生成または空",
      "proposed_change": "Phase 6以降のSIGNALS/EVALUATIONSを蓄積して再分析",
      "expected_effect": "十分な根拠が集まるまで判断を保留",
      "risk_note": "少数サンプルでは誤判定しやすい",
      "apply_automatically": false,
      "priority": 4,
      "notes": "reason_code単位の提案なし"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動反映しない",
    "closed評価が30〜50件以上溜まるまでは提案のみ",
    "人間レビュー後に必要なら実装"
  ]
}
```
