# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-16 11:50:47 JST
生成日時（UTC）: 2026-06-16 02:50:47 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.19
ニュース市場バイアス: risk_off
ニュース矛盾スコア: 19.17
主要テーマ: gold_safe_haven, geopolitical_risk, risk_off
日本語要約: 金安全資産需要、地政学リスク、リスクオフ要因が優勢で、ニュース面では慎重姿勢が強い状態です。
ニュースモード: ニュースはリスクオフ寄り / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 19.17
- risk_off_news_score: 76.67
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 100.0
- oil_supply_risk_news_score: 38.33
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 95.83
- inflation_pressure_news_score: 19.17
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- China economy weakens further in May as retail sales post first drop in over three years (リスクオフ要因)
- The Iran deal came just in time as Strategic Petroleum Reserve hits lowest level since 1983 (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
- Trump trusts Fed Chair Kevin Warsh. It matters for more than interest rates (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Warsh's Fed is likely to hold rates steady — what the leadership change could mean for your money (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Sen. Warren asks Trump if administration plans to raise Social Security retirement age (地政学リスク / 金安全資産需要 / リスクオフ要因)
- How the Strait of Hormuz reopening could unfold if the U.S.-Iran deal is implemented (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
- CFTC chair Selig defends decision to approve ‘perps’ in U.S. (リスクオフ要因)
- Wall Street's fear gauge tumbles as traders bid up SpaceX shares (リスクオフ要因)
- Oil tumbles on US-Iran deal framework: How one trader is playing the move (リスクオン要因)
- Vance says U.S. expects Strait of Hormuz to be open 'toll free' long term (金安全資産需要)
