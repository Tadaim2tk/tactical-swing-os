# Narrative Reliability (SPEC-NQ-001)

## 1. 概要

- 生成日時JST: 2026-06-29 08:14:59 JST
- narrative_reliability_status: unavailable
- narrative_source: missing
- total_narratives: 0
- strong_positive: 0 / strong_negative: 0
- unproven: 0 / insufficient_data: 0
- decay_divergence: 0
- 適用ゲート: SPEC-SG-001 (n>=30, p<0.05, Sharpe>0.5 for positive)
- weights_json_updated: false / requires_human_approval: true

## 2. strong_positive (統計的に信頼できる追い風ナラティブ)

該当なし

## 3. strong_negative (統計的に信頼できる逆風ナラティブ)

該当なし

## 4. 未証明・データ不足

該当なし

## 5. 注意

- AIの文章分析(ナラティブ分類)はここで初めて統計的監査を受けます
- strong_positive/negativeは「人間レビュー用の候補」であり、weights.jsonは更新しません
- n>=30未満のナラティブは判断保留(insufficient_data)です
- 実売買・発注は行いません
