# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-29 08:14:33 JST
生成日時（UTC）: 2026-06-28 23:14:33 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.77
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 19.17
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 19.17
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 38.33
- inflation_pressure_news_score: 19.17
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- If you think China needs to dethrone U.S. dollar, you don't understand how it is waging global currency war (地政学リスク / 金安全資産需要 / リスクオフ要因)
- IRAs hold trillions more than 401(k) plans — yet people hardly save in them (リスクオフ要因)
- Oil prices rise, stock futures inch higher as U.S. and Iran trade more airstrikes (インフレ圧力 / 金利圧力候補)
- Russia stocks lower at close of trade; MOEX Russia Index unchanged (地政学リスク / リスクオフ要因)
