# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-29 08:14:33 JST
Actions実行時刻（UTC）: 2026-06-28 23:14:33 UTC
対象日: 2026-06-28
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 36.15
- risk_off: 39.37
- dollar: 35.1
- rate: 34.71
- volatility: 47.53
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=7, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 36.15 | 39.37 | 35.1 | 34.71 | 42.69 | 36.08 | 47.53 | 93.86 |
| DXY | 51.65 | 48.03 | 50.15 | 49.59 | 47.85 | 51.54 | 47.53 | 92.78 |
| GOLD | 51.65 | 48.03 | 50.15 | 49.59 | 47.85 | 51.54 | 47.53 | 92.78 |
| NASDAQ | 51.65 | 48.03 | 50.15 | 49.59 | 47.85 | 51.54 | 47.53 | 92.78 |
| SPX | 51.65 | 48.03 | 50.15 | 49.59 | 47.85 | 51.54 | 47.53 | 92.78 |
| US10Y | 51.65 | 48.03 | 50.15 | 49.59 | 47.85 | 51.54 | 47.53 | 92.78 |
| USDJPY | 51.65 | 48.03 | 50.15 | 49.59 | 47.85 | 51.54 | 47.53 | 92.78 |
| VIX | 51.65 | 48.03 | 50.15 | 49.59 | 47.85 | 51.54 | 47.53 | 92.78 |
| WTI | 51.65 | 48.03 | 50.15 | 49.59 | 47.85 | 51.54 | 47.53 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260628_BTC_SHORT_B-Watch | BTC | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold | neutral | 5 | BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260628_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260628_GOLD_NONE_NO_TRADE | GOLD | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260628_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | NO_TRADE | momentum_negative|atr_too_high|rr_too_low|range_middle|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260628_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | NO_TRADE | momentum_negative|rr_too_low|range_middle|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260628_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260628_WTI_SHORT_B-Watch | WTI | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold | neutral | 0 | WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり
- top_news_drivers: If you think China needs to dethrone U.S. dollar, you don't understand how it is waging global currency war, IRAs hold trillions more than 401(k) plans — yet people hardly save in them, Oil prices rise, stock futures inch higher as U.S. and Iran trade more airstrikes, Russia stocks lower at close of trade; MOEX Russia Index unchanged

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-28T23:14:33,2026-06-29 08:14:33 JST,2026-06-28 23:14:33 UTC,2026-06-28,BTC,20260628_BTC_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold,neutral,5,36.15,39.37,35.1,34.71,42.69,36.08,47.53,93.86,100.0,market_proxy_plus_news,,,context_neutral,BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,BTC SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-28T23:14:33,2026-06-29 08:14:33 JST,2026-06-28 23:14:33 UTC,2026-06-28,DXY,20260628_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|rr_too_low,neutral,0,36.15,39.37,35.1,34.71,42.69,36.08,47.53,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-28T23:14:33,2026-06-29 08:14:33 JST,2026-06-28 23:14:33 UTC,2026-06-28,GOLD,20260628_GOLD_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rr_too_low,neutral,0,36.15,39.37,35.1,34.71,42.69,36.08,47.53,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,GOLD NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-28T23:14:33,2026-06-29 08:14:33 JST,2026-06-28 23:14:33 UTC,2026-06-28,NASDAQ,20260628_NASDAQ_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|atr_too_high|rr_too_low|range_middle|pullback_to_ma20,neutral,0,36.15,39.37,35.1,34.71,42.69,36.08,47.53,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,NASDAQ NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-28T23:14:33,2026-06-29 08:14:33 JST,2026-06-28 23:14:33 UTC,2026-06-28,SPX,20260628_SPX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|rr_too_low|range_middle|pullback_to_ma20,neutral,0,36.15,39.37,35.1,34.71,42.69,36.08,47.53,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,SPX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-28T23:14:33,2026-06-29 08:14:33 JST,2026-06-28 23:14:33 UTC,2026-06-28,USDJPY,20260628_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,36.15,39.37,35.1,34.71,42.69,36.08,47.53,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-28T23:14:33,2026-06-29 08:14:33 JST,2026-06-28 23:14:33 UTC,2026-06-28,WTI,20260628_WTI_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold,neutral,0,36.15,39.37,35.1,34.71,42.69,36.08,47.53,93.86,100.0,market_proxy_plus_news,,,context_neutral,WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,WTI SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-28T23:14:33",
  "generated_at_jst": "2026-06-29 08:14:33 JST",
  "generated_at_utc": "2026-06-28 23:14:33 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-28",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "top_news_drivers": [
    {
      "title": "If you think China needs to dethrone U.S. dollar, you don't understand how it is waging global currency war",
      "source": "CNBC Markets",
      "matched_assets": "USDJPY|DXY",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/28/china-doesnt-need-to-de-throne-dollar-to-win-global-currency-war.html"
    },
    {
      "title": "IRAs hold trillions more than 401(k) plans — yet people hardly save in them",
      "source": "CNBC Markets",
      "matched_assets": "VIX",
      "matched_rules": "risk_off_news_score:fear",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/28/ira-money-401k-rollovers.html"
    },
    {
      "title": "Oil prices rise, stock futures inch higher as U.S. and Iran trade more airstrikes",
      "source": "MarketWatch Top Stories",
      "matched_assets": "WTI|VIX",
      "matched_rules": "inflation_pressure_news_score:prices rise",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.marketwatch.com/story/oil-prices-rise-stock-futures-inch-higher-as-u-s-and-iran-trade-more-airstrikes-3fc66beb?mod=mw_rss_topstories"
    },
    {
      "title": "Russia stocks lower at close of trade; MOEX Russia Index unchanged",
      "source": "Investing.com Commodities",
      "matched_assets": "SPX",
      "matched_rules": "geopolitical_risk_news_score:russia",
      "driver_tags": "geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオフ要因",
      "link": "https://www.investing.com/news/stock-market-news/russia-stocks-lower-at-close-of-trade-moex-russia-index-unchanged-4764170"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 36.15,
      "risk_off_score": 39.37,
      "dollar_strength_score": 35.1,
      "rate_pressure_score": 34.71,
      "gold_safe_haven_score": 42.69,
      "oil_supply_risk_proxy_score": 34.84,
      "crypto_liquidity_score": 36.08,
      "equity_momentum_score": 36.62,
      "volatility_stress_score": 47.53,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 0.0,
      "risk_off_news_score": 19.17,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 19.17,
      "oil_supply_risk_news_score": 0.0,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 38.33,
      "inflation_pressure_news_score": 19.17,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 51.65,
      "risk_off_score": 48.03,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 49.59,
      "gold_safe_haven_score": 47.85,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.54,
      "equity_momentum_score": 52.31,
      "volatility_stress_score": 47.53,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.001,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 51.65,
      "risk_off_score": 48.03,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 49.59,
      "gold_safe_haven_score": 47.85,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.54,
      "equity_momentum_score": 52.31,
      "volatility_stress_score": 47.53,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.5706,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 51.65,
      "risk_off_score": 48.03,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 49.59,
      "gold_safe_haven_score": 47.85,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.54,
      "equity_momentum_score": 52.31,
      "volatility_stress_score": 47.53,
      "narrative_confidence": 92.78,
      "asset_change_pct": 1.0066,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 51.65,
      "risk_off_score": 48.03,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 49.59,
      "gold_safe_haven_score": 47.85,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.54,
      "equity_momentum_score": 52.31,
      "volatility_stress_score": 47.53,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.5238,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 51.65,
      "risk_off_score": 48.03,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 49.59,
      "gold_safe_haven_score": 47.85,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.54,
      "equity_momentum_score": 52.31,
      "volatility_stress_score": 47.53,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.3646,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 51.65,
      "risk_off_score": 48.03,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 49.59,
      "gold_safe_haven_score": 47.85,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.54,
      "equity_momentum_score": 52.31,
      "volatility_stress_score": 47.53,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0569,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 51.65,
      "risk_off_score": 48.03,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 49.59,
      "gold_safe_haven_score": 47.85,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.54,
      "equity_momentum_score": 52.31,
      "volatility_stress_score": 47.53,
      "narrative_confidence": 92.78,
      "asset_change_pct": -6.5482,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 51.65,
      "risk_off_score": 48.03,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 49.59,
      "gold_safe_haven_score": 47.85,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.54,
      "equity_momentum_score": 52.31,
      "volatility_stress_score": 47.53,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.4823,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260628_BTC_SHORT_B-Watch",
      "asset": "BTC",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 5,
      "narrative_comment": "BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260628_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260628_GOLD_NONE_NO_TRADE",
      "asset": "GOLD",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260628_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|atr_too_high|rr_too_low|range_middle|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260628_SPX_NONE_NO_TRADE",
      "asset": "SPX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|rr_too_low|range_middle|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260628_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260628_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
