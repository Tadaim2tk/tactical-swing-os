# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-30 07:41:41 JST
生成日時（UTC）: 2026-06-29 22:41:41 UTC
headline件数: 73
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.51
ニュース市場バイアス: neutral
ニュース矛盾スコア: 18.48
主要テーマ: geopolitical_risk
日本語要約: 地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 36.96
- risk_off_news_score: 18.48
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 36.96
- oil_supply_risk_news_score: 18.48
- crypto_liquidity_news_score: 55.44
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 36.96
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Micron's monster post-earnings rally is almost gone. Traders divided on where it goes next (リスクオン要因)
- Oil prices near pre-war levels — but persistent supply risks could spark a rebound, analysts warn (地政学リスク / リスクオン要因 / 金安全資産需要 / リスクオフ要因)
- Oil prices rise as U.S. and Iran reach deal to halt attacks, U.S. oil above $70 per barrel again (地政学リスク / インフレ圧力 / 原油供給リスク / リスクオフ要因 / 金利圧力候補)
- Putin’s fuel shortage admission signals growing strain on Russia’s energy infrastructure (地政学リスク / リスクオフ要因)
- IRAs hold trillions more than 401(k) plans — yet people hardly save in them (リスクオフ要因)
- Op-ed: If you think China needs to dethrone U.S. dollar, you don't understand how it is waging global currency war (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Value stocks beat growth when inflation is high. Here are 13 stocks top newsletters are betting on now. (インフレ圧力 / 金利圧力候補)
- Ukraine transfers $8.3 million in seized crypto amid potential plans for strategic reserve (地政学リスク / リスクオフ要因)
- BlackRock pushes deeper into DeFi with Ethena integration, sending ENA up 8% (暗号資産流動性)
- Saylor's Strategy initiates buybacks and bitcoin monetization program, lifts STRC dividend (暗号資産流動性)
