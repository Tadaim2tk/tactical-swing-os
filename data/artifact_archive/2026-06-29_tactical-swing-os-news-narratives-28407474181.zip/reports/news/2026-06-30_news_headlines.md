# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-30 07:41:40 JST
取得日時（UTC）: 2026-06-29 22:41:40 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.51
headline件数: 73

## 見出し

- [CNBC Markets] Trump bought as much as $5 million in Axon stock before ICE sought $220 million Taser deal (NASDAQ|US10Y|DXY)
- [CNBC Markets] Eli Lilly, Regeneron among first companies selected for FDA initiative to speed review of new manufacturing facilities (未分類)
- [CNBC Markets] SpaceX bulls are back betting on huge, fast gains as Rocket Lab surges (未分類)
- [CNBC Markets] Industry lobbyists push House committee to block a ban on Pentagon defense contractors buying back their own stock (未分類)
- [CNBC Markets] Micron's monster post-earnings rally is almost gone. Traders divided on where it goes next (SPX|NASDAQ)
- [CNBC Markets] Supreme Court rulings on Fed, FTC: What they mean for consumers (US10Y|DXY)
- [CNBC Markets] IRS says Trump Account contributions will not trigger annual gift tax reporting requirements (US10Y|DXY)
- [CNBC Markets] Supreme Court lets presidents fire independent regulators, rules for Trump in FTC case (未分類)
- [CNBC Markets] Supreme Court rules Trump cannot fire Fed Governor Lisa Cook for now (US10Y|DXY)
- [CNBC Markets] Oil prices near pre-war levels — but persistent supply risks could spark a rebound, analysts warn (WTI)
- [CNBC Markets] Trump laments 'tremendous loss' on mail-in ballots at Supreme Court, doubles down on voter-ID bill (US10Y|DXY)
- [CNBC Markets] Comcast announces it will spin off NBCUniversal and Sky from cable business (未分類)
- [CNBC Markets] Comcast's NBCUniversal spinoff raises hope for more deals. There may not be good options (未分類)
- [CNBC Markets] Oil prices rise as U.S. and Iran reach deal to halt attacks, U.S. oil above $70 per barrel again (WTI)
- [CNBC Markets] This insurance stock is on an impressive run. How to ride the momentum with less risk (未分類)
- [CNBC Markets] Here's how Trump Accounts could affect women's retirement savings gap (未分類)
- [CNBC Markets] Salesforce is on an AI buying spree, but Wall Street still has its doubts (SPX)
- [CNBC Markets] Kalshi traders expect this week's jobs report will disappoint Wall Street outlook (SPX)
- [CNBC Markets] Trump says U.S. and Iran to hold fresh talks in Qatar on Tuesday following weekend clashes (未分類)
- [CNBC Markets] Putin’s fuel shortage admission signals growing strain on Russia’s energy infrastructure (未分類)
- [CNBC Markets] IRAs hold trillions more than 401(k) plans — yet people hardly save in them (VIX)
- [CNBC Markets] SpaceX's $25 billion bond sale drives huge demand - and a potential headache for investors (US10Y)
- [CNBC Markets] A 'perfect storm' points to a much smaller U.S. auto market by 2040 (未分類)
- [CNBC Markets] Op-ed: If you think China needs to dethrone U.S. dollar, you don't understand how it is waging global currency war (USDJPY|DXY)
- [CNBC Markets] The AI boom is colliding with a new threat: Severe weather (未分類)
- [CNBC Markets] Protein coffee? Brands cash in on functional beverage boom (未分類)
- [CNBC Markets] Seniors in Medicare are about to get landmark obesity drug coverage — but many may not know it yet (未分類)
- [CNBC Markets] ‘Heated Rivalry’ fuels a boom in gay romance stories, with women leading the fandom (未分類)
- [MarketWatch Top Stories] Trump’s weekend Iran strikes keep sparking Monday stock rallies. Here’s what the data shows us. (SPX)
- [MarketWatch Top Stories] ‘I don’t think I’ll make it to 80’: I’m 70 and single. Do I take out a reverse mortgage or a home-equity agreement? (未分類)
- [MarketWatch Top Stories] ‘I claimed Social Security at 62’: At 76, I’m working at Walmart. Why do I still owe payroll taxes? (未分類)
- [MarketWatch Top Stories] Rocket Lab to take on SpaceX’s Starlink with $8 billion acquisition (未分類)
- [MarketWatch Top Stories] Tesla’s stock rips higher after a long-awaited update to self-driving technology (NASDAQ)
- [MarketWatch Top Stories] Charter may be making ‘frenemies’ with SpaceX, and its stock is soaring (SPX)
- [MarketWatch Top Stories] Most Americans have no idea how close we just came to financial chaos (未分類)
- [MarketWatch Top Stories] Value stocks beat growth when inflation is high. Here are 13 stocks top newsletters are betting on now. (SPX)
- [MarketWatch Top Stories] Bye-bye, ‘HODL’: Strategy now has a plan to sell bitcoin to raise cash and buy its stock (BTC|USDJPY|DXY)
- [MarketWatch Top Stories] My sister died and I’m leaving New York to help raise my niece in Colorado. At 33, am I making a financial mistake? (未分類)
- [CoinDesk] Bitcoin lending is entering a new institutional era, according to Silicon Valley Bank (BTC)
- [CoinDesk] JPMorgan urges strong safeguards as congress weighs crypto market structure rules (BTC)
- [CoinDesk] Private keys, not smart contracts, caused 40% of crypto's $16 billion hack losses. Here's whats being done. (BTC)
- [CoinDesk] White House to speak with law enforcement groups to push Crypto's Clarity Act (BTC)
- [CoinDesk] J.P. Morgan broadens blockchain settlement network as banks modernize cross-border payments (USDJPY)
- [CoinDesk] Crypto analytics firm Chainalysis proposes standards for blockchain tracing (BTC)
- [CoinDesk] MiCA's looming deadline could leave 10 million crypto users without a platform in the EU (BTC)
- [CoinDesk] Ripple wants institutions to borrow against tokenized assets on XRPL (未分類)
- [CoinDesk] Wall Street's BNY expands stablecoin services for institutions, starting with Circle's USDC (SPX)
- [CoinDesk] Strategy opens door to selling billions of bitcoin under new capital plan. Here's what it means (BTC)
- [CoinDesk] Ukraine transfers $8.3 million in seized crypto amid potential plans for strategic reserve (BTC)
- [CoinDesk] BlackRock pushes deeper into DeFi with Ethena integration, sending ENA up 8% (US10Y)
