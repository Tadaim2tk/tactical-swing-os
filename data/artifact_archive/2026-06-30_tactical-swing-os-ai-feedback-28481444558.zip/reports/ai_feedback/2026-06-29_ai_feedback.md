# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-07-01 08:02:24 JST
Actions実行時刻（UTC）: 2026-06-30 23:02:24 UTC
対象日: 2026-06-29
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドルは中立 / 金利圧力は限定的 / ボラティリティは落ち着き
- ニュースモード: ニュースナラティブ未取得
- ニュース市場バイアス: insufficient_data
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_only
- 評価データソース: latest_evaluations
- latest_evaluations_available: True
- fallback_used: False
- risk_on: 51.05
- risk_off: 48.73
- dollar: 49.94
- rate: 49.98
- volatility: 48.36
- news_confidence: 0.0
- シグナル整合性: aligned=0, conflicted=0, neutral=9, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| DXY | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| GOLD | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| NASDAQ | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| SPX | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| US10Y | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| USDJPY | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| VIX | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| WTI | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260629_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260629_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260629_GOLD_SHORT_B-Watch | GOLD | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative | neutral | 3 | GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 |
| 20260629_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260629_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260629_US10Y_NONE_NO_TRADE | US10Y | NONE | NO_TRADE | NO_TRADE | momentum_negative|rsi_oversold|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260629_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260629_VIX_NONE_NO_TRADE | VIX | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260629_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
| 20260622_US10Y_LONG_A-Pullback | US10Y | loss_sl | -1.0 | 損切り到達。Entry/SL幅またはrank判定の再確認が必要です。 | unknown | 追加サンプルで検証します。 |
| 20260623_GOLD_SHORT_B-Watch | GOLD | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260623_US10Y_LONG_A-Pullback | US10Y | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260612_WTI_SHORT_B-Watch | WTI | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260605_US10Y_LONG_TREND | US10Y | loss_sl | -1.0 | 損切り到達。Entry/SL幅またはrank判定の再確認が必要です。 | unknown | 追加サンプルで検証します。 |
| 20260605_GOLD_SHORT_TREND | GOLD | win_tp1 | 1.087 | エントリー/方向判断は一定程度機能しました。 | unknown | 追加サンプルで検証します。 |
| 20260605_DXY_LONG_TREND | DXY | loss_sl | -1.0 | 損切り到達。Entry/SL幅またはrank判定の再確認が必要です。 | unknown | 追加サンプルで検証します。 |
| 20260605_USDJPY_LONG_TREND | USDJPY | win_tp1 | 1.087 | エントリー/方向判断は一定程度機能しました。 | unknown | 追加サンプルで検証します。 |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: False
- news_mode_summary: ニュースナラティブ未取得
- top_news_drivers: ニュースドライバーなし

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-30T23:02:24,2026-07-01 08:02:24 JST,2026-06-30 23:02:24 UTC,2026-06-29,BTC,20260629_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low,neutral,0,51.05,48.73,49.94,49.98,48.46,51.07,48.36,92.78,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-30T23:02:24,2026-07-01 08:02:24 JST,2026-06-30 23:02:24 UTC,2026-06-29,DXY,20260629_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rr_too_low,neutral,0,51.05,48.73,49.94,49.98,48.46,51.07,48.36,92.78,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-30T23:02:24,2026-07-01 08:02:24 JST,2026-06-30 23:02:24 UTC,2026-06-29,GOLD,20260629_GOLD_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative,neutral,3,51.05,48.73,49.94,49.98,48.46,51.07,48.36,92.78,0.0,market_proxy_only,open_unresolved,,context_neutral,GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。,GOLD SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-30T23:02:24,2026-07-01 08:02:24 JST,2026-06-30 23:02:24 UTC,2026-06-29,NASDAQ,20260629_NASDAQ_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20,neutral,0,51.05,48.73,49.94,49.98,48.46,51.07,48.36,92.78,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,NASDAQ NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-30T23:02:24,2026-07-01 08:02:24 JST,2026-06-30 23:02:24 UTC,2026-06-29,SPX,20260629_SPX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20,neutral,0,51.05,48.73,49.94,49.98,48.46,51.07,48.36,92.78,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,SPX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-30T23:02:24,2026-07-01 08:02:24 JST,2026-06-30 23:02:24 UTC,2026-06-29,US10Y,20260629_US10Y_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|rsi_oversold|rr_too_low,neutral,0,51.05,48.73,49.94,49.98,48.46,51.07,48.36,92.78,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,US10Y NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-30T23:02:24,2026-07-01 08:02:24 JST,2026-06-30 23:02:24 UTC,2026-06-29,USDJPY,20260629_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,51.05,48.73,49.94,49.98,48.46,51.07,48.36,92.78,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-30T23:02:24,2026-07-01 08:02:24 JST,2026-06-30 23:02:24 UTC,2026-06-29,VIX,20260629_VIX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low|pullback_to_ma20,neutral,0,51.05,48.73,49.94,49.98,48.46,51.07,48.36,92.78,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,VIX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-30T23:02:24,2026-07-01 08:02:24 JST,2026-06-30 23:02:24 UTC,2026-06-29,WTI,20260629_WTI_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low,neutral,0,51.05,48.73,49.94,49.98,48.46,51.07,48.36,92.78,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,WTI NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-30T23:02:24",
  "generated_at_jst": "2026-07-01 08:02:24 JST",
  "generated_at_utc": "2026-06-30 23:02:24 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-29",
  "data_source": "Google Sheets",
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 75,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "market_mode_summary": "リスクオン/オフは中立 / ドルは中立 / 金利圧力は限定的 / ボラティリティは落ち着き",
  "news_narrative_available": false,
  "news_mode_summary": "ニュースナラティブ未取得",
  "top_news_drivers": [],
  "narrative_source_mix": "market_proxy_only",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": null
    },
    {
      "asset": "DXY",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.2535
    },
    {
      "asset": "GOLD",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1265
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0317
    },
    {
      "asset": "SPX",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0367
    },
    {
      "asset": "US10Y",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0914
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0352
    },
    {
      "asset": "VIX",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -5.1075
    },
    {
      "asset": "WTI",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1278
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260629_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260629_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260629_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 3,
      "narrative_comment": "GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。"
    },
    {
      "signal_id": "20260629_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260629_SPX_NONE_NO_TRADE",
      "asset": "SPX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260629_US10Y_NONE_NO_TRADE",
      "asset": "US10Y",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|rsi_oversold|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260629_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260629_VIX_NONE_NO_TRADE",
      "asset": "VIX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260629_WTI_NONE_NO_TRADE",
      "asset": "WTI",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "signal_id": "20260622_US10Y_LONG_A-Pullback",
      "asset": "US10Y",
      "outcome": "loss_sl",
      "r_multiple": -1.0,
      "technical_view": "損切り到達。Entry/SL幅またはrank判定の再確認が必要です。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    },
    {
      "signal_id": "20260623_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260623_US10Y_LONG_A-Pullback",
      "asset": "US10Y",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260612_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260605_US10Y_LONG_TREND",
      "asset": "US10Y",
      "outcome": "loss_sl",
      "r_multiple": -1.0,
      "technical_view": "損切り到達。Entry/SL幅またはrank判定の再確認が必要です。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    },
    {
      "signal_id": "20260605_GOLD_SHORT_TREND",
      "asset": "GOLD",
      "outcome": "win_tp1",
      "r_multiple": 1.087,
      "technical_view": "エントリー/方向判断は一定程度機能しました。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    },
    {
      "signal_id": "20260605_DXY_LONG_TREND",
      "asset": "DXY",
      "outcome": "loss_sl",
      "r_multiple": -1.0,
      "technical_view": "損切り到達。Entry/SL幅またはrank判定の再確認が必要です。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    },
    {
      "signal_id": "20260605_USDJPY_LONG_TREND",
      "asset": "USDJPY",
      "outcome": "win_tp1",
      "r_multiple": 1.087,
      "technical_view": "エントリー/方向判断は一定程度機能しました。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
