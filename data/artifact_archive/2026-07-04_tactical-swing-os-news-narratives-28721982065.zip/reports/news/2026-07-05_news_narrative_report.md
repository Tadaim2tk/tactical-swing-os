# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-05 07:41:35 JST
生成日時（UTC）: 2026-07-04 22:41:35 UTC
headline件数: 67
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.01
ニュース市場バイアス: neutral
ニュース矛盾スコア: 18.52
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 18.52
- risk_off_news_score: 18.52
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 18.52
- gold_safe_haven_news_score: 37.04
- oil_supply_risk_news_score: 18.52
- crypto_liquidity_news_score: 37.04
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 55.57
- inflation_pressure_news_score: 37.04
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 18.52
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- 5 takeaways from President Donald Trump's interview with CNBC (金安全資産需要)
- UK and France agree with Oman to ensure safety of its territorial waters (地政学リスク / 原油供給リスク / リスクオフ要因)
- Gold prices set for first weekly rise in a month as investors scale back Fed rate hike bets (金利圧力候補 / 中銀タカ派)
- Why June’s jobs and inflation data are bullish for bonds (インフレ圧力 / 金利圧力候補)
- How ethical hackers with just a $3,000 server found a flaw that could've put $70 billion in crypto at risk (地政学リスク / リスクオフ要因)
- UK's bold new crypto rules promise to unlock global trading, but huge compliance hurdles still threaten the rollout (暗号資産流動性)
- Live updates: Bitcoin rises above $62,000 as the red hot semiconductor trade starts to fade (暗号資産流動性)
- Ether and solana extend gains as a short squeeze lifts bitcoin toward $62,000 (リスクオン要因)
- Russia stocks lower at close of trade; MOEX Russia Index unchanged (地政学リスク / リスクオフ要因)
- Is AI inflation transitory? (インフレ圧力 / 金利圧力候補)
