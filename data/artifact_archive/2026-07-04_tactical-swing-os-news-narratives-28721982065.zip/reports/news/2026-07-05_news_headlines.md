# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-05 07:41:33 JST
取得日時（UTC）: 2026-07-04 22:41:33 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.01
headline件数: 67

## 見出し

- [CNBC Markets] First known congressional SpaceX stock buys surface after record IPO (US10Y|DXY)
- [CNBC Markets] The World Cup sends prediction market volumes soaring to record highs (未分類)
- [CNBC Markets] Iran begins six-day funeral for Ayatollah Khamenei nearly four months after his death (未分類)
- [CNBC Markets] 5 takeaways from President Donald Trump's interview with CNBC (未分類)
- [CNBC Markets] UK and France agree with Oman to ensure safety of its territorial waters (未分類)
- [CNBC Markets] Feds seek lower prison term for $100M New Jersey deli fraudster — but some reasons why are hidden (US10Y|DXY)
- [CNBC Markets] From Macron to Modi, governments are rolling out the red carpet for AI giants (NASDAQ)
- [CNBC Markets] I’ve worked with over 5,000 kids: I swear by this No. 1 parenting rule—it’s ‘surprisingly simple’ (SPX)
- [CNBC Markets] Oman walks a diplomatic tightrope over Strait of Hormuz fees, creating a ‘blind spot’ for markets (WTI)
- [CNBC Markets] The hunt for AI's next winners defined the stock market's holiday-shortened week (SPX)
- [CNBC Markets] American Express and Chase move luxury lounge wars beyond the airport (未分類)
- [CNBC Markets] Ford achieves quality milestone, as CEO targets flawless new vehicle launches (SPX|NASDAQ)
- [CNBC Markets] Extreme heat wave threatens U.S. power grids and July 4 travel (未分類)
- [CNBC Markets] Trump’s Freedom 250 draws corporate sponsors with business before his administration (US10Y|DXY)
- [CNBC Markets] Acting DNI Pulte fires dozens of intelligence officials: MS Now (未分類)
- [CNBC Markets] As ACA enrollment falls by millions, Trump administration and policy gurus disagree on why (未分類)
- [CNBC Markets] Don't throw away your shot to speak to an AI Alexander Hamilton at Boston's new finance museum (未分類)
- [CNBC Markets] Gold prices set for first weekly rise in a month as investors scale back Fed rate hike bets (GOLD|US10Y|DXY)
- [CNBC Markets] Venezuela quake toll climbs to 2,595 as damage estimates mount after strongest tremor in a century (未分類)
- [CNBC Markets] Manhattan luxury real estate sales hold firm despite fears of a 'Mamdani effect' (VIX)
- [CNBC Markets] AI is outpacing the rules, Europe’s top bankers and regulators warn (未分類)
- [CNBC Markets] Rafael Nadal talks tennis prize money, his hotels, and what sports taught him about business (未分類)
- [CNBC Markets] Christine Lagarde leaves door open to early ECB exit, as she mulls French politics (未分類)
- [CNBC Markets] Safe havens aren't behaving like they used to. Here's what's changed (GOLD|USDJPY|US10Y|DXY|VIX)
- [MarketWatch Top Stories] Gamer trades in $1,000 of physical discs at GameStop, days after Sony announces end of disc era (未分類)
- [MarketWatch Top Stories] ‘She wants him gone’: My friend took in a homeless man as a caretaker. After 10 years, how can she evict him? (未分類)
- [MarketWatch Top Stories] Here’s what’s worth streaming in July 2026 on Netflix, Hulu, HBO Max and more (BTC)
- [MarketWatch Top Stories] Why a founder at age 50 is twice as likely to find success as one at age 30 (未分類)
- [MarketWatch Top Stories] Why June’s jobs and inflation data are bullish for bonds (US10Y)
- [MarketWatch Top Stories] Insurers shifted roof-replacement costs onto homeowners thanks to a new federal rule — just in time for hail and hurricane season (US10Y|DXY)
- [MarketWatch Top Stories] Where can I invest my kid’s ‘Trump account’ money? The Treasury Department just answered that question. (US10Y|DXY)
- [MarketWatch Top Stories] Jelly Roll’s ex-wife Bunnie Xo says he gave her their $6 million Tennessee estate in divorce (未分類)
- [MarketWatch Top Stories] Want to live longer in retirement? This one money move could add years to your life. (未分類)
- [MarketWatch Top Stories] I have no kids. Will I cause family drama by leaving different amounts to my nieces and nephews? (未分類)
- [CoinDesk] Tokenization's next use case is personalized portfolios, NYLIM executive says (未分類)
- [CoinDesk] Bitcoin jumps above $63,000, reversing end-June losses (BTC)
- [CoinDesk] Bitcoin experts split over plan to freeze Satoshi's 1.1 million bitcoin as quantum threat grows (BTC)
- [CoinDesk] How ethical hackers with just a $3,000 server found a flaw that could've put $70 billion in crypto at risk (BTC|USDJPY|DXY)
- [CoinDesk] Why bitcoin's disconnect from record-high stocks won't last (BTC|SPX)
- [CoinDesk] Trump's crypto token buyers are down $3.8 billion, blockchain data shows (BTC)
- [CoinDesk] Europe led on crypto regulation. Now implementation must match ambition (BTC)
- [CoinDesk] EU moves to block retail investors from explosive boom of multibillion-dollar prediction markets (USDJPY|DXY)
- [CoinDesk] UK's bold new crypto rules promise to unlock global trading, but huge compliance hurdles still threaten the rollout (BTC)
- [CoinDesk] XRP climbs 8% as record holder losses signal better risk-reward for buyers (未分類)
- [CoinDesk] Bitcoin’s next parabolic run may need $1 trillion in fresh capital (BTC)
- [CoinDesk] This sanctioned Russian stablecoin claims it processes billions, but blockchain analysts disagree (BTC)
- [CoinDesk] Trump says there is ‘nothing wrong’ with family’s crypto windfall (BTC)
- [CoinDesk] Bitcoin whales bought $16.7 billion of bitcoin in 2 weeks even as ETFs bled a record $4 billion (BTC)
- [CoinDesk] Bitcoin, ether traders aren't fully buying the bounce, options markets show (BTC)
- [CoinDesk] Crypto bulls on firmer footing as U.S. rate-hike risk recedes (BTC|US10Y|DXY)
