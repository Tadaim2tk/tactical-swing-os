# Tactical Swing OS Weekly Review

## 1. 週次結論

次週モードは「通常」、最大日次リスクは 0.5% です。 データ不足 週次R損益は横ばいです。

## 2. 週次サマリー

| week_start | week_end | total_signals | a_signals | b_signals | no_trade_signals | closed_signals | pending_signals | skipped_signals | win_rate | profit_factor | total_r | average_r | max_win_r | max_loss_r | best_asset | worst_asset | next_week_mode | max_daily_risk_pct | rule_change_1 | rule_change_2 | rule_change_3 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-05-31 | 2026-06-06 | 19 | 0 | 9 | 10 | 0 | 4 | 5 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | BTC | BTC | 通常 | 0.5 | 評価期間またはentry条件の見直し | データ不足 |  |

## 3. Rank別成績

| rank | signals | closed | win_rate | total_r | average_r |
| --- | --- | --- | --- | --- | --- |
| A | 0 | 0 | 0.0 | 0.0 | 0.0 |
| B | 9 | 0 | 0.0 | 0.0 | 0.0 |
| NO_TRADE | 10 | 0 | 0.0 | 0.0 | 0.0 |
| その他 | 0 | 0 | 0.0 | 0.0 | 0.0 |

## 4. 資産別成績

| asset | signals | closed | win_rate | total_r | average_r | best_r | worst_r |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BTC | 3 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| DXY | 2 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| GOLD | 2 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| NASDAQ | 2 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| SPX | 2 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| US10Y | 2 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| USDJPY | 2 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| VIX | 2 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| WTI | 2 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |

## 5. Side別成績

| side | signals | closed | win_rate | total_r | average_r | best_r | worst_r |
| --- | --- | --- | --- | --- | --- | --- | --- |
| LONG | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| SHORT | 3 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| NONE | 10 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |

## 6. エラー分類

| error_type | count |
| --- | --- |
| 未分類 | 9 |

## 7. 取り逃し監査

MFE候補はありません

| missed_candidate | asset | count | note |
| --- | --- | --- | --- |
| pending_or_skipped_ab | DXY | 1 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | GOLD | 1 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | US10Y | 1 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | USDJPY | 1 | A/B候補の未完了評価が多い可能性 |

## 8. モデル更新メモ

- 評価期間またはentry条件の見直し
- データ不足
- 特記事項なし

## 9. REVIEW_LOG CSV

```csv
week_start,week_end,total_signals,a_signals,b_signals,no_trade_signals,closed_signals,pending_signals,skipped_signals,win_rate,profit_factor,total_r,average_r,max_win_r,max_loss_r,best_asset,worst_asset,next_week_mode,max_daily_risk_pct,rule_change_1,rule_change_2,rule_change_3
2026-05-31,2026-06-06,19,0,9,10,0,4,5,0.0,0.0,0.0,0.0,0.0,0.0,BTC,BTC,通常,0.5,評価期間またはentry条件の見直し,データ不足,
```

## 10. REVIEW_LOG JSON

```json
[
  {
    "week_start":"2026-05-31",
    "week_end":"2026-06-06",
    "total_signals":19,
    "a_signals":0,
    "b_signals":9,
    "no_trade_signals":10,
    "closed_signals":0,
    "pending_signals":4,
    "skipped_signals":5,
    "win_rate":0.0,
    "profit_factor":0.0,
    "total_r":0.0,
    "average_r":0.0,
    "max_win_r":0.0,
    "max_loss_r":0.0,
    "best_asset":"BTC",
    "worst_asset":"BTC",
    "next_week_mode":"通常",
    "max_daily_risk_pct":0.5,
    "rule_change_1":"評価期間またはentry条件の見直し",
    "rule_change_2":"データ不足",
    "rule_change_3":""
  }
]
```
