# Tactical Swing OS Rule Update Proposals

## 1. 結論

ルール改善候補を生成しました。自動反映は行いません。

対象期間: 2026-06-13 - 2026-07-12

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. 高優先度の改善候補

_該当なし_

## 3. reason_codeを強める候補

_該当なし_

## 4. reason_codeを弱める候補

_該当なし_

## 5. no_trade_reasonの見直し候補

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-12T06:16:36 | 2026-06-13 | 2026-07-12 | 20260712_no_trade_reason_data_insufficient_data_insufficient | data_insufficient | no_trade_reason | data_insufficient | DATA_INSUFFICIENT | 2 | 0.0 | 0.0 | 0.0 | 0 | data_insufficient: correct=0, missed=2, avg_mfe_r=0.00 | 見送り理由の件数が少ないため監視継続 | 誤ったフィルター調整を避ける | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | insufficient_data |
| 2026-07-12T06:16:36 | 2026-06-13 | 2026-07-12 | 20260712_no_trade_reason_low_volatility_data_insufficient | data_insufficient | no_trade_reason | low_volatility | DATA_INSUFFICIENT | 27 | 0.0741 | 0.0 | 0.0 | 0 | low_volatility: correct=2, missed=20, avg_mfe_r=0.00 | 追加データを待つ | 判断保留 | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | over_filtering_risk |
| 2026-07-12T06:16:36 | 2026-06-13 | 2026-07-12 | 20260712_no_trade_reason_rr_too_low_data_insufficient | data_insufficient | no_trade_reason | rr_too_low | DATA_INSUFFICIENT | 89 | 0.382 | 0.0 | 0.0 | 0 | rr_too_low: correct=34, missed=43, avg_mfe_r=0.00 | 追加データを待つ | 判断保留 | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | over_filtering_risk |

## 6. asset / side / rank の見直し候補

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-12T06:16:36 | 2026-06-13 | 2026-07-12 | 20260712_rank_A_data_insufficient | data_insufficient | rank | A | DATA_INSUFFICIENT | 4 | 0.0 | 0.0364 | 0.1455 | 0 | rank=A avg_r=0.0364 | 評価件数不足のため監視継続 | 過剰調整を避ける | カテゴリ単位の調整は相場環境依存に注意 | False | 4 | group performance review |

## 7. データ不足の項目

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-12T06:16:36 | 2026-06-13 | 2026-07-12 | 20260712_no_trade_reason_data_insufficient_data_insufficient | data_insufficient | no_trade_reason | data_insufficient | DATA_INSUFFICIENT | 2 | 0.0 | 0.0 | 0.0 | 0 | data_insufficient: correct=0, missed=2, avg_mfe_r=0.00 | 見送り理由の件数が少ないため監視継続 | 誤ったフィルター調整を避ける | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | insufficient_data |
| 2026-07-12T06:16:36 | 2026-06-13 | 2026-07-12 | 20260712_no_trade_reason_low_volatility_data_insufficient | data_insufficient | no_trade_reason | low_volatility | DATA_INSUFFICIENT | 27 | 0.0741 | 0.0 | 0.0 | 0 | low_volatility: correct=2, missed=20, avg_mfe_r=0.00 | 追加データを待つ | 判断保留 | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | over_filtering_risk |
| 2026-07-12T06:16:36 | 2026-06-13 | 2026-07-12 | 20260712_no_trade_reason_rr_too_low_data_insufficient | data_insufficient | no_trade_reason | rr_too_low | DATA_INSUFFICIENT | 89 | 0.382 | 0.0 | 0.0 | 0 | rr_too_low: correct=34, missed=43, avg_mfe_r=0.00 | 追加データを待つ | 判断保留 | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | over_filtering_risk |
| 2026-07-12T06:16:36 | 2026-06-13 | 2026-07-12 | 20260712_rank_A_data_insufficient | data_insufficient | rank | A | DATA_INSUFFICIENT | 4 | 0.0 | 0.0364 | 0.1455 | 0 | rank=A avg_r=0.0364 | 評価件数不足のため監視継続 | 過剰調整を避ける | カテゴリ単位の調整は相場環境依存に注意 | False | 4 | group performance review |
| 2026-07-12T06:16:36 | 2026-06-13 | 2026-07-12 | 20260712_reason_code_data_insufficient_data_insufficient | data_insufficient | reason_code | data_insufficient | DATA_INSUFFICIENT | 2 | 0.0 | 0.0 | 0.0 | 0 | data_insufficient は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |

## 8. 自動反映しない理由

- 実売買には使わない
- weights.jsonは自動更新しない
- generate_signal.pyは自動変更しない
- closed評価が30〜50件以上溜まるまでは提案のみ

## 9. 次に人間が確認すべき点

- HIGH / MEDIUM の提案が特定assetやsideに偏っていないか
- no_trade_reason緩和で低品質シグナルが増えないか
- reason_codeの成績が一時的な相場環境に依存していないか

## 10. RULE_UPDATE_PROPOSALS CSV

```csv
generated_at,period_start,period_end,proposal_id,proposal_type,target_type,target_name,proposal_strength,evidence_count,win_rate,average_r,total_r,missed_opportunity_count,current_behavior,proposed_change,expected_effect,risk_note,apply_automatically,priority,notes
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_atr_too_high_monitor_reason_code,monitor_reason_code,reason_code,atr_too_high,LOW,33,0.0,-0.0334,-1.0697,0,atr_too_high は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_atr_too_low_monitor_reason_code,monitor_reason_code,reason_code,atr_too_low,LOW,28,0.0,-0.0116,-0.3253,0,atr_too_low は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_breakout_down_monitor_reason_code,monitor_reason_code,reason_code,breakout_down,LOW,12,0.0,0.0867,0.954,0,breakout_down は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_breakout_up_monitor_reason_code,monitor_reason_code,reason_code,breakout_up,LOW,7,0.0,0.0256,0.1538,0,breakout_up は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_ma_alignment_bear_monitor_reason_code,monitor_reason_code,reason_code,ma_alignment_bear,LOW,64,0.0,-0.0069,-0.4377,0,ma_alignment_bear は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_ma_alignment_bull_monitor_reason_code,monitor_reason_code,reason_code,ma_alignment_bull,LOW,81,0.0,0.0021,0.1623,0,ma_alignment_bull は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_momentum_negative_monitor_reason_code,monitor_reason_code,reason_code,momentum_negative,LOW,102,0.0,0.0155,1.5611,0,momentum_negative は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_momentum_positive_monitor_reason_code,monitor_reason_code,reason_code,momentum_positive,LOW,73,0.0,-0.023,-1.6356,0,momentum_positive は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_overextended_monitor_reason_code,monitor_reason_code,reason_code,overextended,LOW,26,0.0,0.073,1.8992,0,overextended は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_pullback_to_ma20_monitor_reason_code,monitor_reason_code,reason_code,pullback_to_ma20,LOW,49,0.0,0.0315,1.5127,0,pullback_to_ma20 は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_range_middle_monitor_reason_code,monitor_reason_code,reason_code,range_middle,LOW,35,0.0,-0.0106,-0.3695,0,range_middle は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_rr_too_low_monitor_reason_code,monitor_reason_code,reason_code,rr_too_low,LOW,116,0.0,0.0,0.0,0,rr_too_low は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_rsi_overbought_monitor_reason_code,monitor_reason_code,reason_code,rsi_overbought,LOW,25,0.0,0.0051,0.1277,0,rsi_overbought は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_rsi_oversold_monitor_reason_code,monitor_reason_code,reason_code,rsi_oversold,LOW,20,0.0,-0.0546,-1.0928,0,rsi_oversold は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_trend_down_monitor_reason_code,monitor_reason_code,reason_code,trend_down,LOW,64,0.0,-0.0069,-0.4377,0,trend_down は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_trend_up_monitor_reason_code,monitor_reason_code,reason_code,trend_up,LOW,81,0.0,0.0021,0.1623,0,trend_up は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_no_trade_reason_data_insufficient_data_insufficient,data_insufficient,no_trade_reason,data_insufficient,DATA_INSUFFICIENT,2,0.0,0.0,0.0,0,"data_insufficient: correct=0, missed=2, avg_mfe_r=0.00",見送り理由の件数が少ないため監視継続,誤ったフィルター調整を避ける,NO_TRADE緩和はノイズ取引増加に注意,False,4,insufficient_data
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_no_trade_reason_low_volatility_data_insufficient,data_insufficient,no_trade_reason,low_volatility,DATA_INSUFFICIENT,27,0.0741,0.0,0.0,0,"low_volatility: correct=2, missed=20, avg_mfe_r=0.00",追加データを待つ,判断保留,NO_TRADE緩和はノイズ取引増加に注意,False,4,over_filtering_risk
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_no_trade_reason_rr_too_low_data_insufficient,data_insufficient,no_trade_reason,rr_too_low,DATA_INSUFFICIENT,89,0.382,0.0,0.0,0,"rr_too_low: correct=34, missed=43, avg_mfe_r=0.00",追加データを待つ,判断保留,NO_TRADE緩和はノイズ取引増加に注意,False,4,over_filtering_risk
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_rank_A_data_insufficient,data_insufficient,rank,A,DATA_INSUFFICIENT,4,0.0,0.0364,0.1455,0,rank=A avg_r=0.0364,評価件数不足のため監視継続,過剰調整を避ける,カテゴリ単位の調整は相場環境依存に注意,False,4,group performance review
2026-07-12T06:16:36,2026-06-13,2026-07-12,20260712_reason_code_data_insufficient_data_insufficient,data_insufficient,reason_code,data_insufficient,DATA_INSUFFICIENT,2,0.0,0.0,0.0,0,data_insufficient は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
```

## 11. RULE_UPDATE_PROPOSALS JSON

```json
{
  "generated_at": "2026-07-12T06:16:36",
  "period_start": "2026-06-13",
  "period_end": "2026-07-12",
  "summary": {
    "proposal_count": 21,
    "high_priority_count": 0,
    "data_insufficient_count": 5,
    "apply_automatically": false
  },
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 251,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "proposals": [
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_atr_too_high_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "atr_too_high",
      "proposal_strength": "LOW",
      "evidence_count": 33,
      "win_rate": 0.0,
      "average_r": -0.0334,
      "total_r": -1.0697,
      "missed_opportunity_count": 0,
      "current_behavior": "atr_too_high は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_atr_too_low_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "atr_too_low",
      "proposal_strength": "LOW",
      "evidence_count": 28,
      "win_rate": 0.0,
      "average_r": -0.0116,
      "total_r": -0.3253,
      "missed_opportunity_count": 0,
      "current_behavior": "atr_too_low は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_breakout_down_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "breakout_down",
      "proposal_strength": "LOW",
      "evidence_count": 12,
      "win_rate": 0.0,
      "average_r": 0.0867,
      "total_r": 0.954,
      "missed_opportunity_count": 0,
      "current_behavior": "breakout_down は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_breakout_up_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "breakout_up",
      "proposal_strength": "LOW",
      "evidence_count": 7,
      "win_rate": 0.0,
      "average_r": 0.0256,
      "total_r": 0.1538,
      "missed_opportunity_count": 0,
      "current_behavior": "breakout_up は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_ma_alignment_bear_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "ma_alignment_bear",
      "proposal_strength": "LOW",
      "evidence_count": 64,
      "win_rate": 0.0,
      "average_r": -0.0069,
      "total_r": -0.4377,
      "missed_opportunity_count": 0,
      "current_behavior": "ma_alignment_bear は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_ma_alignment_bull_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "ma_alignment_bull",
      "proposal_strength": "LOW",
      "evidence_count": 81,
      "win_rate": 0.0,
      "average_r": 0.0021,
      "total_r": 0.1623,
      "missed_opportunity_count": 0,
      "current_behavior": "ma_alignment_bull は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_momentum_negative_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "momentum_negative",
      "proposal_strength": "LOW",
      "evidence_count": 102,
      "win_rate": 0.0,
      "average_r": 0.0155,
      "total_r": 1.5611,
      "missed_opportunity_count": 0,
      "current_behavior": "momentum_negative は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_momentum_positive_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "momentum_positive",
      "proposal_strength": "LOW",
      "evidence_count": 73,
      "win_rate": 0.0,
      "average_r": -0.023,
      "total_r": -1.6356,
      "missed_opportunity_count": 0,
      "current_behavior": "momentum_positive は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_overextended_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "overextended",
      "proposal_strength": "LOW",
      "evidence_count": 26,
      "win_rate": 0.0,
      "average_r": 0.073,
      "total_r": 1.8992,
      "missed_opportunity_count": 0,
      "current_behavior": "overextended は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_pullback_to_ma20_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "pullback_to_ma20",
      "proposal_strength": "LOW",
      "evidence_count": 49,
      "win_rate": 0.0,
      "average_r": 0.0315,
      "total_r": 1.5127,
      "missed_opportunity_count": 0,
      "current_behavior": "pullback_to_ma20 は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_range_middle_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "range_middle",
      "proposal_strength": "LOW",
      "evidence_count": 35,
      "win_rate": 0.0,
      "average_r": -0.0106,
      "total_r": -0.3695,
      "missed_opportunity_count": 0,
      "current_behavior": "range_middle は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_rr_too_low_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "rr_too_low",
      "proposal_strength": "LOW",
      "evidence_count": 116,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_rsi_overbought_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "rsi_overbought",
      "proposal_strength": "LOW",
      "evidence_count": 25,
      "win_rate": 0.0,
      "average_r": 0.0051,
      "total_r": 0.1277,
      "missed_opportunity_count": 0,
      "current_behavior": "rsi_overbought は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_rsi_oversold_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "rsi_oversold",
      "proposal_strength": "LOW",
      "evidence_count": 20,
      "win_rate": 0.0,
      "average_r": -0.0546,
      "total_r": -1.0928,
      "missed_opportunity_count": 0,
      "current_behavior": "rsi_oversold は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_trend_down_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "trend_down",
      "proposal_strength": "LOW",
      "evidence_count": 64,
      "win_rate": 0.0,
      "average_r": -0.0069,
      "total_r": -0.4377,
      "missed_opportunity_count": 0,
      "current_behavior": "trend_down は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_trend_up_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "trend_up",
      "proposal_strength": "LOW",
      "evidence_count": 81,
      "win_rate": 0.0,
      "average_r": 0.0021,
      "total_r": 0.1623,
      "missed_opportunity_count": 0,
      "current_behavior": "trend_up は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_no_trade_reason_data_insufficient_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "data_insufficient",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "data_insufficient: correct=0, missed=2, avg_mfe_r=0.00",
      "proposed_change": "見送り理由の件数が少ないため監視継続",
      "expected_effect": "誤ったフィルター調整を避ける",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_no_trade_reason_low_volatility_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "low_volatility",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 27,
      "win_rate": 0.0741,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "low_volatility: correct=2, missed=20, avg_mfe_r=0.00",
      "proposed_change": "追加データを待つ",
      "expected_effect": "判断保留",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "over_filtering_risk"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_no_trade_reason_rr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "rr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 89,
      "win_rate": 0.382,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low: correct=34, missed=43, avg_mfe_r=0.00",
      "proposed_change": "追加データを待つ",
      "expected_effect": "判断保留",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "over_filtering_risk"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_rank_A_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "rank",
      "target_name": "A",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 4,
      "win_rate": 0.0,
      "average_r": 0.0364,
      "total_r": 0.1455,
      "missed_opportunity_count": 0,
      "current_behavior": "rank=A avg_r=0.0364",
      "proposed_change": "評価件数不足のため監視継続",
      "expected_effect": "過剰調整を避ける",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_data_insufficient_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "data_insufficient",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "data_insufficient は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    }
  ],
  "high_priority_proposals": [],
  "data_insufficient_items": [
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_no_trade_reason_data_insufficient_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "data_insufficient",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "data_insufficient: correct=0, missed=2, avg_mfe_r=0.00",
      "proposed_change": "見送り理由の件数が少ないため監視継続",
      "expected_effect": "誤ったフィルター調整を避ける",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_no_trade_reason_low_volatility_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "low_volatility",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 27,
      "win_rate": 0.0741,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "low_volatility: correct=2, missed=20, avg_mfe_r=0.00",
      "proposed_change": "追加データを待つ",
      "expected_effect": "判断保留",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "over_filtering_risk"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_no_trade_reason_rr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "rr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 89,
      "win_rate": 0.382,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low: correct=34, missed=43, avg_mfe_r=0.00",
      "proposed_change": "追加データを待つ",
      "expected_effect": "判断保留",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "over_filtering_risk"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_rank_A_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "rank",
      "target_name": "A",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 4,
      "win_rate": 0.0,
      "average_r": 0.0364,
      "total_r": 0.1455,
      "missed_opportunity_count": 0,
      "current_behavior": "rank=A avg_r=0.0364",
      "proposed_change": "評価件数不足のため監視継続",
      "expected_effect": "過剰調整を避ける",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-12T06:16:36",
      "period_start": "2026-06-13",
      "period_end": "2026-07-12",
      "proposal_id": "20260712_reason_code_data_insufficient_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "data_insufficient",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "data_insufficient は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動反映しない",
    "closed評価が30〜50件以上溜まるまでは提案のみ",
    "人間レビュー後に必要なら実装"
  ]
}
```
