# Tactical Swing OS Reason Code Analysis

## 1. 結論

reason_codesの有効性を集計しました。

対象期間: 2026-06-13 - 2026-07-12

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. reason_codes 上位プラス要因

_該当なし_

## 3. reason_codes 上位マイナス要因

_該当なし_

## 4. no_trade_reason 分析

| no_trade_reason | count | no_trade_correct_count | no_trade_missed_count | missed_opportunity_count | average_mfe_r | average_r | assessment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rr_too_low | 89 | 34 | 43 | 0 | 0.0 | 0.0 | over_filtering_risk |
| low_volatility | 27 | 2 | 20 | 0 | 0.0 | 0.0 | over_filtering_risk |
| data_insufficient | 2 | 0 | 2 | 0 | 0.0 | 0.0 | insufficient_data |

## 5. 取り逃し候補

| no_trade_reason | count | no_trade_correct_count | no_trade_missed_count | missed_opportunity_count | average_mfe_r | average_r | assessment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rr_too_low | 89 | 34 | 43 | 0 | 0.0 | 0.0 | over_filtering_risk |
| low_volatility | 27 | 2 | 20 | 0 | 0.0 | 0.0 | over_filtering_risk |

## 6. 改善候補

_該当なし_

## 7. データ不足の注意

reason_codeごとの評価件数が5件未満の場合は `insufficient_data` とし、weights.jsonは自動更新しません。

## 8. REASON_CODE_ANALYSIS CSV

```csv
reason_code,signals_count,evaluated_count,win_count,loss_count,no_entry_count,missed_opportunity_count,win_rate,total_r,average_r,median_r,best_r,worst_r,average_mfe_r,average_mae_r,rank_a_count,rank_b_count,no_trade_count,recommended_action_trade_count,recommended_action_watch_count,recommended_action_no_trade_count,reliability_label
breakout_down,12,12,0,0,0,0,0.0,0.954,0.0867,0.0,0.4435,-0.1807,0.2549,-0.14,0,9,3,0,9,3,neutral
overextended,26,26,0,0,0,0,0.0,1.8992,0.073,0.0,0.4435,-0.1807,0.2464,-0.2195,2,13,11,2,13,11,neutral
pullback_to_ma20,49,49,0,1,0,0,0.0,1.5127,0.0315,0.0,0.892,-1.0,0.5103,-0.5394,1,16,32,1,16,32,neutral
breakout_up,7,7,0,0,0,0,0.0,0.1538,0.0256,0.0341,0.3176,-0.2089,0.3517,-0.1926,1,6,0,1,6,0,neutral
momentum_negative,102,102,0,1,0,0,0.0,1.5611,0.0155,0.0,0.892,-1.0,0.3364,-0.3142,2,39,61,2,39,61,neutral
rsi_overbought,25,25,0,0,0,0,0.0,0.1277,0.0051,0.0,0.3176,-0.2089,0.4051,-0.1975,1,4,20,1,4,20,neutral
ma_alignment_bull,81,81,0,1,0,0,0.0,0.1623,0.0021,0.0,0.892,-1.0,0.3588,-0.4673,1,36,44,1,36,44,neutral
trend_up,81,81,0,1,0,0,0.0,0.1623,0.0021,0.0,0.892,-1.0,0.3588,-0.4673,1,36,44,1,36,44,neutral
rr_too_low,116,116,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,116,0,0,116,neutral
data_insufficient,2,2,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,2,0,0,2,insufficient_data
ma_alignment_bear,64,64,0,0,0,0,0.0,-0.4377,-0.0069,0.0,0.4435,-0.618,0.2529,-0.2929,3,29,32,3,29,32,neutral
trend_down,64,64,0,0,0,0,0.0,-0.4377,-0.0069,0.0,0.4435,-0.618,0.2529,-0.2929,3,29,32,3,29,32,neutral
range_middle,35,35,0,1,0,0,0.0,-0.3695,-0.0106,0.0,0.892,-1.0,1.0642,-0.7958,0,4,31,0,4,31,neutral
atr_too_low,28,28,0,0,0,0,0.0,-0.3253,-0.0116,0.0,0.0,-0.3253,0.5012,-0.3733,1,0,27,1,0,27,neutral
momentum_positive,73,73,0,0,0,0,0.0,-1.6356,-0.023,0.0,0.3176,-0.9626,0.2821,-0.478,1,24,48,1,24,48,neutral
atr_too_high,33,33,0,0,0,0,0.0,-1.0697,-0.0334,0.0,0.1979,-0.4707,0.2034,-0.5401,0,19,14,0,19,14,neutral
rsi_oversold,20,20,0,0,0,0,0.0,-1.0928,-0.0546,-0.0153,0.3693,-0.618,0.1655,-0.2652,0,13,7,0,13,7,neutral
```

## 9. REASON_CODE_ANALYSIS JSON

```json
{
  "start_date": "2026-06-13",
  "end_date": "2026-07-12",
  "reason_code_summary": [
    {
      "reason_code": "breakout_down",
      "signals_count": 12,
      "evaluated_count": 12,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.954,
      "average_r": 0.0867,
      "median_r": 0.0,
      "best_r": 0.4435,
      "worst_r": -0.1807,
      "average_mfe_r": 0.2549,
      "average_mae_r": -0.14,
      "rank_a_count": 0,
      "rank_b_count": 9,
      "no_trade_count": 3,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 9,
      "recommended_action_no_trade_count": 3,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "overextended",
      "signals_count": 26,
      "evaluated_count": 26,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 1.8992,
      "average_r": 0.073,
      "median_r": 0.0,
      "best_r": 0.4435,
      "worst_r": -0.1807,
      "average_mfe_r": 0.2464,
      "average_mae_r": -0.2195,
      "rank_a_count": 2,
      "rank_b_count": 13,
      "no_trade_count": 11,
      "recommended_action_trade_count": 2,
      "recommended_action_watch_count": 13,
      "recommended_action_no_trade_count": 11,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "pullback_to_ma20",
      "signals_count": 49,
      "evaluated_count": 49,
      "win_count": 0,
      "loss_count": 1,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 1.5127,
      "average_r": 0.0315,
      "median_r": 0.0,
      "best_r": 0.892,
      "worst_r": -1.0,
      "average_mfe_r": 0.5103,
      "average_mae_r": -0.5394,
      "rank_a_count": 1,
      "rank_b_count": 16,
      "no_trade_count": 32,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 16,
      "recommended_action_no_trade_count": 32,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "breakout_up",
      "signals_count": 7,
      "evaluated_count": 7,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.1538,
      "average_r": 0.0256,
      "median_r": 0.0341,
      "best_r": 0.3176,
      "worst_r": -0.2089,
      "average_mfe_r": 0.3517,
      "average_mae_r": -0.1926,
      "rank_a_count": 1,
      "rank_b_count": 6,
      "no_trade_count": 0,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "momentum_negative",
      "signals_count": 102,
      "evaluated_count": 102,
      "win_count": 0,
      "loss_count": 1,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 1.5611,
      "average_r": 0.0155,
      "median_r": 0.0,
      "best_r": 0.892,
      "worst_r": -1.0,
      "average_mfe_r": 0.3364,
      "average_mae_r": -0.3142,
      "rank_a_count": 2,
      "rank_b_count": 39,
      "no_trade_count": 61,
      "recommended_action_trade_count": 2,
      "recommended_action_watch_count": 39,
      "recommended_action_no_trade_count": 61,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rsi_overbought",
      "signals_count": 25,
      "evaluated_count": 25,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.1277,
      "average_r": 0.0051,
      "median_r": 0.0,
      "best_r": 0.3176,
      "worst_r": -0.2089,
      "average_mfe_r": 0.4051,
      "average_mae_r": -0.1975,
      "rank_a_count": 1,
      "rank_b_count": 4,
      "no_trade_count": 20,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 4,
      "recommended_action_no_trade_count": 20,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 81,
      "evaluated_count": 81,
      "win_count": 0,
      "loss_count": 1,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.1623,
      "average_r": 0.0021,
      "median_r": 0.0,
      "best_r": 0.892,
      "worst_r": -1.0,
      "average_mfe_r": 0.3588,
      "average_mae_r": -0.4673,
      "rank_a_count": 1,
      "rank_b_count": 36,
      "no_trade_count": 44,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 36,
      "recommended_action_no_trade_count": 44,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 81,
      "evaluated_count": 81,
      "win_count": 0,
      "loss_count": 1,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.1623,
      "average_r": 0.0021,
      "median_r": 0.0,
      "best_r": 0.892,
      "worst_r": -1.0,
      "average_mfe_r": 0.3588,
      "average_mae_r": -0.4673,
      "rank_a_count": 1,
      "rank_b_count": 36,
      "no_trade_count": 44,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 36,
      "recommended_action_no_trade_count": 44,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rr_too_low",
      "signals_count": 116,
      "evaluated_count": 116,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 116,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 116,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "data_insufficient",
      "signals_count": 2,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 2,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 2,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "ma_alignment_bear",
      "signals_count": 64,
      "evaluated_count": 64,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.4377,
      "average_r": -0.0069,
      "median_r": 0.0,
      "best_r": 0.4435,
      "worst_r": -0.618,
      "average_mfe_r": 0.2529,
      "average_mae_r": -0.2929,
      "rank_a_count": 3,
      "rank_b_count": 29,
      "no_trade_count": 32,
      "recommended_action_trade_count": 3,
      "recommended_action_watch_count": 29,
      "recommended_action_no_trade_count": 32,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_down",
      "signals_count": 64,
      "evaluated_count": 64,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.4377,
      "average_r": -0.0069,
      "median_r": 0.0,
      "best_r": 0.4435,
      "worst_r": -0.618,
      "average_mfe_r": 0.2529,
      "average_mae_r": -0.2929,
      "rank_a_count": 3,
      "rank_b_count": 29,
      "no_trade_count": 32,
      "recommended_action_trade_count": 3,
      "recommended_action_watch_count": 29,
      "recommended_action_no_trade_count": 32,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "range_middle",
      "signals_count": 35,
      "evaluated_count": 35,
      "win_count": 0,
      "loss_count": 1,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.3695,
      "average_r": -0.0106,
      "median_r": 0.0,
      "best_r": 0.892,
      "worst_r": -1.0,
      "average_mfe_r": 1.0642,
      "average_mae_r": -0.7958,
      "rank_a_count": 0,
      "rank_b_count": 4,
      "no_trade_count": 31,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 4,
      "recommended_action_no_trade_count": 31,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "atr_too_low",
      "signals_count": 28,
      "evaluated_count": 28,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.3253,
      "average_r": -0.0116,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": -0.3253,
      "average_mfe_r": 0.5012,
      "average_mae_r": -0.3733,
      "rank_a_count": 1,
      "rank_b_count": 0,
      "no_trade_count": 27,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 27,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "momentum_positive",
      "signals_count": 73,
      "evaluated_count": 73,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.6356,
      "average_r": -0.023,
      "median_r": 0.0,
      "best_r": 0.3176,
      "worst_r": -0.9626,
      "average_mfe_r": 0.2821,
      "average_mae_r": -0.478,
      "rank_a_count": 1,
      "rank_b_count": 24,
      "no_trade_count": 48,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 24,
      "recommended_action_no_trade_count": 48,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "atr_too_high",
      "signals_count": 33,
      "evaluated_count": 33,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.0697,
      "average_r": -0.0334,
      "median_r": 0.0,
      "best_r": 0.1979,
      "worst_r": -0.4707,
      "average_mfe_r": 0.2034,
      "average_mae_r": -0.5401,
      "rank_a_count": 0,
      "rank_b_count": 19,
      "no_trade_count": 14,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 19,
      "recommended_action_no_trade_count": 14,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rsi_oversold",
      "signals_count": 20,
      "evaluated_count": 20,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.0928,
      "average_r": -0.0546,
      "median_r": -0.0153,
      "best_r": 0.3693,
      "worst_r": -0.618,
      "average_mfe_r": 0.1655,
      "average_mae_r": -0.2652,
      "rank_a_count": 0,
      "rank_b_count": 13,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 13,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "neutral"
    }
  ],
  "no_trade_reason_summary": [
    {
      "no_trade_reason": "rr_too_low",
      "count": 89,
      "no_trade_correct_count": 34,
      "no_trade_missed_count": 43,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "over_filtering_risk"
    },
    {
      "no_trade_reason": "low_volatility",
      "count": 27,
      "no_trade_correct_count": 2,
      "no_trade_missed_count": 20,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "over_filtering_risk"
    },
    {
      "no_trade_reason": "data_insufficient",
      "count": 2,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 2,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "insufficient_data"
    }
  ],
  "top_positive_reasons": [],
  "top_negative_reasons": [],
  "over_filtering_candidates": [
    {
      "no_trade_reason": "rr_too_low",
      "count": 89,
      "no_trade_correct_count": 34,
      "no_trade_missed_count": 43,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "over_filtering_risk"
    },
    {
      "no_trade_reason": "low_volatility",
      "count": 27,
      "no_trade_correct_count": 2,
      "no_trade_missed_count": 20,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "over_filtering_risk"
    }
  ],
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 251,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "notes": [
    "reason_code単位のweights自動更新はまだ行いません。",
    "insufficient_data reason_codes: 1"
  ]
}
```
