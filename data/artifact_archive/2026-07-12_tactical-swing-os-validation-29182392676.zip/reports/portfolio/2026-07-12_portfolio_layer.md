# Portfolio Layer

## 1. 概要

- 生成日時JST: 2026-07-12 15:16:41 JST
- portfolio_status: active
- candidate assets: 2
- defensive assets: 1
- offensive assets: 0
- cash candidate: 0.46
- average confidence: 0.8393
- portfolio concentration: 0.3
- risk concentration: 0.0
- recommended exposure: 0.54
- recommended next action: human_review_allocations
- requires_human_approval: true
- weights_json_updated: false
- patch_applied: false
- generate_signal_updated: false
- orders_created: false

## 2. Top Allocation Candidates

| asset | allocation_score | portfolio_weight_candidate | confidence | risk_class | risk_role | latest_rank | latest_side | rationale |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GOLD | 52.83 | 0.3 | 0.9 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=0.10 win_rate=1.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| USDJPY | 52.32 | 0.24 | 0.9 | medium | balanced |  |  | signal data unavailable; evaluation avg_r=0.04 win_rate=1.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| BTC | 39.12 | 0.0 | 0.9 | high | offensive |  |  | signal data unavailable; evaluation avg_r=-0.11 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| WTI | 40.97 | 0.0 | 0.9 | high | offensive |  |  | signal data unavailable; evaluation avg_r=0.12 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| NASDAQ | 39.58 | 0.0 | 0.9 | high | offensive |  |  | signal data unavailable; evaluation avg_r=-0.05 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| ETH | 40.0 | 0.0 | 0.35 | high | offensive |  |  | signal data unavailable; evaluation rows unavailable; meta learning unavailable; auto calibration rows=0; human override rows=0; proposal impact unavailable; market snapshot unavailable |
| SPX | 40.34 | 0.0 | 0.9 | medium | offensive |  |  | signal data unavailable; evaluation avg_r=0.04 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| VIX | 39.84 | 0.0 | 0.8633 | high | defensive |  |  | signal data unavailable; evaluation avg_r=-0.02 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| DXY | 39.88 | 0.0 | 0.9 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=-0.02 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| US10Y | 39.98 | 0.0 | 0.88 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=-0.00 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |

## 3. Risk Concentration

- high risk weight candidate: 0.0
- portfolio concentration: 0.3
- cash ratio candidate: 0.46

## 4. 注意事項

- Portfolio Layerは配分候補を生成するだけです
- 自動売買・自動発注・自動リバランスは行いません
- weights.jsonは更新しません
- generate_signal.pyは変更しません
- Google Sheetsへの書き込みは行いません
- すべての候補は人間承認が必須です
