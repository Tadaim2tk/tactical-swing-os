# Tactical Swing OS Monthly Calibration

## 1. 月次結論

翌月モードは「通常」、最大日次リスクは 0.5% です。データ不足。

## 2. 月次サマリー

| month_start | month_end | total_signals | closed_signals | pending_signals | skipped_signals | win_rate | profit_factor | total_r | average_r | max_win_r | max_loss_r | best_asset | worst_asset | best_rank | worst_rank | best_side | worst_side | next_month_mode | max_daily_risk_pct | weight_change_summary | rule_change_1 | rule_change_2 | rule_change_3 | evaluation_source | latest_evaluations_available | fallback_used |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-13 | 2026-07-12 | 188 | 1 | 69 | 118 | 0.0 | 0.0 | -1.0 | -1.0 | -1.0 | -1.0 | BTC | US10Y | A | B | SHORT | LONG | 通常 | 0.5 | 変更提案なし | closed評価10件未満のため自動適用しない | Entry/SL/Rank判定の見直し | データ不足 | latest_evaluations | True | False |

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 3. 資産別較正

| asset | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BTC | 26 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| DXY | 21 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| GOLD | 21 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| NASDAQ | 23 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| SPX | 21 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| US10Y | 17 | 1 | 0.0 | -1.0 | -1.0 | -1.0 | 0.97 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=1 < 30) |
| USDJPY | 20 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| VIX | 18 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| WTI | 21 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

## 4. Rank別較正

| rank | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | 4 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| B | 66 | 1 | 0.0 | -1.0 | -1.0 | -1.0 | 0.97 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=1 < 30) |
| NO_TRADE | 118 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

## 5. Side別較正

| side | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| LONG | 37 | 1 | 0.0 | -1.0 | -1.0 | -1.0 | 0.97 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=1 < 30) |
| SHORT | 33 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| NONE | 118 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

## 6. レジーム別較正 (SPEC-RD-001)

| regime | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| UPTREND | 81 | 1 | 0.0 | -1.0 | -1.0 | -1.0 | 0.97 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=1 < 30) |
| DOWNTREND | 64 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| RANGE | 41 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| UNKNOWN | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

- decayed_avg_r: 半減期90日の指数減衰加重平均R(直近の成績ほど重い)
- effective_n: 減衰後の実効サンプル数
- decay_divergence: True = 全期間平均と直近加重平均の符号が逆。レジームシフトの兆候として人間が確認すること

decay_divergenceは検出されていません。

## 7. ナラティブ信頼性 (SPEC-NQ-001)

| narrative_alignment | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| aligned | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| conflicted | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| neutral | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| insufficient_data | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

- 整合判定はシグナル発生時点に記録された値のみを使用(追記専用・後知恵バイアス防止)
- 重み変更提案はSPEC-SG-001と同一ゲート(n>=30, p<0.05, 増加はSharpe>0.5)に従う

ナラティブ優位性検定: データ不足 (aligned n=0, conflicted n=0, 必要数: 各30)。判定保留。

## 8. 翌月の暫定モード

- next_month_mode: 通常
- max_daily_risk_pct: 0.5

## 9. 重み変更案

変更提案なし

## 10. 据え置き理由

weights.jsonは初期値のまま据え置きます。今回の出力は提案のみで、自動更新は行いません。

## 11. データ不足の注意

closed評価が30件未満、または統計的有意性(p < 0.05)が確認できない区分には、重み変更を提案しません。weights.jsonの自動適用は引き続き行いません。(SPEC-SG-001)

## 12. Reason Code較正メモ

reason_code分析は未生成です。別artifact生成後に月次較正メモへ反映されます。

### strong_positive reason_codes

_該当なし_

### strong_negative reason_codes

_該当なし_

## 13. MONTHLY_CALIBRATION_LOG CSV

```csv
month_start,month_end,total_signals,closed_signals,pending_signals,skipped_signals,win_rate,profit_factor,total_r,average_r,max_win_r,max_loss_r,best_asset,worst_asset,best_rank,worst_rank,best_side,worst_side,next_month_mode,max_daily_risk_pct,weight_change_summary,rule_change_1,rule_change_2,rule_change_3,evaluation_source,latest_evaluations_available,fallback_used
2026-06-13,2026-07-12,188,1,69,118,0.0,0.0,-1.0,-1.0,-1.0,-1.0,BTC,US10Y,A,B,SHORT,LONG,通常,0.5,変更提案なし,closed評価10件未満のため自動適用しない,Entry/SL/Rank判定の見直し,データ不足,latest_evaluations,True,False
```

## 14. MONTHLY_CALIBRATION_LOG JSON

```json
[
  {
    "month_start": "2026-06-13",
    "month_end": "2026-07-12",
    "total_signals": 188,
    "closed_signals": 1,
    "pending_signals": 69,
    "skipped_signals": 118,
    "win_rate": 0.0,
    "profit_factor": 0.0,
    "total_r": -1.0,
    "average_r": -1.0,
    "max_win_r": -1.0,
    "max_loss_r": -1.0,
    "best_asset": "BTC",
    "worst_asset": "US10Y",
    "best_rank": "A",
    "worst_rank": "B",
    "best_side": "SHORT",
    "worst_side": "LONG",
    "next_month_mode": "通常",
    "max_daily_risk_pct": 0.5,
    "weight_change_summary": "変更提案なし",
    "rule_change_1": "closed評価10件未満のため自動適用しない",
    "rule_change_2": "Entry/SL/Rank判定の見直し",
    "rule_change_3": "データ不足",
    "evaluation_source": "latest_evaluations",
    "latest_evaluations_available": true,
    "fallback_used": false,
    "asset_calibration": [
      {
        "asset": "BTC",
        "signals": 26,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "DXY",
        "signals": 21,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "GOLD",
        "signals": 21,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "NASDAQ",
        "signals": 23,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "SPX",
        "signals": 21,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "US10Y",
        "signals": 17,
        "closed": 1,
        "win_rate": 0.0,
        "total_r": -1.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 0.97,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "asset": "USDJPY",
        "signals": 20,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "VIX",
        "signals": 18,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "WTI",
        "signals": 21,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "rank_calibration": [
      {
        "rank": "A",
        "signals": 4,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "rank": "B",
        "signals": 66,
        "closed": 1,
        "win_rate": 0.0,
        "total_r": -1.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 0.97,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "rank": "NO_TRADE",
        "signals": 118,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "side_calibration": [
      {
        "side": "LONG",
        "signals": 37,
        "closed": 1,
        "win_rate": 0.0,
        "total_r": -1.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 0.97,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "side": "SHORT",
        "signals": 33,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "side": "NONE",
        "signals": 118,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "regime_calibration": [
      {
        "regime": "UPTREND",
        "signals": 81,
        "closed": 1,
        "win_rate": 0.0,
        "total_r": -1.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 0.97,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "regime": "DOWNTREND",
        "signals": 64,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "regime": "RANGE",
        "signals": 41,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "regime": "UNKNOWN",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "narrative_calibration": [
      {
        "narrative_alignment": "aligned",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "narrative_alignment": "conflicted",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "narrative_alignment": "neutral",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "narrative_alignment": "insufficient_data",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "narrative_edge": {
      "aligned_n": 0,
      "conflicted_n": 0,
      "aligned_avg_r": 0.0,
      "conflicted_avg_r": 0.0,
      "mean_diff": 0.0,
      "t_stat": 0.0,
      "p_value": 1.0,
      "welch_df": 0.0,
      "verdict": "insufficient_data"
    },
    "decay_half_life_days": 90,
    "proposed_weight_changes": {
      "asset": [
        {
          "asset": "BTC",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "DXY",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "GOLD",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "NASDAQ",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "SPX",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "US10Y",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=1 < 30)"
        },
        {
          "asset": "USDJPY",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "VIX",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "WTI",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        }
      ],
      "rank": [
        {
          "rank": "A",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "rank": "B",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=1 < 30)"
        },
        {
          "rank": "NO_TRADE",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        }
      ],
      "side": [
        {
          "side": "LONG",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=1 < 30)"
        },
        {
          "side": "SHORT",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "side": "NONE",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        }
      ]
    }
  }
]
```
