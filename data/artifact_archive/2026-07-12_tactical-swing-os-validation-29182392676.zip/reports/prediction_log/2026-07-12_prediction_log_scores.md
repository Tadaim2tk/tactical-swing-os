# Prediction Log 遡及採点（全判断の後日検証 / Phase 29.6）

- 生成日時JST: 2026-07-12 15:16:22 JST
- 対象: data/signal_log.csv の**全行**（A/B/NO_TRADE・side NONE 含む）
- 原則: 全ての判断を記録し採点する（見送りも学習サンプル）。reference/risk は判断時の記録値のみ（反後知恵）。

## 1. ランク別集計

| rank | 行数 | actionable | 5d勝率 | 10d勝率 | 平均R(5d) | 統計的根拠 |
| --- | --- | --- | --- | --- | --- | --- |
| A | 5 | 5 | 60% (3/5) | 40% (2/5) | -0.5753 | insufficient_data |
| B | 64 | 48 | 67% (26/39) | 64% (14/22) | 0.7892 | ok |
| NO_TRADE | 62 | 0 | — | — | — | insufficient_data |

- n<30 は insufficient_data（件数と勝敗は正直に表示するが、優位性の判断材料にはまだしない）。
- side NONE / NO_TRADE 行は方向Rを持たない（not_applicable）が、+1/3/5/10営業日の実リターンは
  data/prediction_log_scores.csv に記録済み — 「見送った後に何が起きたか」を後日検証できる。

## 2. 全行の採点

| date | signal_id | asset | side | rank | +5営業日R | +10営業日R | 5d | 10d | entry充足 | status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-08 | 20260608_BTC_SHORT_A-MOMENTUM | BTC | SHORT | B | 0.14 | 0.53 | success | success | Y | scored |
| 2026-06-08 | 20260608_GOLD_NONE_NO_TRADE | GOLD | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-08 | 20260608_NASDAQ_LONG_A-PULLBACK | NASDAQ | LONG | B | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-08 | 20260608_USDJPY_LONG_A-MOMENTUM | USDJPY | LONG | B | -0.02 | 0.65 | failure | success | Y | scored |
| 2026-06-08 | 20260608_WTI_LONG_A-MOMENTUM | WTI | LONG | A | -3.65 | -5.42 | failure | failure | — | scored |
| 2026-06-09 | 20260609_BTC_SHORT_B-PULLBACK | BTC | SHORT | B | 0.06 | 0.98 | success | success | Y | scored |
| 2026-06-09 | 20260609_ETH_NONE_NO_TRADE | ETH | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | invalid_data |
| 2026-06-09 | 20260609_GOLD_NONE_NO_TRADE | GOLD | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-09 | 20260609_NASDAQ_LONG_B-PULLBACK | NASDAQ | LONG | B | — | — | suspect_data | suspect_data | — | scored |
| 2026-06-09 | 20260609_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-09 | 20260609_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-09 | 20260609_WTI_LONG_B-MOMENTUM | WTI | LONG | B | -5.41 | -6.91 | failure | failure | — | scored |
| 2026-06-16 | 20260616_BTC_NONE | BTC | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-16 | 20260616_DXY_NONE | DXY | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-16 | 20260616_ETH_NONE | ETH | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | invalid_data |
| 2026-06-16 | 20260616_GOLD_NONE | GOLD | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-16 | 20260616_NASDAQ_LONG_PULLBACK | NASDAQ | LONG | B | — | — | suspect_data | suspect_data | — | scored |
| 2026-06-16 | 20260616_US10Y_NONE | US10Y | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-16 | 20260616_USDJPY_SHORT_PULLBACK | USDJPY | SHORT | B | -1.82 | -2.43 | failure | failure | Y | scored |
| 2026-06-16 | 20260616_VIX_NONE | VIX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-16 | 20260616_WTI_SHORT_PULLBACK | WTI | SHORT | B | 5.03 | 5.79 | success | success | — | scored |
| 2026-06-17 | 20260617_BTC_NONE | BTC | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-17 | 20260617_GOLD_NONE | GOLD | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-17 | 20260617_NASDAQ_LONG_PULLBACK | NASDAQ | LONG | B | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-17 | 20260617_USDJPY_SHORT_PULLBACK | USDJPY | SHORT | B | -1.33 | -3.05 | failure | failure | Y | scored |
| 2026-06-17 | 20260617_WTI_SHORT_MOMENTUM | WTI | SHORT | B | 1.53 | 2.77 | success | success | Y | scored |
| 2026-06-18 | 20260618_NASDAQ_LONG_PULLBACK | NASDAQ | LONG | B | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-18 | 20260618_USDJPY_SHORT_PULLBACK | USDJPY | SHORT | B | -1.56 | -2.75 | failure | failure | — | scored |
| 2026-06-18 | 20260618_WTI_SHORT_MOMENTUM | WTI | SHORT | A | 2.30 | 2.56 | success | success | Y | scored |
| 2026-06-19 | 20260619_BTC_SHORT_A-MOMENTUM | BTC | SHORT | A | 1.49 | 2.04 | success | success | Y | scored |
| 2026-06-19 | 20260619_ETH_NONE_NO_TRADE | ETH | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | invalid_data |
| 2026-06-19 | 20260619_GOLD_NONE_NO_TRADE | GOLD | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-19 | 20260619_QQQ_LONG_B-MOMENTUM | QQQ | LONG | B | — | — | not_applicable | not_applicable | — | invalid_data |
| 2026-06-19 | 20260619_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-19 | 20260619_USDJPY_LONG_B-MOMENTUM | USDJPY | LONG | B | 0.62 | 0.16 | success | success | Y | scored |
| 2026-06-19 | 20260619_WTI_SHORT_B-PULLBACK | WTI | SHORT | B | 7.52 | 8.14 | success | success | Y | scored |
| 2026-06-20 | 20260620_BTC_SHORT_A_PULLBACK | BTC | SHORT | B | 2.32 | 2.92 | success | success | Y | scored |
| 2026-06-20 | 20260620_NO_TRADE | NONE | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | invalid_data |
| 2026-06-20 | 20260620_WTI_LONG_A_MOMENTUM | WTI | LONG | B | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-21 | 20260621_BTC_SHORT_A_PULLBACK | BTC | SHORT | B | 2.07 | 2.07 | success | success | Y | scored |
| 2026-06-21 | 20260621_ETH_SHORT_A_PULLBACK | ETH | SHORT | B | — | — | not_applicable | not_applicable | — | invalid_data |
| 2026-06-21 | 20260621_NO_TRADE | NONE | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | invalid_data |
| 2026-06-22 | 20260622_BTC_SHORT_B-PULLBACK | BTC | SHORT | B | 4.53 | 3.19 | success | success | — | scored |
| 2026-06-22 | 20260622_DXY_NONE_REGIME | DXY | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-22 | 20260622_ETH_NONE_NO_TRADE | ETH | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | invalid_data |
| 2026-06-22 | 20260622_GOLD_LONG_B-MOMENTUM | GOLD | LONG | B | -3.87 | -0.59 | failure | failure | — | scored |
| 2026-06-22 | 20260622_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-22 | 20260622_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-22 | 20260622_US10Y_NONE_REGIME | US10Y | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-22 | 20260622_USDJPY_LONG_B-MOMENTUM | USDJPY | LONG | B | 1.80 | 1.38 | success | success | — | scored |
| 2026-06-22 | 20260622_VIX_NONE_REGIME | VIX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-22 | 20260622_WTI_LONG_A-MOMENTUM | WTI | LONG | A | -5.07 | -5.29 | failure | failure | — | scored |
| 2026-06-23 | 20260623_BTC_SHORT_B-PULLBACK | BTC | SHORT | B | 2.93 | 1.39 | success | success | — | scored |
| 2026-06-23 | 20260623_GOLD_SHORT_B-PULLBACK | GOLD | SHORT | B | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-23 | 20260623_USDJPY_LONG_B-MOMENTUM | USDJPY | LONG | B | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-23 | 20260623_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-24 | 20260624_BTC_SHORT_B-MOMENTUM | BTC | SHORT | B | 3.06 | 0.37 | success | success | — | scored |
| 2026-06-24 | 20260624_DXY_NONE_REGIME | DXY | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-24 | 20260624_ETH_NONE_NO_TRADE | ETH | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | invalid_data |
| 2026-06-24 | 20260624_GOLD_SHORT_B-PULLBACK | GOLD | SHORT | B | 1.93 | 0.69 | success | success | — | scored |
| 2026-06-24 | 20260624_NASDAQ_SHORT_B-MOMENTUM | NASDAQ | SHORT | B | — | — | suspect_data | suspect_data | — | scored |
| 2026-06-24 | 20260624_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-24 | 20260624_US10Y_NONE_REGIME | US10Y | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-24 | 20260624_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-24 | 20260624_VIX_NONE_REGIME | VIX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-24 | 20260624_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-25 | 20260625_BTC_SHORT_A-MOMENTUM | BTC | SHORT | A | 2.06 | -1.16 | success | failure | — | scored |
| 2026-06-25 | 20260625_DXY_NONE_REGIME | DXY | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-25 | 20260625_ETH_NONE_NO_TRADE | ETH | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | invalid_data |
| 2026-06-25 | 20260625_GOLD_SHORT_B-MOMENTUM | GOLD | SHORT | B | -1.48 | -1.50 | failure | failure | Y | scored |
| 2026-06-25 | 20260625_NASDAQ_SHORT_B-PULLBACK | NASDAQ | SHORT | B | — | — | suspect_data | suspect_data | — | scored |
| 2026-06-25 | 20260625_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-25 | 20260625_US10Y_NONE_REGIME | US10Y | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-25 | 20260625_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-25 | 20260625_VIX_NONE_REGIME | VIX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-25 | 20260625_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-26 | 20260626_BTC_SHORT_B-PULLBACK | BTC | SHORT | B | 1.06 | -1.60 | success | failure | Y | scored |
| 2026-06-26 | 20260626_DXY_NONE_REGIME | DXY | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-26 | 20260626_ETH_NONE_NO_TRADE | ETH | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | invalid_data |
| 2026-06-26 | 20260626_GOLD_LONG_B-REVERSAL | GOLD | LONG | B | 2.78 | — | success | awaiting | Y | awaiting_horizon |
| 2026-06-26 | 20260626_NASDAQ_SHORT_B-PULLBACK | NASDAQ | SHORT | B | — | — | suspect_data | suspect_data | — | awaiting_horizon |
| 2026-06-26 | 20260626_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-26 | 20260626_US10Y_NONE_REGIME | US10Y | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-26 | 20260626_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-26 | 20260626_VIX_NONE_REGIME | VIX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-26 | 20260626_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-27 | 20260627_BTC_SHORT_B-PULLBACK | BTC | SHORT | B | -0.27 | -1.72 | failure | failure | Y | scored |
| 2026-06-27 | 20260627_DXY_NONE_REGIME | DXY | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-27 | 20260627_ETH_NONE_NO_TRADE | ETH | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | invalid_data |
| 2026-06-27 | 20260627_GOLD_LONG_B-REVERSAL | GOLD | LONG | B | 2.34 | — | success | awaiting | Y | awaiting_horizon |
| 2026-06-27 | 20260627_NASDAQ_SHORT_B-PULLBACK | NASDAQ | SHORT | B | — | — | suspect_data | suspect_data | — | awaiting_horizon |
| 2026-06-27 | 20260627_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-27 | 20260627_US10Y_NONE_REGIME | US10Y | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-27 | 20260627_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-06-27 | 20260627_VIX_NONE_REGIME | VIX | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-27 | 20260627_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-30 | TSO-20260630-001 | USDJPY | LONG | B | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-30 | TSO-20260630-002 | WTI | LONG | B | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-06-30 | TSO-20260630-003 | BTC | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-07-01 | TSO-20260701-001 | USDJPY | LONG | B | 0.85 | — | success | awaiting | Y | awaiting_horizon |
| 2026-07-01 | TSO-20260701-002 | WTI | LONG | B | 1.29 | — | success | awaiting | Y | awaiting_horizon |
| 2026-07-01 | TSO-20260701-003 | GOLD | SHORT | B | -0.86 | — | failure | awaiting | Y | awaiting_horizon |
| 2026-07-01 | TSO-20260701-004 | BTC | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | scored |
| 2026-07-02 | TSO-20260702-001 | USDJPY | LONG | B | 0.61 | — | success | awaiting | Y | awaiting_horizon |
| 2026-07-02 | TSO-20260702-002 | GOLD | SHORT | B | -0.23 | — | failure | awaiting | Y | awaiting_horizon |
| 2026-07-02 | TSO-20260702-003 | WTI | LONG | B | 1.46 | — | success | awaiting | Y | awaiting_horizon |
| 2026-07-02 | TSO-20260702-004 | BTC | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-07-03 | TSO-20260703-001 | USDJPY | LONG | B | 0.10 | — | success | awaiting | Y | awaiting_horizon |
| 2026-07-03 | TSO-20260703-002 | GOLD | LONG | B | -0.58 | — | failure | awaiting | Y | awaiting_horizon |
| 2026-07-03 | TSO-20260703-003 | WTI | LONG | B | 0.76 | — | success | awaiting | Y | awaiting_horizon |
| 2026-07-03 | TSO-20260703-004 | BTC | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-07-04 | TSO-20260704-001 | GOLD | LONG | B | -0.18 | — | failure | awaiting | Y | awaiting_horizon |
| 2026-07-04 | TSO-20260704-002 | USDJPY | LONG | B | 0.69 | — | success | awaiting | — | awaiting_horizon |
| 2026-07-04 | TSO-20260704-003 | WTI | LONG | B | 1.56 | — | success | awaiting | Y | awaiting_horizon |
| 2026-07-04 | TSO-20260704-004 | BTC | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-07-05 | TSO-20260705-001 | GOLD | LONG | B | -0.51 | — | failure | awaiting | Y | awaiting_horizon |
| 2026-07-05 | TSO-20260705-002 | USDJPY | LONG | B | 0.69 | — | success | awaiting | — | awaiting_horizon |
| 2026-07-05 | TSO-20260705-003 | WTI | LONG | B | 1.16 | — | success | awaiting | Y | awaiting_horizon |
| 2026-07-05 | TSO-20260705-004 | BTC | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-07-06 | TSO-20260706-001 | GOLD | LONG | B | — | — | awaiting | awaiting | Y | awaiting_horizon |
| 2026-07-06 | TSO-20260706-002 | USDJPY | LONG | B | — | — | awaiting | awaiting | — | awaiting_horizon |
| 2026-07-06 | TSO-20260706-003 | WTI | LONG | B | — | — | awaiting | awaiting | — | awaiting_horizon |
| 2026-07-06 | TSO-20260706-004 | BTC | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-07-07 | TSO-20260707-001 | GOLD | LONG | B | — | — | awaiting | awaiting | — | awaiting_horizon |
| 2026-07-07 | TSO-20260707-002 | USDJPY | LONG | B | — | — | awaiting | awaiting | — | awaiting_horizon |
| 2026-07-07 | TSO-20260707-003 | WTI | LONG | B | — | — | awaiting | awaiting | — | awaiting_horizon |
| 2026-07-07 | TSO-20260707-004 | BTC | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-07-09 | TSO-20260709-001 | WTI | LONG | B | — | — | awaiting | awaiting | Y | awaiting_horizon |
| 2026-07-09 | TSO-20260709-002 | USDJPY | LONG | B | — | — | awaiting | awaiting | — | awaiting_horizon |
| 2026-07-09 | TSO-20260709-003 | GOLD | NONE | B | — | — | not_applicable | not_applicable | — | awaiting_horizon |
| 2026-07-09 | TSO-20260709-004 | BTC | NONE | NO_TRADE | — | — | not_applicable | not_applicable | — | awaiting_horizon |

## 3. 注意

- close ベースの R（PROTO-0001 と同じ定義）。SLキャップ後のトレードP&Lとは別物。
- awaiting は結果窓未確定の正直表示。日次再実行で自動確定する。
- 採点のみで signal score・実売買には未接続。
