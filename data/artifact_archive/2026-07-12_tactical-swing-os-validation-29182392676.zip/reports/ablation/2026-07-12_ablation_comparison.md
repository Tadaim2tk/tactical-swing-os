# Ablation Comparison（3系統比較 / Phase 29.3）

## 1. 概要

- 生成日時JST: 2026-07-12 15:16:21 JST
- status: **insufficient_data** / cohort行数: 0 / 局面日数: 11
- 系統: technical_only / text_narrative_only / technical_plus_text（同一cohort・同一結果窓）
- cost_source が unconfigured の間は net R = gross R（コスト値は捏造しない）

## 2. 指標（arm × horizon）

_cohort なし（narrative memory の局面文書 11 日 / 最低 6 日 + 価格履歴が必要）。データが溜まれば自動で数字が出る。_

## 3. text系統は technical を上回るか（対比較・改善判定）

_対ペアなし（cohort 蓄積待ち）。閾値と表示は先に固定済み — データが溜まれば自動で判定が出る。_

- 判定閾値（固定済み）: n_pairs>=30 / 符号検定 p<=0.05 / 平均R差の符号。
  **improves** = semantic類似が予測に効いている証拠 / **degrades** = 悪化 /
  **no_significant_difference** = 「似た説明が見つかっただけ」と区別できない。
- text 層を signal score へ接続する将来判断は improves 判定 + 人間承認PRを経る。

## 4. 読み方と注意

- n_actionable >= 30 の行だけが判断材料（status=ok）。未満は insufficient_data の正直表示。
- テキスト系統は「基準日までに結果が確定した類似日」だけで方向を決めている（as-of・lookahead-safe）。
- この比較は分析専用で、実推奨・signal score には未接続。実売買・発注は行わない。
