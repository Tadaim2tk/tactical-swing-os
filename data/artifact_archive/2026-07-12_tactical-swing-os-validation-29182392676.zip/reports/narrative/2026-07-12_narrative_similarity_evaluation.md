# Narrative Similarity Evaluation（類似検索の予測力検証 v0）

## 1. 概要

- 生成日時JST: 2026-07-12 15:16:20 JST
- status: **insufficient_data** / 局面日数: 11 / 評価ペア: 6
- 方式: 各日 d の top-1 類似日 s（d 以前のみから as-of 検索）について、
  d と s の +5/10/20営業日リターンの**方向一致率**を集計。n>=30 で判断材料になる。

## 2. 資産×ホライズン別

| asset | horizon | pairs | 方向一致率 | mean fwd(similar) | mean fwd(query) | status |
| --- | --- | --- | --- | --- | --- | --- |
| BTC | 5d | 0 | — | nan | nan | insufficient_data |
| BTC | 10d | 0 | — | nan | nan | insufficient_data |
| BTC | 20d | 0 | — | nan | nan | insufficient_data |
| DXY | 5d | 0 | — | nan | nan | insufficient_data |
| DXY | 10d | 0 | — | nan | nan | insufficient_data |
| DXY | 20d | 0 | — | nan | nan | insufficient_data |
| GOLD | 5d | 0 | — | nan | nan | insufficient_data |
| GOLD | 10d | 0 | — | nan | nan | insufficient_data |
| GOLD | 20d | 0 | — | nan | nan | insufficient_data |
| NASDAQ | 5d | 0 | — | nan | nan | insufficient_data |
| NASDAQ | 10d | 0 | — | nan | nan | insufficient_data |
| NASDAQ | 20d | 0 | — | nan | nan | insufficient_data |
| SPX | 5d | 0 | — | nan | nan | insufficient_data |
| SPX | 10d | 0 | — | nan | nan | insufficient_data |
| SPX | 20d | 0 | — | nan | nan | insufficient_data |
| US10Y | 5d | 0 | — | nan | nan | insufficient_data |
| US10Y | 10d | 0 | — | nan | nan | insufficient_data |
| US10Y | 20d | 0 | — | nan | nan | insufficient_data |
| USDJPY | 5d | 0 | — | nan | nan | insufficient_data |
| USDJPY | 10d | 0 | — | nan | nan | insufficient_data |
| USDJPY | 20d | 0 | — | nan | nan | insufficient_data |
| VIX | 5d | 0 | — | nan | nan | insufficient_data |
| VIX | 10d | 0 | — | nan | nan | insufficient_data |
| VIX | 20d | 0 | — | nan | nan | insufficient_data |
| WTI | 5d | 0 | — | nan | nan | insufficient_data |
| WTI | 10d | 0 | — | nan | nan | insufficient_data |
| WTI | 20d | 0 | — | nan | nan | insufficient_data |

## 3. 注意

- insufficient_data はデータ不足の正直表示であり失敗ではない。実装はデータを待たない。
- 表示・検証のみ。signal score には未接続。実売買・発注は行わない。
