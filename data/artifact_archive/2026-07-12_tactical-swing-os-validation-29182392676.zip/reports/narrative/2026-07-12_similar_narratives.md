# Similar Narrative Cases（類似局面検索 v0）

## 1. 概要

- 基準日: 2026-07-12
- status: **ok**
- embedding provider: `tfidf_local` / 過去局面 10 日から上位 5 日を検索。

## 2. 類似局面と、その後の実リターン（5/10/20営業日）

| rank | similar_date | similarity | asset | +5d | +10d | +20d | status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 2026-07-11 | 0.5685 | BTC | — | — | — | awaiting_horizon |
| 1 | 2026-07-11 | 0.5685 | DXY | — | — | — | awaiting_horizon |
| 1 | 2026-07-11 | 0.5685 | GOLD | — | — | — | awaiting_horizon |
| 1 | 2026-07-11 | 0.5685 | NASDAQ | — | — | — | awaiting_horizon |
| 1 | 2026-07-11 | 0.5685 | SPX | — | — | — | awaiting_horizon |
| 1 | 2026-07-11 | 0.5685 | US10Y | — | — | — | awaiting_horizon |
| 1 | 2026-07-11 | 0.5685 | USDJPY | — | — | — | awaiting_horizon |
| 1 | 2026-07-11 | 0.5685 | VIX | — | — | — | awaiting_horizon |
| 1 | 2026-07-11 | 0.5685 | WTI | — | — | — | awaiting_horizon |
| 2 | 2026-07-04 | 0.549 | BTC | 0.17% | — | — | awaiting_horizon |
| 2 | 2026-07-04 | 0.549 | DXY | 0.11% | — | — | awaiting_horizon |
| 2 | 2026-07-04 | 0.549 | GOLD | 0.02% | — | — | awaiting_horizon |
| 2 | 2026-07-04 | 0.549 | NASDAQ | 1.61% | — | — | awaiting_horizon |
| 2 | 2026-07-04 | 0.549 | SPX | 1.22% | — | — | awaiting_horizon |
| 2 | 2026-07-04 | 0.549 | US10Y | — | — | — | awaiting_horizon |
| 2 | 2026-07-04 | 0.549 | USDJPY | 0.14% | — | — | awaiting_horizon |
| 2 | 2026-07-04 | 0.549 | VIX | -6.93% | — | — | awaiting_horizon |
| 2 | 2026-07-04 | 0.549 | WTI | 3.96% | — | — | awaiting_horizon |
| 3 | 2026-07-07 | 0.543 | BTC | — | — | — | awaiting_horizon |
| 3 | 2026-07-07 | 0.543 | DXY | — | — | — | awaiting_horizon |
| 3 | 2026-07-07 | 0.543 | GOLD | — | — | — | awaiting_horizon |
| 3 | 2026-07-07 | 0.543 | NASDAQ | — | — | — | awaiting_horizon |
| 3 | 2026-07-07 | 0.543 | SPX | — | — | — | awaiting_horizon |
| 3 | 2026-07-07 | 0.543 | US10Y | — | — | — | awaiting_horizon |
| 3 | 2026-07-07 | 0.543 | USDJPY | — | — | — | awaiting_horizon |
| 3 | 2026-07-07 | 0.543 | VIX | — | — | — | awaiting_horizon |
| 3 | 2026-07-07 | 0.543 | WTI | — | — | — | awaiting_horizon |
| 4 | 2026-07-03 | 0.5368 | BTC | -0.46% | — | — | awaiting_horizon |
| 4 | 2026-07-03 | 0.5368 | DXY | 0.11% | — | — | awaiting_horizon |
| 4 | 2026-07-03 | 0.5368 | GOLD | 0.02% | — | — | awaiting_horizon |
| 4 | 2026-07-03 | 0.5368 | NASDAQ | 1.61% | — | — | awaiting_horizon |
| 4 | 2026-07-03 | 0.5368 | SPX | 1.22% | — | — | awaiting_horizon |
| 4 | 2026-07-03 | 0.5368 | US10Y | — | — | — | awaiting_horizon |
| 4 | 2026-07-03 | 0.5368 | USDJPY | 0.14% | — | — | awaiting_horizon |
| 4 | 2026-07-03 | 0.5368 | VIX | -6.93% | — | — | awaiting_horizon |
| 4 | 2026-07-03 | 0.5368 | WTI | 3.96% | — | — | awaiting_horizon |
| 5 | 2026-07-08 | 0.5355 | BTC | — | — | — | awaiting_horizon |
| 5 | 2026-07-08 | 0.5355 | DXY | — | — | — | awaiting_horizon |
| 5 | 2026-07-08 | 0.5355 | GOLD | — | — | — | awaiting_horizon |
| 5 | 2026-07-08 | 0.5355 | NASDAQ | — | — | — | awaiting_horizon |
| 5 | 2026-07-08 | 0.5355 | SPX | — | — | — | awaiting_horizon |
| 5 | 2026-07-08 | 0.5355 | US10Y | — | — | — | awaiting_horizon |
| 5 | 2026-07-08 | 0.5355 | USDJPY | — | — | — | awaiting_horizon |
| 5 | 2026-07-08 | 0.5355 | VIX | — | — | — | awaiting_horizon |
| 5 | 2026-07-08 | 0.5355 | WTI | — | — | — | awaiting_horizon |

## 3. 注意

- allowed_for_signal=true の record のみ・基準日より前の局面のみを検索（lookahead-safe）。
- この出力は表示・記録のみで、signal score には接続していない（connected_to_signal_score=false）。
- 実売買・発注は行わない。
