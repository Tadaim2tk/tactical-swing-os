# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-06 07:42:12 JST
生成日時（UTC）: 2026-07-05 22:42:12 UTC
headline件数: 49
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.24
ニュース市場バイアス: neutral
ニュース矛盾スコア: 18.71
主要テーマ: geopolitical_risk
日本語要約: 地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 18.71
- risk_off_news_score: 18.71
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 18.71
- oil_supply_risk_news_score: 37.43
- crypto_liquidity_news_score: 18.71
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 74.86
- inflation_pressure_news_score: 0.0
- recession_risk_news_score: 18.71
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Cargo vessel in Red Sea reports coming under attack, UK maritime body says (地政学リスク / リスクオフ要因)
- What caused the pre-holiday chip stock slump and what to do about it (リスクオフ要因)
- UK and France agree with Oman to ensure safety of its territorial waters (地政学リスク / 原油供給リスク / リスクオフ要因)
- OPEC+ raises output levels again despite tumbling crude prices (原油供給リスク)
- U.S. stock futures rise as Wall Street looks to extend its rally coming off the holiday weekend (リスクオン要因)
- Americans traded $571 million on Polymarket politic bets despite U.S. ban (金安全資産需要)
- How ethical hackers with just a $3,000 server found a flaw that could've put $70 billion in crypto at risk (地政学リスク / リスクオフ要因)
- UK's bold new crypto rules promise to unlock global trading, but huge compliance hurdles still threaten the rollout (暗号資産流動性)
- Russia stocks lower at close of trade; MOEX Russia Index unchanged (地政学リスク / リスクオフ要因)
- What are the key factors behind the slowdown in tech hiring? (景気後退リスク)
