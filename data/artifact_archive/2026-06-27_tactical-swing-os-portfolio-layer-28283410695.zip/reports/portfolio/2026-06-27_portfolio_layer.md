# Portfolio Layer

## 1. 概要

- 生成日時JST: 2026-06-27 17:07:19 JST
- portfolio_status: active
- candidate assets: 2
- defensive assets: 1
- offensive assets: 0
- cash candidate: 0.5321
- average confidence: 0.4773
- portfolio concentration: 0.24
- risk concentration: 0.0
- recommended exposure: 0.4679
- recommended next action: human_review_allocations
- requires_human_approval: true
- weights_json_updated: false
- patch_applied: false
- generate_signal_updated: false
- orders_created: false

## 2. Top Allocation Candidates

| asset | allocation_score | portfolio_weight_candidate | confidence | risk_class | risk_role | latest_rank | latest_side | rationale |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| USDJPY | 60.7 | 0.24 | 0.3767 | medium | balanced |  |  | signal data unavailable; evaluation avg_r=1.09 win_rate=1.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| GOLD | 54.4 | 0.2279 | 0.5433 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=0.30 win_rate=1.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| BTC | 38.82 | 0.0 | 0.4933 | high | offensive |  |  | signal data unavailable; evaluation avg_r=-0.15 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| WTI | 42.4 | 0.0 | 0.5933 | high | offensive |  |  | signal data unavailable; evaluation avg_r=0.30 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| NASDAQ | 36.17 | 0.0 | 0.5267 | high | offensive |  |  | signal data unavailable; evaluation avg_r=-0.48 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| ETH | 40.0 | 0.0 | 0.35 | high | offensive |  |  | signal data unavailable; evaluation rows unavailable; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| SPX | 36.48 | 0.0 | 0.51 | medium | offensive |  |  | signal data unavailable; evaluation avg_r=-0.44 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| VIX | 37.45 | 0.0 | 0.46 | high | defensive |  |  | signal data unavailable; evaluation avg_r=-0.32 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| DXY | 40.57 | 0.0 | 0.4767 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=0.07 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| US10Y | 35.47 | 0.0 | 0.4433 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=-0.57 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |

## 3. Risk Concentration

- high risk weight candidate: 0.0
- portfolio concentration: 0.24
- cash ratio candidate: 0.5321

## 4. 注意事項

- Portfolio Layerは配分候補を生成するだけです
- 自動売買・自動発注・自動リバランスは行いません
- weights.jsonは更新しません
- generate_signal.pyは変更しません
- Google Sheetsへの書き込みは行いません
- すべての候補は人間承認が必須です
