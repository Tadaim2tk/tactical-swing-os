# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-24 07:54:02 JST
取得日時（UTC）: 2026-06-23 22:54:02 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.23
headline件数: 75

## 見出し

- [CNBC Markets] Cerebras falls 10% after chipmaker forecasts shrinking margin in first earnings report since IPO (SPX|NASDAQ)
- [CNBC Markets] SpaceX raises $25 billion in debt sale less than two weeks after IPO (未分類)
- [CNBC Markets] Alphabet added to Dow Jones Industrial Average, replacing Verizon (未分類)
- [CNBC Markets] Factory job cuts in June neared financial crisis and Covid levels, S&P says (SPX)
- [CNBC Markets] FedEx posts strong earnings results in last quarter with freight business (SPX|NASDAQ|US10Y|DXY)
- [CNBC Markets] PGA Tour CEO Brian Rolapp unveils sweeping changes to professional golf (未分類)
- [CNBC Markets] House expected to pass affordable housing bill, send it to Trump's desk (未分類)
- [CNBC Markets] Mamdani-backed candidates are likely to win in NYC primaries, prediction market traders expect (未分類)
- [CNBC Markets] Five things to watch in Tuesday's primaries as New York races take center stage (未分類)
- [CNBC Markets] Senate backs Iran war powers resolution as GOP pressure grows on Trump's deal to end war (未分類)
- [CNBC Markets] Bill Gates testimony on Jeffrey Epstein ties released by House oversight panel (未分類)
- [CNBC Markets] CFTC sues Kentucky over actions against prediction markets, making it first red state to face federal scrutiny (US10Y|DXY)
- [CNBC Markets] Inside Kevin Warsh's selection process for the next Atlanta Fed president (US10Y|DXY)
- [CNBC Markets] Strait of Hormuz evacuation plan to begin for ships stranded in Persian Gulf, maritime organization says (未分類)
- [CNBC Markets] Traders are loving this cheap way to make big bets against chip stocks (SPX|NASDAQ)
- [CNBC Markets] Meta announces new smart glasses starting at $299, as Zuckerberg keeps pushing wearables (未分類)
- [CNBC Markets] An off-grid power project gets a major proof of concept. What it means for GE Vernova (未分類)
- [CNBC Markets] Meta is building a prediction markets app. These stocks fell in response (SPX)
- [CNBC Markets] Sen. Cassidy plans to push 'big idea' for Social Security reform in last days in office (未分類)
- [CNBC Markets] Progressive Brad Lander’s surging bid for Congress splinters Democrats' labor union alliance (GOLD)
- [CNBC Markets] SpaceX seeing some interest from short sellers, but many still afraid to bet against Musk (SPX)
- [CNBC Markets] SpaceX closes nearly 1% higher, snapping three-day losing streak (未分類)
- [CNBC Markets] U.S. issues sweeping Iran oil sanctions waivers, unlocking billions in revenue for Tehran (WTI)
- [CNBC Markets] 'I like their money': Trump threatens lawsuits against ABC for reporting on Reflecting Pool (US10Y|DXY)
- [CNBC Markets] Trump administration to loan $17 billion to speed deployment of 10 big nuclear reactors in U.S. (未分類)
- [CNBC Markets] Brexit 10 years later: How the UK economy and politics changed, in charts (未分類)
- [CNBC Markets] Oracle sheds 21,000 roles over the past year amid wave of AI layoffs from tech giants (NASDAQ)
- [CNBC Markets] Google’s online dominance is showing signs of cracking in AI era (SPX)
- [CNBC Markets] Gold and silver tumble as rate-hike fears hit precious metals (GOLD|SPX|VIX)
- [CNBC Markets] Sens. Warren, Kelly press Trump administration on effects of tariffs on manufacturing (未分類)
- [MarketWatch Top Stories] I want to leave everything to my sons, but I’m terrified they’ll give it to my ex-husband. How do I prevent this? (未分類)
- [MarketWatch Top Stories] ‘We own our home outright’: I am 67 and earn $100,000. Do I take my $30,000-a-year Social Security now or wait? (US10Y)
- [MarketWatch Top Stories] Alphabet’s stock is set to join the Dow. Here’s which company is getting the boot. (未分類)
- [MarketWatch Top Stories] Cerebras delivers its first earnings report — but it’s not enough to lift the stock (SPX|NASDAQ)
- [MarketWatch Top Stories] SpaceX reveals pricing details for what could be one of the year’s biggest debt deals (未分類)
- [MarketWatch Top Stories] The No. 1 overall NBA draft pick will make nearly $70 million overnight, as historic TV deals keeping money flowing into NBA (未分類)
- [MarketWatch Top Stories] Micron and Sandisk lead a sharp tech selloff in a ‘gut-check’ moment for AI stocks (SPX|NASDAQ|VIX)
- [MarketWatch Top Stories] SpaceX succumbs to gravity as the stock briefly dips below its debut price on Nasdaq (NASDAQ)
- [MarketWatch Top Stories] SpaceX stock’s wild price swings since its IPO show how risky leveraged ETFs can be (BTC|SPX)
- [MarketWatch Top Stories] Trump regrets once selling IBM’s stock. Now he’s cheering its quantum future and dealing its shares. (SPX)
- [CoinDesk] Crypto critic Roubini joins tokenization boom with onchain 'Technodollar' (BTC|USDJPY|NASDAQ|DXY)
- [CoinDesk] Meta is developing a prediction market app called ‘Arena’ as sector booms: NYT (未分類)
- [CoinDesk] BNY sees 'FOMO' driving asset managers into tokenized funds (BTC|VIX)
- [CoinDesk] Chainlink teams up with 47 South Korean, European banks to speed up international money transfers (USDJPY|DXY)
- [CoinDesk] Vitalik Buterin says Ethereum Foundation will cut budget 40% in major reset (BTC|WTI)
- [CoinDesk] Bitcoin's recent drop below $60,000 signals Fed, ETF and AI pressures: Deutsche Bank (BTC|US10Y|DXY)
- [CoinDesk] The SEC delayed tokenizing stocks, and here’s why that’s a relief (SPX)
- [CoinDesk] Ethereum Foundation cuts 20% of staff amid leadership exodus (BTC)
- [CoinDesk] Bitcoin may need to plunge 15% or more to mark bottom, according to this long-time indicator (BTC)
- [CoinDesk] Former Robinhood Crypto COO Tanya Denisova joins stablecoin issuer Agora as head of operations (BTC)
