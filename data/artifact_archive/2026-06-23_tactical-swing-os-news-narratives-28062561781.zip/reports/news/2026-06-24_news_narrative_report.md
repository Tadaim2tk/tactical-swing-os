# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-24 07:54:04 JST
生成日時（UTC）: 2026-06-23 22:54:04 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.23
ニュース市場バイアス: risk_off
ニュース矛盾スコア: 0.0
主要テーマ: risk_off, geopolitical_risk
日本語要約: リスクオフ要因、地政学リスクが優勢で、ニュース面では慎重姿勢が強い状態です。
ニュースモード: ニュースはリスクオフ寄り / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 100.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 18.47
- oil_supply_risk_news_score: 36.93
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 73.87
- inflation_pressure_news_score: 18.47
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 18.47
- news_confidence: 100.0

## Top News Drivers

- Factory job cuts in June neared financial crisis and Covid levels, S&P says (リスクオフ要因)
- Senate backs Iran war powers resolution as GOP pressure grows on Trump's deal to end war (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
- Traders are loving this cheap way to make big bets against chip stocks (中銀ハト派)
- U.S. issues sweeping Iran oil sanctions waivers, unlocking billions in revenue for Tehran (地政学リスク / 原油供給リスク / リスクオフ要因)
- Micron and Sandisk lead a sharp tech selloff in a ‘gut-check’ moment for AI stocks (リスクオフ要因)
- Bitcoin's recent drop below $60,000 signals Fed, ETF and AI pressures: Deutsche Bank (リスクオフ要因)
- Strategy's STRC slump prompts Terra comparisons that don't hold up, says analyst (リスクオフ要因)
- Crypto market drops as Nasdaq tech selloff spills into digital assets (リスクオフ要因)
- Bitcoin falls under $63,000 as a tech selloff drags risk assets lower (リスクオフ要因)
- Lockheed Martin wins $8.4B missile contract modification (地政学リスク / リスクオフ要因)
