# Pending Signal Re-evaluation Report

## 1. 概要

* 生成日時JST: 2026-06-16 15:07:21 JST
* データソース: sheets
* 対象SIGNALS件数: 90
* 再評価対象件数: 29
* closed化した件数: 5
* no_entry継続件数: 1
* open継続件数: 23
* missed_opportunity件数: 0
* Sheets保存: 未実行
* Sheets保存成功件数: 0
* Sheets重複スキップ件数: 0
* Sheets保存warning: なし

## 2. 決着したシグナル

| signal_id | asset | side | rank | previous_outcome | outcome | r_multiple | error_type |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B |  | win_tp1 | 1.087 | target_reached |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B |  | win_tp1 | 1.087 | target_reached |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B |  | loss_sl | -1.0 | stop_loss |

## 3. 未決着継続

| signal_id | asset | side | rank | outcome | mfe_r | mae_r | bars_checked |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | open_unresolved | 0.5155 | -0.9005 | 6 |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | open_unresolved | 0.5891 | -0.7126 | 7 |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | open_unresolved | 0.5155 | -0.9005 | 6 |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | open_unresolved | 0.5891 | -0.7126 | 7 |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 0.0295 | -0.27 | 9 |
| 20260605_DXY_LONG_A-Momentum | DXY | LONG | B | open_unresolved | 0.1269 | -0.1945 | 6 |
| 20260605_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.7325 | -0.0407 | 7 |
| 20260605_US10Y_LONG_A-Pullback | US10Y | LONG | B | open_unresolved | 0.1602 | -0.3819 | 5 |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.7836 | -0.0124 | 7 |
| 20260608_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.7917 | -0.008 | 6 |
| 20260608_US10Y_LONG_B-Watch | US10Y | LONG | B | open_unresolved | 0.0821 | -0.5098 | 4 |
| 20260609_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 0.0965 | -0.2192 | 6 |
| 20260609_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.0498 | -0.1436 | 5 |
| 20260609_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 0.4592 | -0.2116 | 5 |
| 20260610_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.067 | -0.437 | 4 |
| 20260611_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 0.2791 | -0.0392 | 3 |
| 20260612_WTI_SHORT_B-Watch | WTI | SHORT | B | no_entry | 0.2027 | 0.0947 | 2 |
| 20260614_NASDAQ_LONG_A-Pullback | NASDAQ | LONG | B | open_unresolved | 0.4962 | -0.0335 | 2 |
| 20260614_SPX_LONG_A-Pullback | SPX | LONG | B | open_unresolved | 0.5605 | -0.0124 | 2 |
| 20260614_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 0.0725 | -0.0239 | 2 |

## 4. 取り逃し候補

取り逃し候補はありません。

## 5. No Trade再評価

No Trade再評価は実行していません。

## 6. 注意

* このレポートは実売買ではありません。
* Tactical Swing OS が過去に出した判断の仮想評価です。
* 価格データの欠損や市場休場により、評価が遅れる場合があります。
* append-only運用でEVALUATIONSへ追記する場合、分析側では最新評価行を採用する必要があります。
