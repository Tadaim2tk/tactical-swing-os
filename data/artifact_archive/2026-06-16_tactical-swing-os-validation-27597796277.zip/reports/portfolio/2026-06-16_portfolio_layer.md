# Portfolio Layer

## 1. 概要

- 生成日時JST: 2026-06-16 15:07:41 JST
- portfolio_status: active
- candidate assets: 1
- defensive assets: 1
- offensive assets: 0
- cash candidate: 0.7
- average confidence: 0.517
- portfolio concentration: 0.3
- risk concentration: 0.0
- recommended exposure: 0.3
- recommended next action: human_review_allocations
- requires_human_approval: true
- weights_json_updated: false
- patch_applied: false
- generate_signal_updated: false
- orders_created: false

## 2. Top Allocation Candidates

| asset | allocation_score | portfolio_weight_candidate | confidence | risk_class | risk_role | latest_rank | latest_side | rationale |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GOLD | 53.07 | 0.3 | 0.58 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=0.13 win_rate=1.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| WTI | 41.18 | 0.0 | 0.58 | high | offensive |  |  | signal data unavailable; evaluation avg_r=0.15 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| BTC | 35.88 | 0.0 | 0.5467 | high | offensive |  |  | signal data unavailable; evaluation avg_r=-0.52 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| NASDAQ | 40.0 | 0.0 | 0.53 | high | offensive |  |  | signal data unavailable; evaluation avg_r=0.00 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| USDJPY | 39.47 | 0.0 | 0.4967 | medium | balanced |  |  | signal data unavailable; evaluation avg_r=-0.07 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| ETH | 40.0 | 0.0 | 0.35 | high | offensive |  |  | signal data unavailable; evaluation rows unavailable; meta learning unavailable; auto calibration rows=0; human override rows=0; proposal impact unavailable; market snapshot unavailable |
| SPX | 40.0 | 0.0 | 0.53 | medium | offensive |  |  | signal data unavailable; evaluation avg_r=0.00 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| VIX | 40.0 | 0.0 | 0.5133 | high | defensive |  |  | signal data unavailable; evaluation avg_r=0.00 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| DXY | 36.15 | 0.0 | 0.5133 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=-0.48 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |
| US10Y | 35.31 | 0.0 | 0.53 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=-0.59 win_rate=0.00; meta learning unavailable; auto calibration rows=1; human override rows=1; proposal impact unavailable; market momentum 1d=0.00 5d=0.00 |

## 3. Risk Concentration

- high risk weight candidate: 0.0
- portfolio concentration: 0.3
- cash ratio candidate: 0.7

## 4. 注意事項

- Portfolio Layerは配分候補を生成するだけです
- 自動売買・自動発注・自動リバランスは行いません
- weights.jsonは更新しません
- generate_signal.pyは変更しません
- Google Sheetsへの書き込みは行いません
- すべての候補は人間承認が必須です
