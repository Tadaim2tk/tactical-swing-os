# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-02 07:55:30 JST
生成日時（UTC）: 2026-07-01 22:55:30 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.18
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 18.47
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 0.0
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 0.0
- inflation_pressure_news_score: 55.4
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 18.47
- news_confidence: 100.0

## Top News Drivers

- Inflation peaked in May as energy prices fell in June, Kalshi traders think (インフレ圧力 / 金利圧力候補)
- U.S. auto industry faces increased uncertainty without extension of USMCA trade deal (リスクオフ要因)
- Is Meta ‘giving up’ on cutting-edge AI? Wall Street is divided over potential cloud pivot. (中銀ハト派)
- Bitcoin breaks above $60,000 after Fed Chair Warsh said inflation risks has come down (インフレ圧力 / 金利圧力候補)
