# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-16 16:20:41 JST
生成日時（UTC）: 2026-06-16 07:20:41 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.31
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 57.5
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 38.33
- oil_supply_risk_news_score: 57.5
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 57.5
- inflation_pressure_news_score: 38.33
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- China economy weakens further in May as retail sales post first drop in over three years (リスクオフ要因)
- Bank of Japan hikes rates to 1%, highest since 1995, as yen and inflation worries take hold (インフレ圧力 / 金利圧力候補)
- South Korean defense stocks surge on prospects for post-Iran-war sales boosts (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
- Australia central bank warns hikes are not off the table as it keeps rates steady at 4.35% (インフレ圧力 / 金利圧力候補)
- The Iran deal came just in time as Strategic Petroleum Reserve hits lowest level since 1983 (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
- How the Strait of Hormuz reopening could unfold if the U.S.-Iran deal is implemented (原油供給リスク)
- CFTC chair Selig defends decision to approve ‘perps’ in U.S. (リスクオフ要因)
- Wall Street's fear gauge tumbles as traders bid up SpaceX shares (リスクオフ要因)
