# Tactical Swing OS Reason Code Analysis

## 1. 結論

reason_codesの有効性を集計しました。

対象期間: 2026-05-18 - 2026-06-16

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. reason_codes 上位プラス要因

_該当なし_

## 3. reason_codes 上位マイナス要因

| reason_code | signals_count | evaluated_count | win_count | loss_count | no_entry_count | missed_opportunity_count | win_rate | total_r | average_r | median_r | best_r | worst_r | average_mfe_r | average_mae_r | rank_a_count | rank_b_count | no_trade_count | recommended_action_trade_count | recommended_action_watch_count | recommended_action_no_trade_count | reliability_label |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| momentum_positive | 32 | 5 | 0 | 0 | 1 | 0 | 0.0 | -0.9297 | -0.2324 | -0.2444 | 0.0 | -0.4409 | 0.2163 | -0.2071 | 0 | 5 | 27 | 0 | 5 | 27 | negative |
| ma_alignment_bull | 25 | 7 | 0 | 0 | 2 | 0 | 0.0 | -0.9297 | -0.1859 | -0.17 | 0.0 | -0.4409 | 0.2852 | -0.0675 | 0 | 7 | 18 | 0 | 7 | 18 | negative |
| trend_up | 25 | 7 | 0 | 0 | 2 | 0 | 0.0 | -0.9297 | -0.1859 | -0.17 | 0.0 | -0.4409 | 0.2852 | -0.0675 | 0 | 7 | 18 | 0 | 7 | 18 | negative |
| overextended | 12 | 6 | 0 | 0 | 0 | 0 | 0.0 | -0.4818 | -0.1205 | -0.1434 | 0.2047 | -0.3996 | 0.0883 | -0.1973 | 1 | 5 | 6 | 1 | 5 | 6 | negative |

## 4. no_trade_reason 分析

| no_trade_reason | count | no_trade_correct_count | no_trade_missed_count | missed_opportunity_count | average_mfe_r | average_r | assessment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rr_too_low | 40 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |
| low_volatility | 11 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |

## 5. 取り逃し候補

_該当なし_

## 6. 改善候補

| reason_code | signals_count | evaluated_count | win_count | loss_count | no_entry_count | missed_opportunity_count | win_rate | total_r | average_r | median_r | best_r | worst_r | average_mfe_r | average_mae_r | rank_a_count | rank_b_count | no_trade_count | recommended_action_trade_count | recommended_action_watch_count | recommended_action_no_trade_count | reliability_label |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| overextended | 12 | 6 | 0 | 0 | 0 | 0 | 0.0 | -0.4818 | -0.1205 | -0.1434 | 0.2047 | -0.3996 | 0.0883 | -0.1973 | 1 | 5 | 6 | 1 | 5 | 6 | negative |
| ma_alignment_bull | 25 | 7 | 0 | 0 | 2 | 0 | 0.0 | -0.9297 | -0.1859 | -0.17 | 0.0 | -0.4409 | 0.2852 | -0.0675 | 0 | 7 | 18 | 0 | 7 | 18 | negative |
| trend_up | 25 | 7 | 0 | 0 | 2 | 0 | 0.0 | -0.9297 | -0.1859 | -0.17 | 0.0 | -0.4409 | 0.2852 | -0.0675 | 0 | 7 | 18 | 0 | 7 | 18 | negative |
| momentum_positive | 32 | 5 | 0 | 0 | 1 | 0 | 0.0 | -0.9297 | -0.2324 | -0.2444 | 0.0 | -0.4409 | 0.2163 | -0.2071 | 0 | 5 | 27 | 0 | 5 | 27 | negative |

## 7. データ不足の注意

reason_codeごとの評価件数が5件未満の場合は `insufficient_data` とし、weights.jsonは自動更新しません。

## 8. REASON_CODE_ANALYSIS CSV

```csv
reason_code,signals_count,evaluated_count,win_count,loss_count,no_entry_count,missed_opportunity_count,win_rate,total_r,average_r,median_r,best_r,worst_r,average_mfe_r,average_mae_r,rank_a_count,rank_b_count,no_trade_count,recommended_action_trade_count,recommended_action_watch_count,recommended_action_no_trade_count,reliability_label
rr_too_low,51,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,51,0,0,51,insufficient_data
atr_too_low,11,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,11,0,0,11,insufficient_data
pullback_to_ma20,10,2,0,0,2,0,0.0,0.0,0.0,0.0,0.0,0.0,0.5283,0.4624,0,2,8,0,2,8,insufficient_data
atr_too_high,7,3,0,0,1,0,0.0,0.0,0.0,0.0,0.0,0.0,0.4962,0.4339,0,3,4,0,3,4,insufficient_data
rsi_overbought,7,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,7,0,0,7,insufficient_data
momentum_negative,33,12,0,0,2,0,0.0,-0.2405,-0.0219,0.0101,0.3745,-0.3996,0.3507,-0.1103,0,12,21,0,12,21,neutral
ma_alignment_bear,27,13,0,0,2,0,0.0,-0.2405,-0.0219,0.0101,0.3745,-0.3996,0.3507,-0.1103,1,12,14,1,12,14,neutral
trend_down,27,13,0,0,2,0,0.0,-0.2405,-0.0219,0.0101,0.3745,-0.3996,0.3507,-0.1103,1,12,14,1,12,14,neutral
breakout_down,7,6,0,0,1,0,0.0,-0.1681,-0.0336,0.0101,0.2047,-0.3996,0.2421,-0.062,0,6,1,0,6,1,neutral
overextended,12,6,0,0,0,0,0.0,-0.4818,-0.1205,-0.1434,0.2047,-0.3996,0.0883,-0.1973,1,5,6,1,5,6,negative
rsi_oversold,11,4,0,0,0,0,0.0,-0.5702,-0.1425,-0.2725,0.3745,-0.3996,0.1484,-0.3183,0,4,7,0,4,7,insufficient_data
breakout_up,6,1,0,0,0,0,0.0,-0.17,-0.17,-0.17,-0.17,-0.17,0.1269,-0.1945,0,1,5,0,1,5,insufficient_data
ma_alignment_bull,25,7,0,0,2,0,0.0,-0.9297,-0.1859,-0.17,0.0,-0.4409,0.2852,-0.0675,0,7,18,0,7,18,negative
trend_up,25,7,0,0,2,0,0.0,-0.9297,-0.1859,-0.17,0.0,-0.4409,0.2852,-0.0675,0,7,18,0,7,18,negative
momentum_positive,32,5,0,0,1,0,0.0,-0.9297,-0.2324,-0.2444,0.0,-0.4409,0.2163,-0.2071,0,5,27,0,5,27,negative
risk_penalty_high,1,1,0,0,0,0,0.0,-0.297,-0.297,-0.297,-0.297,-0.297,0.0295,-0.351,0,1,0,0,1,0,insufficient_data
range_middle,14,2,0,0,0,0,0.0,-0.7597,-0.3799,-0.3799,-0.3188,-0.4409,0.1212,-0.534,0,2,12,0,2,12,insufficient_data
```

## 9. REASON_CODE_ANALYSIS JSON

```json
{
  "start_date": "2026-05-18",
  "end_date": "2026-06-16",
  "reason_code_summary": [
    {
      "reason_code": "rr_too_low",
      "signals_count": 51,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 51,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 51,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "atr_too_low",
      "signals_count": 11,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 11,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 11,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "pullback_to_ma20",
      "signals_count": 10,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.5283,
      "average_mae_r": 0.4624,
      "rank_a_count": 0,
      "rank_b_count": 2,
      "no_trade_count": 8,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 2,
      "recommended_action_no_trade_count": 8,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "atr_too_high",
      "signals_count": 7,
      "evaluated_count": 3,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.4962,
      "average_mae_r": 0.4339,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 4,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 4,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "rsi_overbought",
      "signals_count": 7,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "momentum_negative",
      "signals_count": 33,
      "evaluated_count": 12,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.2405,
      "average_r": -0.0219,
      "median_r": 0.0101,
      "best_r": 0.3745,
      "worst_r": -0.3996,
      "average_mfe_r": 0.3507,
      "average_mae_r": -0.1103,
      "rank_a_count": 0,
      "rank_b_count": 12,
      "no_trade_count": 21,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 12,
      "recommended_action_no_trade_count": 21,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "ma_alignment_bear",
      "signals_count": 27,
      "evaluated_count": 13,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.2405,
      "average_r": -0.0219,
      "median_r": 0.0101,
      "best_r": 0.3745,
      "worst_r": -0.3996,
      "average_mfe_r": 0.3507,
      "average_mae_r": -0.1103,
      "rank_a_count": 1,
      "rank_b_count": 12,
      "no_trade_count": 14,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 12,
      "recommended_action_no_trade_count": 14,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_down",
      "signals_count": 27,
      "evaluated_count": 13,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.2405,
      "average_r": -0.0219,
      "median_r": 0.0101,
      "best_r": 0.3745,
      "worst_r": -0.3996,
      "average_mfe_r": 0.3507,
      "average_mae_r": -0.1103,
      "rank_a_count": 1,
      "rank_b_count": 12,
      "no_trade_count": 14,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 12,
      "recommended_action_no_trade_count": 14,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "breakout_down",
      "signals_count": 7,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.1681,
      "average_r": -0.0336,
      "median_r": 0.0101,
      "best_r": 0.2047,
      "worst_r": -0.3996,
      "average_mfe_r": 0.2421,
      "average_mae_r": -0.062,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 1,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 1,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "overextended",
      "signals_count": 12,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.4818,
      "average_r": -0.1205,
      "median_r": -0.1434,
      "best_r": 0.2047,
      "worst_r": -0.3996,
      "average_mfe_r": 0.0883,
      "average_mae_r": -0.1973,
      "rank_a_count": 1,
      "rank_b_count": 5,
      "no_trade_count": 6,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 5,
      "recommended_action_no_trade_count": 6,
      "reliability_label": "negative"
    },
    {
      "reason_code": "rsi_oversold",
      "signals_count": 11,
      "evaluated_count": 4,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.5702,
      "average_r": -0.1425,
      "median_r": -0.2725,
      "best_r": 0.3745,
      "worst_r": -0.3996,
      "average_mfe_r": 0.1484,
      "average_mae_r": -0.3183,
      "rank_a_count": 0,
      "rank_b_count": 4,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 4,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "breakout_up",
      "signals_count": 6,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.17,
      "average_r": -0.17,
      "median_r": -0.17,
      "best_r": -0.17,
      "worst_r": -0.17,
      "average_mfe_r": 0.1269,
      "average_mae_r": -0.1945,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 5,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 25,
      "evaluated_count": 7,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.9297,
      "average_r": -0.1859,
      "median_r": -0.17,
      "best_r": 0.0,
      "worst_r": -0.4409,
      "average_mfe_r": 0.2852,
      "average_mae_r": -0.0675,
      "rank_a_count": 0,
      "rank_b_count": 7,
      "no_trade_count": 18,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 7,
      "recommended_action_no_trade_count": 18,
      "reliability_label": "negative"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 25,
      "evaluated_count": 7,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.9297,
      "average_r": -0.1859,
      "median_r": -0.17,
      "best_r": 0.0,
      "worst_r": -0.4409,
      "average_mfe_r": 0.2852,
      "average_mae_r": -0.0675,
      "rank_a_count": 0,
      "rank_b_count": 7,
      "no_trade_count": 18,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 7,
      "recommended_action_no_trade_count": 18,
      "reliability_label": "negative"
    },
    {
      "reason_code": "momentum_positive",
      "signals_count": 32,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.9297,
      "average_r": -0.2324,
      "median_r": -0.2444,
      "best_r": 0.0,
      "worst_r": -0.4409,
      "average_mfe_r": 0.2163,
      "average_mae_r": -0.2071,
      "rank_a_count": 0,
      "rank_b_count": 5,
      "no_trade_count": 27,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 5,
      "recommended_action_no_trade_count": 27,
      "reliability_label": "negative"
    },
    {
      "reason_code": "risk_penalty_high",
      "signals_count": 1,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.297,
      "average_r": -0.297,
      "median_r": -0.297,
      "best_r": -0.297,
      "worst_r": -0.297,
      "average_mfe_r": 0.0295,
      "average_mae_r": -0.351,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "range_middle",
      "signals_count": 14,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.7597,
      "average_r": -0.3799,
      "median_r": -0.3799,
      "best_r": -0.3188,
      "worst_r": -0.4409,
      "average_mfe_r": 0.1212,
      "average_mae_r": -0.534,
      "rank_a_count": 0,
      "rank_b_count": 2,
      "no_trade_count": 12,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 2,
      "recommended_action_no_trade_count": 12,
      "reliability_label": "insufficient_data"
    }
  ],
  "no_trade_reason_summary": [
    {
      "no_trade_reason": "rr_too_low",
      "count": 40,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    },
    {
      "no_trade_reason": "low_volatility",
      "count": 11,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    }
  ],
  "top_positive_reasons": [],
  "top_negative_reasons": [
    {
      "reason_code": "momentum_positive",
      "signals_count": 32,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.9297,
      "average_r": -0.2324,
      "median_r": -0.2444,
      "best_r": 0.0,
      "worst_r": -0.4409,
      "average_mfe_r": 0.2163,
      "average_mae_r": -0.2071,
      "rank_a_count": 0,
      "rank_b_count": 5,
      "no_trade_count": 27,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 5,
      "recommended_action_no_trade_count": 27,
      "reliability_label": "negative"
    },
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 25,
      "evaluated_count": 7,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.9297,
      "average_r": -0.1859,
      "median_r": -0.17,
      "best_r": 0.0,
      "worst_r": -0.4409,
      "average_mfe_r": 0.2852,
      "average_mae_r": -0.0675,
      "rank_a_count": 0,
      "rank_b_count": 7,
      "no_trade_count": 18,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 7,
      "recommended_action_no_trade_count": 18,
      "reliability_label": "negative"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 25,
      "evaluated_count": 7,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 2,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.9297,
      "average_r": -0.1859,
      "median_r": -0.17,
      "best_r": 0.0,
      "worst_r": -0.4409,
      "average_mfe_r": 0.2852,
      "average_mae_r": -0.0675,
      "rank_a_count": 0,
      "rank_b_count": 7,
      "no_trade_count": 18,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 7,
      "recommended_action_no_trade_count": 18,
      "reliability_label": "negative"
    },
    {
      "reason_code": "overextended",
      "signals_count": 12,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.4818,
      "average_r": -0.1205,
      "median_r": -0.1434,
      "best_r": 0.2047,
      "worst_r": -0.3996,
      "average_mfe_r": 0.0883,
      "average_mae_r": -0.1973,
      "rank_a_count": 1,
      "rank_b_count": 5,
      "no_trade_count": 6,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 5,
      "recommended_action_no_trade_count": 6,
      "reliability_label": "negative"
    }
  ],
  "over_filtering_candidates": [],
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 30,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "notes": [
    "reason_code単位のweights自動更新はまだ行いません。",
    "insufficient_data reason_codes: 9"
  ]
}
```
