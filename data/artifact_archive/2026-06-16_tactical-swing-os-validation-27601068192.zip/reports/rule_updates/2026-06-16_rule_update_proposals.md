# Tactical Swing OS Rule Update Proposals

## 1. 結論

ルール改善候補を生成しました。自動反映は行いません。

対象期間: 2026-05-18 - 2026-06-16

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. 高優先度の改善候補

_該当なし_

## 3. reason_codeを強める候補

_該当なし_

## 4. reason_codeを弱める候補

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_reason_code_momentum_positive_weaken_reason_code | weaken_reason_code | reason_code | momentum_positive | MEDIUM | 5 | 0.0 | -0.2324 | -0.9297 | 0 | momentum_positive は負の期待値 | risk_penalty_scoreを +3〜+8、またはrankを一段階下げる条件を検討 | 低期待値シグナルの抑制 | 相場環境依存の可能性あり | False | 2 | negative |

## 5. no_trade_reasonの見直し候補

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_no_trade_reason_low_volatility_data_insufficient | data_insufficient | no_trade_reason | low_volatility | DATA_INSUFFICIENT | 11 | 0.0 | 0.0 | 0.0 | 0 | low_volatility: correct=0, missed=0, avg_mfe_r=0.00 | 追加データを待つ | 判断保留 | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | neutral |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_no_trade_reason_rr_too_low_data_insufficient | data_insufficient | no_trade_reason | rr_too_low | DATA_INSUFFICIENT | 40 | 0.0 | 0.0 | 0.0 | 0 | rr_too_low: correct=0, missed=0, avg_mfe_r=0.00 | 追加データを待つ | 判断保留 | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | neutral |

## 6. asset / side / rank の見直し候補

_該当なし_

## 7. データ不足の項目

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_no_trade_reason_low_volatility_data_insufficient | data_insufficient | no_trade_reason | low_volatility | DATA_INSUFFICIENT | 11 | 0.0 | 0.0 | 0.0 | 0 | low_volatility: correct=0, missed=0, avg_mfe_r=0.00 | 追加データを待つ | 判断保留 | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | neutral |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_no_trade_reason_rr_too_low_data_insufficient | data_insufficient | no_trade_reason | rr_too_low | DATA_INSUFFICIENT | 40 | 0.0 | 0.0 | 0.0 | 0 | rr_too_low: correct=0, missed=0, avg_mfe_r=0.00 | 追加データを待つ | 判断保留 | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | neutral |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_reason_code_atr_too_high_data_insufficient | data_insufficient | reason_code | atr_too_high | DATA_INSUFFICIENT | 3 | 0.0 | 0.0 | 0.0 | 0 | atr_too_high は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_reason_code_atr_too_low_data_insufficient | data_insufficient | reason_code | atr_too_low | DATA_INSUFFICIENT | 0 | 0.0 | 0.0 | 0.0 | 0 | atr_too_low は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_reason_code_breakout_up_data_insufficient | data_insufficient | reason_code | breakout_up | DATA_INSUFFICIENT | 1 | 0.0 | -0.17 | -0.17 | 0 | breakout_up は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_reason_code_pullback_to_ma20_data_insufficient | data_insufficient | reason_code | pullback_to_ma20 | DATA_INSUFFICIENT | 2 | 0.0 | 0.0 | 0.0 | 0 | pullback_to_ma20 は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_reason_code_range_middle_data_insufficient | data_insufficient | reason_code | range_middle | DATA_INSUFFICIENT | 2 | 0.0 | -0.3799 | -0.7597 | 0 | range_middle は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_reason_code_risk_penalty_high_data_insufficient | data_insufficient | reason_code | risk_penalty_high | DATA_INSUFFICIENT | 1 | 0.0 | -0.297 | -0.297 | 0 | risk_penalty_high は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_reason_code_rr_too_low_data_insufficient | data_insufficient | reason_code | rr_too_low | DATA_INSUFFICIENT | 0 | 0.0 | 0.0 | 0.0 | 0 | rr_too_low は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_reason_code_rsi_overbought_data_insufficient | data_insufficient | reason_code | rsi_overbought | DATA_INSUFFICIENT | 0 | 0.0 | 0.0 | 0.0 | 0 | rsi_overbought は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-06-16T07:20:58 | 2026-05-18 | 2026-06-16 | 20260616_reason_code_rsi_oversold_data_insufficient | data_insufficient | reason_code | rsi_oversold | DATA_INSUFFICIENT | 4 | 0.0 | -0.1425 | -0.5702 | 0 | rsi_oversold は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |

## 8. 自動反映しない理由

- 実売買には使わない
- weights.jsonは自動更新しない
- generate_signal.pyは自動変更しない
- closed評価が30〜50件以上溜まるまでは提案のみ

## 9. 次に人間が確認すべき点

- HIGH / MEDIUM の提案が特定assetやsideに偏っていないか
- no_trade_reason緩和で低品質シグナルが増えないか
- reason_codeの成績が一時的な相場環境に依存していないか

## 10. RULE_UPDATE_PROPOSALS CSV

```csv
generated_at,period_start,period_end,proposal_id,proposal_type,target_type,target_name,proposal_strength,evidence_count,win_rate,average_r,total_r,missed_opportunity_count,current_behavior,proposed_change,expected_effect,risk_note,apply_automatically,priority,notes
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_momentum_positive_weaken_reason_code,weaken_reason_code,reason_code,momentum_positive,MEDIUM,5,0.0,-0.2324,-0.9297,0,momentum_positive は負の期待値,risk_penalty_scoreを +3〜+8、またはrankを一段階下げる条件を検討,低期待値シグナルの抑制,相場環境依存の可能性あり,False,2,negative
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_breakout_down_monitor_reason_code,monitor_reason_code,reason_code,breakout_down,LOW,6,0.0,-0.0336,-0.1681,0,breakout_down は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_ma_alignment_bear_monitor_reason_code,monitor_reason_code,reason_code,ma_alignment_bear,LOW,13,0.0,-0.0219,-0.2405,0,ma_alignment_bear は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_ma_alignment_bull_monitor_reason_code,monitor_reason_code,reason_code,ma_alignment_bull,LOW,7,0.0,-0.1859,-0.9297,0,ma_alignment_bull は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,negative
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_momentum_negative_monitor_reason_code,monitor_reason_code,reason_code,momentum_negative,LOW,12,0.0,-0.0219,-0.2405,0,momentum_negative は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_overextended_monitor_reason_code,monitor_reason_code,reason_code,overextended,LOW,6,0.0,-0.1205,-0.4818,0,overextended は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,negative
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_trend_down_monitor_reason_code,monitor_reason_code,reason_code,trend_down,LOW,13,0.0,-0.0219,-0.2405,0,trend_down は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_trend_up_monitor_reason_code,monitor_reason_code,reason_code,trend_up,LOW,7,0.0,-0.1859,-0.9297,0,trend_up は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,negative
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_no_trade_reason_low_volatility_data_insufficient,data_insufficient,no_trade_reason,low_volatility,DATA_INSUFFICIENT,11,0.0,0.0,0.0,0,"low_volatility: correct=0, missed=0, avg_mfe_r=0.00",追加データを待つ,判断保留,NO_TRADE緩和はノイズ取引増加に注意,False,4,neutral
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_no_trade_reason_rr_too_low_data_insufficient,data_insufficient,no_trade_reason,rr_too_low,DATA_INSUFFICIENT,40,0.0,0.0,0.0,0,"rr_too_low: correct=0, missed=0, avg_mfe_r=0.00",追加データを待つ,判断保留,NO_TRADE緩和はノイズ取引増加に注意,False,4,neutral
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_atr_too_high_data_insufficient,data_insufficient,reason_code,atr_too_high,DATA_INSUFFICIENT,3,0.0,0.0,0.0,0,atr_too_high は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_atr_too_low_data_insufficient,data_insufficient,reason_code,atr_too_low,DATA_INSUFFICIENT,0,0.0,0.0,0.0,0,atr_too_low は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_breakout_up_data_insufficient,data_insufficient,reason_code,breakout_up,DATA_INSUFFICIENT,1,0.0,-0.17,-0.17,0,breakout_up は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_pullback_to_ma20_data_insufficient,data_insufficient,reason_code,pullback_to_ma20,DATA_INSUFFICIENT,2,0.0,0.0,0.0,0,pullback_to_ma20 は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_range_middle_data_insufficient,data_insufficient,reason_code,range_middle,DATA_INSUFFICIENT,2,0.0,-0.3799,-0.7597,0,range_middle は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_risk_penalty_high_data_insufficient,data_insufficient,reason_code,risk_penalty_high,DATA_INSUFFICIENT,1,0.0,-0.297,-0.297,0,risk_penalty_high は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_rr_too_low_data_insufficient,data_insufficient,reason_code,rr_too_low,DATA_INSUFFICIENT,0,0.0,0.0,0.0,0,rr_too_low は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_rsi_overbought_data_insufficient,data_insufficient,reason_code,rsi_overbought,DATA_INSUFFICIENT,0,0.0,0.0,0.0,0,rsi_overbought は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-06-16T07:20:58,2026-05-18,2026-06-16,20260616_reason_code_rsi_oversold_data_insufficient,data_insufficient,reason_code,rsi_oversold,DATA_INSUFFICIENT,4,0.0,-0.1425,-0.5702,0,rsi_oversold は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
```

## 11. RULE_UPDATE_PROPOSALS JSON

```json
{
  "generated_at": "2026-06-16T07:20:58",
  "period_start": "2026-05-18",
  "period_end": "2026-06-16",
  "summary": {
    "proposal_count": 19,
    "high_priority_count": 0,
    "data_insufficient_count": 11,
    "apply_automatically": false
  },
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 30,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "proposals": [
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_momentum_positive_weaken_reason_code",
      "proposal_type": "weaken_reason_code",
      "target_type": "reason_code",
      "target_name": "momentum_positive",
      "proposal_strength": "MEDIUM",
      "evidence_count": 5,
      "win_rate": 0.0,
      "average_r": -0.2324,
      "total_r": -0.9297,
      "missed_opportunity_count": 0,
      "current_behavior": "momentum_positive は負の期待値",
      "proposed_change": "risk_penalty_scoreを +3〜+8、またはrankを一段階下げる条件を検討",
      "expected_effect": "低期待値シグナルの抑制",
      "risk_note": "相場環境依存の可能性あり",
      "apply_automatically": false,
      "priority": 2,
      "notes": "negative"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_breakout_down_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "breakout_down",
      "proposal_strength": "LOW",
      "evidence_count": 6,
      "win_rate": 0.0,
      "average_r": -0.0336,
      "total_r": -0.1681,
      "missed_opportunity_count": 0,
      "current_behavior": "breakout_down は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_ma_alignment_bear_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "ma_alignment_bear",
      "proposal_strength": "LOW",
      "evidence_count": 13,
      "win_rate": 0.0,
      "average_r": -0.0219,
      "total_r": -0.2405,
      "missed_opportunity_count": 0,
      "current_behavior": "ma_alignment_bear は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_ma_alignment_bull_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "ma_alignment_bull",
      "proposal_strength": "LOW",
      "evidence_count": 7,
      "win_rate": 0.0,
      "average_r": -0.1859,
      "total_r": -0.9297,
      "missed_opportunity_count": 0,
      "current_behavior": "ma_alignment_bull は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "negative"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_momentum_negative_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "momentum_negative",
      "proposal_strength": "LOW",
      "evidence_count": 12,
      "win_rate": 0.0,
      "average_r": -0.0219,
      "total_r": -0.2405,
      "missed_opportunity_count": 0,
      "current_behavior": "momentum_negative は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_overextended_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "overextended",
      "proposal_strength": "LOW",
      "evidence_count": 6,
      "win_rate": 0.0,
      "average_r": -0.1205,
      "total_r": -0.4818,
      "missed_opportunity_count": 0,
      "current_behavior": "overextended は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "negative"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_trend_down_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "trend_down",
      "proposal_strength": "LOW",
      "evidence_count": 13,
      "win_rate": 0.0,
      "average_r": -0.0219,
      "total_r": -0.2405,
      "missed_opportunity_count": 0,
      "current_behavior": "trend_down は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_trend_up_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "trend_up",
      "proposal_strength": "LOW",
      "evidence_count": 7,
      "win_rate": 0.0,
      "average_r": -0.1859,
      "total_r": -0.9297,
      "missed_opportunity_count": 0,
      "current_behavior": "trend_up は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "negative"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_no_trade_reason_low_volatility_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "low_volatility",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 11,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "low_volatility: correct=0, missed=0, avg_mfe_r=0.00",
      "proposed_change": "追加データを待つ",
      "expected_effect": "判断保留",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_no_trade_reason_rr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "rr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 40,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low: correct=0, missed=0, avg_mfe_r=0.00",
      "proposed_change": "追加データを待つ",
      "expected_effect": "判断保留",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_atr_too_high_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "atr_too_high",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 3,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "atr_too_high は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_atr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "atr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "atr_too_low は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_breakout_up_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "breakout_up",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": -0.17,
      "total_r": -0.17,
      "missed_opportunity_count": 0,
      "current_behavior": "breakout_up は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_pullback_to_ma20_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "pullback_to_ma20",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "pullback_to_ma20 は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_range_middle_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "range_middle",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 0.0,
      "average_r": -0.3799,
      "total_r": -0.7597,
      "missed_opportunity_count": 0,
      "current_behavior": "range_middle は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_risk_penalty_high_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "risk_penalty_high",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": -0.297,
      "total_r": -0.297,
      "missed_opportunity_count": 0,
      "current_behavior": "risk_penalty_high は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_rr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "rr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_rsi_overbought_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "rsi_overbought",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rsi_overbought は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_rsi_oversold_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "rsi_oversold",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 4,
      "win_rate": 0.0,
      "average_r": -0.1425,
      "total_r": -0.5702,
      "missed_opportunity_count": 0,
      "current_behavior": "rsi_oversold は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    }
  ],
  "high_priority_proposals": [],
  "data_insufficient_items": [
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_no_trade_reason_low_volatility_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "low_volatility",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 11,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "low_volatility: correct=0, missed=0, avg_mfe_r=0.00",
      "proposed_change": "追加データを待つ",
      "expected_effect": "判断保留",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_no_trade_reason_rr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "rr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 40,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low: correct=0, missed=0, avg_mfe_r=0.00",
      "proposed_change": "追加データを待つ",
      "expected_effect": "判断保留",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_atr_too_high_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "atr_too_high",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 3,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "atr_too_high は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_atr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "atr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "atr_too_low は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_breakout_up_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "breakout_up",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": -0.17,
      "total_r": -0.17,
      "missed_opportunity_count": 0,
      "current_behavior": "breakout_up は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_pullback_to_ma20_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "pullback_to_ma20",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "pullback_to_ma20 は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_range_middle_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "range_middle",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 0.0,
      "average_r": -0.3799,
      "total_r": -0.7597,
      "missed_opportunity_count": 0,
      "current_behavior": "range_middle は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_risk_penalty_high_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "risk_penalty_high",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": -0.297,
      "total_r": -0.297,
      "missed_opportunity_count": 0,
      "current_behavior": "risk_penalty_high は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_rr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "rr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_rsi_overbought_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "rsi_overbought",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rsi_overbought は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-06-16T07:20:58",
      "period_start": "2026-05-18",
      "period_end": "2026-06-16",
      "proposal_id": "20260616_reason_code_rsi_oversold_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "rsi_oversold",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 4,
      "win_rate": 0.0,
      "average_r": -0.1425,
      "total_r": -0.5702,
      "missed_opportunity_count": 0,
      "current_behavior": "rsi_oversold は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動反映しない",
    "closed評価が30〜50件以上溜まるまでは提案のみ",
    "人間レビュー後に必要なら実装"
  ]
}
```
