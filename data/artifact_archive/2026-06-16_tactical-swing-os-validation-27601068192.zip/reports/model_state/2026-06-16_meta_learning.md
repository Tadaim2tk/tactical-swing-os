# Meta Learning Layer

## 1. 概要

- 生成日時JST: 2026-06-16 16:21:01 JST
- meta_learning_status: unavailable
- proposal_impact_status: unavailable
- total_candidates: 0
- success_pattern_count: 0
- failure_pattern_count: 0
- neutral_pattern_count: 0
- insufficient_data_count: 0
- recommended_next_action: wait_for_more_data
- apply_automatically: false
- weights_json_updated: false
- patch_applied: false
- requires_human_approval: true

## 2. 成功パターン候補

該当なし

## 3. 失敗パターン候補

該当なし

## 4. 保留・中立候補

該当なし

## 5. 注意事項

- Meta Learningは提案のみです
- weights.jsonは更新しません
- patchは適用しません
- 自動適用は禁止です
- 実売買・発注・XM操作は行いません
- Proposal Impactが未取得の場合は、未取得summaryのみ生成します
