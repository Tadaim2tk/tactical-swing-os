# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-13 08:41:04 JST
取得日時（UTC）: 2026-06-12 23:41:04 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.7
headline件数: 30

## 見出し

- [CNBC Markets] Trump administration: Iran deal signing likely in coming days, but not '100%' certain (未分類)
- [CNBC Markets] Paramount-WBD merger wins approval from DOJ (未分類)
- [CNBC Markets] Small investors scrambled to get in on the SpaceX IPO, even as some believe the valuation is 'stupid' (SPX)
- [CNBC Markets] Trump name must be removed from Kennedy Center by Friday night as appeals court denies DOJ motion (US10Y|DXY)
- [CNBC Markets] SpaceX market cap tops $2 trillion after shares of Elon Musk's rocket company gain 19% on debut (SPX|NASDAQ)
- [CNBC Markets] Top House Republican’s family investment poised to benefit from SpaceX IPO (未分類)
- [CNBC Markets] Call Kevin Warsh the Fed 'chairman' (US10Y|DXY)
- [CNBC Markets] As investors flock to SpaceX, one trader eyes a sleepy 'stealth' play (未分類)
- [CNBC Markets] For Warsh as Fed chair, silence may be the point (US10Y|DXY)
- [CNBC Markets] Pirro's losses in Fed investigation should stay on the books, judge rules (US10Y|DXY)
- [CNBC Markets] Jim Cramer says it's not too late to buy SpaceX — under one condition (未分類)
- [CNBC Markets] SpaceX COO Shotwell says Tesla tie-up ‘might make Elon’s life a little easier’ (NASDAQ)
- [CNBC Markets] SpaceX 'proxies' plunge as real deal arrives: Here's where traders are buying the dip (SPX)
- [CNBC Markets] Social Security COLA for 2027 may jump to 4.7%, one estimate finds. This chart shows prices driving the increase (未分類)
- [CNBC Markets] Judge blocks DOJ 'anti-weaponization' fund for longer, wants guarantee it’s dead (US10Y|DXY)
- [CNBC Markets] New SpaceX millionaires are reinventing the business of managing large wealth (未分類)
- [CNBC Markets] SpaceX’s Gwynne Shotwell had IPO doubts for years, now she has a message for investors (未分類)
- [CNBC Markets] Goldman nets a big payday for SpaceX IPO. Plus, what drove our winners and losers this week (GOLD)
- [CNBC Markets] How to get SpaceX stock — without buying the IPO (SPX)
- [CNBC Markets] U.S. crude oil falls below $85 as U.S. and Iran near a deal to reopen Hormuz (WTI)
- [CNBC Markets] The S&P 500 already made a big call on SpaceX stock and index fund investors need to know it (SPX)
- [CNBC Markets] Bitcoin's latest plunge revives the debate over owning it—and whether it's just 'crypto being crypto' (BTC|VIX)
- [CNBC Markets] Options volume in space stocks boomed as investors look for any way 'to get long SpaceX' (SPX)
- [CNBC Markets] Meta reportedly begins dismantling $2 billion Manus deal on Beijing's orders (未分類)
- [CNBC Markets] Former Tesla board member says SpaceX needs to achieve 2 of its 3 moonshots to keep its valuation (未分類)
- [CNBC Markets] Warren questions SpaceX IPO oversight in new letter to stock indexes (未分類)
- [CNBC Markets] Some U.S. states still don't know if the World Cup will benefit them financially—just look at New Jersey (未分類)
- [MarketWatch Top Stories] This hidden investing flaw is costing you money. Talking to political opponents fixes it. (未分類)
- [MarketWatch Top Stories] There’s a 68% chance the stock market ends the year higher. Why the headlines shouldn’t disrupt your portfolio. (未分類)
- [MarketWatch Top Stories] ‘This is not a flash in the pan’: Why value stocks are beating growth by such a wide margin (SPX|NASDAQ)
