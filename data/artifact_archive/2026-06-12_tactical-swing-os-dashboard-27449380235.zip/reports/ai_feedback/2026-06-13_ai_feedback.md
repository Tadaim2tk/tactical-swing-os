# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-13 08:41:05 JST
Actions実行時刻（UTC）: 2026-06-12 23:41:05 UTC
対象日: 2026-06-13
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 36.5
- risk_off: 39.02
- dollar: 35.06
- rate: 34.97
- volatility: 46.66
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=1, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 36.5 | 39.02 | 35.06 | 34.97 | 63.05 | 36.41 | 46.66 | 93.86 |
| DXY | 52.14 | 47.53 | 50.08 | 49.96 | 47.21 | 52.02 | 46.66 | 92.78 |
| GOLD | 52.14 | 47.53 | 50.08 | 49.96 | 47.21 | 52.02 | 46.66 | 92.78 |
| NASDAQ | 52.14 | 47.53 | 50.08 | 49.96 | 47.21 | 52.02 | 46.66 | 92.78 |
| SPX | 52.14 | 47.53 | 50.08 | 49.96 | 47.21 | 52.02 | 46.66 | 92.78 |
| US10Y | 52.14 | 47.53 | 50.08 | 49.96 | 47.21 | 52.02 | 46.66 | 92.78 |
| USDJPY | 52.14 | 47.53 | 50.08 | 49.96 | 47.21 | 52.02 | 46.66 | 92.78 |
| VIX | 52.14 | 47.53 | 50.08 | 49.96 | 47.21 | 52.02 | 46.66 | 92.78 |
| WTI | 52.14 | 47.53 | 50.08 | 49.96 | 47.21 | 52.02 | 46.66 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260613_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり
- top_news_drivers: Trump administration: Iran deal signing likely in coming days, but not '100%' certain, Call Kevin Warsh the Fed 'chairman', For Warsh as Fed chair, silence may be the point, Social Security COLA for 2027 may jump to 4.7%, one estimate finds. This chart shows prices driving the increase, Judge blocks DOJ 'anti-weaponization' fund for longer, wants guarantee it’s dead

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-12T23:41:05,2026-06-13 08:41:05 JST,2026-06-12 23:41:05 UTC,2026-06-13,USDJPY,20260613_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,36.5,39.02,35.06,34.97,63.05,36.41,46.66,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-12T23:41:05",
  "generated_at_jst": "2026-06-13 08:41:05 JST",
  "generated_at_utc": "2026-06-12 23:41:05 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-13",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 90,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "top_news_drivers": [
    {
      "title": "Trump administration: Iran deal signing likely in coming days, but not '100%' certain",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "gold_safe_haven_news_score:war|gold_safe_haven_news_score:conflict|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/12/iran-deal-trump-pakistan-sharif.html"
    },
    {
      "title": "Call Kevin Warsh the Fed 'chairman'",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/12/fed-kevin-warsh-chairman-title.html"
    },
    {
      "title": "For Warsh as Fed chair, silence may be the point",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/12/warsh-fed-chair-interest-rates.html"
    },
    {
      "title": "Social Security COLA for 2027 may jump to 4.7%, one estimate finds. This chart shows prices driving the increase",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "inflation_pressure_news_score:inflation",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/06/12/social-security-cola-2027-inflation-estimate.html"
    },
    {
      "title": "Judge blocks DOJ 'anti-weaponization' fund for longer, wants guarantee it’s dead",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/12/trump-doj-fund-preliminary-injunction-blanche-bessent.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 36.5,
      "risk_off_score": 39.02,
      "dollar_strength_score": 35.06,
      "rate_pressure_score": 34.97,
      "gold_safe_haven_score": 63.05,
      "oil_supply_risk_proxy_score": 34.21,
      "crypto_liquidity_score": 36.41,
      "equity_momentum_score": 37.08,
      "volatility_stress_score": 46.66,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 0.0,
      "risk_off_news_score": 19.17,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 100.0,
      "oil_supply_risk_news_score": 0.0,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 95.83,
      "inflation_pressure_news_score": 19.17,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 52.14,
      "risk_off_score": 47.53,
      "dollar_strength_score": 50.08,
      "rate_pressure_score": 49.96,
      "gold_safe_haven_score": 47.21,
      "oil_supply_risk_proxy_score": 48.87,
      "crypto_liquidity_score": 52.02,
      "equity_momentum_score": 52.97,
      "volatility_stress_score": 46.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1375,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 52.14,
      "risk_off_score": 47.53,
      "dollar_strength_score": 50.08,
      "rate_pressure_score": 49.96,
      "gold_safe_haven_score": 47.21,
      "oil_supply_risk_proxy_score": 48.87,
      "crypto_liquidity_score": 52.02,
      "equity_momentum_score": 52.97,
      "volatility_stress_score": 46.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1181,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 52.14,
      "risk_off_score": 47.53,
      "dollar_strength_score": 50.08,
      "rate_pressure_score": 49.96,
      "gold_safe_haven_score": 47.21,
      "oil_supply_risk_proxy_score": 48.87,
      "crypto_liquidity_score": 52.02,
      "equity_momentum_score": 52.97,
      "volatility_stress_score": 46.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.7503,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 52.14,
      "risk_off_score": 47.53,
      "dollar_strength_score": 50.08,
      "rate_pressure_score": 49.96,
      "gold_safe_haven_score": 47.21,
      "oil_supply_risk_proxy_score": 48.87,
      "crypto_liquidity_score": 52.02,
      "equity_momentum_score": 52.97,
      "volatility_stress_score": 46.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.5238,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 52.14,
      "risk_off_score": 47.53,
      "dollar_strength_score": 50.08,
      "rate_pressure_score": 49.96,
      "gold_safe_haven_score": 47.21,
      "oil_supply_risk_proxy_score": 48.87,
      "crypto_liquidity_score": 52.02,
      "equity_momentum_score": 52.97,
      "volatility_stress_score": 46.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.313,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 52.14,
      "risk_off_score": 47.53,
      "dollar_strength_score": 50.08,
      "rate_pressure_score": 49.96,
      "gold_safe_haven_score": 47.21,
      "oil_supply_risk_proxy_score": 48.87,
      "crypto_liquidity_score": 52.02,
      "equity_momentum_score": 52.97,
      "volatility_stress_score": 46.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1645,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 52.14,
      "risk_off_score": 47.53,
      "dollar_strength_score": 50.08,
      "rate_pressure_score": 49.96,
      "gold_safe_haven_score": 47.21,
      "oil_supply_risk_proxy_score": 48.87,
      "crypto_liquidity_score": 52.02,
      "equity_momentum_score": 52.97,
      "volatility_stress_score": 46.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": -9.3798,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 52.14,
      "risk_off_score": 47.53,
      "dollar_strength_score": 50.08,
      "rate_pressure_score": 49.96,
      "gold_safe_haven_score": 47.21,
      "oil_supply_risk_proxy_score": 48.87,
      "crypto_liquidity_score": 52.02,
      "equity_momentum_score": 52.97,
      "volatility_stress_score": 46.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": -2.7124,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260613_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
