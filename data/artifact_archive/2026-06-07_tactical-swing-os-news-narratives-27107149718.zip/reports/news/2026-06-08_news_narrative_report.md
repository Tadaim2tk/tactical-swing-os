# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-08 07:47:56 JST
生成日時（UTC）: 2026-06-07 22:47:56 UTC
headline件数: 57
ニュース市場バイアス: mixed
ニュース矛盾スコア: 74.46
主要テーマ: gold_safe_haven, geopolitical_risk, risk_off, risk_on
日本語要約: 金安全資産需要、地政学リスク、リスクオフ要因が目立ち、リスクオン材料とリスクオフ材料が混在しています。方向感は一方向ではなく、ボラティリティ上昇に注意が必要です。
ニュースモード: ニュースは混在 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 74.46
- risk_off_news_score: 93.07
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 100.0
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 37.23
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Fragile ceasefire in jeopardy as Iran reportedly fires missiles at Israel (地政学リスク / リスクオフ要因)
- Inflation inside the electronics you buy may soon become a bit more sticky (インフレ圧力 / 金利圧力候補)
- Chinese EVs may hit U.S. within a few years, one way or another (インフレ圧力 / 金利圧力候補)
- U.S. confirms second Texas screwworm case, Canada restricts livestock imports (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Abel goes his own way with new Berkshire investments, including billions for AI (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Wall Street's 'fear gauge' punches back as the 'crash up' in chip stocks finally reverses (リスクオフ要因 / リスクオン要因)
- Social media bans on teens risk strengthening Big Tech's grip on the sector, Bluesky exec warns (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Amazon unveils latest warehouse robot as tech giants continue AI layoffs (地政学リスク / 金安全資産需要 / リスクオフ要因)
- U.S. stock futures dip, oil prices surge as new attacks threaten the cease-fire with Iran (地政学リスク / リスクオフ要因 / リスクオン要因)
- S&P 500 sees $1.8 trillion wipeout, Nasdaq tallies biggest point drop on record: What investors need to know about Friday’s selloff (リスクオフ要因)
