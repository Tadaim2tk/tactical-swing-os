# Pending Signal Re-evaluation Report

## 1. 概要

* 生成日時JST: 2026-06-15 08:21:11 JST
* データソース: sheets
* 対象SIGNALS件数: 81
* 再評価対象件数: 25
* closed化した件数: 9
* no_entry継続件数: 1
* open継続件数: 15
* missed_opportunity件数: 0
* Sheets保存: 実行
* Sheets保存成功件数: 21
* Sheets重複スキップ件数: 4
* Sheets保存warning: なし

## 2. 決着したシグナル

| signal_id | asset | side | rank | previous_outcome | outcome | r_multiple | error_type |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_DXY_LONG_TREND | DXY | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B |  | win_tp1 | 1.087 | target_reached |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260605_DXY_LONG_TREND | DXY | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B |  | win_tp1 | 1.087 | target_reached |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B |  | loss_sl | -1.0 | stop_loss |

## 3. 未決着継続

| signal_id | asset | side | rank | outcome | mfe_r | mae_r | bars_checked |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 0.0295 | -0.2523 | 8 |
| 20260605_DXY_LONG_A-Momentum | DXY | LONG | B | open_unresolved | 0.1269 | -0.2691 | 6 |
| 20260605_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.7325 | 0.0001 | 6 |
| 20260605_US10Y_LONG_A-Pullback | US10Y | LONG | B | open_unresolved | 0.1602 | -0.3819 | 5 |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.7836 | 0.0297 | 6 |
| 20260608_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.7917 | 0.0343 | 5 |
| 20260608_US10Y_LONG_B-Watch | US10Y | LONG | B | open_unresolved | 0.0821 | -0.5098 | 4 |
| 20260609_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 0.0965 | -0.2004 | 5 |
| 20260609_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.02 | -0.0761 | 4 |
| 20260609_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 0.4328 | -0.2116 | 4 |
| 20260610_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.067 | -0.3877 | 3 |
| 20260611_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 0.2558 | -0.0392 | 2 |
| 20260612_WTI_SHORT_B-Watch | WTI | SHORT | B | no_entry | 0.1808 | 0.0947 | 1 |
| 20260614_NASDAQ_LONG_A-Pullback | NASDAQ | LONG | B | open_unresolved |  |  | 0 |
| 20260614_SPX_LONG_A-Pullback | SPX | LONG | B | open_unresolved |  |  | 0 |
| 20260614_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved |  |  | 0 |

## 4. 取り逃し候補

取り逃し候補はありません。

## 5. No Trade再評価

No Trade再評価は実行していません。

## 6. 注意

* このレポートは実売買ではありません。
* Tactical Swing OS が過去に出した判断の仮想評価です。
* 価格データの欠損や市場休場により、評価が遅れる場合があります。
* append-only運用でEVALUATIONSへ追記する場合、分析側では最新評価行を採用する必要があります。
