# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-11 07:42:43 JST
取得日時（UTC）: 2026-07-10 22:42:43 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.92
headline件数: 75

## 見出し

- [CNBC Markets] SK Hynix rises 13% in Nasdaq debut. Chairman tells CNBC 'demand is enormous' (USDJPY|NASDAQ|DXY)
- [CNBC Markets] Apple sues OpenAI alleging trade secret theft, says scheme was 'at every level' (未分類)
- [CNBC Markets] Trump says he won't sign housing bill, which would become law automatically (未分類)
- [CNBC Markets] OpenAI power consolidates under co-founder Greg Brockman ahead of prospective IPO (未分類)
- [CNBC Markets] The AI race is shifting from bigger models to cheaper, smarter systems (未分類)
- [CNBC Markets] Trump admin eases export controls for UAE; Warren blasts 'corrupt' provision (未分類)
- [CNBC Markets] Stablecoin issuer Circle just got the greenlight to operate as a bank. The shares are up 5% (SPX)
- [CNBC Markets] Traders fall back in love with Meta. Here's where bulls see it going (SPX)
- [CNBC Markets] These are America's 10 most expensive states for 2026, where inflation is punishing residents (未分類)
- [CNBC Markets] These are America's 10 cheapest states for 2026, where you can still beat inflation (未分類)
- [CNBC Markets] Senate Democrats want hearings on Trump’s crypto holdings and foreign investors (BTC)
- [CNBC Markets] Trump purges Election Assistance Commission members, months before midterms (未分類)
- [CNBC Markets] The ETF market is pushing the limits of the leverage it can handle. SK Hynix is the latest example (BTC)
- [CNBC Markets] As bank earnings approach, a market anomaly emerges (SPX|NASDAQ)
- [CNBC Markets] Trump Accounts may help foster children build a financial safety net. What to know (未分類)
- [CNBC Markets] Air taxi company Beta wraps first test flights in U.S. government's pilot program (US10Y|DXY)
- [CNBC Markets] America's Top States for Business 2026: See the full rankings and where your state finished (未分類)
- [CNBC Markets] How Apple stock rode the AI rollercoaster to record highs in 1 chart (SPX)
- [CNBC Markets] Trump says U.S. to continue talks with Iran despite scrapped ceasefire (未分類)
- [CNBC Markets] How the U.S.-Iran deal set the stage for renewed fighting over the Strait of Hormuz (未分類)
- [CNBC Markets] Meta's stock has best week since early 2024 as optimism builds around AI strategy (未分類)
- [CNBC Markets] Kraken is rebuilding its app around agentic trading as crypto exchanges evolve beyond crypto (BTC)
- [CNBC Markets] Delta expects higher airfare to last, bringing 2026 profit goal in reach, CEO says (未分類)
- [CNBC Markets] Meta found to breach EU laws with 'addictive' Instagram, Facebook designs (未分類)
- [CNBC Markets] Private chef salaries reach $300,000 as the rich seek their own Michelin stars (未分類)
- [CNBC Markets] OpenAI exec Fidji Simo says she's stepping down due to chronic illness, will transition to advisor (未分類)
- [CNBC Markets] Inside NATO's extraordinary 48 hours that revealed Trump's grip on global diplomacy (未分類)
- [CNBC Markets] AI, data center fears could be key in closely watched Michigan Democratic Senate primary (VIX)
- [CNBC Markets] I worked at a garden center for $17/hour after getting laid off—why it's 'one of the best jobs I've ever had' (未分類)
- [CNBC Markets] Why the stock market and economy may seem out of sync (未分類)
- [MarketWatch Top Stories] Meta’s stock roars back to life as it notches its best week in years (未分類)
- [MarketWatch Top Stories] SK Hynix’s stock sees double-digit pop in Nasdaq debut (NASDAQ)
- [MarketWatch Top Stories] Apple sues OpenAI for alleged theft of confidential info — and says that’s just ‘the tip of the iceberg’ (未分類)
- [MarketWatch Top Stories] ‘I’d hate to end up with an unexpected tax bill’: I’m 73 and still work full time. Can I avoid paying taxes on my Social Security benefits? (未分類)
- [MarketWatch Top Stories] ‘I get $1,460 in Social Security’: My millionaire ex-husband, 74, refuses to pay alimony. What can I do? (未分類)
- [MarketWatch Top Stories] My insurance company said my roof lost a few tiles. Loss adjusters found $10,000 in storm damage. How could this happen? (未分類)
- [MarketWatch Top Stories] Summer travel season is here: Make this vital purchase before your next vacation (未分類)
- [MarketWatch Top Stories] Where to put cash right now: Should you lock in at 4% — or wait for the next Fed rate decision? (US10Y|DXY)
- [MarketWatch Top Stories] A hedge-fund trade blamed for a massive market blowup in 2024 has made a big comeback, Goldman Sachs says (GOLD)
- [MarketWatch Top Stories] Prepare for the Fed to undo rate cuts that stabilized the economy, expert cautions (US10Y|DXY)
- [CoinDesk] Meta's Chief Data Officer Says Agentic Commerce is the "Next Tier of Business" (未分類)
- [CoinDesk] U.S. government digital dollar set to be banned tonight under housing law's CBDC limit (USDJPY|DXY)
- [CoinDesk] Hyundai becomes first major South Korean company to introduce internal stablecoin transfers (未分類)
- [CoinDesk] OKX, MetaMask, Matter Labs back dispute resolution court for AI agents (未分類)
- [CoinDesk] Circle soars after securing U.S. trust bank approval in crypto expansion (BTC|US10Y|DXY)
- [CoinDesk] Japan's 'invest locally' plan likely to spur demand for assets like bitcoin, gold (BTC|GOLD)
- [CoinDesk] Crypto defies equity weakness as altcoin optimism builds into the weekend (BTC)
- [CoinDesk] Polymarket seeks approval to bring margin trading to U.S. customers (未分類)
- [CoinDesk] Bitcoin's $60,000-$70,000 range becomes third most traded range in history (BTC)
- [CoinDesk] Metaplanet explores bringing bitcoin-backed digital credit to Japan (BTC|US10Y|DXY)
