# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-11 07:42:44 JST
生成日時（UTC）: 2026-07-10 22:42:44 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.92
ニュース市場バイアス: neutral
ニュース矛盾スコア: 18.47
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 55.4
- risk_off_news_score: 18.47
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 18.47
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 36.93
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 36.93
- inflation_pressure_news_score: 36.93
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- These are America's 10 most expensive states for 2026, where inflation is punishing residents (インフレ圧力 / 金利圧力候補)
- These are America's 10 cheapest states for 2026, where you can still beat inflation (インフレ圧力 / 金利圧力候補)
- Meta's stock has best week since early 2024 as optimism builds around AI strategy (リスクオン要因)
- Crypto defies equity weakness as altcoin optimism builds into the weekend (リスクオン要因)
- Live updates: Bitcoin rises to $64,000 as SK Hynix opens for trade after $26.5 billion IPO (暗号資産流動性)
- Bitcoin zips higher to nearly $64,000 as chip rally and yen strength drive gains (リスクオフ要因 / リスクオン要因)
- Billions flowing out of bitcoin ETFs and private credit funds suggest rising market risks (暗号資産流動性)
- Russia stocks lower at close of trade; MOEX Russia Index down 2.13% (地政学リスク / リスクオフ要因)
- Occidental’s quarterly realized oil prices jump amid Iran war disruption (地政学リスク / 金安全資産需要 / リスクオフ要因)
