# Tactical Swing OS Reason Code Analysis

## 1. 結論

reason_codesの有効性を集計しました。

対象期間: 2026-07-05 - 2026-07-11

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. reason_codes 上位プラス要因

_該当なし_

## 3. reason_codes 上位マイナス要因

_該当なし_

## 4. no_trade_reason 分析

| no_trade_reason | count | no_trade_correct_count | no_trade_missed_count | missed_opportunity_count | average_mfe_r | average_r | assessment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rr_too_low | 15 | 3 | 1 | 0 | 0.0 | 0.0 | over_filtering_risk |
| low_volatility | 5 | 1 | 0 | 0 | 0.0 | 0.0 | neutral |

## 5. 取り逃し候補

| no_trade_reason | count | no_trade_correct_count | no_trade_missed_count | missed_opportunity_count | average_mfe_r | average_r | assessment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rr_too_low | 15 | 3 | 1 | 0 | 0.0 | 0.0 | over_filtering_risk |

## 6. 改善候補

_該当なし_

## 7. データ不足の注意

reason_codeごとの評価件数が5件未満の場合は `insufficient_data` とし、weights.jsonは自動更新しません。

## 8. REASON_CODE_ANALYSIS CSV

```csv
reason_code,signals_count,evaluated_count,win_count,loss_count,no_entry_count,missed_opportunity_count,win_rate,total_r,average_r,median_r,best_r,worst_r,average_mfe_r,average_mae_r,rank_a_count,rank_b_count,no_trade_count,recommended_action_trade_count,recommended_action_watch_count,recommended_action_no_trade_count,reliability_label
atr_too_high,4,4,0,0,0,0,0.0,0.2412,0.0804,0.1025,0.1387,0.0,0.1308,-0.3317,0,3,1,0,3,1,insufficient_data
ma_alignment_bull,13,13,0,0,0,0,0.0,0.4805,0.0437,0.0,0.2132,0.0,0.1418,-0.273,0,6,7,0,6,7,neutral
trend_up,13,13,0,0,0,0,0.0,0.4805,0.0437,0.0,0.2132,0.0,0.1418,-0.273,0,6,7,0,6,7,neutral
momentum_negative,13,13,0,0,0,0,0.0,0.4622,0.0385,0.0,0.2132,0.0,0.1651,-0.281,0,4,9,0,4,9,neutral
breakout_up,2,2,0,0,0,0,0.0,0.0261,0.0261,0.0261,0.0261,0.0261,0.0843,-0.1681,0,2,0,0,2,0,insufficient_data
pullback_to_ma20,11,11,0,0,0,0,0.0,0.2412,0.0241,0.0,0.1387,0.0,0.1308,-0.3317,0,3,8,0,3,8,neutral
momentum_positive,11,11,0,0,0,0,0.0,0.1387,0.0154,0.0,0.1387,0.0,0.1443,-0.0999,0,3,8,0,3,8,neutral
rr_too_low,20,20,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,20,0,0,20,neutral
ma_alignment_bear,6,6,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,1,5,0,1,5,neutral
trend_down,6,6,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,1,5,0,1,5,neutral
atr_too_low,5,5,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,5,0,0,5,neutral
range_middle,5,5,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,5,0,0,5,neutral
overextended,2,2,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,2,0,0,2,insufficient_data
breakout_down,1,1,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,1,0,0,1,0,insufficient_data
rsi_oversold,1,1,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,1,0,0,1,insufficient_data
```

## 9. REASON_CODE_ANALYSIS JSON

```json
{
  "start_date": "2026-07-05",
  "end_date": "2026-07-11",
  "reason_code_summary": [
    {
      "reason_code": "atr_too_high",
      "signals_count": 4,
      "evaluated_count": 4,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.2412,
      "average_r": 0.0804,
      "median_r": 0.1025,
      "best_r": 0.1387,
      "worst_r": 0.0,
      "average_mfe_r": 0.1308,
      "average_mae_r": -0.3317,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 1,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 1,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 13,
      "evaluated_count": 13,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.4805,
      "average_r": 0.0437,
      "median_r": 0.0,
      "best_r": 0.2132,
      "worst_r": 0.0,
      "average_mfe_r": 0.1418,
      "average_mae_r": -0.273,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 13,
      "evaluated_count": 13,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.4805,
      "average_r": 0.0437,
      "median_r": 0.0,
      "best_r": 0.2132,
      "worst_r": 0.0,
      "average_mfe_r": 0.1418,
      "average_mae_r": -0.273,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "momentum_negative",
      "signals_count": 13,
      "evaluated_count": 13,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.4622,
      "average_r": 0.0385,
      "median_r": 0.0,
      "best_r": 0.2132,
      "worst_r": 0.0,
      "average_mfe_r": 0.1651,
      "average_mae_r": -0.281,
      "rank_a_count": 0,
      "rank_b_count": 4,
      "no_trade_count": 9,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 4,
      "recommended_action_no_trade_count": 9,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "breakout_up",
      "signals_count": 2,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0261,
      "average_r": 0.0261,
      "median_r": 0.0261,
      "best_r": 0.0261,
      "worst_r": 0.0261,
      "average_mfe_r": 0.0843,
      "average_mae_r": -0.1681,
      "rank_a_count": 0,
      "rank_b_count": 2,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 2,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "pullback_to_ma20",
      "signals_count": 11,
      "evaluated_count": 11,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.2412,
      "average_r": 0.0241,
      "median_r": 0.0,
      "best_r": 0.1387,
      "worst_r": 0.0,
      "average_mfe_r": 0.1308,
      "average_mae_r": -0.3317,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 8,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 8,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "momentum_positive",
      "signals_count": 11,
      "evaluated_count": 11,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.1387,
      "average_r": 0.0154,
      "median_r": 0.0,
      "best_r": 0.1387,
      "worst_r": 0.0,
      "average_mfe_r": 0.1443,
      "average_mae_r": -0.0999,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 8,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 8,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rr_too_low",
      "signals_count": 20,
      "evaluated_count": 20,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 20,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 20,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "ma_alignment_bear",
      "signals_count": 6,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 5,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_down",
      "signals_count": 6,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 5,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "atr_too_low",
      "signals_count": 5,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 5,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "range_middle",
      "signals_count": 5,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 5,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "overextended",
      "signals_count": 2,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 2,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 2,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "breakout_down",
      "signals_count": 1,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "rsi_oversold",
      "signals_count": 1,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 1,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 1,
      "reliability_label": "insufficient_data"
    }
  ],
  "no_trade_reason_summary": [
    {
      "no_trade_reason": "rr_too_low",
      "count": 15,
      "no_trade_correct_count": 3,
      "no_trade_missed_count": 1,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "over_filtering_risk"
    },
    {
      "no_trade_reason": "low_volatility",
      "count": 5,
      "no_trade_correct_count": 1,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    }
  ],
  "top_positive_reasons": [],
  "top_negative_reasons": [],
  "over_filtering_candidates": [
    {
      "no_trade_reason": "rr_too_low",
      "count": 15,
      "no_trade_correct_count": 3,
      "no_trade_missed_count": 1,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "over_filtering_risk"
    }
  ],
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 249,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "notes": [
    "reason_code単位のweights自動更新はまだ行いません。",
    "insufficient_data reason_codes: 5"
  ]
}
```
