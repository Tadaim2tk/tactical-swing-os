# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-24 08:16:47 JST
取得日時（UTC）: 2026-06-23 23:16:47 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.03
headline件数: 30

## 見出し

- [CNBC Markets] Cerebras falls 10% after chipmaker forecasts shrinking margin in first earnings report since IPO (SPX|NASDAQ)
- [CNBC Markets] SpaceX raises $25 billion in debt sale less than two weeks after IPO (未分類)
- [CNBC Markets] Alphabet added to Dow Jones Industrial Average, replacing Verizon (未分類)
- [CNBC Markets] Factory job cuts in June neared financial crisis and Covid levels, S&P says (SPX)
- [CNBC Markets] FedEx posts strong earnings results in last quarter with freight business (SPX|NASDAQ|US10Y|DXY)
- [CNBC Markets] PGA Tour CEO Brian Rolapp unveils sweeping changes to professional golf (未分類)
- [CNBC Markets] House expected to pass affordable housing bill, send it to Trump's desk (未分類)
- [CNBC Markets] Mamdani-backed candidates are likely to win in NYC primaries, prediction market traders expect (未分類)
- [CNBC Markets] Five things to watch in Tuesday's primaries as New York races take center stage (未分類)
- [CNBC Markets] Senate backs Iran war powers resolution as GOP pressure grows on Trump's deal to end war (未分類)
- [CNBC Markets] Bill Gates testimony on Jeffrey Epstein ties released by House oversight panel (未分類)
- [CNBC Markets] CFTC sues Kentucky over actions against prediction markets, making it first red state to face federal scrutiny (US10Y|DXY)
- [CNBC Markets] Inside Kevin Warsh's selection process for the next Atlanta Fed president (US10Y|DXY)
- [CNBC Markets] Strait of Hormuz evacuation plan to begin for ships stranded in Persian Gulf, maritime organization says (未分類)
- [CNBC Markets] Traders are loving this cheap way to make big bets against chip stocks (SPX|NASDAQ)
- [CNBC Markets] Meta announces new smart glasses starting at $299, as Zuckerberg keeps pushing wearables (未分類)
- [CNBC Markets] An off-grid power project gets a major proof of concept. What it means for GE Vernova (未分類)
- [CNBC Markets] Meta is building a prediction markets app. These stocks fell in response (SPX)
- [CNBC Markets] Sen. Cassidy plans to push 'big idea' for Social Security reform in last days in office (未分類)
- [CNBC Markets] Progressive Brad Lander’s surging bid for Congress splinters Democrats' labor union alliance (GOLD)
- [CNBC Markets] SpaceX seeing some interest from short sellers, but many still afraid to bet against Musk (SPX)
- [CNBC Markets] SpaceX closes nearly 1% higher, snapping three-day losing streak (未分類)
- [CNBC Markets] U.S. issues sweeping Iran oil sanctions waivers, unlocking billions in revenue for Tehran (WTI)
- [CNBC Markets] 'I like their money': Trump threatens lawsuits against ABC for reporting on Reflecting Pool (US10Y|DXY)
- [CNBC Markets] Trump administration to loan $17 billion to speed deployment of 10 big nuclear reactors in U.S. (未分類)
- [CNBC Markets] Brexit 10 years later: How the UK economy and politics changed, in charts (未分類)
- [CNBC Markets] Oracle sheds 21,000 roles over the past year amid wave of AI layoffs from tech giants (NASDAQ)
- [CNBC Markets] Google’s online dominance is showing signs of cracking in AI era (SPX)
- [CNBC Markets] Gold and silver tumble as rate-hike fears hit precious metals (GOLD|SPX|VIX)
- [CNBC Markets] Sens. Warren, Kelly press Trump administration on effects of tariffs on manufacturing (未分類)
