# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-24 08:16:49 JST
Actions実行時刻（UTC）: 2026-06-23 23:16:49 UTC
対象日: 2026-06-23
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 35.0
- risk_off: 40.69
- dollar: 35.14
- rate: 35.17
- volatility: 49.83
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=3, neutral=6, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 35.0 | 40.69 | 35.14 | 35.17 | 48.53 | 35.01 | 49.83 | 93.86 |
| DXY | 50.0 | 49.92 | 50.2 | 50.24 | 49.62 | 50.02 | 49.83 | 92.78 |
| GOLD | 50.0 | 49.92 | 50.2 | 50.24 | 49.62 | 50.02 | 49.83 | 92.78 |
| NASDAQ | 50.0 | 49.92 | 50.2 | 50.24 | 49.62 | 50.02 | 49.83 | 92.78 |
| SPX | 50.0 | 49.92 | 50.2 | 50.24 | 49.62 | 50.02 | 49.83 | 92.78 |
| US10Y | 50.0 | 49.92 | 50.2 | 50.24 | 49.62 | 50.02 | 49.83 | 92.78 |
| USDJPY | 50.0 | 49.92 | 50.2 | 50.24 | 49.62 | 50.02 | 49.83 | 92.78 |
| VIX | 50.0 | 49.92 | 50.2 | 50.24 | 49.62 | 50.02 | 49.83 | 92.78 |
| WTI | 50.0 | 49.92 | 50.2 | 50.24 | 49.62 | 50.02 | 49.83 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260623_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260623_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|atr_too_low|rr_too_low|range_middle | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260623_DXY_LONG_A-Momentum | DXY | LONG | B | WATCH | trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought | conflicted | -15 | DXYはドル高圧力を中心に評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260623_GOLD_SHORT_B-Watch | GOLD | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative | conflicted | -19 | GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260623_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | NO_TRADE | momentum_positive|atr_too_high|rr_too_low|range_middle|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260623_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | NO_TRADE | atr_too_high|rr_too_low|range_middle | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260623_US10Y_LONG_A-Pullback | US10Y | LONG | B | WATCH | trend_up|ma_alignment_bull|momentum_negative|range_middle|pullback_to_ma20 | conflicted | -15 | US10Yは金利上昇圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260623_VIX_NONE_NO_TRADE | VIX | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low|range_middle|overextended | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260623_WTI_SHORT_B-Watch | WTI | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative|breakout_down|rsi_oversold|overextended | neutral | -11 | WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- top_news_drivers: Factory job cuts in June neared financial crisis and Covid levels, S&P says, Senate backs Iran war powers resolution as GOP pressure grows on Trump's deal to end war, Traders are loving this cheap way to make big bets against chip stocks, U.S. issues sweeping Iran oil sanctions waivers, unlocking billions in revenue for Tehran

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-23T23:16:49,2026-06-24 08:16:49 JST,2026-06-23 23:16:49 UTC,2026-06-23,USDJPY,20260623_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,35.0,40.69,35.14,35.17,48.53,35.01,49.83,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-23T23:16:49,2026-06-24 08:16:49 JST,2026-06-23 23:16:49 UTC,2026-06-23,BTC,20260623_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|atr_too_low|rr_too_low|range_middle,neutral,0,35.0,40.69,35.14,35.17,48.53,35.01,49.83,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-23T23:16:49,2026-06-24 08:16:49 JST,2026-06-23 23:16:49 UTC,2026-06-23,DXY,20260623_DXY_LONG_A-Momentum,LONG,B,WATCH,trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought,conflicted,-15,35.0,40.69,35.14,35.17,48.53,35.01,49.83,93.86,100.0,market_proxy_plus_news,,,context_warning,DXYはドル高圧力を中心に評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,DXY LONG は市場文脈と衝突。明日はrank/entry条件を慎重化する仮説。,False,sheets_evaluations,False,True
2026-06-23T23:16:49,2026-06-24 08:16:49 JST,2026-06-23 23:16:49 UTC,2026-06-23,GOLD,20260623_GOLD_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative,conflicted,-19,35.0,40.69,35.14,35.17,48.53,35.01,49.83,93.86,100.0,market_proxy_plus_news,,,context_warning,GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,GOLD SHORT は市場文脈と衝突。明日はrank/entry条件を慎重化する仮説。,False,sheets_evaluations,False,True
2026-06-23T23:16:49,2026-06-24 08:16:49 JST,2026-06-23 23:16:49 UTC,2026-06-23,NASDAQ,20260623_NASDAQ_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|atr_too_high|rr_too_low|range_middle|pullback_to_ma20,neutral,0,35.0,40.69,35.14,35.17,48.53,35.01,49.83,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,NASDAQ NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-23T23:16:49,2026-06-24 08:16:49 JST,2026-06-23 23:16:49 UTC,2026-06-23,SPX,20260623_SPX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,atr_too_high|rr_too_low|range_middle,neutral,0,35.0,40.69,35.14,35.17,48.53,35.01,49.83,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,SPX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-23T23:16:49,2026-06-24 08:16:49 JST,2026-06-23 23:16:49 UTC,2026-06-23,US10Y,20260623_US10Y_LONG_A-Pullback,LONG,B,WATCH,trend_up|ma_alignment_bull|momentum_negative|range_middle|pullback_to_ma20,conflicted,-15,35.0,40.69,35.14,35.17,48.53,35.01,49.83,93.86,100.0,market_proxy_plus_news,,,context_warning,US10Yは金利上昇圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,US10Y LONG は市場文脈と衝突。明日はrank/entry条件を慎重化する仮説。,False,sheets_evaluations,False,True
2026-06-23T23:16:49,2026-06-24 08:16:49 JST,2026-06-23 23:16:49 UTC,2026-06-23,VIX,20260623_VIX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low|range_middle|overextended,neutral,0,35.0,40.69,35.14,35.17,48.53,35.01,49.83,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,VIX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-23T23:16:49,2026-06-24 08:16:49 JST,2026-06-23 23:16:49 UTC,2026-06-23,WTI,20260623_WTI_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative|breakout_down|rsi_oversold|overextended,neutral,-11,35.0,40.69,35.14,35.17,48.53,35.01,49.83,93.86,100.0,market_proxy_plus_news,,,context_neutral,WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,WTI SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-23T23:16:49",
  "generated_at_jst": "2026-06-24 08:16:49 JST",
  "generated_at_utc": "2026-06-23 23:16:49 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-23",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
  "top_news_drivers": [
    {
      "title": "Factory job cuts in June neared financial crisis and Covid levels, S&P says",
      "source": "CNBC Markets",
      "matched_assets": "SPX",
      "matched_rules": "risk_off_news_score:crisis",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/23/factory-job-cuts-reported-around-financial-crisis-and-covid-levels-for-june-sp-says.html"
    },
    {
      "title": "Senate backs Iran war powers resolution as GOP pressure grows on Trump's deal to end war",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "gold_safe_haven_news_score:war|oil_supply_risk_news_score:sanctions|geopolitical_risk_news_score:sanctions|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|oil_supply_risk|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/23/thune-congress-vote-trump-iran-deal.html"
    },
    {
      "title": "Traders are loving this cheap way to make big bets against chip stocks",
      "source": "CNBC Markets",
      "matched_assets": "SPX|NASDAQ",
      "matched_rules": "central_bank_dovish_score:pivot",
      "driver_tags": "central_bank_dovish",
      "driver_summary_ja": "中銀ハト派",
      "link": "https://www.cnbc.com/2026/06/23/traders-are-loving-this-cheap-way-to-make-big-bets-against-chip-stocks.html"
    },
    {
      "title": "U.S. issues sweeping Iran oil sanctions waivers, unlocking billions in revenue for Tehran",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "oil_supply_risk_news_score:sanctions|geopolitical_risk_news_score:sanctions",
      "driver_tags": "oil_supply_risk|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 原油供給リスク / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/23/us-iran-oil-sanction-relief-strait-of-hormuz-peace-deal-.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 35.0,
      "risk_off_score": 40.69,
      "dollar_strength_score": 35.14,
      "rate_pressure_score": 35.17,
      "gold_safe_haven_score": 48.53,
      "oil_supply_risk_proxy_score": 46.41,
      "crypto_liquidity_score": 35.01,
      "equity_momentum_score": 35.02,
      "volatility_stress_score": 49.83,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 0.0,
      "risk_off_news_score": 19.17,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 19.17,
      "oil_supply_risk_news_score": 38.33,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 57.5,
      "inflation_pressure_news_score": 0.0,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 50.0,
      "risk_off_score": 49.92,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.24,
      "gold_safe_haven_score": 49.62,
      "oil_supply_risk_proxy_score": 49.88,
      "crypto_liquidity_score": 50.02,
      "equity_momentum_score": 50.03,
      "volatility_stress_score": 49.83,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.3812,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 50.0,
      "risk_off_score": 49.92,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.24,
      "gold_safe_haven_score": 49.62,
      "oil_supply_risk_proxy_score": 49.88,
      "crypto_liquidity_score": 50.02,
      "equity_momentum_score": 50.03,
      "volatility_stress_score": 49.83,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1768,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 50.0,
      "risk_off_score": 49.92,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.24,
      "gold_safe_haven_score": 49.62,
      "oil_supply_risk_proxy_score": 49.88,
      "crypto_liquidity_score": 50.02,
      "equity_momentum_score": 50.03,
      "volatility_stress_score": 49.83,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.3611,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 50.0,
      "risk_off_score": 49.92,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.24,
      "gold_safe_haven_score": 49.62,
      "oil_supply_risk_proxy_score": 49.88,
      "crypto_liquidity_score": 50.02,
      "equity_momentum_score": 50.03,
      "volatility_stress_score": 49.83,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.2114,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 50.0,
      "risk_off_score": 49.92,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.24,
      "gold_safe_haven_score": 49.62,
      "oil_supply_risk_proxy_score": 49.88,
      "crypto_liquidity_score": 50.02,
      "equity_momentum_score": 50.03,
      "volatility_stress_score": 49.83,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1337,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 50.0,
      "risk_off_score": 49.92,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.24,
      "gold_safe_haven_score": 49.62,
      "oil_supply_risk_proxy_score": 49.88,
      "crypto_liquidity_score": 50.02,
      "equity_momentum_score": 50.03,
      "volatility_stress_score": 49.83,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0136,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 50.0,
      "risk_off_score": 49.92,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.24,
      "gold_safe_haven_score": 49.62,
      "oil_supply_risk_proxy_score": 49.88,
      "crypto_liquidity_score": 50.02,
      "equity_momentum_score": 50.03,
      "volatility_stress_score": 49.83,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.9151,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 50.0,
      "risk_off_score": 49.92,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.24,
      "gold_safe_haven_score": 49.62,
      "oil_supply_risk_proxy_score": 49.88,
      "crypto_liquidity_score": 50.02,
      "equity_momentum_score": 50.03,
      "volatility_stress_score": 49.83,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.2461,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260623_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260623_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|atr_too_low|rr_too_low|range_middle",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260623_DXY_LONG_A-Momentum",
      "asset": "DXY",
      "side": "LONG",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought",
      "narrative_alignment": "conflicted",
      "narrative_alignment_score": -15,
      "narrative_comment": "DXYはドル高圧力を中心に評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260623_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative",
      "narrative_alignment": "conflicted",
      "narrative_alignment_score": -19,
      "narrative_comment": "GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260623_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|atr_too_high|rr_too_low|range_middle|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260623_SPX_NONE_NO_TRADE",
      "asset": "SPX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "atr_too_high|rr_too_low|range_middle",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260623_US10Y_LONG_A-Pullback",
      "asset": "US10Y",
      "side": "LONG",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_negative|range_middle|pullback_to_ma20",
      "narrative_alignment": "conflicted",
      "narrative_alignment_score": -15,
      "narrative_comment": "US10Yは金利上昇圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260623_VIX_NONE_NO_TRADE",
      "asset": "VIX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low|range_middle|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260623_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|breakout_down|rsi_oversold|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": -11,
      "narrative_comment": "WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
