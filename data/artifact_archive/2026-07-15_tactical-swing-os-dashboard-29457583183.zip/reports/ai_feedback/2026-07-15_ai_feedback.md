# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-07-16 08:07:43 JST
Actions実行時刻（UTC）: 2026-07-15 23:07:43 UTC
対象日: 2026-07-15
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 35.51
- risk_off: 34.4
- dollar: 34.89
- rate: 34.37
- volatility: 48.93
- news_confidence: 92.0
- シグナル整合性: aligned=1, conflicted=0, neutral=9, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 35.51 | 34.4 | 34.89 | 34.37 | 43.54 | 35.52 | 48.93 | 92.78 |
| DXY | 50.73 | 49.14 | 49.85 | 49.1 | 49.06 | 50.75 | 48.93 | 92.78 |
| ETH | 50.73 | 49.14 | 49.85 | 49.1 | 49.06 | 50.75 | 48.93 | 92.78 |
| GOLD | 50.73 | 49.14 | 49.85 | 49.1 | 49.06 | 50.75 | 48.93 | 92.78 |
| NASDAQ | 50.73 | 49.14 | 49.85 | 49.1 | 49.06 | 50.75 | 48.93 | 92.78 |
| SPX | 50.73 | 49.14 | 49.85 | 49.1 | 49.06 | 50.75 | 48.93 | 92.78 |
| US10Y | 50.73 | 49.14 | 49.85 | 49.1 | 49.06 | 50.75 | 48.93 | 92.78 |
| USDJPY | 50.73 | 49.14 | 49.85 | 49.1 | 49.06 | 50.75 | 48.93 | 92.78 |
| VIX | 50.73 | 49.14 | 49.85 | 49.1 | 49.06 | 50.75 | 48.93 | 92.78 |
| WTI | 50.73 | 49.14 | 49.85 | 49.1 | 49.06 | 50.75 | 48.93 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260715_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | momentum_positive|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260715_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low|range_middle | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260715_ETH_NONE_NO_TRADE | ETH | NONE | NO_TRADE | NO_TRADE | momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low|overextended | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260715_GOLD_NONE_NO_TRADE | GOLD | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260715_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | NO_TRADE | momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260715_SPX_LONG_B-Watch | SPX | LONG | B | WATCH | trend_up|ma_alignment_bull|momentum_positive | neutral | -9 | SPXは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260715_US10Y_NONE_NO_TRADE | US10Y | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260715_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260715_VIX_SHORT_TREND | VIX | SHORT | A | TRADE | trend_down|ma_alignment_bear|momentum_negative|overextended | aligned | 17 | VIXはボラティリティストレスとリスクオフで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260715_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | NO_TRADE | momentum_negative|rsi_overbought|rr_too_low|overextended | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり
- top_news_drivers: Wholesale prices unexpectedly declined 0.3% in June on big drop in gasoline, Trump says Iran wants to meet as U.S. fires more strikes; analysts warn of 'forever war' risk

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-07-15T23:07:43,2026-07-16 08:07:43 JST,2026-07-15 23:07:43 UTC,2026-07-15,BTC,20260715_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|atr_too_low|rr_too_low,neutral,0,35.51,34.4,34.89,34.37,43.54,35.52,48.93,92.78,92.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-15T23:07:43,2026-07-16 08:07:43 JST,2026-07-15 23:07:43 UTC,2026-07-15,DXY,20260715_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low|range_middle,neutral,0,35.51,34.4,34.89,34.37,43.54,35.52,48.93,92.78,92.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-15T23:07:43,2026-07-16 08:07:43 JST,2026-07-15 23:07:43 UTC,2026-07-15,ETH,20260715_ETH_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low|overextended,neutral,0,35.51,34.4,34.89,34.37,43.54,35.52,48.93,92.78,92.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,ETH NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-15T23:07:43,2026-07-16 08:07:43 JST,2026-07-15 23:07:43 UTC,2026-07-15,GOLD,20260715_GOLD_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rr_too_low,neutral,0,35.51,34.4,34.89,34.37,43.54,35.52,48.93,92.78,92.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,GOLD NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-15T23:07:43,2026-07-16 08:07:43 JST,2026-07-15 23:07:43 UTC,2026-07-15,NASDAQ,20260715_NASDAQ_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20,neutral,0,35.51,34.4,34.89,34.37,43.54,35.52,48.93,92.78,92.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,NASDAQ NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-15T23:07:43,2026-07-16 08:07:43 JST,2026-07-15 23:07:43 UTC,2026-07-15,SPX,20260715_SPX_LONG_B-Watch,LONG,B,WATCH,trend_up|ma_alignment_bull|momentum_positive,neutral,-9,35.51,34.4,34.89,34.37,43.54,35.52,48.93,92.78,92.0,market_proxy_plus_news,open_unresolved,,context_neutral,SPXは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,SPX LONG は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-15T23:07:43,2026-07-16 08:07:43 JST,2026-07-15 23:07:43 UTC,2026-07-15,US10Y,20260715_US10Y_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low,neutral,0,35.51,34.4,34.89,34.37,43.54,35.52,48.93,92.78,92.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,US10Y NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-15T23:07:43,2026-07-16 08:07:43 JST,2026-07-15 23:07:43 UTC,2026-07-15,USDJPY,20260715_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low|pullback_to_ma20,neutral,0,35.51,34.4,34.89,34.37,43.54,35.52,48.93,92.78,92.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-15T23:07:43,2026-07-16 08:07:43 JST,2026-07-15 23:07:43 UTC,2026-07-15,VIX,20260715_VIX_SHORT_TREND,SHORT,A,TRADE,trend_down|ma_alignment_bear|momentum_negative|overextended,aligned,17,35.51,34.4,34.89,34.37,43.54,35.52,48.93,92.78,92.0,market_proxy_plus_news,open_unresolved,,context_support,VIXはボラティリティストレスとリスクオフで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,VIX SHORT は市場文脈と整合。既存ルールを維持し、過剰強化はしない。,False,sheets_evaluations,False,True
2026-07-15T23:07:43,2026-07-16 08:07:43 JST,2026-07-15 23:07:43 UTC,2026-07-15,WTI,20260715_WTI_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|rsi_overbought|rr_too_low|overextended,neutral,0,35.51,34.4,34.89,34.37,43.54,35.52,48.93,92.78,92.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,WTI NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-07-15T23:07:43",
  "generated_at_jst": "2026-07-16 08:07:43 JST",
  "generated_at_utc": "2026-07-15 23:07:43 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-07-15",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 94,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "top_news_drivers": [
    {
      "title": "Wholesale prices unexpectedly declined 0.3% in June on big drop in gasoline",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "central_bank_dovish_score:easing",
      "driver_tags": "central_bank_dovish",
      "driver_summary_ja": "中銀ハト派",
      "link": "https://www.cnbc.com/2026/07/15/wholesale-inflation-june-2026-.html"
    },
    {
      "title": "Trump says Iran wants to meet as U.S. fires more strikes; analysts warn of 'forever war' risk",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "gold_safe_haven_news_score:war|oil_supply_risk_news_score:middle east|geopolitical_risk_news_score:middle east|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|oil_supply_risk|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/07/15/trump-iran-hormuz-strikes-power-plants-targeted.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 35.51,
      "risk_off_score": 34.4,
      "dollar_strength_score": 34.89,
      "rate_pressure_score": 34.37,
      "gold_safe_haven_score": 43.54,
      "oil_supply_risk_proxy_score": 40.93,
      "crypto_liquidity_score": 35.52,
      "equity_momentum_score": 35.62,
      "volatility_stress_score": 48.93,
      "narrative_confidence": 92.78,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 0.0,
      "risk_off_news_score": 0.0,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 19.17,
      "oil_supply_risk_news_score": 19.17,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 38.33,
      "inflation_pressure_news_score": 0.0,
      "recession_risk_news_score": 0.0,
      "news_confidence": 92.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 50.73,
      "risk_off_score": 49.14,
      "dollar_strength_score": 49.85,
      "rate_pressure_score": 49.1,
      "gold_safe_haven_score": 49.06,
      "oil_supply_risk_proxy_score": 50.26,
      "crypto_liquidity_score": 50.75,
      "equity_momentum_score": 50.89,
      "volatility_stress_score": 48.93,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.4162,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "ETH",
      "risk_on_score": 50.73,
      "risk_off_score": 49.14,
      "dollar_strength_score": 49.85,
      "rate_pressure_score": 49.1,
      "gold_safe_haven_score": 49.06,
      "oil_supply_risk_proxy_score": 50.26,
      "crypto_liquidity_score": 50.75,
      "equity_momentum_score": 50.89,
      "volatility_stress_score": 48.93,
      "narrative_confidence": 92.78,
      "asset_change_pct": 1.7212,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 50.73,
      "risk_off_score": 49.14,
      "dollar_strength_score": 49.85,
      "rate_pressure_score": 49.1,
      "gold_safe_haven_score": 49.06,
      "oil_supply_risk_proxy_score": 50.26,
      "crypto_liquidity_score": 50.75,
      "equity_momentum_score": 50.89,
      "volatility_stress_score": 48.93,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0614,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 50.73,
      "risk_off_score": 49.14,
      "dollar_strength_score": 49.85,
      "rate_pressure_score": 49.1,
      "gold_safe_haven_score": 49.06,
      "oil_supply_risk_proxy_score": 50.26,
      "crypto_liquidity_score": 50.75,
      "equity_momentum_score": 50.89,
      "volatility_stress_score": 48.93,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0059,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 50.73,
      "risk_off_score": 49.14,
      "dollar_strength_score": 49.85,
      "rate_pressure_score": 49.1,
      "gold_safe_haven_score": 49.06,
      "oil_supply_risk_proxy_score": 50.26,
      "crypto_liquidity_score": 50.75,
      "equity_momentum_score": 50.89,
      "volatility_stress_score": 48.93,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.023,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 50.73,
      "risk_off_score": 49.14,
      "dollar_strength_score": 49.85,
      "rate_pressure_score": 49.1,
      "gold_safe_haven_score": 49.06,
      "oil_supply_risk_proxy_score": 50.26,
      "crypto_liquidity_score": 50.75,
      "equity_momentum_score": 50.89,
      "volatility_stress_score": 48.93,
      "narrative_confidence": 92.78,
      "asset_change_pct": -1.3672,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 50.73,
      "risk_off_score": 49.14,
      "dollar_strength_score": 49.85,
      "rate_pressure_score": 49.1,
      "gold_safe_haven_score": 49.06,
      "oil_supply_risk_proxy_score": 50.26,
      "crypto_liquidity_score": 50.75,
      "equity_momentum_score": 50.89,
      "volatility_stress_score": 48.93,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0049,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 50.73,
      "risk_off_score": 49.14,
      "dollar_strength_score": 49.85,
      "rate_pressure_score": 49.1,
      "gold_safe_haven_score": 49.06,
      "oil_supply_risk_proxy_score": 50.26,
      "crypto_liquidity_score": 50.75,
      "equity_momentum_score": 50.89,
      "volatility_stress_score": 48.93,
      "narrative_confidence": 92.78,
      "asset_change_pct": -3.2716,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 50.73,
      "risk_off_score": 49.14,
      "dollar_strength_score": 49.85,
      "rate_pressure_score": 49.1,
      "gold_safe_haven_score": 49.06,
      "oil_supply_risk_proxy_score": 50.26,
      "crypto_liquidity_score": 50.75,
      "equity_momentum_score": 50.89,
      "volatility_stress_score": 48.93,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.55,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260715_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260715_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low|range_middle",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260715_ETH_NONE_NO_TRADE",
      "asset": "ETH",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260715_GOLD_NONE_NO_TRADE",
      "asset": "GOLD",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260715_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260715_SPX_LONG_B-Watch",
      "asset": "SPX",
      "side": "LONG",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": -9,
      "narrative_comment": "SPXは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260715_US10Y_NONE_NO_TRADE",
      "asset": "US10Y",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260715_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260715_VIX_SHORT_TREND",
      "asset": "VIX",
      "side": "SHORT",
      "rank": "A",
      "recommended_action": "TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|overextended",
      "narrative_alignment": "aligned",
      "narrative_alignment_score": 17,
      "narrative_comment": "VIXはボラティリティストレスとリスクオフで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260715_WTI_NONE_NO_TRADE",
      "asset": "WTI",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|rsi_overbought|rr_too_low|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
