# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-16 08:07:41 JST
生成日時（UTC）: 2026-07-15 23:07:41 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.84
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 19.17
- oil_supply_risk_news_score: 19.17
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 38.33
- inflation_pressure_news_score: 0.0
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 19.17
- news_confidence: 92.0

## Top News Drivers

- Wholesale prices unexpectedly declined 0.3% in June on big drop in gasoline (中銀ハト派)
- Trump says Iran wants to meet as U.S. fires more strikes; analysts warn of 'forever war' risk (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
