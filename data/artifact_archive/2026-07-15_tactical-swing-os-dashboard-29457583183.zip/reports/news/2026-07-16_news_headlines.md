# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-16 08:07:39 JST
取得日時（UTC）: 2026-07-15 23:07:39 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.84
headline件数: 30

## 見出し

- [CNBC Markets] Fed Chairman Warsh says he meets 'often' with Trump administration, defends independence (US10Y|DXY)
- [CNBC Markets] United earnings top estimates but airline expects $6 billion in added fuel costs (SPX|NASDAQ)
- [CNBC Markets] World Cup gave bars and restaurants a needed boost as consumers flash warning signs, Fed says (US10Y|DXY)
- [CNBC Markets] Kalshi traders see gas prices crossing $4 by end of July (未分類)
- [CNBC Markets] Trump's pick to head national intelligence, Jay Clayton, won't tell senators Biden won the 2020 election (未分類)
- [CNBC Markets] Warren Buffett on the market today: 'It's tough to find values when everybody is preferring gambling' (未分類)
- [CNBC Markets] Historic IBM stock crash sets up unique options strategy (SPX)
- [CNBC Markets] Trump blasts New York AI data center moratorium, says state should change policy 'immediately' (未分類)
- [CNBC Markets] Warren Buffett tells CNBC he initiated Berkshire Hathaway's investment in Alphabet (未分類)
- [CNBC Markets] Mortgage rates rise to highest level in nearly a year, causing homebuyers to pause (US10Y|DXY)
- [CNBC Markets] Anthropic moves closer to mega-IPO as bankers line up investor meetings (未分類)
- [CNBC Markets] Public Service Loan Forgiveness has new rules — 3 changes borrowers should know about (未分類)
- [CNBC Markets] SpaceX stock sinks below $135 IPO price for the first time (SPX|NASDAQ)
- [CNBC Markets] Amazon senior cloud executive departs after 18 years (未分類)
- [CNBC Markets] Fed Chairman Kevin Warsh's testimony to Senate banking committee hits on economy, interest rates (US10Y|DXY)
- [CNBC Markets] J&J falls despite a beat-and-raise quarter. Why we're raising our price target anyways (未分類)
- [CNBC Markets] Wholesale prices unexpectedly declined 0.3% in June on big drop in gasoline (WTI)
- [CNBC Markets] Todd Blanche says he has 'full faith' in Kash Patel as FBI director (未分類)
- [CNBC Markets] IRS chief Frank Bisignano will lead Trump Accounts expansion (US10Y|DXY)
- [CNBC Markets] DTCC, Wall Street’s post-trade powerhouse, tests tokenized markets with industry heavy hitters (SPX)
- [CNBC Markets] Goldman Sachs’ former top lawyer tells House Epstein was a ‘masterful liar’ who used her to bolster his standing (GOLD)
- [CNBC Markets] ‘Arsenal of democracy’: Jamie Dimon announces $24 million effort to boost American shipbuilding (未分類)
- [CNBC Markets] Trump says Iran wants to meet as U.S. fires more strikes; analysts warn of 'forever war' risk (未分類)
- [CNBC Markets] Morgan Stanley posts record quarterly revenue and profit as equities trading surges 69% (GOLD)
- [CNBC Markets] Stripe, Advent make $53 billion takeover offer for PayPal, sending stock soaring (未分類)
- [CNBC Markets] Hassett sees no 'excuse' to raise rates, says Warsh will push Fed to 'right answer' (US10Y|DXY)
- [CNBC Markets] Star analyst Dan Ives forms Yorkville Ives merchant bank after leaving Wedbush (未分類)
- [CNBC Markets] Warren Buffett calls Bill Gates' actions with Epstein 'distasteful' but says people make mistakes (未分類)
- [CNBC Markets] Americans say they need $1.2 million to retire comfortably, survey finds — but many expect to fall short (未分類)
- [CNBC Markets] Alibaba’s U.S.-listed shares rise 4% after Qwen AI set to be integrated in Apple Intelligence (SPX)
