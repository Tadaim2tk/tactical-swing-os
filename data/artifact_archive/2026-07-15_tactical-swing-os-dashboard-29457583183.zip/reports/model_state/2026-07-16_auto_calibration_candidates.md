# Auto Calibration Candidates

## 1. 概要

- 生成日時JST: 2026-07-16 08:08:02 JST
- candidate_status: active
- candidate_count: 47
- increase_count: 0
- decrease_count: 0
- hold_count: 47
- insufficient_data_count: 0
- blocked_count: 0
- recommended_next_action: wait_for_more_data
- requires_human_approval: true
- patch_applied: false
- weights_json_updated: false
- generate_signal_updated: false
- apply_automatically: false

## 2. 候補一覧

| candidate_id | asset | category | target | factor | classification | current_value | suggested_delta | suggested_value | confidence | sample_size | source | rationale |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| AC_0001_20260716_asset_BTC_asset_weight_adjustment |  | asset | BTC | asset_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 38 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0002_20260716_asset_DXY_asset_weight_adjustment |  | asset | DXY | asset_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 32 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0003_20260716_asset_GOLD_asset_weight_adjustment |  | asset | GOLD | asset_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 33 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0004_20260716_asset_NASDAQ_asset_weight_adjustment |  | asset | NASDAQ | asset_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 34 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0005_20260716_asset_SPX_asset_weight_adjustment |  | asset | SPX | asset_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 32 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0006_20260716_asset_US10Y_asset_weight_adjustment |  | asset | US10Y | asset_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 27 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0007_20260716_asset_USDJPY_asset_weight_adjustment |  | asset | USDJPY | asset_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 31 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0008_20260716_asset_VIX_asset_weight_adjustment |  | asset | VIX | asset_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 26 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0009_20260716_asset_WTI_asset_weight_adjustment |  | asset | WTI | asset_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 32 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0010_20260716_narrative_crypto_liquidity_narrative_weight_adjustment |  | narrative | crypto_liquidity | narrative_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 286 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |

## 3. ブロック/保留候補

該当なし

## 4. 注意事項

- Auto Calibration Candidatesは将来の重み変更候補を作るだけです
- weights.jsonは更新しません
- patchは適用しません
- generate_signal.pyは変更しません
- Google Sheetsへの書き込みは行いません
- 実売買・発注・XM操作は行いません
- すべての候補は人間承認が必須です
