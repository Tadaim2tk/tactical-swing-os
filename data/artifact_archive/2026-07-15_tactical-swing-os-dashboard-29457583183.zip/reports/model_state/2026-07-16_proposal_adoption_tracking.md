# Proposal Adoption Tracking

## 1. 概要

- 生成日時JST: 2026-07-16 08:08:00 JST
- tracking_status: active
- review_status: blocked
- total_tracked_proposals: 47
- accepted_count: 0
- pending_review_count: 0
- held_count: 0
- rejected_count: 0
- blocked_count: 0
- superseded_count: 0
- manual_decision_count: 0
- derived_decision_count: 47
- recommended_next_action: no_action
- requires_human_approval: true
- patch_applied: false
- weights_json_updated: false

## 2. 承認判断待ち

該当なし

## 3. 保留中

該当なし

## 4. 確定済みまたはブロック済み

該当なし

## 5. 注意

- このレポートは提案の採用状態を追跡するだけです
- weights.jsonは更新しません
- patchは適用しません
- 実売買・発注・XM操作は行いません
- 手動判断ファイルがない場合はWeights Patch Reviewから状態を自動導出します
