# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-12 07:32:03 JST
取得日時（UTC）: 2026-07-11 22:32:03 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.07
headline件数: 71

## 見出し

- [CNBC Markets] 'Funflation' hits home: Why staying in isn't the cost-saver it used to be (未分類)
- [CNBC Markets] Trump threatens to 'decimate' Iran if it tries to kill him, as Treasury sanctions alleged Iranian financier (US10Y|DXY)
- [CNBC Markets] Apple sues OpenAI alleging trade secret theft, says scheme was 'at every level' (未分類)
- [CNBC Markets] Burnout, frustration and heartbreak: Amazon layoffs take their toll in saturated job market (未分類)
- [CNBC Markets] New housing law targets affordability — what it means for homebuyers and sellers (未分類)
- [CNBC Markets] These underperforming trades could yield big returns over next six months (BTC|SPX|US10Y)
- [CNBC Markets] Berkshire Hathaway gains ground, but still trails the S&P 500 as '26 enters second half (SPX)
- [CNBC Markets] A tiny GLP-1 implant is the latest bet to help patients maintain their weight loss (未分類)
- [CNBC Markets] The best states to live in for 2026: No. 1 has a six-year winning streak (未分類)
- [CNBC Markets] These are America’s 10 worst states to live in for 2026 (未分類)
- [CNBC Markets] AstraZeneca's trial flop raises a bigger question: Is its pipeline premium becoming more vulnerable? (未分類)
- [CNBC Markets] Trump Accounts: Who is eligible, how $1,000 deposits work and how to open one (未分類)
- [CNBC Markets] While Musk's Neuralink drills into skulls, China's BrainCo bets the future of brain tech is wearable (NASDAQ)
- [CNBC Markets] From booksmaxxing to looksmaxxing: Why the viral trends concern some mental health experts (未分類)
- [CNBC Markets] SK Hynix rises 13% in Nasdaq debut. Chairman tells CNBC 'demand is enormous' (USDJPY|NASDAQ|DXY)
- [CNBC Markets] OpenAI power consolidates under co-founder Greg Brockman ahead of prospective IPO (未分類)
- [CNBC Markets] The volatile AI trade marched higher, but oil kept Wall Street on edge last week (WTI|SPX|NASDAQ)
- [CNBC Markets] The AI race is shifting from bigger models to cheaper, smarter systems (未分類)
- [CNBC Markets] Trump admin eases export controls for UAE; Warren blasts 'corrupt' provision (未分類)
- [CNBC Markets] Stablecoin issuer Circle just got the greenlight to operate as a bank. The shares are up 5% (SPX)
- [CNBC Markets] Traders fall back in love with Meta. Here's where bulls see it going (SPX)
- [CNBC Markets] Senate Democrats want hearings on Trump’s crypto holdings and foreign investors (BTC)
- [CNBC Markets] Trump purges Election Assistance Commission members, months before midterms (未分類)
- [CNBC Markets] The ETF market is pushing the limits of the leverage it can handle. SK Hynix is the latest example (BTC)
- [CNBC Markets] As bank earnings approach, a market anomaly emerges (SPX|NASDAQ)
- [CNBC Markets] Trump Accounts may help foster children build a financial safety net. What to know (未分類)
- [CNBC Markets] Air taxi company Beta wraps first test flights in U.S. government's pilot program (US10Y|DXY)
- [CNBC Markets] How the U.S.-Iran deal set the stage for renewed fighting over the Strait of Hormuz (未分類)
- [CNBC Markets] Meta's stock has best week since early 2024 as optimism builds around AI strategy (未分類)
- [CNBC Markets] Kraken is rebuilding its app around agentic trading as crypto exchanges evolve beyond crypto (BTC)
- [MarketWatch Top Stories] My insurance company said my roof lost a few tiles. Loss adjusters found $10,000 in storm damage. How could this happen? (未分類)
- [MarketWatch Top Stories] ‘I get $1,460 in Social Security’: My millionaire ex-husband, 74, refuses to pay alimony. What can I do? (未分類)
- [MarketWatch Top Stories] ‘It’s heartbreaking’: My brother claimed Social Security at 70. He died from cancer after one payment. Why wait to claim? (未分類)
- [MarketWatch Top Stories] Is it better to spend my savings now so I can delay taking Social Security? How do I choose? (未分類)
- [MarketWatch Top Stories] Your data built the AI boom — but Big Tech is pocketing 100% of the equity (NASDAQ)
- [MarketWatch Top Stories] Only 5% of U.S. adults can ace this 8-question financial-literacy test. Can you? (未分類)
- [MarketWatch Top Stories] You want a portfolio that matches your morals. Your retirement plan might disagree. (未分類)
- [MarketWatch Top Stories] The dot-com crash was a $5 trillion blip. Why the next financial crisis could hit 4 times harder. (未分類)
- [MarketWatch Top Stories] Stocks rally when Congress goes on summer break. Here’s why. (SPX|VIX)
- [MarketWatch Top Stories] Your investing expectations are more than double the reality. Here is the tough truth. (未分類)
- [CoinDesk] Lending protocol Bonzo loses 77% of value locked as $9 million oracle exploit rattles Hedera (未分類)
- [CoinDesk] Crypto IPO market stalls as capital rotates to AI and macro uncertainty weighs (BTC)
- [CoinDesk] The UK has finally shown it’s serious about crypto (BTC)
- [CoinDesk] Bitcoin treasury company Empery Digital sold about half of its BTC stack (BTC|US10Y|DXY)
- [CoinDesk] AI found an Ethereum bug that could take validators offline, but humans had to prove it (BTC)
- [CoinDesk] Bitcoin analysts predict $300,000–$500,000 price in 2029. The math says no (BTC)
- [CoinDesk] Meta's Chief Data Officer Says Agentic Commerce is the "Next Tier of Business" (未分類)
- [CoinDesk] U.S. government digital dollar set to be banned tonight under housing law's CBDC limit (USDJPY|DXY)
- [CoinDesk] Hyundai becomes first major South Korean company to introduce internal stablecoin transfers (未分類)
- [CoinDesk] OKX, MetaMask, Matter Labs back dispute resolution court for AI agents (未分類)
