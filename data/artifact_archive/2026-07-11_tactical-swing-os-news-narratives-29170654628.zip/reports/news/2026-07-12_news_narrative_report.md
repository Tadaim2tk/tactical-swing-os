# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-12 07:32:05 JST
生成日時（UTC）: 2026-07-11 22:32:05 UTC
headline件数: 71
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.07
ニュース市場バイアス: mixed
ニュース矛盾スコア: 73.97
主要テーマ: risk_on, risk_off
日本語要約: リスクオン要因、リスクオフ要因が目立ち、リスクオン材料とリスクオフ材料が混在しています。方向感は一方向ではなく、ボラティリティ上昇に注意が必要です。
ニュースモード: ニュースは混在 / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 92.46
- risk_off_news_score: 73.97
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 18.49
- oil_supply_risk_news_score: 36.99
- crypto_liquidity_news_score: 18.49
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 55.48
- inflation_pressure_news_score: 0.0
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Trump threatens to 'decimate' Iran if it tries to kill him, as Treasury sanctions alleged Iranian financier (地政学リスク / 原油供給リスク / リスクオフ要因)
- Meta's stock has best week since early 2024 as optimism builds around AI strategy (リスクオン要因)
- The dot-com crash was a $5 trillion blip. Why the next financial crisis could hit 4 times harder. (リスクオフ要因)
- Stocks rally when Congress goes on summer break. Here’s why. (リスクオフ要因 / リスクオン要因)
- Crypto IPO market stalls as capital rotates to AI and macro uncertainty weighs (リスクオフ要因)
- Bitcoin analysts predict $300,000–$500,000 price in 2029. The math says no (リスクオン要因)
- Crypto defies equity weakness as altcoin optimism builds into the weekend (リスクオン要因)
- Live updates: Bitcoin rises to $64,000 as SK Hynix opens for trade after $26.5 billion IPO (暗号資産流動性)
- Bitcoin zips higher to nearly $64,000 as chip rally and yen strength drive gains (リスクオフ要因 / リスクオン要因)
- Russia stocks lower at close of trade; MOEX Russia Index unchanged (地政学リスク / リスクオフ要因)
