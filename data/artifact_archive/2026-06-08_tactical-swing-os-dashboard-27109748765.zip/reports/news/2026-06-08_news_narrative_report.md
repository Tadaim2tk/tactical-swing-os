# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-08 09:39:53 JST
生成日時（UTC）: 2026-06-08 00:39:53 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.21
ニュース市場バイアス: neutral
ニュース矛盾スコア: 38.33
主要テーマ: geopolitical_risk
日本語要約: 地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 38.33
- risk_off_news_score: 57.5
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 57.5
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 19.17
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Fragile ceasefire in jeopardy as Iran reportedly fires missiles at Israel (地政学リスク / リスクオフ要因)
- Inflation inside the electronics you buy may soon become a bit more sticky (インフレ圧力 / 金利圧力候補)
- U.S. confirms second Texas screwworm case, Canada restricts livestock imports (地政学リスク / 金安全資産需要 / リスクオフ要因)
- U.S. stock futures mixed, oil prices surge as new attacks threaten the cease-fire with Iran (地政学リスク / リスクオフ要因 / リスクオン要因)
- S&P 500 sees $1.8 trillion wipeout, Nasdaq tallies biggest point drop on record: What investors need to know about Friday’s selloff (リスクオフ要因)
- ‘This would be a one-time event’: How can I take extra money from my 401(k) without triggering higher Medicare premiums? (リスクオン要因)
- Ethereum Foundation cuts and departures aren't a crisis, Joe Lubin says (地政学リスク / リスクオフ要因 / 金安全資産需要)
- Russia stocks lower at close of trade; MOEX Russia Index unchanged (地政学リスク / リスクオフ要因)
