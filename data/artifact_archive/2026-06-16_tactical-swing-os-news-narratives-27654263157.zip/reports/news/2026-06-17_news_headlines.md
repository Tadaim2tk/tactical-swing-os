# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-17 08:12:03 JST
取得日時（UTC）: 2026-06-16 23:12:03 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.29
headline件数: 75

## 見出し

- [CNBC Markets] Fed Chair Warsh expected to withhold 'dot' from central bank's interest rate outlook (US10Y|DXY)
- [CNBC Markets] Carvana is expanding into new vehicles. The implications could reshape the U.S. automotive retail market (未分類)
- [CNBC Markets] Michael Burry says he's tempted to bet against SpaceX, but passes on expensive options (未分類)
- [CNBC Markets] Bill limiting investors from buying homes set to speed through Congress (未分類)
- [CNBC Markets] Databricks sales growth tops 80%, but margin are shrinking from swarm of AI agents (未分類)
- [CNBC Markets] Anthropic's Fable shutdown is a big moment for open-source AI (未分類)
- [CNBC Markets] Intel begins production of most-advanced chip, inching closer to possible Apple deal (NASDAQ)
- [CNBC Markets] Technical factors are adding fuel to SpaceX's meme stock fire (BTC|NASDAQ)
- [CNBC Markets] Jim Cramer says SpaceX investors aren't buying earnings — they're buying Elon Musk (SPX|NASDAQ)
- [CNBC Markets] New Wharton forecast puts Social Security trust fund depletion later than official projections (未分類)
- [CNBC Markets] 'Godfather' of options sees SpaceX surpassing Nvidia, Tesla as early trades come in (未分類)
- [CNBC Markets] SpaceX rises 4% to leapfrog Amazon in market cap, closes short of Microsoft (未分類)
- [CNBC Markets] How Roku fits into Fox's future — and what investors are missing about the deal (未分類)
- [CNBC Markets] DOJ assists Musk's xAI in NAACP air pollution suit, asks court to toss case (US10Y|DXY)
- [CNBC Markets] Snap unveils $2,195 AR glasses as CEO Evan Spiegel bets on post-smartphone future (未分類)
- [CNBC Markets] Veteran traders stunned as SpaceX fans bet on 80% overnight gains: 'I've never seen anything like it' (未分類)
- [CNBC Markets] Trump signals he could send details of Iran deal to Congress (未分類)
- [CNBC Markets] The new oil? Inside the effort to turn AI computing power into a tradeable commodity (WTI)
- [CNBC Markets] SpaceX's blistering start still faces key tests that will determine the stock's true value (未分類)
- [CNBC Markets] Odds that a proposed billionaire tax appears on California ballots plunge on prediction markets (未分類)
- [CNBC Markets] FBI says it disrupted alleged plot targeting UFC event at White House (未分類)
- [CNBC Markets] Prediction market traders speculate Anthropic will restore access quickly to AI model after Trump admin directed it to limit reach (未分類)
- [CNBC Markets] SpaceX to acquire the AI coding startup Cursor for $60 billion (未分類)
- [CNBC Markets] Self-driving tech supplier Mobileye targets U.S. robotaxi launch in 2027 (NASDAQ)
- [CNBC Markets] Novig wins CFTC approval as competition intensifies in sports prediction markets (未分類)
- [CNBC Markets] Kevin Warsh's Fed is not expected to make any change to rates for a while, according to CNBC Fed Survey (US10Y|DXY)
- [CNBC Markets] Brent falls below $80 per barrel on report U.S. will allow Iran to sell oil immediately (WTI)
- [CNBC Markets] Student loan borrowers face glitches and misinformation ahead of major July 1 changes, advocates say (NASDAQ)
- [CNBC Markets] Trump turns his attention to Ukraine ahead of Iran deal: 'I’m going to do whatever I can’ (未分類)
- [CNBC Markets] Yum Brands sells Pizza Hut to private equity firm LongRange Capital and Yum China for $2.7 billion (未分類)
- [MarketWatch Top Stories] Intel takes a major step toward turning around a business that’s bleeding cash (未分類)
- [MarketWatch Top Stories] I’m spending $170,000 to upgrade my home for my aging parents. Can I get tax breaks? (未分類)
- [MarketWatch Top Stories] Chicken tenders are taking over the world, and KFC is rushing to keep up (未分類)
- [MarketWatch Top Stories] Wall Street can’t stop talking about ‘MANGOS’ stocks as the ‘Magnificent Seven’ becomes passé (SPX)
- [MarketWatch Top Stories] ‘We own our home outright’: I am 67 and earn $100,000. Do I take my $30,000-a-year Social Security now or wait? (US10Y)
- [MarketWatch Top Stories] SpaceX trading hits ‘bonkers’ levels as new ETFs see a massive cash influx (BTC)
- [MarketWatch Top Stories] Tesla booted from the ‘Magnificent Seven’ by a top fund manager. Here is the tech giant he’s crowned. (NASDAQ)
- [MarketWatch Top Stories] The one-page pledge that forces your financial adviser to put you first (未分類)
- [MarketWatch Top Stories] A woman bought coasters at my garage sale for $2 — and emailed me that she’s reselling them for $29. Was I ripped off? (未分類)
- [MarketWatch Top Stories] This little-known AI stock has beaten Micron and Arm this year, and now it’s extending its lead (SPX)
- [CoinDesk] Here is why Strategy's dividend-paying crypto stock is crashing to near-historic lows (BTC)
- [CoinDesk] Bitcoin miners' AI pivot faces $50 billion reality check, says VanEck (BTC)
- [CoinDesk] U.S. senators urge Treasury not to leave states out of GENIUS Act stablecoin process (US10Y|DXY)
- [CoinDesk] Hyperliquid, Uniswap and Worldcoin buck crypto slump as traders chase AI, DeFi trends (BTC)
- [CoinDesk] Coinbase intoduces AI advisor, stock options, and pre-IPO markets in finance push (BTC)
- [CoinDesk] Ripple invests in Flutterwave, pushing its stablecoin and XRP Ledger into payments across Africa (未分類)
- [CoinDesk] Coinbase to join tokenized stock race with onchain shares, dividend payments (BTC|SPX)
- [CoinDesk] Binance says its European regulatory application is compliant despite report of Greek rejection (BTC)
- [CoinDesk] Ethereum’s biggest protocol overhaul in years moves into its final development stage (BTC)
- [CoinDesk] State Street targets stablecoin reserve boom with new money market fund (未分類)
