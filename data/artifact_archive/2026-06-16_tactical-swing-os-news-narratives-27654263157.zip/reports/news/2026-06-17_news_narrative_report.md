# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-17 08:12:05 JST
生成日時（UTC）: 2026-06-16 23:12:05 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.29
ニュース市場バイアス: neutral
ニュース矛盾スコア: 18.47
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 18.47
- risk_off_news_score: 18.47
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 18.47
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 55.4
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 55.4
- inflation_pressure_news_score: 0.0
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 36.93
- news_confidence: 100.0

## Top News Drivers

- Kevin Warsh's Fed is not expected to make any change to rates for a while, according to CNBC Fed Survey (中銀ハト派)
- Trump turns his attention to Ukraine ahead of Iran deal: 'I’m going to do whatever I can’ (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Bitcoin miners' AI pivot faces $50 billion reality check, says VanEck (中銀ハト派)
- Hyperliquid, Uniswap and Worldcoin buck crypto slump as traders chase AI, DeFi trends (リスクオフ要因)
- BlackRock's new bitcoin ETF lets institutions earn from volatility. There's a catch. (暗号資産流動性)
- XRP gives back gains after 10% rally as traders take profit near $1.25 (リスクオン要因 / 暗号資産流動性)
- Bitcoin rises after Bank of Japan hikes interest rates to a 31-year high (暗号資産流動性)
