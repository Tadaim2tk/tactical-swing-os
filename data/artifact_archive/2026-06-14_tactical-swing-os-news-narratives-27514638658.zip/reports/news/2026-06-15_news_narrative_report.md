# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-15 07:53:34 JST
生成日時（UTC）: 2026-06-14 22:53:34 UTC
headline件数: 63
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.01
ニュース市場バイアス: neutral
ニュース矛盾スコア: 18.56
主要テーマ: gold_safe_haven, geopolitical_risk
日本語要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 37.11
- risk_off_news_score: 18.56
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 100.0
- oil_supply_risk_news_score: 18.56
- crypto_liquidity_news_score: 55.67
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 0.0
- recession_risk_news_score: 18.56
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 37.11
- news_confidence: 100.0

## Top News Drivers

- U.S. and Iran agree on peace deal to end the war, Trump and Pakistan say (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Trump heads to G7 summit in France after reaching deal to end war with Iran (地政学リスク / 金安全資産需要 / リスクオフ要因)
- UK forces board sanctioned Russian shadow fleet oil tanker (地政学リスク / 原油供給リスク / リスクオフ要因)
- Here are the 3 big things we're watching in the stock market in the week ahead (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Highly charismatic people use 5 'magnetic' phrases to be more likable, says public speaking expert (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Moats vs. moonshots: The Warren Buffett-Elon Musk style debate (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Will the real Kevin Warsh please stand up? Ahead of his first Fed meeting, economists honestly don’t know what to expect. (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Defaults in debt markets are starting again, warns Pimco. Here’s the bond giant’s game plan. (地政学リスク / 金安全資産需要 / 景気後退リスク / リスクオフ要因)
- ‘This would be a one-time event’: How can I take extra money from my 401(k) without triggering higher Medicare premiums? (リスクオン要因)
- Aerodrome is turning liquidity into a prediction market with its biggest upgrade yet (地政学リスク / 暗号資産流動性 / 金安全資産需要 / リスクオフ要因)
