# Tactical Swing OS Audit Report v0.1

**Date:** 2026-06-10

## Data Integrity Score

**Status:** ✅ PASS

## Reasons

- No data integrity anomalies detected.

## Metrics

| item | value |
|---|---:|
| SIGNALS duplicate signal_id | 0 |
| EVALUATIONS duplicate signal_id | 0 |
| Unique reason codes | N/A |
