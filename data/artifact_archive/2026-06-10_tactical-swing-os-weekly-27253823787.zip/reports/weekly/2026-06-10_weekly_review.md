# Tactical Swing OS Weekly Review

## 1. 週次結論

次週モードは「通常」、最大日次リスクは 0.5% です。 データ不足 週次R損益はマイナスです。

## 2. 週次サマリー

| week_start | week_end | total_signals | a_signals | b_signals | no_trade_signals | closed_signals | pending_signals | skipped_signals | win_rate | profit_factor | total_r | average_r | max_win_r | max_loss_r | best_asset | worst_asset | next_week_mode | max_daily_risk_pct | rule_change_1 | rule_change_2 | rule_change_3 | evaluation_source | latest_evaluations_available | fallback_used |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-04 | 2026-06-10 | 49 | 0 | 19 | 30 | 1 | 14 | 5 | 0.0 | 0.0 | -1.0 | -1.0 | -1.0 | -1.0 | DXY | BTC | 通常 | 0.5 | Entry/SL/Rank判定の見直し | 評価期間またはentry条件の見直し | データ不足 | latest_evaluations | True | False |

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 3. Rank別成績

| rank | signals | closed | win_rate | total_r | average_r |
| --- | --- | --- | --- | --- | --- |
| A | 0 | 0 | 0.0 | 0.0 | 0.0 |
| B | 19 | 1 | 0.0 | -1.0 | -1.0 |
| NO_TRADE | 30 | 0 | 0.0 | 0.0 | 0.0 |
| その他 | 0 | 0 | 0.0 | 0.0 | 0.0 |

## 4. 資産別成績

| asset | signals | closed | win_rate | total_r | average_r | best_r | worst_r |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BTC | 7 | 1 | 0.0 | -1.0 | -1.0 | -1.0 | -1.0 |
| DXY | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| GOLD | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| NASDAQ | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| SPX | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| US10Y | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| USDJPY | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| VIX | 4 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| WTI | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |

## 5. Side別成績

| side | signals | closed | win_rate | total_r | average_r | best_r | worst_r |
| --- | --- | --- | --- | --- | --- | --- | --- |
| LONG | 9 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| SHORT | 10 | 1 | 0.0 | -1.0 | -1.0 | -1.0 | -1.0 |
| NONE | 30 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |

## 6. エラー分類

| error_type | count |
| --- | --- |
| unresolved | 9 |
| 未分類 | 5 |
| data_missing | 3 |
| no_entry | 2 |
| stop_loss | 1 |

## 7. 取り逃し監査

| missed_candidate | asset | count | note |
| --- | --- | --- | --- |
| pending_or_skipped_ab | BTC | 2 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | DXY | 2 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | GOLD | 5 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | US10Y | 3 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | USDJPY | 1 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | WTI | 1 | A/B候補の未完了評価が多い可能性 |
| large_mfe_review | GOLD | 1 | MFE=85.432 のためentry/約定条件を確認 |
| large_mfe_review | BTC | 1 | MFE=309.1417 のためentry/約定条件を確認 |
| large_mfe_review | BTC | 1 | MFE=504.5412 のためentry/約定条件を確認 |
| large_mfe_review | GOLD | 1 | MFE=89.1637 のためentry/約定条件を確認 |
| large_mfe_review | GOLD | 1 | MFE=101.4414 のためentry/約定条件を確認 |
| large_mfe_review | GOLD | 1 | MFE=103.2913 のためentry/約定条件を確認 |

## 8. モデル更新メモ

- Entry/SL/Rank判定の見直し
- 評価期間またはentry条件の見直し
- データ不足

## 9. Reason Code分析メモ

reason code analysisは別artifact参照。現時点では分析結果が未生成です。

### reason_code 上位プラス3件

_該当なし_

### reason_code 上位マイナス3件

_該当なし_

### no_trade_reason 取り逃し候補

_該当なし_

## 10. REVIEW_LOG CSV

```csv
week_start,week_end,total_signals,a_signals,b_signals,no_trade_signals,closed_signals,pending_signals,skipped_signals,win_rate,profit_factor,total_r,average_r,max_win_r,max_loss_r,best_asset,worst_asset,next_week_mode,max_daily_risk_pct,rule_change_1,rule_change_2,rule_change_3,evaluation_source,latest_evaluations_available,fallback_used
2026-06-04,2026-06-10,49,0,19,30,1,14,5,0.0,0.0,-1.0,-1.0,-1.0,-1.0,DXY,BTC,通常,0.5,Entry/SL/Rank判定の見直し,評価期間またはentry条件の見直し,データ不足,latest_evaluations,True,False
```

## 11. REVIEW_LOG JSON

```json
[
  {
    "week_start":"2026-06-04",
    "week_end":"2026-06-10",
    "total_signals":49,
    "a_signals":0,
    "b_signals":19,
    "no_trade_signals":30,
    "closed_signals":1,
    "pending_signals":14,
    "skipped_signals":5,
    "win_rate":0.0,
    "profit_factor":0.0,
    "total_r":-1.0,
    "average_r":-1.0,
    "max_win_r":-1.0,
    "max_loss_r":-1.0,
    "best_asset":"DXY",
    "worst_asset":"BTC",
    "next_week_mode":"通常",
    "max_daily_risk_pct":0.5,
    "rule_change_1":"Entry\/SL\/Rank判定の見直し",
    "rule_change_2":"評価期間またはentry条件の見直し",
    "rule_change_3":"データ不足",
    "evaluation_source":"latest_evaluations",
    "latest_evaluations_available":true,
    "fallback_used":false
  }
]
```
