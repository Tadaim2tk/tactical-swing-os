# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-29 07:45:04 JST
生成日時（UTC）: 2026-06-28 22:45:04 UTC
headline件数: 60
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.07
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 55.75
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 18.58
- gold_safe_haven_news_score: 18.58
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 37.17
- inflation_pressure_news_score: 55.75
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- If you think China needs to dethrone U.S. dollar, you don't understand how it is waging global currency war (地政学リスク / 金安全資産需要 / リスクオフ要因)
- IRAs hold trillions more than 401(k) plans — yet people hardly save in them (リスクオフ要因)
- The memory shortage shaking Apple and Microsoft is 'existential crisis' for smaller players (リスクオフ要因)
- Why investors may want to prioritize bond markets outside the U.S. (インフレ圧力 / 金利圧力候補)
- Trading in these two ETFs suggests inflation fears are overblown (インフレ圧力 / 金利圧力候補)
- Oil prices rise, stock futures inch higher as U.S. and Iran trade more airstrikes (インフレ圧力 / 金利圧力候補)
- Why a selloff in gold and silver is dragging bitcoin down (金利圧力候補 / リスクオフ要因)
- Russia stocks lower at close of trade; MOEX Russia Index unchanged (地政学リスク / リスクオフ要因)
