# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-08 07:53:31 JST
Actions実行時刻（UTC）: 2026-06-07 22:53:31 UTC
対象日: 2026-06-06
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオフ優勢 / ドルは中立 / 金利圧力は限定的 / ボラティリティ警戒
- ニュースモード: ニュースナラティブ未取得
- ニュース市場バイアス: insufficient_data
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_only
- risk_on: 41.28
- risk_off: 59.55
- dollar: 51.04
- rate: 53.11
- volatility: 63.1
- news_confidence: 0.0
- シグナル整合性: aligned=2, conflicted=0, neutral=2, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 41.28 | 59.55 | 51.04 | 53.11 | 59.57 | 41.78 | 63.1 | 100.0 |
| BTC | 41.28 | 59.55 | 51.04 | 53.11 | 59.57 | 41.78 | 63.1 | 100.0 |
| DXY | 41.28 | 59.55 | 51.04 | 53.11 | 59.57 | 41.78 | 63.1 | 100.0 |
| GOLD | 41.28 | 59.55 | 51.04 | 53.11 | 59.57 | 41.78 | 63.1 | 100.0 |
| NASDAQ | 41.28 | 59.55 | 51.04 | 53.11 | 59.57 | 41.78 | 63.1 | 100.0 |
| SPX | 41.28 | 59.55 | 51.04 | 53.11 | 59.57 | 41.78 | 63.1 | 100.0 |
| US10Y | 41.28 | 59.55 | 51.04 | 53.11 | 59.57 | 41.78 | 63.1 | 100.0 |
| USDJPY | 41.28 | 59.55 | 51.04 | 53.11 | 59.57 | 41.78 | 63.1 | 100.0 |
| VIX | 41.28 | 59.55 | 51.04 | 53.11 | 59.57 | 41.78 | 63.1 | 100.0 |
| WTI | 41.28 | 59.55 | 51.04 | 53.11 | 59.57 | 41.78 | 63.1 | 100.0 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260606_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE |  |  | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260606_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE |  |  | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B |  |  | aligned | 16 | BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。 |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|risk_penalty_high|overextended | aligned | 16 | BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- VIX上昇中の株価指数LONGは慎重化し、entry条件を厳格化する候補。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: False
- news_mode_summary: ニュースナラティブ未取得
- top_news_drivers: ニュースドライバーなし

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically
2026-06-07T22:53:31,2026-06-08 07:53:31 JST,2026-06-07 22:53:31 UTC,2026-06-06,BTC,20260606_BTC_NONE_NO_TRADE,NONE,NO_TRADE,,,neutral,0,41.28,59.55,51.04,53.11,59.57,41.78,63.1,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False
2026-06-07T22:53:31,2026-06-08 07:53:31 JST,2026-06-07 22:53:31 UTC,2026-06-06,BTC,20260606_BTC_NONE_NO_TRADE,NONE,NO_TRADE,,,neutral,0,41.28,59.55,51.04,53.11,59.57,41.78,63.1,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False
2026-06-07T22:53:31,2026-06-08 07:53:31 JST,2026-06-07 22:53:31 UTC,2026-06-06,BTC,20260606_BTC_SHORT_TREND,SHORT,B,,,aligned,16,41.28,59.55,51.04,53.11,59.57,41.78,63.1,100.0,0.0,market_proxy_only,,,context_support,BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。,BTC SHORT は市場文脈と整合。既存ルールを維持し、過剰強化はしない。,False
2026-06-07T22:53:31,2026-06-08 07:53:31 JST,2026-06-07 22:53:31 UTC,2026-06-06,BTC,20260606_BTC_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|risk_penalty_high|overextended,aligned,16,41.28,59.55,51.04,53.11,59.57,41.78,63.1,100.0,0.0,market_proxy_only,,,context_support,BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。,BTC SHORT は市場文脈と整合。既存ルールを維持し、過剰強化はしない。,False

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-07T22:53:31",
  "generated_at_jst": "2026-06-08 07:53:31 JST",
  "generated_at_utc": "2026-06-07 22:53:31 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-06",
  "data_source": "Google Sheets",
  "market_mode_summary": "リスクオフ優勢 / ドルは中立 / 金利圧力は限定的 / ボラティリティ警戒",
  "news_narrative_available": false,
  "news_mode_summary": "ニュースナラティブ未取得",
  "top_news_drivers": [],
  "narrative_source_mix": "market_proxy_only",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 41.28,
      "risk_off_score": 59.55,
      "dollar_strength_score": 51.04,
      "rate_pressure_score": 53.11,
      "gold_safe_haven_score": 59.57,
      "oil_supply_risk_proxy_score": 49.12,
      "crypto_liquidity_score": 41.78,
      "equity_momentum_score": 37.94,
      "volatility_stress_score": 63.1,
      "narrative_confidence": 100.0,
      "asset_change_pct": null
    },
    {
      "asset": "BTC",
      "risk_on_score": 41.28,
      "risk_off_score": 59.55,
      "dollar_strength_score": 51.04,
      "rate_pressure_score": 53.11,
      "gold_safe_haven_score": 59.57,
      "oil_supply_risk_proxy_score": 49.12,
      "crypto_liquidity_score": 41.78,
      "equity_momentum_score": 37.94,
      "volatility_stress_score": 63.1,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.2134
    },
    {
      "asset": "DXY",
      "risk_on_score": 41.28,
      "risk_off_score": 59.55,
      "dollar_strength_score": 51.04,
      "rate_pressure_score": 53.11,
      "gold_safe_haven_score": 59.57,
      "oil_supply_risk_proxy_score": 49.12,
      "crypto_liquidity_score": 41.78,
      "equity_momentum_score": 37.94,
      "volatility_stress_score": 63.1,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.6437
    },
    {
      "asset": "GOLD",
      "risk_on_score": 41.28,
      "risk_off_score": 59.55,
      "dollar_strength_score": 51.04,
      "rate_pressure_score": 53.11,
      "gold_safe_haven_score": 59.57,
      "oil_supply_risk_proxy_score": 49.12,
      "crypto_liquidity_score": 41.78,
      "equity_momentum_score": 37.94,
      "volatility_stress_score": 63.1,
      "narrative_confidence": 100.0,
      "asset_change_pct": -3.023
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 41.28,
      "risk_off_score": 59.55,
      "dollar_strength_score": 51.04,
      "rate_pressure_score": 53.11,
      "gold_safe_haven_score": 59.57,
      "oil_supply_risk_proxy_score": 49.12,
      "crypto_liquidity_score": 41.78,
      "equity_momentum_score": 37.94,
      "volatility_stress_score": 63.1,
      "narrative_confidence": 100.0,
      "asset_change_pct": -4.562
    },
    {
      "asset": "SPX",
      "risk_on_score": 41.28,
      "risk_off_score": 59.55,
      "dollar_strength_score": 51.04,
      "rate_pressure_score": 53.11,
      "gold_safe_haven_score": 59.57,
      "oil_supply_risk_proxy_score": 49.12,
      "crypto_liquidity_score": 41.78,
      "equity_momentum_score": 37.94,
      "volatility_stress_score": 63.1,
      "narrative_confidence": 100.0,
      "asset_change_pct": -2.4903
    },
    {
      "asset": "US10Y",
      "risk_on_score": 41.28,
      "risk_off_score": 59.55,
      "dollar_strength_score": 51.04,
      "rate_pressure_score": 53.11,
      "gold_safe_haven_score": 59.57,
      "oil_supply_risk_proxy_score": 49.12,
      "crypto_liquidity_score": 41.78,
      "equity_momentum_score": 37.94,
      "volatility_stress_score": 63.1,
      "narrative_confidence": 100.0,
      "asset_change_pct": 1.5447
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 41.28,
      "risk_off_score": 59.55,
      "dollar_strength_score": 51.04,
      "rate_pressure_score": 53.11,
      "gold_safe_haven_score": 59.57,
      "oil_supply_risk_proxy_score": 49.12,
      "crypto_liquidity_score": 41.78,
      "equity_momentum_score": 37.94,
      "volatility_stress_score": 63.1,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.2339
    },
    {
      "asset": "VIX",
      "risk_on_score": 41.28,
      "risk_off_score": 59.55,
      "dollar_strength_score": 51.04,
      "rate_pressure_score": 53.11,
      "gold_safe_haven_score": 59.57,
      "oil_supply_risk_proxy_score": 49.12,
      "crypto_liquidity_score": 41.78,
      "equity_momentum_score": 37.94,
      "volatility_stress_score": 63.1,
      "narrative_confidence": 100.0,
      "asset_change_pct": 35.5388
    },
    {
      "asset": "WTI",
      "risk_on_score": 41.28,
      "risk_off_score": 59.55,
      "dollar_strength_score": 51.04,
      "rate_pressure_score": 53.11,
      "gold_safe_haven_score": 59.57,
      "oil_supply_risk_proxy_score": 49.12,
      "crypto_liquidity_score": 41.78,
      "equity_momentum_score": 37.94,
      "volatility_stress_score": 63.1,
      "narrative_confidence": 100.0,
      "asset_change_pct": -2.4564
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260606_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "",
      "reason_codes": "",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260606_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "",
      "reason_codes": "",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260606_BTC_SHORT_TREND",
      "asset": "BTC",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "",
      "reason_codes": "",
      "narrative_alignment": "aligned",
      "narrative_alignment_score": 16,
      "narrative_comment": "BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。"
    },
    {
      "signal_id": "20260606_BTC_SHORT_B-Watch",
      "asset": "BTC",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|risk_penalty_high|overextended",
      "narrative_alignment": "aligned",
      "narrative_alignment_score": 16,
      "narrative_comment": "BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "VIX上昇中の株価指数LONGは慎重化し、entry条件を厳格化する候補。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
