# Portfolio Layer

## 1. 概要

- 生成日時JST: 2026-06-20 17:29:00 JST
- portfolio_status: active
- candidate assets: 2
- defensive assets: 1
- offensive assets: 0
- cash candidate: 0.5369
- average confidence: 0.4407
- portfolio concentration: 0.24
- risk concentration: 0.0
- recommended exposure: 0.4631
- recommended next action: human_review_allocations
- requires_human_approval: true
- weights_json_updated: false
- patch_applied: false
- generate_signal_updated: false
- orders_created: false

## 2. Top Allocation Candidates

| asset | allocation_score | portfolio_weight_candidate | confidence | risk_class | risk_role | latest_rank | latest_side | rationale |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| USDJPY | 60.7 | 0.24 | 0.3767 | medium | balanced |  |  | signal data unavailable; evaluation avg_r=1.09 win_rate=1.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| GOLD | 55.31 | 0.2231 | 0.4767 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=0.41 win_rate=1.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| BTC | 37.34 | 0.0 | 0.4433 | high | offensive |  |  | signal data unavailable; evaluation avg_r=-0.33 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| WTI | 41.34 | 0.0 | 0.5267 | high | offensive |  |  | signal data unavailable; evaluation avg_r=0.17 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| NASDAQ | 41.26 | 0.0 | 0.4767 | high | offensive |  |  | signal data unavailable; evaluation avg_r=0.16 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| ETH | 40.0 | 0.0 | 0.35 | high | offensive |  |  | signal data unavailable; evaluation rows unavailable; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| SPX | 40.39 | 0.0 | 0.4767 | medium | offensive |  |  | signal data unavailable; evaluation avg_r=0.05 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| VIX | 39.77 | 0.0 | 0.4433 | high | defensive |  |  | signal data unavailable; evaluation avg_r=-0.03 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| DXY | 39.44 | 0.0 | 0.4267 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=-0.07 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |
| US10Y | 35.84 | 0.0 | 0.41 | defensive | defensive |  |  | signal data unavailable; evaluation avg_r=-0.52 win_rate=0.00; meta learning unavailable; auto calibration unavailable; human override unavailable; proposal impact unavailable; market snapshot unavailable |

## 3. Risk Concentration

- high risk weight candidate: 0.0
- portfolio concentration: 0.24
- cash ratio candidate: 0.5369

## 4. 注意事項

- Portfolio Layerは配分候補を生成するだけです
- 自動売買・自動発注・自動リバランスは行いません
- weights.jsonは更新しません
- generate_signal.pyは変更しません
- Google Sheetsへの書き込みは行いません
- すべての候補は人間承認が必須です
