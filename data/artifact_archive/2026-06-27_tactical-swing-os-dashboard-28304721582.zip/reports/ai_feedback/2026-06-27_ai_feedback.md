# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-28 08:12:54 JST
Actions実行時刻（UTC）: 2026-06-27 23:12:54 UTC
対象日: 2026-06-27
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立
- ニュースモード: ニュースのリスク方向は中立
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 35.62
- risk_off: 51.58
- dollar: 34.73
- rate: 40.67
- volatility: 48.32
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=2, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 35.62 | 51.58 | 34.73 | 40.67 | 33.98 | 35.69 | 48.32 | 93.86 |
| DXY | 50.89 | 49.04 | 49.61 | 49.88 | 48.54 | 50.99 | 48.32 | 92.78 |
| GOLD | 50.89 | 49.04 | 49.61 | 49.88 | 48.54 | 50.99 | 48.32 | 92.78 |
| NASDAQ | 50.89 | 49.04 | 49.61 | 49.88 | 48.54 | 50.99 | 48.32 | 92.78 |
| SPX | 50.89 | 49.04 | 49.61 | 49.88 | 48.54 | 50.99 | 48.32 | 92.78 |
| US10Y | 50.89 | 49.04 | 49.61 | 49.88 | 48.54 | 50.99 | 48.32 | 92.78 |
| USDJPY | 50.89 | 49.04 | 49.61 | 49.88 | 48.54 | 50.99 | 48.32 | 92.78 |
| VIX | 50.89 | 49.04 | 49.61 | 49.88 | 48.54 | 50.99 | 48.32 | 92.78 |
| WTI | 50.89 | 49.04 | 49.61 | 49.88 | 48.54 | 50.99 | 48.32 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260627_BTC_SHORT_B-Watch | BTC | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative | neutral | 6 | BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260627_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立
- top_news_drivers: The memory shortage shaking Apple and Microsoft is 'existential crisis' for smaller players, U.S. military attacks Iranian targets after commercial tanker hit in the Strait of Hormuz, Why investors may want to prioritize bond markets outside the U.S., Trading in these two ETFs suggests inflation fears are overblown, The AI trade cooled and oil sank. A closer look at Wall Street's volatile week

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-27T23:12:54,2026-06-28 08:12:54 JST,2026-06-27 23:12:54 UTC,2026-06-27,BTC,20260627_BTC_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative,neutral,6,35.62,51.58,34.73,40.67,33.98,35.69,48.32,93.86,100.0,market_proxy_plus_news,,,context_neutral,BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,BTC SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-27T23:12:54,2026-06-28 08:12:54 JST,2026-06-27 23:12:54 UTC,2026-06-27,USDJPY,20260627_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,35.62,51.58,34.73,40.67,33.98,35.69,48.32,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-27T23:12:54",
  "generated_at_jst": "2026-06-28 08:12:54 JST",
  "generated_at_utc": "2026-06-27 23:12:54 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-27",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立",
  "top_news_drivers": [
    {
      "title": "The memory shortage shaking Apple and Microsoft is 'existential crisis' for smaller players",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "risk_off_news_score:crisis",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/27/memory-crunch-shaking-apple-and-microsoft-existential-for-small-guys.html"
    },
    {
      "title": "U.S. military attacks Iranian targets after commercial tanker hit in the Strait of Hormuz",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "oil_supply_risk_news_score:tanker",
      "driver_tags": "oil_supply_risk",
      "driver_summary_ja": "原油供給リスク",
      "link": "https://www.cnbc.com/2026/06/27/tanker-struck-in-strait-of-hormuz-as-us-iran-tensions-escalate.html"
    },
    {
      "title": "Why investors may want to prioritize bond markets outside the U.S.",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "inflation_pressure_news_score:inflation",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/06/27/inflation-as-major-reason-to-invest-in-global-bond-markets.html"
    },
    {
      "title": "Trading in these two ETFs suggests inflation fears are overblown",
      "source": "CNBC Markets",
      "matched_assets": "BTC|WTI|US10Y|VIX",
      "matched_rules": "inflation_pressure_news_score:inflation",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/06/27/trading-in-these-two-etfs-suggests-inflation-fears-are-overblown.html"
    },
    {
      "title": "The AI trade cooled and oil sank. A closer look at Wall Street's volatile week",
      "source": "CNBC Markets",
      "matched_assets": "WTI|SPX|NASDAQ",
      "matched_rules": "inflation_pressure_news_score:inflation",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/06/27/the-ai-trade-cooled-and-oil-sank-a-closer-look-at-wall-streets-volatile-week.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 35.62,
      "risk_off_score": 51.58,
      "dollar_strength_score": 34.73,
      "rate_pressure_score": 40.67,
      "gold_safe_haven_score": 33.98,
      "oil_supply_risk_proxy_score": 40.31,
      "crypto_liquidity_score": 35.69,
      "equity_momentum_score": 35.71,
      "volatility_stress_score": 48.32,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 0.0,
      "risk_off_news_score": 57.5,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 19.17,
      "gold_safe_haven_news_score": 0.0,
      "oil_supply_risk_news_score": 19.17,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 0.0,
      "inflation_pressure_news_score": 57.5,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 50.89,
      "risk_off_score": 49.04,
      "dollar_strength_score": 49.61,
      "rate_pressure_score": 49.88,
      "gold_safe_haven_score": 48.54,
      "oil_supply_risk_proxy_score": 49.37,
      "crypto_liquidity_score": 50.99,
      "equity_momentum_score": 51.01,
      "volatility_stress_score": 48.32,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.135,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 50.89,
      "risk_off_score": 49.04,
      "dollar_strength_score": 49.61,
      "rate_pressure_score": 49.88,
      "gold_safe_haven_score": 48.54,
      "oil_supply_risk_proxy_score": 49.37,
      "crypto_liquidity_score": 50.99,
      "equity_momentum_score": 51.01,
      "volatility_stress_score": 48.32,
      "narrative_confidence": 92.78,
      "asset_change_pct": 1.4489,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 50.89,
      "risk_off_score": 49.04,
      "dollar_strength_score": 49.61,
      "rate_pressure_score": 49.88,
      "gold_safe_haven_score": 48.54,
      "oil_supply_risk_proxy_score": 49.37,
      "crypto_liquidity_score": 50.99,
      "equity_momentum_score": 51.01,
      "volatility_stress_score": 48.32,
      "narrative_confidence": 92.78,
      "asset_change_pct": -1.5433,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 50.89,
      "risk_off_score": 49.04,
      "dollar_strength_score": 49.61,
      "rate_pressure_score": 49.88,
      "gold_safe_haven_score": 48.54,
      "oil_supply_risk_proxy_score": 49.37,
      "crypto_liquidity_score": 50.99,
      "equity_momentum_score": 51.01,
      "volatility_stress_score": 48.32,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.4542,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 50.89,
      "risk_off_score": 49.04,
      "dollar_strength_score": 49.61,
      "rate_pressure_score": 49.88,
      "gold_safe_haven_score": 48.54,
      "oil_supply_risk_proxy_score": 49.37,
      "crypto_liquidity_score": 50.99,
      "equity_momentum_score": 51.01,
      "volatility_stress_score": 48.32,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.3646,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 50.89,
      "risk_off_score": 49.04,
      "dollar_strength_score": 49.61,
      "rate_pressure_score": 49.88,
      "gold_safe_haven_score": 48.54,
      "oil_supply_risk_proxy_score": 49.37,
      "crypto_liquidity_score": 50.99,
      "equity_momentum_score": 51.01,
      "volatility_stress_score": 48.32,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 50.89,
      "risk_off_score": 49.04,
      "dollar_strength_score": 49.61,
      "rate_pressure_score": 49.88,
      "gold_safe_haven_score": 48.54,
      "oil_supply_risk_proxy_score": 49.37,
      "crypto_liquidity_score": 50.99,
      "equity_momentum_score": 51.01,
      "volatility_stress_score": 48.32,
      "narrative_confidence": 92.78,
      "asset_change_pct": -6.5482,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 50.89,
      "risk_off_score": 49.04,
      "dollar_strength_score": 49.61,
      "rate_pressure_score": 49.88,
      "gold_safe_haven_score": 48.54,
      "oil_supply_risk_proxy_score": 49.37,
      "crypto_liquidity_score": 50.99,
      "equity_momentum_score": 51.01,
      "volatility_stress_score": 48.32,
      "narrative_confidence": 92.78,
      "asset_change_pct": -1.6797,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260627_BTC_SHORT_B-Watch",
      "asset": "BTC",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 6,
      "narrative_comment": "BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260627_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
