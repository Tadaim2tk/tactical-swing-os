# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-28 08:12:53 JST
生成日時（UTC）: 2026-06-27 23:12:53 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.65
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 57.5
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 19.17
- gold_safe_haven_news_score: 0.0
- oil_supply_risk_news_score: 19.17
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 0.0
- inflation_pressure_news_score: 57.5
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- The memory shortage shaking Apple and Microsoft is 'existential crisis' for smaller players (リスクオフ要因)
- U.S. military attacks Iranian targets after commercial tanker hit in the Strait of Hormuz (原油供給リスク)
- Why investors may want to prioritize bond markets outside the U.S. (インフレ圧力 / 金利圧力候補)
- Trading in these two ETFs suggests inflation fears are overblown (インフレ圧力 / 金利圧力候補)
- The AI trade cooled and oil sank. A closer look at Wall Street's volatile week (インフレ圧力 / 金利圧力候補)
- This disease is more expensive than cancer and heart disease combined. And it’s only going to get worse. (リスクオフ要因)
- Why a selloff in gold and silver is dragging bitcoin down (金利圧力候補 / リスクオフ要因)
