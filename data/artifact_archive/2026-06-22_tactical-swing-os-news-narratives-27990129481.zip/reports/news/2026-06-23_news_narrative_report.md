# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-23 08:07:10 JST
生成日時（UTC）: 2026-06-22 23:07:10 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.04
ニュース市場バイアス: mixed
ニュース矛盾スコア: 73.87
主要テーマ: risk_on, risk_off
日本語要約: リスクオン要因、リスクオフ要因が目立ち、リスクオン材料とリスクオフ材料が混在しています。方向感は一方向ではなく、ボラティリティ上昇に注意が必要です。
ニュースモード: ニュースは混在 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 73.87
- risk_off_news_score: 73.87
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 36.93
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 36.93
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 36.93
- inflation_pressure_news_score: 0.0
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- SpaceX stock tanks 16%, extending slump following post-IPO rally (リスクオフ要因 / リスクオン要因)
- Treasury Department authorizes Iranian oil sales through August (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Caterpillar’s stock hits a milestone as AI-fueled industrials rally sweeps up Wall Street (リスクオン要因)
- Alphabet sees $225 billion market-cap wipeout as investors fear it’s losing the war for AI talent (地政学リスク / リスクオフ要因 / 金安全資産需要)
- Strive says digital credit selloff was a liquidation event, not a credit crisis (リスクオフ要因)
- Bitcoin ETF outflow pain eases just as another headwind gathers strength (暗号資産流動性)
- As bitcoin, altcoin prices gain, derivatives signal skepticism over a sustained rally (リスクオン要因)
- Live markets: Bitcoin gives up morning gains as Nasdaq sheds more than 1% (暗号資産流動性)
- XRP briefly loses $1.14 support before buyers drive sharp rebound (リスクオン要因)
