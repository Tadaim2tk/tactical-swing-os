# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-23 08:07:08 JST
取得日時（UTC）: 2026-06-22 23:07:08 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.04
headline件数: 75

## 見出し

- [CNBC Markets] SpaceX stock tanks 16%, extending slump following post-IPO rally (未分類)
- [CNBC Markets] Alphabet has its worst day in over a year on AI concerns after high-profile exits (未分類)
- [CNBC Markets] 'We'll see' — Trump hedges on guarantee Iran won't use oil profits to rebuild military (WTI|US10Y|DXY)
- [CNBC Markets] Tesla faces federal probe after Model 3 slams into Texas home, killing 76-year-old (US10Y|DXY)
- [CNBC Markets] Senate advances housing bill to limit private equity purchases of single-family homes (未分類)
- [CNBC Markets] Nvidia's stock struggles as Kalshi traders bet chip prices are coming down (SPX|NASDAQ)
- [CNBC Markets] Three key AI stocks to watch this week with traders expecting giant moves (SPX|NASDAQ)
- [CNBC Markets] Treasury Department authorizes Iranian oil sales through August (WTI|US10Y|DXY)
- [CNBC Markets] Alan Greenspan, former chairman of the Fed, dies at age 100 (US10Y|DXY)
- [CNBC Markets] Companies are demanding states cut red tape. Data center-wary voters may think differently (未分類)
- [CNBC Markets] Meta's WhatsApp head to step down, will be replaced by Indian fintech founder Kunal Shah (NASDAQ)
- [CNBC Markets] Vance hails 'great progress' in U.S.-Iran talks despite 'threatening' and 'whining' (未分類)
- [CNBC Markets] SpaceX kicks off bond sale days after record IPO, discloses over $100 billion cash pile (US10Y)
- [CNBC Markets] Can anyone join Musk in the trillionaire club? Zuckerberg has best shot, according to prediction markets (未分類)
- [CNBC Markets] CNBC Elite Advisors: Top ultra-high net worth wealth management firms for 2026 (未分類)
- [CNBC Markets] Amazon Prime Day arrives earlier this year. Here's why Wall Street is watching closely (SPX)
- [CNBC Markets] Who is Andy Burnham? And 4 other things investors should know as the UK replaces its prime minister (未分類)
- [CNBC Markets] Childcare tax breaks can save families and businesses money — but few use them, congressional report finds (未分類)
- [CNBC Markets] 'Reward for failure': Investor support for Target Chair Brian Cornell falls to lowest level ever (未分類)
- [CNBC Markets] Lucid to lay off roughly 18% of U.S. workforce, COO Marc Winterhoff leaves (未分類)
- [CNBC Markets] Shipping stalls in Strait of Hormuz after Iran declares key waterway closed again (WTI)
- [CNBC Markets] How to pick up some quick income using an auto stock hitting its stride (VIX)
- [CNBC Markets] UK PM Starmer resigns as Britain faces its seventh leader in 10 years (未分類)
- [CNBC Markets] UPS to invest $48 million in temperature-controlled facilities amid healthcare boom (未分類)
- [CNBC Markets] Chevron to fuel massive Microsoft data center in Texas using natural gas (未分類)
- [CNBC Markets] Raising the minimum wage has been a big political winner. Now it's running into resistance (未分類)
- [CNBC Markets] China imposes trade curbs on dozens of U.S. firms in retaliation for Pentagon blacklist (NASDAQ)
- [CNBC Markets] The new arms race in wealth management: Winning the ultra-wealthy (未分類)
- [CNBC Markets] Why a 66-year-old water treaty is becoming the latest India-Pakistan flashpoint (未分類)
- [CNBC Markets] Oil prices fall after U.S. authorizes Iranian crude sales (WTI)
- [MarketWatch Top Stories] Trump may say he’s banning Wall Street from buying homes. Does the bipartisan housing bill actually do that? (SPX)
- [MarketWatch Top Stories] Big Tech has split into two artificial-intelligence camps — but the smart money isn’t chasing the next OpenAI (NASDAQ)
- [MarketWatch Top Stories] A 40% market crash is lurking in the IPO pipeline. SpaceX and OpenAI could trigger it. (未分類)
- [MarketWatch Top Stories] China’s weird new economic spark: toy elves and robocops (未分類)
- [MarketWatch Top Stories] Wall Street loves growth stocks — but these 10 ‘losers’ are primed to win (SPX)
- [MarketWatch Top Stories] Caterpillar’s stock hits a milestone as AI-fueled industrials rally sweeps up Wall Street (SPX)
- [MarketWatch Top Stories] Super Micro’s stock is seeing its best run in a year thanks to Nvidia partnership (SPX)
- [MarketWatch Top Stories] Micron’s stock momentum builds as the company inks a new Anthropic partnership (未分類)
- [MarketWatch Top Stories] Salesforce’s stock extends record losing streak. Can the company disrupt itself? (SPX)
- [MarketWatch Top Stories] Alphabet sees $225 billion market-cap wipeout as investors fear it’s losing the war for AI talent (VIX)
- [CoinDesk] U.S. Senate passes housing bill that carries four-year ban on a Fed CBDC (US10Y|DXY)
- [CoinDesk] Securitize and tZERO clash over patents as race to bring Wall Street onchain heats up (SPX)
- [CoinDesk] Ric Edelman says crypto’s biggest growth story is happening off the price chart (BTC)
- [CoinDesk] 21Shares co-founder warns tokenization hype is outrunning Wall Street reality (SPX)
- [CoinDesk] Strive says digital credit selloff was a liquidation event, not a credit crisis (VIX)
- [CoinDesk] Ether’s biggest corporate holders back new Ethereum research hub (BTC)
- [CoinDesk] Ethereum Foundation talent exodus sparks fresh debate over leadership (BTC)
- [CoinDesk] Crypto's second U.S. lobbying front — tax policy — sees industry push on mining, staking (BTC)
- [CoinDesk] Anchorage aims to bring banks onchain with new tokenized deposit platform (BTC)
- [CoinDesk] MoneyGram joins Solana as validator amid stablecoin payment push (未分類)
