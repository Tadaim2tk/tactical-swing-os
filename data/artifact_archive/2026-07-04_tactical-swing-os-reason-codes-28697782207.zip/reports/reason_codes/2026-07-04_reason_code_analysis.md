# Tactical Swing OS Reason Code Analysis

## 1. 結論

reason_codesの有効性を集計しました。

対象期間: 2026-06-28 - 2026-07-04

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. reason_codes 上位プラス要因

_該当なし_

## 3. reason_codes 上位マイナス要因

| reason_code | signals_count | evaluated_count | win_count | loss_count | no_entry_count | missed_opportunity_count | win_rate | total_r | average_r | median_r | best_r | worst_r | average_mfe_r | average_mae_r | rank_a_count | rank_b_count | no_trade_count | recommended_action_trade_count | recommended_action_watch_count | recommended_action_no_trade_count | reliability_label |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| trend_down | 16 | 7 | 0 | 0 | 0 | 0 | 0.0 | -1.0161 | -0.1452 | -0.0118 | 0.0678 | -0.4328 | 0.1072 | -0.1867 | 0 | 7 | 9 | 0 | 7 | 9 | negative |
| ma_alignment_bear | 16 | 7 | 0 | 0 | 0 | 0 | 0.0 | -1.0161 | -0.1452 | -0.0118 | 0.0678 | -0.4328 | 0.1072 | -0.1867 | 0 | 7 | 9 | 0 | 7 | 9 | negative |
| momentum_negative | 34 | 13 | 0 | 0 | 0 | 0 | 0.0 | -1.162 | -0.1291 | -0.0118 | 0.0825 | -0.4328 | 0.1122 | -0.2172 | 0 | 13 | 21 | 0 | 13 | 21 | negative |
| rsi_oversold | 10 | 6 | 0 | 0 | 0 | 0 | 0.0 | -0.725 | -0.1208 | -0.0046 | 0.0678 | -0.4328 | 0.1007 | -0.1625 | 0 | 6 | 4 | 0 | 6 | 4 | negative |

## 4. no_trade_reason 分析

| no_trade_reason | count | no_trade_correct_count | no_trade_missed_count | missed_opportunity_count | average_mfe_r | average_r | assessment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rr_too_low | 32 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |
| low_volatility | 5 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |

## 5. 取り逃し候補

_該当なし_

## 6. 改善候補

| reason_code | signals_count | evaluated_count | win_count | loss_count | no_entry_count | missed_opportunity_count | win_rate | total_r | average_r | median_r | best_r | worst_r | average_mfe_r | average_mae_r | rank_a_count | rank_b_count | no_trade_count | recommended_action_trade_count | recommended_action_watch_count | recommended_action_no_trade_count | reliability_label |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| rsi_oversold | 10 | 6 | 0 | 0 | 0 | 0 | 0.0 | -0.725 | -0.1208 | -0.0046 | 0.0678 | -0.4328 | 0.1007 | -0.1625 | 0 | 6 | 4 | 0 | 6 | 4 | negative |
| momentum_negative | 34 | 13 | 0 | 0 | 0 | 0 | 0.0 | -1.162 | -0.1291 | -0.0118 | 0.0825 | -0.4328 | 0.1122 | -0.2172 | 0 | 13 | 21 | 0 | 13 | 21 | negative |
| ma_alignment_bear | 16 | 7 | 0 | 0 | 0 | 0 | 0.0 | -1.0161 | -0.1452 | -0.0118 | 0.0678 | -0.4328 | 0.1072 | -0.1867 | 0 | 7 | 9 | 0 | 7 | 9 | negative |
| trend_down | 16 | 7 | 0 | 0 | 0 | 0 | 0.0 | -1.0161 | -0.1452 | -0.0118 | 0.0678 | -0.4328 | 0.1072 | -0.1867 | 0 | 7 | 9 | 0 | 7 | 9 | negative |

## 7. データ不足の注意

reason_codeごとの評価件数が5件未満の場合は `insufficient_data` とし、weights.jsonは自動更新しません。

## 8. REASON_CODE_ANALYSIS CSV

```csv
reason_code,signals_count,evaluated_count,win_count,loss_count,no_entry_count,missed_opportunity_count,win_rate,total_r,average_r,median_r,best_r,worst_r,average_mfe_r,average_mae_r,rank_a_count,rank_b_count,no_trade_count,recommended_action_trade_count,recommended_action_watch_count,recommended_action_no_trade_count,reliability_label
rr_too_low,37,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,37,0,0,37,insufficient_data
momentum_positive,16,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,16,0,0,16,insufficient_data
pullback_to_ma20,13,3,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,3,10,0,3,10,insufficient_data
range_middle,7,1,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,1,6,0,1,6,insufficient_data
rsi_overbought,7,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,7,0,0,7,insufficient_data
atr_too_low,5,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,5,0,0,5,insufficient_data
overextended,4,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,4,0,0,4,insufficient_data
breakout_down,1,1,0,0,0,0,0.0,-0.0118,-0.0118,-0.0118,-0.0118,-0.0118,0.0483,-0.0284,0,1,0,0,1,0,insufficient_data
ma_alignment_bull,22,6,0,0,0,0,0.0,-0.1459,-0.0729,-0.0729,0.0825,-0.2284,0.1297,-0.3239,0,6,16,0,6,16,neutral
trend_up,22,6,0,0,0,0,0.0,-0.1459,-0.0729,-0.0729,0.0825,-0.2284,0.1297,-0.3239,0,6,16,0,6,16,neutral
rsi_oversold,10,6,0,0,0,0,0.0,-0.725,-0.1208,-0.0046,0.0678,-0.4328,0.1007,-0.1625,0,6,4,0,6,4,negative
momentum_negative,34,13,0,0,0,0,0.0,-1.162,-0.1291,-0.0118,0.0825,-0.4328,0.1122,-0.2172,0,13,21,0,13,21,negative
ma_alignment_bear,16,7,0,0,0,0,0.0,-1.0161,-0.1452,-0.0118,0.0678,-0.4328,0.1072,-0.1867,0,7,9,0,7,9,negative
trend_down,16,7,0,0,0,0,0.0,-1.0161,-0.1452,-0.0118,0.0678,-0.4328,0.1072,-0.1867,0,7,9,0,7,9,negative
atr_too_high,7,2,0,0,0,0,0.0,-0.2284,-0.2284,-0.2284,-0.2284,-0.2284,0.0584,-0.4805,0,2,5,0,2,5,insufficient_data
```

## 9. REASON_CODE_ANALYSIS JSON

```json
{
  "start_date": "2026-06-28",
  "end_date": "2026-07-04",
  "reason_code_summary": [
    {
      "reason_code": "rr_too_low",
      "signals_count": 37,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 37,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 37,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "momentum_positive",
      "signals_count": 16,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 16,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 16,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "pullback_to_ma20",
      "signals_count": 13,
      "evaluated_count": 3,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 10,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 10,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "range_middle",
      "signals_count": 7,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 6,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 6,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "rsi_overbought",
      "signals_count": 7,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "atr_too_low",
      "signals_count": 5,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 5,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "overextended",
      "signals_count": 4,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 4,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 4,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "breakout_down",
      "signals_count": 1,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.0118,
      "average_r": -0.0118,
      "median_r": -0.0118,
      "best_r": -0.0118,
      "worst_r": -0.0118,
      "average_mfe_r": 0.0483,
      "average_mae_r": -0.0284,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 22,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.1459,
      "average_r": -0.0729,
      "median_r": -0.0729,
      "best_r": 0.0825,
      "worst_r": -0.2284,
      "average_mfe_r": 0.1297,
      "average_mae_r": -0.3239,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 16,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 16,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 22,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.1459,
      "average_r": -0.0729,
      "median_r": -0.0729,
      "best_r": 0.0825,
      "worst_r": -0.2284,
      "average_mfe_r": 0.1297,
      "average_mae_r": -0.3239,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 16,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 16,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rsi_oversold",
      "signals_count": 10,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.725,
      "average_r": -0.1208,
      "median_r": -0.0046,
      "best_r": 0.0678,
      "worst_r": -0.4328,
      "average_mfe_r": 0.1007,
      "average_mae_r": -0.1625,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 4,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 4,
      "reliability_label": "negative"
    },
    {
      "reason_code": "momentum_negative",
      "signals_count": 34,
      "evaluated_count": 13,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.162,
      "average_r": -0.1291,
      "median_r": -0.0118,
      "best_r": 0.0825,
      "worst_r": -0.4328,
      "average_mfe_r": 0.1122,
      "average_mae_r": -0.2172,
      "rank_a_count": 0,
      "rank_b_count": 13,
      "no_trade_count": 21,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 13,
      "recommended_action_no_trade_count": 21,
      "reliability_label": "negative"
    },
    {
      "reason_code": "ma_alignment_bear",
      "signals_count": 16,
      "evaluated_count": 7,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.0161,
      "average_r": -0.1452,
      "median_r": -0.0118,
      "best_r": 0.0678,
      "worst_r": -0.4328,
      "average_mfe_r": 0.1072,
      "average_mae_r": -0.1867,
      "rank_a_count": 0,
      "rank_b_count": 7,
      "no_trade_count": 9,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 7,
      "recommended_action_no_trade_count": 9,
      "reliability_label": "negative"
    },
    {
      "reason_code": "trend_down",
      "signals_count": 16,
      "evaluated_count": 7,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.0161,
      "average_r": -0.1452,
      "median_r": -0.0118,
      "best_r": 0.0678,
      "worst_r": -0.4328,
      "average_mfe_r": 0.1072,
      "average_mae_r": -0.1867,
      "rank_a_count": 0,
      "rank_b_count": 7,
      "no_trade_count": 9,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 7,
      "recommended_action_no_trade_count": 9,
      "reliability_label": "negative"
    },
    {
      "reason_code": "atr_too_high",
      "signals_count": 7,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.2284,
      "average_r": -0.2284,
      "median_r": -0.2284,
      "best_r": -0.2284,
      "worst_r": -0.2284,
      "average_mfe_r": 0.0584,
      "average_mae_r": -0.4805,
      "rank_a_count": 0,
      "rank_b_count": 2,
      "no_trade_count": 5,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 2,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "insufficient_data"
    }
  ],
  "no_trade_reason_summary": [
    {
      "no_trade_reason": "rr_too_low",
      "count": 32,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    },
    {
      "no_trade_reason": "low_volatility",
      "count": 5,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    }
  ],
  "top_positive_reasons": [],
  "top_negative_reasons": [
    {
      "reason_code": "trend_down",
      "signals_count": 16,
      "evaluated_count": 7,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.0161,
      "average_r": -0.1452,
      "median_r": -0.0118,
      "best_r": 0.0678,
      "worst_r": -0.4328,
      "average_mfe_r": 0.1072,
      "average_mae_r": -0.1867,
      "rank_a_count": 0,
      "rank_b_count": 7,
      "no_trade_count": 9,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 7,
      "recommended_action_no_trade_count": 9,
      "reliability_label": "negative"
    },
    {
      "reason_code": "ma_alignment_bear",
      "signals_count": 16,
      "evaluated_count": 7,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.0161,
      "average_r": -0.1452,
      "median_r": -0.0118,
      "best_r": 0.0678,
      "worst_r": -0.4328,
      "average_mfe_r": 0.1072,
      "average_mae_r": -0.1867,
      "rank_a_count": 0,
      "rank_b_count": 7,
      "no_trade_count": 9,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 7,
      "recommended_action_no_trade_count": 9,
      "reliability_label": "negative"
    },
    {
      "reason_code": "momentum_negative",
      "signals_count": 34,
      "evaluated_count": 13,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.162,
      "average_r": -0.1291,
      "median_r": -0.0118,
      "best_r": 0.0825,
      "worst_r": -0.4328,
      "average_mfe_r": 0.1122,
      "average_mae_r": -0.2172,
      "rank_a_count": 0,
      "rank_b_count": 13,
      "no_trade_count": 21,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 13,
      "recommended_action_no_trade_count": 21,
      "reliability_label": "negative"
    },
    {
      "reason_code": "rsi_oversold",
      "signals_count": 10,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.725,
      "average_r": -0.1208,
      "median_r": -0.0046,
      "best_r": 0.0678,
      "worst_r": -0.4328,
      "average_mfe_r": 0.1007,
      "average_mae_r": -0.1625,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 4,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 4,
      "reliability_label": "negative"
    }
  ],
  "over_filtering_candidates": [],
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 85,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "notes": [
    "reason_code単位のweights自動更新はまだ行いません。",
    "insufficient_data reason_codes: 9"
  ]
}
```
