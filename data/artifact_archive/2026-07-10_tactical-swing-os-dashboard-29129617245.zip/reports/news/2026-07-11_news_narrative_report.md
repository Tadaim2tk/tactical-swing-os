# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-11 08:09:22 JST
生成日時（UTC）: 2026-07-10 23:09:22 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.48
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立

## スコア

- risk_on_news_score: 19.17
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 0.0
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 0.0
- inflation_pressure_news_score: 38.33
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 98.0

## Top News Drivers

- These are America's 10 most expensive states for 2026, where inflation is punishing residents (インフレ圧力 / 金利圧力候補)
- These are America's 10 cheapest states for 2026, where you can still beat inflation (インフレ圧力 / 金利圧力候補)
- Meta's stock has best week since early 2024 as optimism builds around AI strategy (リスクオン要因)
