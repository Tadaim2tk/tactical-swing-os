# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-13 08:03:56 JST
取得日時（UTC）: 2026-06-12 23:03:56 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.13
headline件数: 75

## 見出し

- [CNBC Markets] Trump administration: Iran deal signing likely in coming days, but not '100%' certain (未分類)
- [CNBC Markets] Paramount-WBD merger wins approval from DOJ (未分類)
- [CNBC Markets] Elon Musk becomes world's first trillionaire as SpaceX begins trading on the Nasdaq (NASDAQ)
- [CNBC Markets] SpaceX market cap tops $2 trillion after shares of Elon Musk's rocket company gain 19% on debut (SPX|NASDAQ)
- [CNBC Markets] Top House Republican’s family investment poised to benefit from SpaceX IPO (未分類)
- [CNBC Markets] Call Kevin Warsh the Fed 'chairman' (US10Y|DXY)
- [CNBC Markets] As investors flock to SpaceX, one trader eyes a sleepy 'stealth' play (未分類)
- [CNBC Markets] Small investors scrambled to get in on the SpaceX IPO, even as some believe the valuation is 'stupid' (SPX)
- [CNBC Markets] For Warsh as Fed chair, silence may be the point (US10Y|DXY)
- [CNBC Markets] Pirro's losses in Fed investigation should stay on the books, judge rules (US10Y|DXY)
- [CNBC Markets] Trump name still must come down from Kennedy Center, judge says (US10Y|DXY)
- [CNBC Markets] SpaceX 'proxies' plunge as real deal arrives: Here's where traders are buying the dip (SPX)
- [CNBC Markets] Social Security COLA for 2027 may jump to 4.7%, one estimate finds. This chart shows prices driving the increase (未分類)
- [CNBC Markets] Judge blocks DOJ 'anti-weaponization' fund for longer, wants guarantee it’s dead (US10Y|DXY)
- [CNBC Markets] New SpaceX millionaires are reinventing the business of managing large wealth (未分類)
- [CNBC Markets] SpaceX’s Gwynne Shotwell had IPO doubts for years, now she has a message for investors (未分類)
- [CNBC Markets] Goldman nets a big payday for SpaceX IPO. Plus, what drove our winners and losers this week (GOLD)
- [CNBC Markets] How to get SpaceX stock — without buying the IPO (SPX)
- [CNBC Markets] U.S. crude oil falls below $85 as U.S. and Iran near a deal to reopen Hormuz (WTI)
- [CNBC Markets] The S&P 500 already made a big call on SpaceX stock and index fund investors need to know it (SPX)
- [CNBC Markets] Bitcoin's latest plunge revives the debate over owning it—and whether it's just 'crypto being crypto' (BTC|VIX)
- [CNBC Markets] Options volume in space stocks boomed as investors look for any way 'to get long SpaceX' (SPX)
- [CNBC Markets] Meta reportedly begins dismantling $2 billion Manus deal on Beijing's orders (未分類)
- [CNBC Markets] Waymo launches premier subscription tier for $29.99 a month, starting in select cities (未分類)
- [CNBC Markets] Ex-Andreessen Horowitz partner slams his old firm, other VCs for 'political infiltration' around AI (未分類)
- [CNBC Markets] Former Tesla board member says SpaceX needs to achieve 2 of its 3 moonshots to keep its valuation (未分類)
- [CNBC Markets] Trump picks former SEC Chairman Jay Clayton as national intelligence director (未分類)
- [CNBC Markets] Warren questions SpaceX IPO oversight in new letter to stock indexes (未分類)
- [CNBC Markets] Some U.S. states still don't know if the World Cup will benefit them financially—just look at New Jersey (未分類)
- [CNBC Markets] Honeywell CEO says AI will 'redefine automation' as labor shortages mount (未分類)
- [MarketWatch Top Stories] This hidden investing flaw is costing you money. Talking to political opponents fixes it. (未分類)
- [MarketWatch Top Stories] There’s a 68% chance the stock market ends the year higher. Why the headlines shouldn’t disrupt your portfolio. (未分類)
- [MarketWatch Top Stories] ‘This is not a flash in the pan’: Why value stocks are beating growth by such a wide margin (SPX|NASDAQ)
- [MarketWatch Top Stories] How Elon Musk nailed the SpaceX IPO: ‘I’m not sure that this could have gone much better’ (SPX)
- [MarketWatch Top Stories] FIFA World Cup prize money: What each USMNT player stands to earn (未分類)
- [MarketWatch Top Stories] I’m 55 and earn $100,000. Should I take a $2,900 monthly pension — or $2,200 with 3% annual hikes? (未分類)
- [MarketWatch Top Stories] How to decide whether a major splurge — like spending thousands on Knicks or World Cup tickets — is worth it (BTC)
- [MarketWatch Top Stories] ‘I feel like he may be taking advantage of us’: Our adviser pushes annuities after we already said no. Do we fire him? (未分類)
- [MarketWatch Top Stories] Is it too late to buy SpaceX’s stock? Here’s how Tesla’s did after one day — and five years. (BTC|GOLD)
- [MarketWatch Top Stories] ‘It seems too good to be true’: At a steak-dinner retirement seminar, the guy said annuities can outperform the market. Is that true? (未分類)
- [CoinDesk] Bitcoin hit bottom at $59,000 marking end to the crypto winter, says Standard Chartered analyst (BTC|VIX)
- [CoinDesk] VanEck bets BNB’s real-world usage can stand out in a crowded crypto ETF market (BTC)
- [CoinDesk] Elon Musk's SpaceX soars 20% in blockbuster Nasdaq debut (NASDAQ)
- [CoinDesk] Bloomberg Analyst: Most Bitcoin ETF Investors Have Stayed Put Despite Outflows (BTC)
- [CoinDesk] Kalshi’s crypto perpetuals spark debate over whether they’re futures or swaps (BTC)
- [CoinDesk] The U.S. government is betting $2 Billion on quantum computing, and the defense side can't keep up (BTC)
- [CoinDesk] FTX's Sam Bankman-Fried loses appeal of criminal conviction on fraud, conspiracy charges (未分類)
- [CoinDesk] XRP sentiment falls to 8-month low, and that has been a buy signal before (未分類)
- [CoinDesk] CoinDesk 20 performance update: Ethereum (ETH) falls 1% as index trades lower (BTC)
- [CoinDesk] For crypto, SpaceX's stock market debut could go either way (BTC)
