# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-13 08:03:58 JST
生成日時（UTC）: 2026-06-12 23:03:58 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.13
ニュース市場バイアス: neutral
ニュース矛盾スコア: 36.93
主要テーマ: gold_safe_haven, geopolitical_risk
日本語要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 36.93
- risk_off_news_score: 36.93
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 100.0
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 18.47
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 18.47
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Trump administration: Iran deal signing likely in coming days, but not '100%' certain (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Call Kevin Warsh the Fed 'chairman' (地政学リスク / 金安全資産需要 / リスクオフ要因)
- For Warsh as Fed chair, silence may be the point (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Social Security COLA for 2027 may jump to 4.7%, one estimate finds. This chart shows prices driving the increase (インフレ圧力 / 金利圧力候補)
- Judge blocks DOJ 'anti-weaponization' fund for longer, wants guarantee it’s dead (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Bitcoin's latest plunge revives the debate over owning it—and whether it's just 'crypto being crypto' (リスクオフ要因)
- Warren questions SpaceX IPO oversight in new letter to stock indexes (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Bitcoin hit bottom at $59,000 marking end to the crypto winter, says Standard Chartered analyst (リスクオフ要因)
- Bloomberg Analyst: Most Bitcoin ETF Investors Have Stayed Put Despite Outflows (暗号資産流動性)
- XRP sentiment falls to 8-month low, and that has been a buy signal before (リスクオン要因)
