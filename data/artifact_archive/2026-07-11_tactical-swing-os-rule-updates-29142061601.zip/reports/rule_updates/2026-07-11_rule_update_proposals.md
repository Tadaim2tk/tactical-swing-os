# Tactical Swing OS Rule Update Proposals

## 1. 結論

ルール改善候補を生成しました。自動反映は行いません。

対象期間: 2026-06-12 - 2026-07-11

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. 高優先度の改善候補

_該当なし_

## 3. reason_codeを強める候補

_該当なし_

## 4. reason_codeを弱める候補

_該当なし_

## 5. no_trade_reasonの見直し候補

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-11T05:59:01 | 2026-06-12 | 2026-07-11 | 20260711_no_trade_reason_low_volatility_strengthen_no_trade_filter | strengthen_no_trade_filter | no_trade_reason | low_volatility | LOW | 5 | 0.2 | 0.0 | 0.0 | 0 | low_volatility: correct=1, missed=0, avg_mfe_r=0.00 | 有効な見送り条件として維持または軽く強化を検討 | 低品質シグナルの抑制 | NO_TRADE緩和はノイズ取引増加に注意 | False | 3 | neutral |
| 2026-07-11T05:59:01 | 2026-06-12 | 2026-07-11 | 20260711_no_trade_reason_rr_too_low_strengthen_no_trade_filter | strengthen_no_trade_filter | no_trade_reason | rr_too_low | LOW | 15 | 0.2 | 0.0 | 0.0 | 0 | rr_too_low: correct=3, missed=1, avg_mfe_r=0.00 | 有効な見送り条件として維持または軽く強化を検討 | 低品質シグナルの抑制 | NO_TRADE緩和はノイズ取引増加に注意 | False | 3 | over_filtering_risk |

## 6. asset / side / rank の見直し候補

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-11T05:59:01 | 2026-06-12 | 2026-07-11 | 20260711_rank_A_data_insufficient | data_insufficient | rank | A | DATA_INSUFFICIENT | 4 | 0.0 | 0.0364 | 0.1455 | 0 | rank=A avg_r=0.0364 | 評価件数不足のため監視継続 | 過剰調整を避ける | カテゴリ単位の調整は相場環境依存に注意 | False | 4 | group performance review |

## 7. データ不足の項目

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-11T05:59:01 | 2026-06-12 | 2026-07-11 | 20260711_rank_A_data_insufficient | data_insufficient | rank | A | DATA_INSUFFICIENT | 4 | 0.0 | 0.0364 | 0.1455 | 0 | rank=A avg_r=0.0364 | 評価件数不足のため監視継続 | 過剰調整を避ける | カテゴリ単位の調整は相場環境依存に注意 | False | 4 | group performance review |
| 2026-07-11T05:59:01 | 2026-06-12 | 2026-07-11 | 20260711_reason_code_atr_too_high_data_insufficient | data_insufficient | reason_code | atr_too_high | DATA_INSUFFICIENT | 4 | 0.0 | 0.0804 | 0.2412 | 0 | atr_too_high は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-07-11T05:59:01 | 2026-06-12 | 2026-07-11 | 20260711_reason_code_breakout_down_data_insufficient | data_insufficient | reason_code | breakout_down | DATA_INSUFFICIENT | 1 | 0.0 | 0.0 | 0.0 | 0 | breakout_down は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-07-11T05:59:01 | 2026-06-12 | 2026-07-11 | 20260711_reason_code_breakout_up_data_insufficient | data_insufficient | reason_code | breakout_up | DATA_INSUFFICIENT | 2 | 0.0 | 0.0261 | 0.0261 | 0 | breakout_up は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-07-11T05:59:01 | 2026-06-12 | 2026-07-11 | 20260711_reason_code_overextended_data_insufficient | data_insufficient | reason_code | overextended | DATA_INSUFFICIENT | 2 | 0.0 | 0.0 | 0.0 | 0 | overextended は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-07-11T05:59:01 | 2026-06-12 | 2026-07-11 | 20260711_reason_code_rsi_oversold_data_insufficient | data_insufficient | reason_code | rsi_oversold | DATA_INSUFFICIENT | 1 | 0.0 | 0.0 | 0.0 | 0 | rsi_oversold は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |

## 8. 自動反映しない理由

- 実売買には使わない
- weights.jsonは自動更新しない
- generate_signal.pyは自動変更しない
- closed評価が30〜50件以上溜まるまでは提案のみ

## 9. 次に人間が確認すべき点

- HIGH / MEDIUM の提案が特定assetやsideに偏っていないか
- no_trade_reason緩和で低品質シグナルが増えないか
- reason_codeの成績が一時的な相場環境に依存していないか

## 10. RULE_UPDATE_PROPOSALS CSV

```csv
generated_at,period_start,period_end,proposal_id,proposal_type,target_type,target_name,proposal_strength,evidence_count,win_rate,average_r,total_r,missed_opportunity_count,current_behavior,proposed_change,expected_effect,risk_note,apply_automatically,priority,notes
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_atr_too_low_monitor_reason_code,monitor_reason_code,reason_code,atr_too_low,LOW,5,0.0,0.0,0.0,0,atr_too_low は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_ma_alignment_bear_monitor_reason_code,monitor_reason_code,reason_code,ma_alignment_bear,LOW,6,0.0,0.0,0.0,0,ma_alignment_bear は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_ma_alignment_bull_monitor_reason_code,monitor_reason_code,reason_code,ma_alignment_bull,LOW,13,0.0,0.0437,0.4805,0,ma_alignment_bull は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_momentum_negative_monitor_reason_code,monitor_reason_code,reason_code,momentum_negative,LOW,13,0.0,0.0385,0.4622,0,momentum_negative は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_momentum_positive_monitor_reason_code,monitor_reason_code,reason_code,momentum_positive,LOW,11,0.0,0.0154,0.1387,0,momentum_positive は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_pullback_to_ma20_monitor_reason_code,monitor_reason_code,reason_code,pullback_to_ma20,LOW,11,0.0,0.0241,0.2412,0,pullback_to_ma20 は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_range_middle_monitor_reason_code,monitor_reason_code,reason_code,range_middle,LOW,5,0.0,0.0,0.0,0,range_middle は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_rr_too_low_monitor_reason_code,monitor_reason_code,reason_code,rr_too_low,LOW,20,0.0,0.0,0.0,0,rr_too_low は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_trend_down_monitor_reason_code,monitor_reason_code,reason_code,trend_down,LOW,6,0.0,0.0,0.0,0,trend_down は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_trend_up_monitor_reason_code,monitor_reason_code,reason_code,trend_up,LOW,13,0.0,0.0437,0.4805,0,trend_up は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_no_trade_reason_low_volatility_strengthen_no_trade_filter,strengthen_no_trade_filter,no_trade_reason,low_volatility,LOW,5,0.2,0.0,0.0,0,"low_volatility: correct=1, missed=0, avg_mfe_r=0.00",有効な見送り条件として維持または軽く強化を検討,低品質シグナルの抑制,NO_TRADE緩和はノイズ取引増加に注意,False,3,neutral
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_no_trade_reason_rr_too_low_strengthen_no_trade_filter,strengthen_no_trade_filter,no_trade_reason,rr_too_low,LOW,15,0.2,0.0,0.0,0,"rr_too_low: correct=3, missed=1, avg_mfe_r=0.00",有効な見送り条件として維持または軽く強化を検討,低品質シグナルの抑制,NO_TRADE緩和はノイズ取引増加に注意,False,3,over_filtering_risk
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_rank_A_data_insufficient,data_insufficient,rank,A,DATA_INSUFFICIENT,4,0.0,0.0364,0.1455,0,rank=A avg_r=0.0364,評価件数不足のため監視継続,過剰調整を避ける,カテゴリ単位の調整は相場環境依存に注意,False,4,group performance review
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_atr_too_high_data_insufficient,data_insufficient,reason_code,atr_too_high,DATA_INSUFFICIENT,4,0.0,0.0804,0.2412,0,atr_too_high は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_breakout_down_data_insufficient,data_insufficient,reason_code,breakout_down,DATA_INSUFFICIENT,1,0.0,0.0,0.0,0,breakout_down は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_breakout_up_data_insufficient,data_insufficient,reason_code,breakout_up,DATA_INSUFFICIENT,2,0.0,0.0261,0.0261,0,breakout_up は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_overextended_data_insufficient,data_insufficient,reason_code,overextended,DATA_INSUFFICIENT,2,0.0,0.0,0.0,0,overextended は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-07-11T05:59:01,2026-06-12,2026-07-11,20260711_reason_code_rsi_oversold_data_insufficient,data_insufficient,reason_code,rsi_oversold,DATA_INSUFFICIENT,1,0.0,0.0,0.0,0,rsi_oversold は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
```

## 11. RULE_UPDATE_PROPOSALS JSON

```json
{
  "generated_at": "2026-07-11T05:59:01",
  "period_start": "2026-06-12",
  "period_end": "2026-07-11",
  "summary": {
    "proposal_count": 18,
    "high_priority_count": 0,
    "data_insufficient_count": 6,
    "apply_automatically": false
  },
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 249,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "proposals": [
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_atr_too_low_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "atr_too_low",
      "proposal_strength": "LOW",
      "evidence_count": 5,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "atr_too_low は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_ma_alignment_bear_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "ma_alignment_bear",
      "proposal_strength": "LOW",
      "evidence_count": 6,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "ma_alignment_bear は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_ma_alignment_bull_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "ma_alignment_bull",
      "proposal_strength": "LOW",
      "evidence_count": 13,
      "win_rate": 0.0,
      "average_r": 0.0437,
      "total_r": 0.4805,
      "missed_opportunity_count": 0,
      "current_behavior": "ma_alignment_bull は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_momentum_negative_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "momentum_negative",
      "proposal_strength": "LOW",
      "evidence_count": 13,
      "win_rate": 0.0,
      "average_r": 0.0385,
      "total_r": 0.4622,
      "missed_opportunity_count": 0,
      "current_behavior": "momentum_negative は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_momentum_positive_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "momentum_positive",
      "proposal_strength": "LOW",
      "evidence_count": 11,
      "win_rate": 0.0,
      "average_r": 0.0154,
      "total_r": 0.1387,
      "missed_opportunity_count": 0,
      "current_behavior": "momentum_positive は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_pullback_to_ma20_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "pullback_to_ma20",
      "proposal_strength": "LOW",
      "evidence_count": 11,
      "win_rate": 0.0,
      "average_r": 0.0241,
      "total_r": 0.2412,
      "missed_opportunity_count": 0,
      "current_behavior": "pullback_to_ma20 は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_range_middle_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "range_middle",
      "proposal_strength": "LOW",
      "evidence_count": 5,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "range_middle は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_rr_too_low_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "rr_too_low",
      "proposal_strength": "LOW",
      "evidence_count": 20,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_trend_down_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "trend_down",
      "proposal_strength": "LOW",
      "evidence_count": 6,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "trend_down は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_trend_up_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "trend_up",
      "proposal_strength": "LOW",
      "evidence_count": 13,
      "win_rate": 0.0,
      "average_r": 0.0437,
      "total_r": 0.4805,
      "missed_opportunity_count": 0,
      "current_behavior": "trend_up は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_no_trade_reason_low_volatility_strengthen_no_trade_filter",
      "proposal_type": "strengthen_no_trade_filter",
      "target_type": "no_trade_reason",
      "target_name": "low_volatility",
      "proposal_strength": "LOW",
      "evidence_count": 5,
      "win_rate": 0.2,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "low_volatility: correct=1, missed=0, avg_mfe_r=0.00",
      "proposed_change": "有効な見送り条件として維持または軽く強化を検討",
      "expected_effect": "低品質シグナルの抑制",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_no_trade_reason_rr_too_low_strengthen_no_trade_filter",
      "proposal_type": "strengthen_no_trade_filter",
      "target_type": "no_trade_reason",
      "target_name": "rr_too_low",
      "proposal_strength": "LOW",
      "evidence_count": 15,
      "win_rate": 0.2,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low: correct=3, missed=1, avg_mfe_r=0.00",
      "proposed_change": "有効な見送り条件として維持または軽く強化を検討",
      "expected_effect": "低品質シグナルの抑制",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 3,
      "notes": "over_filtering_risk"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_rank_A_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "rank",
      "target_name": "A",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 4,
      "win_rate": 0.0,
      "average_r": 0.0364,
      "total_r": 0.1455,
      "missed_opportunity_count": 0,
      "current_behavior": "rank=A avg_r=0.0364",
      "proposed_change": "評価件数不足のため監視継続",
      "expected_effect": "過剰調整を避ける",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_atr_too_high_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "atr_too_high",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 4,
      "win_rate": 0.0,
      "average_r": 0.0804,
      "total_r": 0.2412,
      "missed_opportunity_count": 0,
      "current_behavior": "atr_too_high は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_breakout_down_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "breakout_down",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "breakout_down は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_breakout_up_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "breakout_up",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 0.0,
      "average_r": 0.0261,
      "total_r": 0.0261,
      "missed_opportunity_count": 0,
      "current_behavior": "breakout_up は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_overextended_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "overextended",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "overextended は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_rsi_oversold_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "rsi_oversold",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rsi_oversold は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    }
  ],
  "high_priority_proposals": [],
  "data_insufficient_items": [
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_rank_A_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "rank",
      "target_name": "A",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 4,
      "win_rate": 0.0,
      "average_r": 0.0364,
      "total_r": 0.1455,
      "missed_opportunity_count": 0,
      "current_behavior": "rank=A avg_r=0.0364",
      "proposed_change": "評価件数不足のため監視継続",
      "expected_effect": "過剰調整を避ける",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_atr_too_high_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "atr_too_high",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 4,
      "win_rate": 0.0,
      "average_r": 0.0804,
      "total_r": 0.2412,
      "missed_opportunity_count": 0,
      "current_behavior": "atr_too_high は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_breakout_down_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "breakout_down",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "breakout_down は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_breakout_up_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "breakout_up",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 0.0,
      "average_r": 0.0261,
      "total_r": 0.0261,
      "missed_opportunity_count": 0,
      "current_behavior": "breakout_up は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_overextended_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "overextended",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "overextended は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-11T05:59:01",
      "period_start": "2026-06-12",
      "period_end": "2026-07-11",
      "proposal_id": "20260711_reason_code_rsi_oversold_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "rsi_oversold",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rsi_oversold は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動反映しない",
    "closed評価が30〜50件以上溜まるまでは提案のみ",
    "人間レビュー後に必要なら実装"
  ]
}
```
