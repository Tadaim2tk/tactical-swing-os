# Narrative Lookahead Audit

## 1. 概要

外部ニュースやAI要約に「未来情報・評価結果」が混入していないかを監査する補助レイヤーです。
自動売買判断ではなく、研究プロセスの時間軸汚染を検出します。最終判断は人間が行います。

## 2. 監査ステータス

- audit_status: **passed**
- recommended_next_action: continue_monitoring
- requires_human_approval: True
- weights_json_updated: False / generate_signal_updated: False

## 3. 件数

- total_checked: 32
- passed: 32 / warning: 0 / high_risk: 0 / blocked: 0
- unavailable: 0 / unknown_timing: 31
- max_lookahead_score: 0

## 4. high_risk / blocked の詳細

_該当なし_

## 5. warning の詳細

_該当なし_

## 6. source_timing_class 別集計

- evaluation_feedback: 1
- unknown_timing: 31

## 7. 注意事項

- この監査は自動売買判断ではありません。
- LLMやニュース要約への未来情報混入を検出する補助です。
- 評価結果を「振り返り」として使うのは許可されます。問題は「事前材料」と混同する場合です。
- 最終判断は人間が行います。
