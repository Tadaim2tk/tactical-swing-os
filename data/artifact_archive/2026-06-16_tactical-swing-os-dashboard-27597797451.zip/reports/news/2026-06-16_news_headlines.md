# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-16 15:07:21 JST
取得日時（UTC）: 2026-06-16 06:07:21 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.1
headline件数: 30

## 見出し

- [CNBC Markets] SpaceX stock jumps 20% in first full day of trading after record debut (未分類)
- [CNBC Markets] China economy weakens further in May as retail sales post first drop in over three years (未分類)
- [CNBC Markets] Bank of Japan hikes rates to 1%, highest since 1995, as yen and inflation worries take hold (USDJPY|US10Y|DXY)
- [CNBC Markets] South Korean defense stocks surge on prospects for post-Iran-war sales boosts (SPX)
- [CNBC Markets] Qualcomm CEO says AI agents will replace apps — as chip giant works on 40 new AI-powered devices (NASDAQ)
- [CNBC Markets] Biotech IPO window is opening but big pharma M&A still sets the pace, top bankers tell CNBC (NASDAQ)
- [CNBC Markets] Nvidia plans to raise at least $20 billion in its first debt sale since start of AI boom (NASDAQ)
- [CNBC Markets] Warsh's Fed is likely to hold rates steady — what the leadership change could mean for your money (US10Y|DXY)
- [CNBC Markets] Sen. Warren asks Trump if administration plans to raise Social Security retirement age (未分類)
- [CNBC Markets] Australia central bank warns hikes are not off the table as it keeps rates steady at 4.35% (US10Y|DXY)
- [CNBC Markets] Gavin Newsom says Trump ordered DOJ to investigate him and his wife (未分類)
- [CNBC Markets] The Iran deal came just in time as Strategic Petroleum Reserve hits lowest level since 1983 (WTI)
- [CNBC Markets] Trump trusts Fed Chair Kevin Warsh. It matters for more than interest rates (US10Y|DXY)
- [CNBC Markets] CNBC's The China Connection newsletter: Waiting for AI to lift the whole market (未分類)
- [CNBC Markets] Vance says 'a lot' of Iran deal details to figure out, but U.S. has 'all the cards' (未分類)
- [CNBC Markets] People in China are watching the World Cup differently this time (未分類)
- [CNBC Markets] I want people to be millionaires — Jim Cramer's blueprint to make money in any market (SPX)
- [CNBC Markets] How the Strait of Hormuz reopening could unfold if the U.S.-Iran deal is implemented (BTC|WTI)
- [CNBC Markets] CFTC chair Selig defends decision to approve ‘perps’ in U.S. (VIX)
- [CNBC Markets] Wall Street's fear gauge tumbles as traders bid up SpaceX shares (SPX|VIX)
- [CNBC Markets] Centene to offer buyouts to some employees as health insurer cuts costs (未分類)
- [CNBC Markets] Fox to buy streaming device maker Roku for $22 billion (未分類)
- [CNBC Markets] Anthropic to meet with Trump administration over Mythos dispute (未分類)
- [CNBC Markets] Oil tumbles on US-Iran deal framework: How one trader is playing the move (BTC|WTI|SPX)
- [CNBC Markets] U.S.-Iran deal explained: What we know — and what remains unresolved (SPX)
- [CNBC Markets] Dick's Sporting Goods expanding Lids shops to 100 locations (未分類)
- [CNBC Markets] Vance says U.S. expects Strait of Hormuz to be open 'toll free' long term (未分類)
- [CNBC Markets] Ron Baron bought $1 billion of SpaceX shares in IPO, lifting stake to $25 billion (USDJPY|SPX|DXY)
- [CNBC Markets] Electronic Arts launches EA Advertising, a new way for brands to advertise 'directly into gameplay' (未分類)
- [CNBC Markets] Oil prices fall about 5% as Iran deal is set to open Hormuz Strait (WTI)
