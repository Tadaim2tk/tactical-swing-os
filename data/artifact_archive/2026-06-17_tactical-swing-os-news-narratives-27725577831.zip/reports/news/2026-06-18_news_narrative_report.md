# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-18 08:09:41 JST
生成日時（UTC）: 2026-06-17 23:09:41 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.28
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: inflation_pressure
日本語要約: インフレ圧力はありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立

## スコア

- risk_on_news_score: 55.4
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 18.47
- gold_safe_haven_news_score: 18.47
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 18.47
- inflation_pressure_news_score: 73.87
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 18.47
- news_confidence: 100.0

## Top News Drivers

- Jeffrey Gundlach says Fed's Warsh is not going to be the 'easy money' chairman many hoped for (インフレ圧力 / 金利圧力候補)
- Allbirds continues AI pivot with name change and CEO hire, sending stock soaring (中銀ハト派)
- SpaceX posts first losing day as stock sinks 5%, losing momentum after a multiday rally (リスクオン要因)
- The market didn't like what it heard from the Fed and its new leader Kevin Warsh (金利圧力候補)
- From supply shock to oil glut: IEA flags scale of demand destruction caused by Iran war (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Did Warsh and Vance just open the door to higher inflation? (インフレ圧力 / 金利圧力候補)
- Kevin Warsh launches his push to change how the Fed operates (インフレ圧力 / 金利圧力候補)
- Stock-market pessimists have one less reason to worry as shares of banks and retailers perk up (リスクオン要因)
- The Fed just threw investors a curveball. Here’s how stocks, bonds, gold and the dollar reacted. (インフレ圧力 / 金利圧力候補)
- Live markets: Fed holds rates steady, but makes a hawkish turn as Warsh takes over (リスクオン要因)
