# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-03 07:48:09 JST
生成日時（UTC）: 2026-07-02 22:48:09 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.93
ニュース市場バイアス: mixed
ニュース矛盾スコア: 55.4
主要テーマ: risk_off
日本語要約: リスクオフ要因が目立ち、リスクオン材料とリスクオフ材料が混在しています。強弱材料が混在しており、方向感は限定的です。
ニュースモード: ニュースは混在

## スコア

- risk_on_news_score: 55.4
- risk_off_news_score: 73.87
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 18.47
- gold_safe_haven_news_score: 0.0
- oil_supply_risk_news_score: 18.47
- crypto_liquidity_news_score: 18.47
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 18.47
- inflation_pressure_news_score: 55.4
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 18.47
- central_bank_dovish_score: 36.93
- news_confidence: 100.0

## Top News Drivers

- Trump bought Apple, Nvidia and other tech giants before tariff reversal fueled rebound (インフレ圧力 / リスクオン要因 / 金利圧力候補)
- Bitwise says STRC selloff signals crypto cycle nearing a bottom, not Strategy’s breaking point (リスクオフ要因)
- US Treasury sanctions over 100 ISIS-K crypto addresses that moved over $1.4 million (地政学リスク / 原油供給リスク / リスクオフ要因)
- JPMorgan says Strategy's bitcoin sales policy adds 'two-way risk' to crypto markets (リスクオフ要因)
- U.S. payroll growth slowed sharply in June, with only 57,000 jobs added (金利圧力候補 / 中銀タカ派)
- Warsh's comments set the stage for U.S. jobs data to ignite bitcoin, gold rally (リスクオン要因)
- Smaller tokens lead as bitcoin, sol rally in 'first real bounce of the selloff' (リスクオフ要因 / リスクオン要因 / 中銀ハト派)
- Bitcoin rises 4% to above $61,000 as inflation fears soften (インフレ圧力 / 暗号資産流動性 / 金利圧力候補)
- ChatGPT developer OpenAI said to discuss offering U.S. government a 5% stake: FT (中銀ハト派)
- Ether, solana, dogecoin in the green after Warsh comments push bitcoin above $60,000 (インフレ圧力 / リスクオフ要因 / 金利圧力候補)
