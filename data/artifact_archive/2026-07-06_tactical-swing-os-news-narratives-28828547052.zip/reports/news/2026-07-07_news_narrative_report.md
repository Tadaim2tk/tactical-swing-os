# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-07 07:48:37 JST
生成日時（UTC）: 2026-07-06 22:48:37 UTC
headline件数: 71
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.12
ニュース市場バイアス: risk_on
ニュース矛盾スコア: 36.99
主要テーマ: geopolitical_risk, risk_on
日本語要約: 地政学リスク、リスクオン要因が優勢で、ニュース面ではリスク選好がやや強い状態です。
ニュースモード: ニュースはリスクオン寄り / 地政学リスク材料あり

## スコア

- risk_on_news_score: 73.97
- risk_off_news_score: 36.99
- dollar_strength_news_score: 18.49
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 55.48
- oil_supply_risk_news_score: 18.49
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 18.49
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 18.49
- news_confidence: 100.0

## Top News Drivers

- China's Alibaba bans Anthropic AI for employees after 'distillation attack' accusation (地政学リスク / リスクオフ要因)
- NATO tensions are ‘growing pains,’ U.S. ambassador says as Trump presses allies (リスクオフ要因)
- Trump's calls, Ukraine's strikes and Russia's barrage on Kyiv put markets on alert (地政学リスク / リスクオフ要因)
- Why Iran may find it difficult to clear its oil inventories even after sanctions relief (地政学リスク / 原油供給リスク / リスクオフ要因)
- Cargo vessel in Red Sea reports coming under attack, UK maritime body says (地政学リスク / リスクオフ要因)
- Stocks rally when Congress goes on summer break. Here’s why. (リスクオフ要因 / リスクオン要因)
- Micron’s stock gains, signaling a ‘return to optimism’ about the chip sector (リスクオン要因)
- TeraWulf’s stock gains after a $19 billion deal with Anthropic (中銀ハト派)
- Securitize eyes acquisitions with $400 million war chest after going public, CEO says (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Russia's largest bank plans crypto wallet launch as Moscow clears market path (地政学リスク / リスクオフ要因)
