# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-14 08:17:41 JST
生成日時（UTC）: 2026-06-13 23:17:41 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.28
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 19.17
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 38.33
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 38.33
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 38.33
- inflation_pressure_news_score: 19.17
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Trump says peace deal will be signed Sunday after Iran said it remains cautious on timing (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Moats vs. moonshots: The Warren Buffett-Elon Musk style debate (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Social Security’s COLA could be 4.7% in 2027 as inflation hits the highest level in 3 years (インフレ圧力 / 金利圧力候補)
- Bitcoin rises above $64,000 after Pakistan prime minister says Iran peace deal is near (リスクオン要因 / 暗号資産流動性)
