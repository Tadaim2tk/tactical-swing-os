# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-09 07:45:29 JST
取得日時（UTC）: 2026-07-08 22:45:29 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.03
headline件数: 75

## 見出し

- [CNBC Markets] U.S. military launches new Iran strikes as Trump says 'not sure' he wants deal (未分類)
- [CNBC Markets] SpaceX stock closes below debut price at $148 in two-day slide after Nasdaq-100 inclusion (NASDAQ)
- [CNBC Markets] McConnell health update demanded by Gov. Beshear as Senate vacancy questions grow (未分類)
- [CNBC Markets] Trump announces long-shot bid to get Supreme Court to rehear birthright citizenship case (未分類)
- [CNBC Markets] Fed officials were split on direction of interest rates at last meeting, minutes show (US10Y|DXY)
- [CNBC Markets] Judge orders E. Jean Carroll be paid $5 million in damages from Trump verdict (未分類)
- [CNBC Markets] Levi Strauss beats quarterly expectations, raises guidance and dividend (未分類)
- [CNBC Markets] Trump says he doesn't want anything to do with Spain: 'Cut off all trade' (未分類)
- [CNBC Markets] Trump pours cold water on NATO allies' united front (未分類)
- [CNBC Markets] Michael Burry bets on sportsbooks DraftKings and Flutter, sees prediction markets curbed by regulation (SPX)
- [CNBC Markets] Meta is building its first big Canadian data center as AI expansion crosses the border (未分類)
- [CNBC Markets] Delta launches 'basic business' fares without lounge access, seat selection (未分類)
- [CNBC Markets] Oil prices jump more than 4% after Trump threatens to bomb Iran and reimpose naval blockade (WTI)
- [CNBC Markets] Fed meeting minutes to show 'family fight' over rates. The squabble could drag on for a while (US10Y|DXY)
- [CNBC Markets] Rivian tailspin hasn't shaken one trader's resolve (未分類)
- [CNBC Markets] Trump loses latest appeals court bid to restore his name to Kennedy Center (未分類)
- [CNBC Markets] Few bright spots in Wednesday's tough market — why Nvidia stock is one of them (未分類)
- [CNBC Markets] Waymo to start driverless rides in 4 more U.S. markets as expansion accelerates (US10Y|DXY)
- [CNBC Markets] Used EVs keep getting more expensive amid Iran war, high gas prices (未分類)
- [CNBC Markets] Delaying Social Security reform raises risks for bond markets and the economy, research finds (US10Y)
- [CNBC Markets] The American Dream is missing one key ingredient, says Harvard happiness expert: Without it, 'life is pretty grim' (未分類)
- [CNBC Markets] Bezos' Blue Origin valued at $130 billion in first outside fundraising round (未分類)
- [CNBC Markets] Apple commits $30 billion to Broadcom for U.S. chipmaking push (NASDAQ)
- [CNBC Markets] Mitch McConnell's health concerns grow amid 4th week in hospital with few details from aides (未分類)
- [CNBC Markets] Healthy Returns: Employers aren't expanding coverage of GLP-1 obesity drugs — many are finding ways around it (未分類)
- [CNBC Markets] OpenAI to publicly release GPT-5.6, rolls out conversational AI models (未分類)
- [CNBC Markets] China warns about AI risks with Anthropic's Claude Code (未分類)
- [CNBC Markets] Weekly mortgage demand drops as rates remain stuck in a narrow range (US10Y|DXY)
- [CNBC Markets] Strait of Hormuz traffic won't return to normal until 2027 after latest setback, Kalshi traders predict (未分類)
- [CNBC Markets] Trump doubles down on push for control over Greenland as Denmark vows to defend it (未分類)
- [MarketWatch Top Stories] Did you mess up on your taxes? The IRS just made it easier to avoid paying a penalty. (未分類)
- [MarketWatch Top Stories] Oil prices extend gains after hours as U.S. forces conduct additional strikes on Iran (WTI)
- [MarketWatch Top Stories] Investors haven’t been this bullish on the dollar in a decade. How the buck can keep climbing. (BTC|WTI|USDJPY|US10Y|DXY)
- [MarketWatch Top Stories] This chart shows stamp prices over the years as USPS hikes postage again this weekend (未分類)
- [MarketWatch Top Stories] The Strait of Hormuz is back under ‘full-conflict conditions’ — and energy markets are scrambling (WTI|VIX)
- [MarketWatch Top Stories] ‘I’d hate to end up with an unexpected tax bill’: I’m 73 and still work full time. Can I avoid paying taxes on my Social Security benefits? (未分類)
- [MarketWatch Top Stories] Nvidia’s stock trades at a juicy discount, according to BofA (未分類)
- [MarketWatch Top Stories] Higher gas prices aren’t the only way rising tensions with Iran will hit home (WTI|SPX)
- [MarketWatch Top Stories] More than two-thirds of tech stocks are at least 20% off recent highs. What’s happening to the AI trade? (SPX|NASDAQ)
- [MarketWatch Top Stories] ‘I’ve plenty of time on my hands’: Advisers bombard me with offers of free steak dinners. Is it wrong to go for the food? (未分類)
- [CoinDesk] Polymarket bets on U.S. marketing blitz to win back trust after 4-year ban: Report (未分類)
- [CoinDesk] Crypto Long & Short: With MSTR concerns assuaged, look to traditional signals around BTC (BTC)
- [CoinDesk] Crypto VC Paradigm launches $1.2 billion AI fund as it broadens beyond digital assets (BTC)
- [CoinDesk] Dinari, tZERO join forces on turnkey platform for tokenized U.S. equities (SPX)
- [CoinDesk] Adam Back's bitcoin treasury firm scraps SPAC merger, seeks new deal (BTC|US10Y|DXY)
- [CoinDesk] BNB Chain is building a new layer-1 for high-frequency trading and AI agents (未分類)
- [CoinDesk] Citadel abandons multi-year crypto lawsuit to focus on bankruptcy order against an ex-employee (BTC)
- [CoinDesk] SpaceX's first bitcoin wallet movements in six months likely don't signal sales (BTC)
- [CoinDesk] Bitcoin's inflation quagmire gets stickier as renewed MidEast conflict sends oil price soaring (BTC|WTI)
- [CoinDesk] Crypto and stocks tumble after Trump declares ceasefire 'over' following Iran strikes (BTC|SPX)
