# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-09 07:45:30 JST
生成日時（UTC）: 2026-07-08 22:45:30 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.03
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 18.47
- gold_safe_haven_news_score: 55.4
- oil_supply_risk_news_score: 18.47
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 55.4
- inflation_pressure_news_score: 36.93
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Used EVs keep getting more expensive amid Iran war, high gas prices (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Investors haven’t been this bullish on the dollar in a decade. How the buck can keep climbing. (地政学リスク / インフレ圧力 / 原油供給リスク / リスクオフ要因 / 金利圧力候補)
- The Strait of Hormuz is back under ‘full-conflict conditions’ — and energy markets are scrambling (金安全資産需要)
- Bitcoin's inflation quagmire gets stickier as renewed MidEast conflict sends oil price soaring (インフレ圧力 / 金安全資産需要 / 金利圧力候補)
- Live markets: Bitcoin drops to $62,000 as oil and bond yields surge on collapse of Iran ceasefire (金利圧力候補)
- Leidos wins $27.2 million missile contract modification (地政学リスク / リスクオフ要因)
