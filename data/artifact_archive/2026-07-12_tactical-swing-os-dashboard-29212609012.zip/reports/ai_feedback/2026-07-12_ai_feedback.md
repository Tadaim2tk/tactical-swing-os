# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-07-13 08:01:16 JST
Actions実行時刻（UTC）: 2026-07-12 23:01:16 UTC
対象日: 2026-07-12
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 19.17
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 41.58
- risk_off: 39.69
- dollar: 35.14
- rate: 35.39
- volatility: 48.0
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=7, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 41.58 | 39.69 | 35.14 | 35.39 | 42.75 | 35.85 | 48.0 | 93.86 |
| DXY | 51.19 | 48.48 | 50.2 | 50.56 | 47.93 | 51.21 | 48.0 | 92.78 |
| GOLD | 51.19 | 48.48 | 50.2 | 50.56 | 47.93 | 51.21 | 48.0 | 92.78 |
| NASDAQ | 51.19 | 48.48 | 50.2 | 50.56 | 47.93 | 51.21 | 48.0 | 92.78 |
| SPX | 51.19 | 48.48 | 50.2 | 50.56 | 47.93 | 51.21 | 48.0 | 92.78 |
| US10Y | 51.19 | 48.48 | 50.2 | 50.56 | 47.93 | 51.21 | 48.0 | 92.78 |
| USDJPY | 51.19 | 48.48 | 50.2 | 50.56 | 47.93 | 51.21 | 48.0 | 92.78 |
| VIX | 51.19 | 48.48 | 50.2 | 50.56 | 47.93 | 51.21 | 48.0 | 92.78 |
| WTI | 51.19 | 48.48 | 50.2 | 50.56 | 47.93 | 51.21 | 48.0 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260712_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260712_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260712_GOLD_SHORT_B-Watch | GOLD | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative | neutral | -12 | GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260712_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | NO_TRADE | momentum_positive|atr_too_high|rr_too_low|range_middle|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260712_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260712_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260712_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | NO_TRADE | momentum_negative|rr_too_low|pullback_to_ma20|overextended | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり
- top_news_drivers: Sen. Lindsey Graham, influential lawmaker and Trump ally, dies at 71 after a brief illness, Here are the 3 big things we're watching in the stock market this week, Oil prices rise, stock futures dip after latest flare-up of strikes between U.S. and Iran, You don’t have to be rich to be financially independent. Here’s how to take control of your money., The stock-market rally now hinges more on AI than oil

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-07-12T23:01:16,2026-07-13 08:01:16 JST,2026-07-12 23:01:16 UTC,2026-07-12,BTC,20260712_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,atr_too_low|rr_too_low,neutral,0,41.58,39.69,35.14,35.39,42.75,35.85,48.0,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-12T23:01:16,2026-07-13 08:01:16 JST,2026-07-12 23:01:16 UTC,2026-07-12,DXY,20260712_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low,neutral,0,41.58,39.69,35.14,35.39,42.75,35.85,48.0,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-12T23:01:16,2026-07-13 08:01:16 JST,2026-07-12 23:01:16 UTC,2026-07-12,GOLD,20260712_GOLD_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative,neutral,-12,41.58,39.69,35.14,35.39,42.75,35.85,48.0,93.86,100.0,market_proxy_plus_news,open_unresolved,,context_neutral,GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,GOLD SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-12T23:01:16,2026-07-13 08:01:16 JST,2026-07-12 23:01:16 UTC,2026-07-12,NASDAQ,20260712_NASDAQ_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|atr_too_high|rr_too_low|range_middle|pullback_to_ma20,neutral,0,41.58,39.69,35.14,35.39,42.75,35.85,48.0,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,NASDAQ NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-12T23:01:16,2026-07-13 08:01:16 JST,2026-07-12 23:01:16 UTC,2026-07-12,SPX,20260712_SPX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rr_too_low,neutral,0,41.58,39.69,35.14,35.39,42.75,35.85,48.0,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,SPX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-12T23:01:16,2026-07-13 08:01:16 JST,2026-07-12 23:01:16 UTC,2026-07-12,USDJPY,20260712_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low|pullback_to_ma20,neutral,0,41.58,39.69,35.14,35.39,42.75,35.85,48.0,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-12T23:01:16,2026-07-13 08:01:16 JST,2026-07-12 23:01:16 UTC,2026-07-12,WTI,20260712_WTI_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|rr_too_low|pullback_to_ma20|overextended,neutral,0,41.58,39.69,35.14,35.39,42.75,35.85,48.0,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,WTI NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-07-12T23:01:16",
  "generated_at_jst": "2026-07-13 08:01:16 JST",
  "generated_at_utc": "2026-07-12 23:01:16 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-07-12",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 66,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "top_news_drivers": [
    {
      "title": "Sen. Lindsey Graham, influential lawmaker and Trump ally, dies at 71 after a brief illness",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "geopolitical_risk_news_score:ukraine",
      "driver_tags": "geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/07/12/senator-lindsey-graham-has-died-after-a-brief-illness-his-office-says.html"
    },
    {
      "title": "Here are the 3 big things we're watching in the stock market this week",
      "source": "CNBC Markets",
      "matched_assets": "SPX|NASDAQ",
      "matched_rules": "inflation_pressure_news_score:inflation",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/07/12/here-are-the-3-big-things-were-watching-in-the-stock-market-this-week.html"
    },
    {
      "title": "Oil prices rise, stock futures dip after latest flare-up of strikes between U.S. and Iran",
      "source": "MarketWatch Top Stories",
      "matched_assets": "WTI",
      "matched_rules": "inflation_pressure_news_score:prices rise",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.marketwatch.com/story/oil-prices-rise-stock-futures-dip-after-latest-flare-up-of-strikes-between-u-s-and-iran-fef7f856?mod=mw_rss_topstories"
    },
    {
      "title": "You don’t have to be rich to be financially independent. Here’s how to take control of your money.",
      "source": "MarketWatch Top Stories",
      "matched_assets": "",
      "matched_rules": "risk_off_news_score:crisis",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.marketwatch.com/story/you-dont-have-to-be-rich-to-be-financially-independent-heres-how-to-take-control-of-your-money-5345f146?mod=mw_rss_topstories"
    },
    {
      "title": "The stock-market rally now hinges more on AI than oil",
      "source": "MarketWatch Top Stories",
      "matched_assets": "WTI|SPX|NASDAQ",
      "matched_rules": "risk_on_news_score:rally",
      "driver_tags": "risk_on",
      "driver_summary_ja": "リスクオン要因",
      "link": "https://www.marketwatch.com/story/the-stock-market-rally-now-hinges-more-on-ai-than-oil-1292260a?mod=mw_rss_topstories"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 41.58,
      "risk_off_score": 39.69,
      "dollar_strength_score": 35.14,
      "rate_pressure_score": 35.39,
      "gold_safe_haven_score": 42.75,
      "oil_supply_risk_proxy_score": 35.06,
      "crypto_liquidity_score": 35.85,
      "equity_momentum_score": 36.11,
      "volatility_stress_score": 48.0,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 19.17,
      "risk_off_news_score": 19.17,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 0.0,
      "oil_supply_risk_news_score": 0.0,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 38.33,
      "inflation_pressure_news_score": 38.33,
      "recession_risk_news_score": 19.17,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 51.19,
      "risk_off_score": 48.48,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.56,
      "gold_safe_haven_score": 47.93,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.21,
      "equity_momentum_score": 51.58,
      "volatility_stress_score": 48.0,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1029,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 51.19,
      "risk_off_score": 48.48,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.56,
      "gold_safe_haven_score": 47.93,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.21,
      "equity_momentum_score": 51.58,
      "volatility_stress_score": 48.0,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.3872,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 51.19,
      "risk_off_score": 48.48,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.56,
      "gold_safe_haven_score": 47.93,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.21,
      "equity_momentum_score": 51.58,
      "volatility_stress_score": 48.0,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.2103,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 51.19,
      "risk_off_score": 48.48,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.56,
      "gold_safe_haven_score": 47.93,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.21,
      "equity_momentum_score": 51.58,
      "volatility_stress_score": 48.0,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1545,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 51.19,
      "risk_off_score": 48.48,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.56,
      "gold_safe_haven_score": 47.93,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.21,
      "equity_momentum_score": 51.58,
      "volatility_stress_score": 48.0,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.6166,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 51.19,
      "risk_off_score": 48.48,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.56,
      "gold_safe_haven_score": 47.93,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.21,
      "equity_momentum_score": 51.58,
      "volatility_stress_score": 48.0,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.2023,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 51.19,
      "risk_off_score": 48.48,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.56,
      "gold_safe_haven_score": 47.93,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.21,
      "equity_momentum_score": 51.58,
      "volatility_stress_score": 48.0,
      "narrative_confidence": 92.78,
      "asset_change_pct": -6.4134,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 51.19,
      "risk_off_score": 48.48,
      "dollar_strength_score": 50.2,
      "rate_pressure_score": 50.56,
      "gold_safe_haven_score": 47.93,
      "oil_supply_risk_proxy_score": 50.08,
      "crypto_liquidity_score": 51.21,
      "equity_momentum_score": 51.58,
      "volatility_stress_score": 48.0,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.19,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260712_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260712_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260712_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": -12,
      "narrative_comment": "GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260712_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|atr_too_high|rr_too_low|range_middle|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260712_SPX_NONE_NO_TRADE",
      "asset": "SPX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260712_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260712_WTI_NONE_NO_TRADE",
      "asset": "WTI",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|rr_too_low|pullback_to_ma20|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
