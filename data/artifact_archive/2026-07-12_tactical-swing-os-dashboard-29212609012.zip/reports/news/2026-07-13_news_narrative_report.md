# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-13 08:01:14 JST
生成日時（UTC）: 2026-07-12 23:01:14 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.49
ニュース市場バイアス: neutral
ニュース矛盾スコア: 19.17
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 19.17
- risk_off_news_score: 19.17
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 0.0
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 38.33
- inflation_pressure_news_score: 38.33
- recession_risk_news_score: 19.17
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Sen. Lindsey Graham, influential lawmaker and Trump ally, dies at 71 after a brief illness (地政学リスク / リスクオフ要因)
- Here are the 3 big things we're watching in the stock market this week (インフレ圧力 / 金利圧力候補)
- Oil prices rise, stock futures dip after latest flare-up of strikes between U.S. and Iran (インフレ圧力 / 金利圧力候補)
- You don’t have to be rich to be financially independent. Here’s how to take control of your money. (リスクオフ要因)
- The stock-market rally now hinges more on AI than oil (リスクオン要因)
- NZ’s Fonterra trims top end of annual milk price forecast on weak demand (景気後退リスク)
- Russia stocks lower at close of trade; MOEX Russia Index unchanged (地政学リスク / リスクオフ要因)
