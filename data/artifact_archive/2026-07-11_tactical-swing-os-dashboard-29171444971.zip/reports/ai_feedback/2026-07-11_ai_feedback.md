# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-07-12 08:01:07 JST
Actions実行時刻（UTC）: 2026-07-11 23:01:07 UTC
対象日: 2026-07-11
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立
- ニュースモード: ニュースのリスク方向は中立
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 19.17
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 41.79
- risk_off: 51.02
- dollar: 34.94
- rate: 35.22
- volatility: 47.7
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=1, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 41.79 | 51.02 | 34.94 | 35.22 | 38.21 | 35.96 | 47.7 | 93.86 |
| DXY | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| GOLD | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| NASDAQ | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| SPX | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| US10Y | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| USDJPY | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| VIX | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| WTI | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260711_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立
- top_news_drivers: Trump threatens to 'decimate' Iran if it tries to kill him, as Treasury sanctions alleged Iranian financier, The dot-com crash was a $5 trillion blip. Why the next financial crisis could hit 4 times harder., Stocks rally when Congress goes on summer break. Here’s why., Crypto IPO market stalls as capital rotates to AI and macro uncertainty weighs

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-07-11T23:01:07,2026-07-12 08:01:07 JST,2026-07-11 23:01:07 UTC,2026-07-11,BTC,20260711_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,atr_too_low|rr_too_low,neutral,0,41.79,51.02,34.94,35.22,38.21,35.96,47.7,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-07-11T23:01:07",
  "generated_at_jst": "2026-07-12 08:01:07 JST",
  "generated_at_utc": "2026-07-11 23:01:07 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-07-11",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 59,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立",
  "top_news_drivers": [
    {
      "title": "Trump threatens to 'decimate' Iran if it tries to kill him, as Treasury sanctions alleged Iranian financier",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "oil_supply_risk_news_score:sanctions|geopolitical_risk_news_score:sanctions",
      "driver_tags": "oil_supply_risk|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 原油供給リスク / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/07/11/trump-threat.html"
    },
    {
      "title": "The dot-com crash was a $5 trillion blip. Why the next financial crisis could hit 4 times harder.",
      "source": "MarketWatch Top Stories",
      "matched_assets": "",
      "matched_rules": "risk_off_news_score:crisis",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.marketwatch.com/story/the-dot-com-crash-was-a-5-trillion-blip-why-the-next-financial-crisis-could-hit-4-times-harder-29f4aa57?mod=mw_rss_topstories"
    },
    {
      "title": "Stocks rally when Congress goes on summer break. Here’s why.",
      "source": "MarketWatch Top Stories",
      "matched_assets": "SPX|VIX",
      "matched_rules": "risk_on_news_score:rally|risk_off_news_score:uncertainty",
      "driver_tags": "risk_on|risk_off",
      "driver_summary_ja": "リスクオフ要因 / リスクオン要因",
      "link": "https://www.marketwatch.com/story/stocks-rally-when-congress-goes-on-summer-break-here-is-the-hidden-reason-e70a6be3?mod=mw_rss_topstories"
    },
    {
      "title": "Crypto IPO market stalls as capital rotates to AI and macro uncertainty weighs",
      "source": "CoinDesk",
      "matched_assets": "BTC",
      "matched_rules": "risk_off_news_score:uncertainty",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.coindesk.com/business/2026/07/08/crypto-ipo-market-stalls-as-capital-rotates-to-ai-and-macro-uncertainty-weighs"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 41.79,
      "risk_off_score": 51.02,
      "dollar_strength_score": 34.94,
      "rate_pressure_score": 35.22,
      "gold_safe_haven_score": 38.21,
      "oil_supply_risk_proxy_score": 40.59,
      "crypto_liquidity_score": 35.96,
      "equity_momentum_score": 36.44,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 19.17,
      "risk_off_news_score": 57.5,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 0.0,
      "oil_supply_risk_news_score": 19.17,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 19.17,
      "inflation_pressure_news_score": 0.0,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0505,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1572,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.4367,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.5107,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.6166,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.425,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": -6.4134,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.4871,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260711_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
