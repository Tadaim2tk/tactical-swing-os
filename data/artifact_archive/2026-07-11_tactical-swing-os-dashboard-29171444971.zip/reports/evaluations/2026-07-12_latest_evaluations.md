# Latest Evaluations Report

## 1. 概要

* 生成日時JST: 2026-07-12 08:01:16 JST
* 入力行数: 2339
* unique signal数: 251
* 最新評価行数: 251
* PENDING_REEVALUATIONS由来の最新評価数: 234
* EVALUATIONS由来の最新評価数: 17

## 2. 決着済み

| signal_id | asset | side | rank | outcome | r_multiple | latest_source | latest_reason |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260606_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | loss_sl | -1.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B | win_tp1 | 1.087 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B | loss_sl | -1.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | win_tp1 | 1.087 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_VIX_NONE_NO_TRADE | VIX | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B | loss_sl | -1.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260609_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_VIX_NONE_NO_TRADE | VIX | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260609_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | no_trade_missed | 0.0 | pending_reevaluations | latest_by_reevaluation_at |

## 3. 未決着

| signal_id | asset | side | rank | status | evaluation_status | outcome | latest_source | latest_reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_DXY_LONG_A-Momentum | DXY | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_US10Y_LONG_A-Pullback | US10Y | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_US10Y_LONG_B-Watch | US10Y | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260609_BTC_SHORT_B-Watch | BTC | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260609_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260609_WTI_SHORT_B-Watch | WTI | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260610_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260611_WTI_SHORT_B-Watch | WTI | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260612_WTI_SHORT_B-Watch | WTI | SHORT | B | no_entry | pending | no_entry | pending_reevaluations | latest_by_reevaluation_at |
| 20260614_NASDAQ_LONG_A-Pullback | NASDAQ | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260614_SPX_LONG_A-Pullback | SPX | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260614_WTI_SHORT_B-Watch | WTI | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260615_NASDAQ_LONG_B-Watch | NASDAQ | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260615_SPX_LONG_B-Watch | SPX | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260615_VIX_SHORT_TREND | VIX | SHORT | A | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260615_WTI_SHORT_B-Watch | WTI | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260616_NASDAQ_LONG_B-Watch | NASDAQ | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260616_SPX_LONG_B-Watch | SPX | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260616_VIX_SHORT_B-Watch | VIX | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260616_WTI_SHORT_B-Watch | WTI | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260617_DXY_LONG_A-Momentum | DXY | LONG | A | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |

## 4. 再評価履歴あり

| signal_id | asset | side | rank | outcome | previous_rows_count | latest_source | latest_reason |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260606_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | no_trade_missed | 4 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | loss_sl | 32 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B | win_tp1 | 32 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | no_trade_missed | 4 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | no_trade_missed | 4 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B | loss_sl | 32 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | win_tp1 | 32 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_VIX_NONE_NO_TRADE | VIX | NONE | NO_TRADE | no_trade_missed | 4 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | no_trade_missed | 4 | pending_reevaluations | latest_by_reevaluation_at |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B | loss_sl | 35 | pending_reevaluations | latest_by_reevaluation_at |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 35 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_DXY_LONG_A-Momentum | DXY | LONG | B | open_unresolved | 31 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 31 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_US10Y_LONG_A-Pullback | US10Y | LONG | B | open_unresolved | 31 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | no_trade_missed | 3 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | no_trade_missed | 3 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | no_trade_missed | 3 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 35 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | no_trade_missed | 3 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | no_trade_missed | 3 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | no_trade_missed | 3 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | no_trade_missed | 3 | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | no_trade_missed | 3 | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | no_trade_missed | 3 | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 34 | pending_reevaluations | latest_by_reevaluation_at |

## 5. 注意

* append-only履歴から最新行だけを選ぶ分析用ビューです。
* 元のEVALUATIONS / PENDING_REEVALUATIONSは削除しません。
* この評価は実売買ではありません。
* 自動発注は行いません。
