# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-12 08:13:22 JST
Actions実行時刻（UTC）: 2026-06-11 23:13:22 UTC
対象日: 2026-06-11
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドルは中立 / 金利圧力は限定的 / ボラティリティは落ち着き
- ニュースモード: ニュースナラティブ未取得
- ニュース市場バイアス: insufficient_data
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_only
- 評価データソース: latest_evaluations
- latest_evaluations_available: True
- fallback_used: False
- risk_on: 47.65
- risk_off: 52.52
- dollar: 50.15
- rate: 50.39
- volatility: 53.68
- news_confidence: 0.0
- シグナル整合性: aligned=0, conflicted=0, neutral=1, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 47.65 | 52.52 | 50.15 | 50.39 | 52.94 | 47.62 | 53.68 | 100.0 |
| BTC | 47.65 | 52.52 | 50.15 | 50.39 | 52.94 | 47.62 | 53.68 | 100.0 |
| DXY | 47.65 | 52.52 | 50.15 | 50.39 | 52.94 | 47.62 | 53.68 | 100.0 |
| GOLD | 47.65 | 52.52 | 50.15 | 50.39 | 52.94 | 47.62 | 53.68 | 100.0 |
| NASDAQ | 47.65 | 52.52 | 50.15 | 50.39 | 52.94 | 47.62 | 53.68 | 100.0 |
| SPX | 47.65 | 52.52 | 50.15 | 50.39 | 52.94 | 47.62 | 53.68 | 100.0 |
| US10Y | 47.65 | 52.52 | 50.15 | 50.39 | 52.94 | 47.62 | 53.68 | 100.0 |
| USDJPY | 47.65 | 52.52 | 50.15 | 50.39 | 52.94 | 47.62 | 53.68 | 100.0 |
| VIX | 47.65 | 52.52 | 50.15 | 50.39 | 52.94 | 47.62 | 53.68 | 100.0 |
| WTI | 47.65 | 52.52 | 50.15 | 50.39 | 52.94 | 47.62 | 53.68 | 100.0 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260611_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
| 20260605_GOLD_SHORT_TREND | GOLD | win_tp1 | 1.087 | エントリー/方向判断は一定程度機能しました。 | unknown | 追加サンプルで検証します。 |
| 20260606_BTC_SHORT_TREND | BTC | loss_sl | -1.0 | 損切り到達。Entry/SL幅またはrank判定の再確認が必要です。 | unknown | 追加サンプルで検証します。 |
| 20260609_GOLD_SHORT_B-Watch | GOLD | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260609_WTI_SHORT_B-Watch | WTI | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: False
- news_mode_summary: ニュースナラティブ未取得
- top_news_drivers: ニュースドライバーなし

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-11T23:13:22,2026-06-12 08:13:22 JST,2026-06-11 23:13:22 UTC,2026-06-11,USDJPY,20260611_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low,neutral,0,47.65,52.52,50.15,50.39,52.94,47.62,53.68,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-11T23:13:22",
  "generated_at_jst": "2026-06-12 08:13:22 JST",
  "generated_at_utc": "2026-06-11 23:13:22 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-11",
  "data_source": "Google Sheets",
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 21,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "market_mode_summary": "リスクオン/オフは中立 / ドルは中立 / 金利圧力は限定的 / ボラティリティは落ち着き",
  "news_narrative_available": false,
  "news_mode_summary": "ニュースナラティブ未取得",
  "top_news_drivers": [],
  "narrative_source_mix": "market_proxy_only",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 47.65,
      "risk_off_score": 52.52,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 50.39,
      "gold_safe_haven_score": 52.94,
      "oil_supply_risk_proxy_score": 50.44,
      "crypto_liquidity_score": 47.62,
      "equity_momentum_score": 46.99,
      "volatility_stress_score": 53.68,
      "narrative_confidence": 100.0,
      "asset_change_pct": null
    },
    {
      "asset": "BTC",
      "risk_on_score": 47.65,
      "risk_off_score": 52.52,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 50.39,
      "gold_safe_haven_score": 52.94,
      "oil_supply_risk_proxy_score": 50.44,
      "crypto_liquidity_score": 47.62,
      "equity_momentum_score": 46.99,
      "volatility_stress_score": 53.68,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.7408
    },
    {
      "asset": "DXY",
      "risk_on_score": 47.65,
      "risk_off_score": 52.52,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 50.39,
      "gold_safe_haven_score": 52.94,
      "oil_supply_risk_proxy_score": 50.44,
      "crypto_liquidity_score": 47.62,
      "equity_momentum_score": 46.99,
      "volatility_stress_score": 53.68,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.079
    },
    {
      "asset": "GOLD",
      "risk_on_score": 47.65,
      "risk_off_score": 52.52,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 50.39,
      "gold_safe_haven_score": 52.94,
      "oil_supply_risk_proxy_score": 50.44,
      "crypto_liquidity_score": 47.62,
      "equity_momentum_score": 46.99,
      "volatility_stress_score": 53.68,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.6936
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 47.65,
      "risk_off_score": 52.52,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 50.39,
      "gold_safe_haven_score": 52.94,
      "oil_supply_risk_proxy_score": 50.44,
      "crypto_liquidity_score": 47.62,
      "equity_momentum_score": 46.99,
      "volatility_stress_score": 53.68,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.3585
    },
    {
      "asset": "SPX",
      "risk_on_score": 47.65,
      "risk_off_score": 52.52,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 50.39,
      "gold_safe_haven_score": 52.94,
      "oil_supply_risk_proxy_score": 50.44,
      "crypto_liquidity_score": 47.62,
      "equity_momentum_score": 46.99,
      "volatility_stress_score": 53.68,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.1756
    },
    {
      "asset": "US10Y",
      "risk_on_score": 47.65,
      "risk_off_score": 52.52,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 50.39,
      "gold_safe_haven_score": 52.94,
      "oil_supply_risk_proxy_score": 50.44,
      "crypto_liquidity_score": 47.62,
      "equity_momentum_score": 46.99,
      "volatility_stress_score": 53.68,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.1764
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 47.65,
      "risk_off_score": 52.52,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 50.39,
      "gold_safe_haven_score": 52.94,
      "oil_supply_risk_proxy_score": 50.44,
      "crypto_liquidity_score": 47.62,
      "equity_momentum_score": 46.99,
      "volatility_stress_score": 53.68,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.0386
    },
    {
      "asset": "VIX",
      "risk_on_score": 47.65,
      "risk_off_score": 52.52,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 50.39,
      "gold_safe_haven_score": 52.94,
      "oil_supply_risk_proxy_score": 50.44,
      "crypto_liquidity_score": 47.62,
      "equity_momentum_score": 46.99,
      "volatility_stress_score": 53.68,
      "narrative_confidence": 100.0,
      "asset_change_pct": 10.5473
    },
    {
      "asset": "WTI",
      "risk_on_score": 47.65,
      "risk_off_score": 52.52,
      "dollar_strength_score": 50.15,
      "rate_pressure_score": 50.39,
      "gold_safe_haven_score": 52.94,
      "oil_supply_risk_proxy_score": 50.44,
      "crypto_liquidity_score": 47.62,
      "equity_momentum_score": 46.99,
      "volatility_stress_score": 53.68,
      "narrative_confidence": 100.0,
      "asset_change_pct": 1.0406
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260611_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "signal_id": "20260605_GOLD_SHORT_TREND",
      "asset": "GOLD",
      "outcome": "win_tp1",
      "r_multiple": 1.087,
      "technical_view": "エントリー/方向判断は一定程度機能しました。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    },
    {
      "signal_id": "20260606_BTC_SHORT_TREND",
      "asset": "BTC",
      "outcome": "loss_sl",
      "r_multiple": -1.0,
      "technical_view": "損切り到達。Entry/SL幅またはrank判定の再確認が必要です。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    },
    {
      "signal_id": "20260609_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260609_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
