# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-25 07:54:13 JST
生成日時（UTC）: 2026-06-24 22:54:13 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.6
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: geopolitical_risk
日本語要約: 地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 55.4
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 18.47
- gold_safe_haven_news_score: 55.4
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 18.47
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 73.87
- inflation_pressure_news_score: 0.0
- recession_risk_news_score: 18.47
- central_bank_hawkish_score: 18.47
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- White House requests $87.6 billion supplemental spending for Iran war, farm aid (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Trump meets defense CEOs as Iran operations strain U.S. missile stockpiles (地政学リスク / リスクオフ要因)
- Anthropic accuses Alibaba of campaign to 'brazenly' and 'illicitly' extract AI capabilities (地政学リスク / リスクオフ要因)
- JPMorgan Chase unveils $50 billion buyback, Goldman Sachs raises dividend after Fed stress test (リスクオフ要因 / 景気後退リスク)
- Why energy could be a great place to invest even with oil prices retreating — 5 stocks to buy (金安全資産需要)
- Did the Trump White House just give Warsh the green light to hike interest rates? This analyst thinks so. (金利圧力候補 / 中銀タカ派)
- YZi Labs ends proxy war with BNB treasury company CEA Industries (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Live markets: Bitcoin claws back some of the losses after Micron beats earnings (暗号資産流動性)
- Bitcoin drops toward $62,000 as the chip selloff deepens for a second day (リスクオフ要因)
- Nasdaq, S&P end lower as tech stocks fall (リスクオフ要因)
