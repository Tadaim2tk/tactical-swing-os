# Tactical Swing OS Audit Report v0.1

**Date:** 2026-07-09

## Data Integrity Score

**Status:** ✅ PASS

## Reasons

- No data integrity anomalies detected.

## Input Coverage

| item | value |
|---|---:|
| SIGNALS rows | 0 |
| EVALUATIONS rows | 0 |
| PENDING_REEVALUATIONS rows | 240 |
| LATEST_EVALUATIONS rows | 240 |
| latest summary input rows | 1860 |
| latest summary unique signals | 240 |

## Duplicate Metrics

| item | value |
|---|---:|
| SIGNALS duplicate signal_id | 0 |
| EVALUATIONS duplicate signal_id | 0 |
| LATEST_EVALUATIONS duplicate signal_id | 0 |

## Label Metrics

| item | value |
|---|---:|
| Unique reason codes from SIGNALS | N/A |

## Status Metrics

| item | value |
|---|---|
| EVALUATIONS evaluation_status counts | N/A |
| LATEST_EVALUATIONS evaluation_status counts | closed: 6, pending: 79, skipped: 155 |
