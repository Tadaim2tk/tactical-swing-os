# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-10 08:22:21 JST
生成日時（UTC）: 2026-07-09 23:22:21 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.5
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: geopolitical_risk, gold_safe_haven
日本語要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 金利圧力材料あり / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 38.33
- gold_safe_haven_news_score: 76.67
- oil_supply_risk_news_score: 38.33
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 0.0
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 38.33
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Kalshi traders see roughly 50% odds of a rate hike in 2026 as Fed is split on policy (金利圧力候補 / 中銀タカ派)
- Kalshi traders think gas prices will stay higher for longer as U.S.-Iran tensions heat back up (金利圧力候補 / 中銀タカ派)
- Oil prices fall 2% as mediators try to prevent U.S. and Iran from returning to war (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
- Tanker traffic through Strait of Hormuz slows after Iranian attacks trigger renewed fighting with U.S. (原油供給リスク)
- Trump says Iran called to make a deal after U.S. strikes; adds it's unclear if war is back on (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Ukraine’s drone playbook is wreaking havoc in Russia — and upending where NATO wants to invest (地政学リスク / 金安全資産需要 / リスクオフ要因)
