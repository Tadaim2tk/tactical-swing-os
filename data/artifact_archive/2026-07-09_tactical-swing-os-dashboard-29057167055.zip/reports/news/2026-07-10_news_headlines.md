# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-10 08:22:21 JST
取得日時（UTC）: 2026-07-09 23:22:21 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.5
headline件数: 30

## 見出し

- [CNBC Markets] Inside NATO's extraordinary 48 hours that revealed Trump's grip on global diplomacy (未分類)
- [CNBC Markets] Kevin Warsh names members of his Federal Reserve task forces, including Marc Andreessen, Doug McMillon (US10Y|DXY)
- [CNBC Markets] A huge trade just happened on the Nasdaq 100. Bulls are taking notice (BTC|NASDAQ)
- [CNBC Markets] Alleged Reflecting Pool vandal David Hearn pleads not guilty; lawyer calls him 'scapegoat' (未分類)
- [CNBC Markets] Prediction markets spark insider trading concerns. Here's how Goldman and other companies are responding (GOLD)
- [CNBC Markets] Anduril CEO says it's bad to IPO in ‘middle of a hype cycle’ (NASDAQ)
- [CNBC Markets] Florida's Palm Beach airport renamed for Trump (未分類)
- [CNBC Markets] Kalshi traders see roughly 50% odds of a rate hike in 2026 as Fed is split on policy (US10Y|DXY)
- [CNBC Markets] June home sales disappoint as prices reach an all-time high (US10Y|DXY)
- [CNBC Markets] These 10 states are best positioned to land AI data center deals despite rising public opposition (未分類)
- [CNBC Markets] How all 50 U.S. states performed over 20 years of Top States for Business (未分類)
- [CNBC Markets] Meta jumps into AI coding market in effort to chase Anthropic and OpenAI (未分類)
- [CNBC Markets] Anthropic appoints former Fed Chair Ben Bernanke to its independent trust (US10Y|DXY)
- [CNBC Markets] Palo Alto CEO Arora says AI pricing needs to fall 90% as token costs skyrocket (未分類)
- [CNBC Markets] America's Top States for Business 2026: See the full rankings and where your state finished (未分類)
- [CNBC Markets] Kalshi traders think gas prices will stay higher for longer as U.S.-Iran tensions heat back up (未分類)
- [CNBC Markets] Action-starved traders look to small-cap stocks for the next big move (SPX)
- [CNBC Markets] It's a jam-packed afternoon of developments impacting 7 portfolio stocks (SPX)
- [CNBC Markets] Trump claims to be 'No. 1' on TikTok. What does that mean? (未分類)
- [CNBC Markets] Oil prices fall 2% as mediators try to prevent U.S. and Iran from returning to war (WTI)
- [CNBC Markets] Arkansas is America's Most Improved State in 2026 as workers move to Walmart's home for low costs, high quality of life (未分類)
- [CNBC Markets] Trump can halt trade with Spain using law behind scrapped tariffs: Greer (未分類)
- [CNBC Markets] Goldman Sachs wins $70 billion in asset management deals with Verizon, Lockheed Martin (GOLD|USDJPY|DXY)
- [CNBC Markets] Tanker traffic through Strait of Hormuz slows after Iranian attacks trigger renewed fighting with U.S. (WTI)
- [CNBC Markets] Trump says Iran called to make a deal after U.S. strikes; adds it's unclear if war is back on (BTC)
- [CNBC Markets] PepsiCo earnings miss estimates as U.S. consumers tighten their budgets (SPX|NASDAQ)
- [CNBC Markets] What AI companies want for the millions they're spending on elections (未分類)
- [CNBC Markets] Here's how Trump Account assets may affect your college aid eligibility (未分類)
- [CNBC Markets] Ukraine’s drone playbook is wreaking havoc in Russia — and upending where NATO wants to invest (未分類)
- [CNBC Markets] Clean power comeback? Don't count out renewable energy and this one stock in particular (未分類)
