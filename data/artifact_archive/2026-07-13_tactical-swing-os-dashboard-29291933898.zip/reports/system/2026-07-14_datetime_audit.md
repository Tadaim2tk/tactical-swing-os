# Datetime Consistency Audit

## 1. 概要

- 生成日時JST: 2026-07-14 08:05:42 JST
- audit_status: warning
- issues_found: 44
- timezone_mismatch: 24
- naive_datetime: 3
- timestamp_mismatch: 0
- string_date_count: 16
- missing_target_count: 1
- recommended_action: use_time_utils_now_utc_or_now_jst

## 2. Warning

| file | line | issue_type | severity | pattern | recommended_action | snippet |
| --- | --- | --- | --- | --- | --- | --- |
| src/build_weekly_review.py | 61 | naive_datetime | warning | timezone_naive_now | use_time_utils_now_utc_or_now_jst | end = pd.Timestamp(datetime.now().date()) |
| src/build_monthly_calibration.py | 71 | naive_datetime | warning | timezone_naive_now | use_time_utils_now_utc_or_now_jst | end = pd.Timestamp(datetime.now().date()) |
| src/build_ai_feedback.py | 212 | naive_datetime | warning | timezone_naive_now | use_time_utils_now_utc_or_now_jst | return datetime.now().strftime("%Y-%m-%d") |

## 3. Info

| file | line | issue_type | severity | pattern | recommended_action | snippet |
| --- | --- | --- | --- | --- | --- | --- |
| src/build_weekly_review.py | 174 | timezone_mismatch | info | timezone_removed | document_timezone_boundary_or_keep_utc | out["_review_date"] = pd.to_datetime(out[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_weekly_review.py | 174 | timezone_mismatch | info | timezone_explicit_usage | verify_consistent_jst_utc_labeling | out["_review_date"] = pd.to_datetime(out[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_weekly_review.py | 174 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | out["_review_date"] = pd.to_datetime(out[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_weekly_review.py | 175 | timezone_mismatch | info | timezone_removed | document_timezone_boundary_or_keep_utc | start_ts = pd.Timestamp(start).tz_localize(None).normalize() |
| src/build_weekly_review.py | 176 | timezone_mismatch | info | timezone_removed | document_timezone_boundary_or_keep_utc | end_ts = pd.Timestamp(end).tz_localize(None).normalize() |
| src/build_weekly_review.py | 469 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | "week_start": start.strftime("%Y-%m-%d"), |
| src/build_weekly_review.py | 470 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | "week_end": end.strftime("%Y-%m-%d"), |
| src/build_weekly_review.py | 510 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | report_path = REPORTS_DIR / f"{end.strftime('%Y-%m-%d')}_weekly_review.md" |
| src/build_monthly_calibration.py | 90 | timezone_mismatch | info | timezone_removed | document_timezone_boundary_or_keep_utc | out["_calibration_date"] = pd.to_datetime(out[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_monthly_calibration.py | 90 | timezone_mismatch | info | timezone_explicit_usage | verify_consistent_jst_utc_labeling | out["_calibration_date"] = pd.to_datetime(out[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_monthly_calibration.py | 90 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | out["_calibration_date"] = pd.to_datetime(out[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_monthly_calibration.py | 91 | timezone_mismatch | info | timezone_removed | document_timezone_boundary_or_keep_utc | start_ts = pd.Timestamp(start).tz_localize(None).normalize() |
| src/build_monthly_calibration.py | 92 | timezone_mismatch | info | timezone_removed | document_timezone_boundary_or_keep_utc | end_ts = pd.Timestamp(end).tz_localize(None).normalize() |
| src/build_monthly_calibration.py | 300 | timezone_mismatch | info | timezone_removed | document_timezone_boundary_or_keep_utc | dates = pd.to_datetime(closed[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_monthly_calibration.py | 300 | timezone_mismatch | info | timezone_explicit_usage | verify_consistent_jst_utc_labeling | dates = pd.to_datetime(closed[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_monthly_calibration.py | 300 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | dates = pd.to_datetime(closed[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_monthly_calibration.py | 523 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | "month_start": start.strftime("%Y-%m-%d"), |
| src/build_monthly_calibration.py | 524 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | "month_end": end.strftime("%Y-%m-%d"), |
| src/build_monthly_calibration.py | 572 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | report_path = REPORTS_DIR / f"{end.strftime('%Y-%m-%d')}_monthly_calibration.md" |
| src/build_ai_feedback.py | 209 | timezone_mismatch | info | timezone_removed | document_timezone_boundary_or_keep_utc | parsed = pd.to_datetime(df[col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 209 | timezone_mismatch | info | timezone_explicit_usage | verify_consistent_jst_utc_labeling | parsed = pd.to_datetime(df[col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 209 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | parsed = pd.to_datetime(df[col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 212 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | return datetime.now().strftime("%Y-%m-%d") |
| src/build_ai_feedback.py | 213 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | return max(candidates).strftime("%Y-%m-%d") |
| src/build_ai_feedback.py | 387 | timezone_mismatch | info | timezone_removed | document_timezone_boundary_or_keep_utc | out["_signal_date"] = pd.to_datetime(out[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 387 | timezone_mismatch | info | timezone_explicit_usage | verify_consistent_jst_utc_labeling | out["_signal_date"] = pd.to_datetime(out[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 387 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | out["_signal_date"] = pd.to_datetime(out[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 400 | timezone_mismatch | info | timezone_removed | document_timezone_boundary_or_keep_utc | out["_eval_date"] = pd.to_datetime(out[sort_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 400 | timezone_mismatch | info | timezone_explicit_usage | verify_consistent_jst_utc_labeling | out["_eval_date"] = pd.to_datetime(out[sort_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 400 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | out["_eval_date"] = pd.to_datetime(out[sort_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 431 | timezone_mismatch | info | timezone_removed | document_timezone_boundary_or_keep_utc | out["_sort_key"] = pd.to_datetime(out[sort_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 431 | timezone_mismatch | info | timezone_explicit_usage | verify_consistent_jst_utc_labeling | out["_sort_key"] = pd.to_datetime(out[sort_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 431 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | out["_sort_key"] = pd.to_datetime(out[sort_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 541 | timezone_mismatch | info | timezone_removed | document_timezone_boundary_or_keep_utc | df["_date"] = pd.to_datetime(df[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 541 | timezone_mismatch | info | timezone_explicit_usage | verify_consistent_jst_utc_labeling | df["_date"] = pd.to_datetime(df[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 541 | string_date | info | string_date_conversion | use_errors_coerce_and_normalize | df["_date"] = pd.to_datetime(df[date_col], errors="coerce", utc=True).dt.tz_localize(None) |
| src/build_ai_feedback.py | 740 | timezone_mismatch | info | timezone_explicit_usage | verify_consistent_jst_utc_labeling | 生成日時（JST）: {generated_at_jst} |
| src/build_ai_feedback.py | 741 | timezone_mismatch | info | timezone_explicit_usage | verify_consistent_jst_utc_labeling | Actions実行時刻（UTC）: {generated_at_utc} |
| src/build_ai_feedback.py | 892 | timezone_mismatch | info | timezone_explicit_usage | verify_consistent_jst_utc_labeling | 生成日時（JST）: {generated_at_jst or generated_at} |
| src/build_ai_feedback.py | 893 | timezone_mismatch | info | timezone_explicit_usage | verify_consistent_jst_utc_labeling | Actions実行時刻（UTC）: {generated_at_utc} |
| src/measure_proposal_impact.py | 0 | missing_target | info | target_file_missing | skip_until_phase_is_available |  |

## 4. 注意事項

- この監査は日付型・時刻型・timezone境界の不安定要素を検出するための品質確認です
- 実売買・発注・XM操作は行いません
- weights.jsonは更新しません
- patchは適用しません
- Google Sheetsへの書き込みは行いません
