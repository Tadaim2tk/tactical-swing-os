# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-07-14 08:05:23 JST
Actions実行時刻（UTC）: 2026-07-13 23:05:23 UTC
対象日: 2026-07-13
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 19.17
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 39.99
- risk_off: 41.67
- dollar: 35.04
- rate: 40.98
- volatility: 51.69
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=1, neutral=8, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 39.99 | 41.67 | 35.04 | 40.98 | 53.33 | 34.24 | 51.69 | 93.86 |
| DXY | 48.92 | 51.31 | 50.06 | 50.33 | 51.55 | 48.91 | 51.69 | 92.78 |
| GOLD | 48.92 | 51.31 | 50.06 | 50.33 | 51.55 | 48.91 | 51.69 | 92.78 |
| NASDAQ | 48.92 | 51.31 | 50.06 | 50.33 | 51.55 | 48.91 | 51.69 | 92.78 |
| SPX | 48.92 | 51.31 | 50.06 | 50.33 | 51.55 | 48.91 | 51.69 | 92.78 |
| US10Y | 48.92 | 51.31 | 50.06 | 50.33 | 51.55 | 48.91 | 51.69 | 92.78 |
| USDJPY | 48.92 | 51.31 | 50.06 | 50.33 | 51.55 | 48.91 | 51.69 | 92.78 |
| VIX | 48.92 | 51.31 | 50.06 | 50.33 | 51.55 | 48.91 | 51.69 | 92.78 |
| WTI | 48.92 | 51.31 | 50.06 | 50.33 | 51.55 | 48.91 | 51.69 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260713_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | momentum_positive|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260713_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260713_GOLD_SHORT_B-Watch | GOLD | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative | conflicted | -19 | GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260713_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | NO_TRADE | momentum_positive|atr_too_high|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260713_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260713_US10Y_NONE_NO_TRADE | US10Y | NONE | NO_TRADE | NO_TRADE | momentum_positive|breakout_up|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260713_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260713_VIX_NONE_NO_TRADE | VIX | NONE | NO_TRADE | NO_TRADE | momentum_negative|rr_too_low|pullback_to_ma20|overextended | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260713_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | NO_TRADE | momentum_negative|rr_too_low|range_middle|overextended | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり
- top_news_drivers: Trump proposes 20% toll on cargo through Strait of Hormuz; restarts Iran blockade, Waller says Fed shouldn't 'fight the last war' on inflation but warns hikes still possible, A July rate hike from the Fed? The odds are rising, Big banks poised to report booming revenue propelled by SpaceX IPO, Iran war volatility, SpaceX’s stock threatens to fall below the IPO price. Do investors face a ‘crisis’ if it does?

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-07-13T23:05:23,2026-07-14 08:05:23 JST,2026-07-13 23:05:23 UTC,2026-07-13,BTC,20260713_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|atr_too_low|rr_too_low,neutral,0,39.99,41.67,35.04,40.98,53.33,34.24,51.69,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-13T23:05:23,2026-07-14 08:05:23 JST,2026-07-13 23:05:23 UTC,2026-07-13,DXY,20260713_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rr_too_low,neutral,0,39.99,41.67,35.04,40.98,53.33,34.24,51.69,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-13T23:05:23,2026-07-14 08:05:23 JST,2026-07-13 23:05:23 UTC,2026-07-13,GOLD,20260713_GOLD_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative,conflicted,-19,39.99,41.67,35.04,40.98,53.33,34.24,51.69,93.86,100.0,market_proxy_plus_news,open_unresolved,,context_warning,GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,GOLD SHORT は市場文脈と衝突。明日はrank/entry条件を慎重化する仮説。,False,sheets_evaluations,False,True
2026-07-13T23:05:23,2026-07-14 08:05:23 JST,2026-07-13 23:05:23 UTC,2026-07-13,NASDAQ,20260713_NASDAQ_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|atr_too_high|rr_too_low,neutral,0,39.99,41.67,35.04,40.98,53.33,34.24,51.69,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,NASDAQ NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-13T23:05:23,2026-07-14 08:05:23 JST,2026-07-13 23:05:23 UTC,2026-07-13,SPX,20260713_SPX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rr_too_low,neutral,0,39.99,41.67,35.04,40.98,53.33,34.24,51.69,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,SPX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-13T23:05:23,2026-07-14 08:05:23 JST,2026-07-13 23:05:23 UTC,2026-07-13,US10Y,20260713_US10Y_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|breakout_up|rr_too_low,neutral,0,39.99,41.67,35.04,40.98,53.33,34.24,51.69,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,US10Y NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-13T23:05:23,2026-07-14 08:05:23 JST,2026-07-13 23:05:23 UTC,2026-07-13,USDJPY,20260713_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low,neutral,0,39.99,41.67,35.04,40.98,53.33,34.24,51.69,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-13T23:05:23,2026-07-14 08:05:23 JST,2026-07-13 23:05:23 UTC,2026-07-13,VIX,20260713_VIX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|rr_too_low|pullback_to_ma20|overextended,neutral,0,39.99,41.67,35.04,40.98,53.33,34.24,51.69,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,VIX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-13T23:05:23,2026-07-14 08:05:23 JST,2026-07-13 23:05:23 UTC,2026-07-13,WTI,20260713_WTI_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|rr_too_low|range_middle|overextended,neutral,0,39.99,41.67,35.04,40.98,53.33,34.24,51.69,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,WTI NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-07-13T23:05:23",
  "generated_at_jst": "2026-07-14 08:05:23 JST",
  "generated_at_utc": "2026-07-13 23:05:23 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-07-13",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 75,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "top_news_drivers": [
    {
      "title": "Trump proposes 20% toll on cargo through Strait of Hormuz; restarts Iran blockade",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/07/13/trump-iran-hormuz-strait-charge-reimburse.html"
    },
    {
      "title": "Waller says Fed shouldn't 'fight the last war' on inflation but warns hikes still possible",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war|inflation_pressure_news_score:inflation",
      "driver_tags": "gold_safe_haven|geopolitical_risk|inflation_pressure",
      "driver_summary_ja": "地政学リスク / インフレ圧力 / 金安全資産需要 / リスクオフ要因 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/07/13/waller-says-fed-shouldnt-fight-the-last-war-on-inflation-but-warns-hikes-still-possible.html"
    },
    {
      "title": "A July rate hike from the Fed? The odds are rising",
      "source": "CNBC Markets",
      "matched_assets": "WTI|US10Y|DXY",
      "matched_rules": "rate_pressure_news_score:rate hike|central_bank_hawkish_score:rate hike",
      "driver_tags": "rate_pressure|central_bank_hawkish",
      "driver_summary_ja": "金利圧力候補 / 中銀タカ派",
      "link": "https://www.cnbc.com/2026/07/13/-a-july-rate-hike-from-the-fed-the-odds-are-rising.html"
    },
    {
      "title": "Big banks poised to report booming revenue propelled by SpaceX IPO, Iran war volatility",
      "source": "CNBC Markets",
      "matched_assets": "SPX|VIX",
      "matched_rules": "risk_on_news_score:rebound|gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "risk_on|gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオン要因 / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/07/13/bank-earnings-jpmorgan-chase-goldman-sachs-bank-of-america.html"
    },
    {
      "title": "SpaceX’s stock threatens to fall below the IPO price. Do investors face a ‘crisis’ if it does?",
      "source": "MarketWatch Top Stories",
      "matched_assets": "",
      "matched_rules": "risk_off_news_score:crisis",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.marketwatch.com/story/spacexs-stock-threatens-to-fall-below-the-ipo-price-do-investors-face-a-crisis-if-it-does-2f330b09?mod=mw_rss_topstories"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 39.99,
      "risk_off_score": 41.67,
      "dollar_strength_score": 35.04,
      "rate_pressure_score": 40.98,
      "gold_safe_haven_score": 53.33,
      "oil_supply_risk_proxy_score": 35.01,
      "crypto_liquidity_score": 34.24,
      "equity_momentum_score": 34.02,
      "volatility_stress_score": 51.69,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 19.17,
      "risk_off_news_score": 19.17,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 19.17,
      "gold_safe_haven_news_score": 57.5,
      "oil_supply_risk_news_score": 0.0,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 57.5,
      "inflation_pressure_news_score": 19.17,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 48.92,
      "risk_off_score": 51.31,
      "dollar_strength_score": 50.06,
      "rate_pressure_score": 50.33,
      "gold_safe_haven_score": 51.55,
      "oil_supply_risk_proxy_score": 50.02,
      "crypto_liquidity_score": 48.91,
      "equity_momentum_score": 48.6,
      "volatility_stress_score": 51.69,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.2375,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 48.92,
      "risk_off_score": 51.31,
      "dollar_strength_score": 50.06,
      "rate_pressure_score": 50.33,
      "gold_safe_haven_score": 51.55,
      "oil_supply_risk_proxy_score": 50.02,
      "crypto_liquidity_score": 48.91,
      "equity_momentum_score": 48.6,
      "volatility_stress_score": 51.69,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1323,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 48.92,
      "risk_off_score": 51.31,
      "dollar_strength_score": 50.06,
      "rate_pressure_score": 50.33,
      "gold_safe_haven_score": 51.55,
      "oil_supply_risk_proxy_score": 50.02,
      "crypto_liquidity_score": 48.91,
      "equity_momentum_score": 48.6,
      "volatility_stress_score": 51.69,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.045,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 48.92,
      "risk_off_score": 51.31,
      "dollar_strength_score": 50.06,
      "rate_pressure_score": 50.33,
      "gold_safe_haven_score": 51.55,
      "oil_supply_risk_proxy_score": 50.02,
      "crypto_liquidity_score": 48.91,
      "equity_momentum_score": 48.6,
      "volatility_stress_score": 51.69,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0298,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 48.92,
      "risk_off_score": 51.31,
      "dollar_strength_score": 50.06,
      "rate_pressure_score": 50.33,
      "gold_safe_haven_score": 51.55,
      "oil_supply_risk_proxy_score": 50.02,
      "crypto_liquidity_score": 48.91,
      "equity_momentum_score": 48.6,
      "volatility_stress_score": 51.69,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.5234,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 48.92,
      "risk_off_score": 51.31,
      "dollar_strength_score": 50.06,
      "rate_pressure_score": 50.33,
      "gold_safe_haven_score": 51.55,
      "oil_supply_risk_proxy_score": 50.02,
      "crypto_liquidity_score": 48.91,
      "equity_momentum_score": 48.6,
      "volatility_stress_score": 51.69,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0099,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 48.92,
      "risk_off_score": 51.31,
      "dollar_strength_score": 50.06,
      "rate_pressure_score": 50.33,
      "gold_safe_haven_score": 51.55,
      "oil_supply_risk_proxy_score": 50.02,
      "crypto_liquidity_score": 48.91,
      "equity_momentum_score": 48.6,
      "volatility_stress_score": 51.69,
      "narrative_confidence": 92.78,
      "asset_change_pct": 5.1471,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 48.92,
      "risk_off_score": 51.31,
      "dollar_strength_score": 50.06,
      "rate_pressure_score": 50.33,
      "gold_safe_haven_score": 51.55,
      "oil_supply_risk_proxy_score": 50.02,
      "crypto_liquidity_score": 48.91,
      "equity_momentum_score": 48.6,
      "volatility_stress_score": 51.69,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1025,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260713_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260713_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260713_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative",
      "narrative_alignment": "conflicted",
      "narrative_alignment_score": -19,
      "narrative_comment": "GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260713_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|atr_too_high|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260713_SPX_NONE_NO_TRADE",
      "asset": "SPX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260713_US10Y_NONE_NO_TRADE",
      "asset": "US10Y",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|breakout_up|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260713_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260713_VIX_NONE_NO_TRADE",
      "asset": "VIX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|rr_too_low|pullback_to_ma20|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260713_WTI_NONE_NO_TRADE",
      "asset": "WTI",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|rr_too_low|range_middle|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
