# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-14 08:05:21 JST
生成日時（UTC）: 2026-07-13 23:05:21 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.85
ニュース市場バイアス: neutral
ニュース矛盾スコア: 19.17
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 19.17
- risk_off_news_score: 19.17
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 19.17
- gold_safe_haven_news_score: 57.5
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 57.5
- inflation_pressure_news_score: 19.17
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 19.17
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Trump proposes 20% toll on cargo through Strait of Hormuz; restarts Iran blockade (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Waller says Fed shouldn't 'fight the last war' on inflation but warns hikes still possible (地政学リスク / インフレ圧力 / 金安全資産需要 / リスクオフ要因 / 金利圧力候補)
- A July rate hike from the Fed? The odds are rising (金利圧力候補 / 中銀タカ派)
- Big banks poised to report booming revenue propelled by SpaceX IPO, Iran war volatility (地政学リスク / リスクオン要因 / 金安全資産需要 / リスクオフ要因)
- SpaceX’s stock threatens to fall below the IPO price. Do investors face a ‘crisis’ if it does? (リスクオフ要因)
