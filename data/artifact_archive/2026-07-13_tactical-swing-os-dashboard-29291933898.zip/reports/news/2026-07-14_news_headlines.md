# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-14 08:05:20 JST
取得日時（UTC）: 2026-07-13 23:05:20 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.85
headline件数: 30

## 見出し

- [CNBC Markets] Trump proposes 20% toll on cargo through Strait of Hormuz; restarts Iran blockade (WTI)
- [CNBC Markets] South Carolina governor taps Lindsey Graham's sister to serve as interim senator (未分類)
- [CNBC Markets] Judge says Trump sued IRS for 'improper purpose'; refers his lawyer to bar (未分類)
- [CNBC Markets] Trump to claim declassified intel reveals 2020 election interference: MS NOW (未分類)
- [CNBC Markets] Chipotle is opening its first restaurant in Mexico (NASDAQ)
- [CNBC Markets] UN maritime agency opposes Hormuz transit fees after Trump demands protection money (未分類)
- [CNBC Markets] Paramount, WBD hit with lawsuit from 12 states, including California, to block merger (未分類)
- [CNBC Markets] The 10 best state economies in America in 2026 (未分類)
- [CNBC Markets] The 10 worst state economies in America in 2026 (未分類)
- [CNBC Markets] Waller says Fed shouldn't 'fight the last war' on inflation but warns hikes still possible (US10Y|DXY)
- [CNBC Markets] 3 things you need to know about cyclospora (未分類)
- [CNBC Markets] Jim Cramer says tech remains the market's best place to find big winners despite recent struggles (SPX|NASDAQ)
- [CNBC Markets] Trump administration urges banks to scrutinize lending to immigrants without work authorization (US10Y|DXY)
- [CNBC Markets] SpaceX stock sinks for a second-straight day, nearing $135 IPO price (NASDAQ)
- [CNBC Markets] A July rate hike from the Fed? The odds are rising (WTI|US10Y|DXY)
- [CNBC Markets] Traders are betting on a comeback quarter for Netflix (BTC|SPX|NASDAQ)
- [CNBC Markets] A toxic stew drags stocks lower as we look at what can get the AI trade back on track (SPX)
- [CNBC Markets] Trump calls for Congress to pass Clarity Act crypto bill to honor Lindsey Graham (BTC)
- [CNBC Markets] Big banks poised to report booming revenue propelled by SpaceX IPO, Iran war volatility (SPX|VIX)
- [CNBC Markets] Meta's Louisiana data center investment to reach $50 billion, aided by generous tax incentives (未分類)
- [CNBC Markets] Kalshi launches 'Pro' product for users trading multiple markets at same time, perpetual futures (未分類)
- [CNBC Markets] Elon Musk and Sam Altman spar on X after Apple files OpenAI lawsuit (未分類)
- [CNBC Markets] AI is changing older workers' careers, research finds — here's how (未分類)
- [CNBC Markets] TSMC, the world's largest contract chipmaker, reports 68% surge in June revenue (SPX|NASDAQ)
- [CNBC Markets] McConnell provides health update after long unexplained absence; says he suffered fall, pneumonia (未分類)
- [CNBC Markets] Chinese EV makers are outpacing U.S. automakers in overseas investments (未分類)
- [MarketWatch Top Stories] I’m 67 with a $140,000 pension. Should I wait until 70 to claim Social Security so my wife gets more? (未分類)
- [MarketWatch Top Stories] The U.S. is maxing out its strategic oil reserves as Trump vows to control the Strait of Hormuz (WTI)
- [MarketWatch Top Stories] Why a borrowing binge by investors is a warning sign for the stock market (SPX)
- [MarketWatch Top Stories] SpaceX’s stock threatens to fall below the IPO price. Do investors face a ‘crisis’ if it does? (未分類)
