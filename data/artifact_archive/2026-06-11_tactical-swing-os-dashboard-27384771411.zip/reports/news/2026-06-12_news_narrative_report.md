# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-12 08:47:36 JST
生成日時（UTC）: 2026-06-11 23:47:36 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.31
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: geopolitical_risk
日本語要約: 地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 38.33
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 57.5
- oil_supply_risk_news_score: 38.33
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 95.83
- inflation_pressure_news_score: 19.17
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 19.17
- news_confidence: 100.0

## Top News Drivers

- From startup to $1.8 trillion: The investors who took a chance on SpaceX now reap the rewards (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Trump claims Iran war settled 'subject to finalization,' expects signing in 'next few days' (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Warren questions SpaceX IPO oversight in new letter to stock indexes (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Gold slumps to 6-month low even as inflation fears rise. Here's why bullion is out of favor (インフレ圧力 / リスクオフ要因 / 金利圧力候補)
- Oil tanker CEO sees Hormuz ship traffic quickly increasing if U.S. and Iran reach a deal (原油供給リスク / 中銀ハト派)
- Iran threatens Elon Musk's companies in Middle East: Iranian state media (地政学リスク / 原油供給リスク / リスクオフ要因)
