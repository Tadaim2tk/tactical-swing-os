# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-12 08:47:34 JST
取得日時（UTC）: 2026-06-11 23:47:34 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.31
headline件数: 30

## 見出し

- [CNBC Markets] SpaceX raising $75 billion in record-setting IPO as Nasdaq debut awaits (SPX|NASDAQ)
- [CNBC Markets] From startup to $1.8 trillion: The investors who took a chance on SpaceX now reap the rewards (未分類)
- [CNBC Markets] SpaceX cuts retail IPO allocation to low 20% range, source says (未分類)
- [CNBC Markets] Trump claims Iran war settled 'subject to finalization,' expects signing in 'next few days' (WTI)
- [CNBC Markets] Trump picks former SEC Chairman Jay Clayton as national intelligence director (未分類)
- [CNBC Markets] Warren questions SpaceX IPO oversight in new letter to stock indexes (未分類)
- [CNBC Markets] What energy insiders in DC are saying about oil prices and a possible Iran deal (WTI|SPX)
- [CNBC Markets] Gold slumps to 6-month low even as inflation fears rise. Here's why bullion is out of favor (GOLD|NASDAQ|VIX)
- [CNBC Markets] SpaceX IPO won’t ‘break’ the bull market. But investors are worried about what comes next (SPX)
- [CNBC Markets] SpaceX soon-to-be millionaires are set to spend big on luxury homes, watches and private jet travel (SPX)
- [CNBC Markets] Oil tanker CEO sees Hormuz ship traffic quickly increasing if U.S. and Iran reach a deal (WTI)
- [CNBC Markets] Pirro's losses in Fed investigation should stay on the books, judge rules (US10Y|DXY)
- [CNBC Markets] Ahead of SpaceX IPO, Elon Musk addresses ASML employees as part of push into chip manufacturing (NASDAQ)
- [CNBC Markets] Ex-Andreessen Horowitz partner slams his old firm, other VCs for 'political infiltration' around AI (未分類)
- [CNBC Markets] Iran threatens Elon Musk's companies in Middle East: Iranian state media (未分類)
- [CNBC Markets] Nearly 7 million student loan borrowers remain in defunct Biden-era payment plan: Trump official (未分類)
- [CNBC Markets] Healthy Returns: CVS Health executives on reducing healthcare's biggest pain points (NASDAQ)
- [CNBC Markets] Eaton moves one step closer to becoming a cleaner bet on the AI boom (未分類)
- [CNBC Markets] SpaceX to close above $2 trillion market cap on its debut, prediction market traders say (未分類)
- [CNBC Markets] OpenAI to acquire Ona to support its AI coding assistant, Codex (NASDAQ)
- [CNBC Markets] Coinbase launches tool to let AI agents manage trading and payments (BTC)
- [CNBC Markets] Waymo launches premier subscription tier for $29.99 a month, starting in select cities (未分類)
- [CNBC Markets] Trump administration appeals ruling blocking $100,000 H-1B fee (未分類)
- [CNBC Markets] Oracle shares tumble 11% on increased capital raise, cash concerns (SPX|NASDAQ)
- [CNBC Markets] Foreign surveillance program to expire Friday after House blocks extension (未分類)
- [CNBC Markets] Elections advertising spend for 2026 expected to reach record high, outpacing presidential years (未分類)
- [CNBC Markets] Some Pentagon workers ordered to shelter in place as air quality issue is investigated (未分類)
- [CNBC Markets] Wholesale prices rose 1.1% in May, more than expected, on surge in energy (未分類)
- [CNBC Markets] Baldwin, Khanna propose new direct foreign investment review board to probe Trump's deals (未分類)
- [CNBC Markets] DoorDash lets customers use photos, prompts to order food and book reservations in latest AI push (未分類)
