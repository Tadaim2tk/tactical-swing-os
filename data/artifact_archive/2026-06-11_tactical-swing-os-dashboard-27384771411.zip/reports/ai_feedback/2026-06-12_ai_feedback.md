# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-12 08:47:36 JST
Actions実行時刻（UTC）: 2026-06-11 23:47:36 UTC
対象日: 2026-06-12
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 33.98
- risk_off: 48.23
- dollar: 34.95
- rate: 34.3
- volatility: 52.79
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=1, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 33.98 | 48.23 | 34.95 | 34.3 | 60.28 | 34.17 | 52.79 | 100.0 |
| BTC | 48.55 | 52.48 | 49.93 | 49.0 | 53.26 | 48.81 | 52.79 | 100.0 |
| DXY | 48.55 | 52.48 | 49.93 | 49.0 | 53.26 | 48.81 | 52.79 | 100.0 |
| GOLD | 48.55 | 52.48 | 49.93 | 49.0 | 53.26 | 48.81 | 52.79 | 100.0 |
| NASDAQ | 48.55 | 52.48 | 49.93 | 49.0 | 53.26 | 48.81 | 52.79 | 100.0 |
| SPX | 48.55 | 52.48 | 49.93 | 49.0 | 53.26 | 48.81 | 52.79 | 100.0 |
| US10Y | 48.55 | 52.48 | 49.93 | 49.0 | 53.26 | 48.81 | 52.79 | 100.0 |
| USDJPY | 48.55 | 52.48 | 49.93 | 49.0 | 53.26 | 48.81 | 52.79 | 100.0 |
| VIX | 48.55 | 52.48 | 49.93 | 49.0 | 53.26 | 48.81 | 52.79 | 100.0 |
| WTI | 48.55 | 52.48 | 49.93 | 49.0 | 53.26 | 48.81 | 52.79 | 100.0 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260612_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- top_news_drivers: From startup to $1.8 trillion: The investors who took a chance on SpaceX now reap the rewards, Trump claims Iran war settled 'subject to finalization,' expects signing in 'next few days', Warren questions SpaceX IPO oversight in new letter to stock indexes, Gold slumps to 6-month low even as inflation fears rise. Here's why bullion is out of favor, Oil tanker CEO sees Hormuz ship traffic quickly increasing if U.S. and Iran reach a deal

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-11T23:47:36,2026-06-12 08:47:36 JST,2026-06-11 23:47:36 UTC,2026-06-12,USDJPY,20260612_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low,neutral,0,33.98,48.23,34.95,34.3,60.28,34.17,52.79,100.0,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-11T23:47:36",
  "generated_at_jst": "2026-06-12 08:47:36 JST",
  "generated_at_utc": "2026-06-11 23:47:36 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-12",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 82,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
  "top_news_drivers": [
    {
      "title": "From startup to $1.8 trillion: The investors who took a chance on SpaceX now reap the rewards",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/11/spacex-investors-reap-rewards-1-8-trillion-valuation.html"
    },
    {
      "title": "Trump claims Iran war settled 'subject to finalization,' expects signing in 'next few days'",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war|geopolitical_risk_news_score:attack",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/11/trump-iran-strikes-deal.html"
    },
    {
      "title": "Warren questions SpaceX IPO oversight in new letter to stock indexes",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/11/warren-spacex-ipo-exchanges.html"
    },
    {
      "title": "Gold slumps to 6-month low even as inflation fears rise. Here's why bullion is out of favor",
      "source": "CNBC Markets",
      "matched_assets": "GOLD|NASDAQ|VIX",
      "matched_rules": "risk_off_news_score:slump|risk_off_news_score:fear|inflation_pressure_news_score:inflation",
      "driver_tags": "risk_off|inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / リスクオフ要因 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/06/11/gold-slumps-to-6-month-low-even-as-inflation-fears-rise-heres-why-bullion-is-out-of-favor.html"
    },
    {
      "title": "Oil tanker CEO sees Hormuz ship traffic quickly increasing if U.S. and Iran reach a deal",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "oil_supply_risk_news_score:tanker|central_bank_dovish_score:easing",
      "driver_tags": "oil_supply_risk|central_bank_dovish",
      "driver_summary_ja": "原油供給リスク / 中銀ハト派",
      "link": "https://www.cnbc.com/2026/06/11/iran-strait-hormuz-oil-tanker-traffic-frontline.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 33.98,
      "risk_off_score": 48.23,
      "dollar_strength_score": 34.95,
      "rate_pressure_score": 34.3,
      "gold_safe_haven_score": 60.28,
      "oil_supply_risk_proxy_score": 46.23,
      "crypto_liquidity_score": 34.17,
      "equity_momentum_score": 33.14,
      "volatility_stress_score": 52.79,
      "narrative_confidence": 100.0,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 0.0,
      "risk_off_news_score": 38.33,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 57.5,
      "oil_supply_risk_news_score": 38.33,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 95.83,
      "inflation_pressure_news_score": 19.17,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "BTC",
      "risk_on_score": 48.55,
      "risk_off_score": 52.48,
      "dollar_strength_score": 49.93,
      "rate_pressure_score": 49.0,
      "gold_safe_haven_score": 53.26,
      "oil_supply_risk_proxy_score": 49.61,
      "crypto_liquidity_score": 48.81,
      "equity_momentum_score": 47.34,
      "volatility_stress_score": 52.79,
      "narrative_confidence": 100.0,
      "asset_change_pct": 3.0744,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "DXY",
      "risk_on_score": 48.55,
      "risk_off_score": 52.48,
      "dollar_strength_score": 49.93,
      "rate_pressure_score": 49.0,
      "gold_safe_haven_score": 53.26,
      "oil_supply_risk_proxy_score": 49.61,
      "crypto_liquidity_score": 48.81,
      "equity_momentum_score": 47.34,
      "volatility_stress_score": 52.79,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.06,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 48.55,
      "risk_off_score": 52.48,
      "dollar_strength_score": 49.93,
      "rate_pressure_score": 49.0,
      "gold_safe_haven_score": 53.26,
      "oil_supply_risk_proxy_score": 49.61,
      "crypto_liquidity_score": 48.81,
      "equity_momentum_score": 47.34,
      "volatility_stress_score": 52.79,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.2692,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 48.55,
      "risk_off_score": 52.48,
      "dollar_strength_score": 49.93,
      "rate_pressure_score": 49.0,
      "gold_safe_haven_score": 53.26,
      "oil_supply_risk_proxy_score": 49.61,
      "crypto_liquidity_score": 48.81,
      "equity_momentum_score": 47.34,
      "volatility_stress_score": 52.79,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.2682,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 48.55,
      "risk_off_score": 52.48,
      "dollar_strength_score": 49.93,
      "rate_pressure_score": 49.0,
      "gold_safe_haven_score": 53.26,
      "oil_supply_risk_proxy_score": 49.61,
      "crypto_liquidity_score": 48.81,
      "equity_momentum_score": 47.34,
      "volatility_stress_score": 52.79,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.1521,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 48.55,
      "risk_off_score": 52.48,
      "dollar_strength_score": 49.93,
      "rate_pressure_score": 49.0,
      "gold_safe_haven_score": 53.26,
      "oil_supply_risk_proxy_score": 49.61,
      "crypto_liquidity_score": 48.81,
      "equity_momentum_score": 47.34,
      "volatility_stress_score": 52.79,
      "narrative_confidence": 100.0,
      "asset_change_pct": -1.2829,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 48.55,
      "risk_off_score": 52.48,
      "dollar_strength_score": 49.93,
      "rate_pressure_score": 49.0,
      "gold_safe_haven_score": 53.26,
      "oil_supply_risk_proxy_score": 49.61,
      "crypto_liquidity_score": 48.81,
      "equity_momentum_score": 47.34,
      "volatility_stress_score": 52.79,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.0582,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 48.55,
      "risk_off_score": 52.48,
      "dollar_strength_score": 49.93,
      "rate_pressure_score": 49.0,
      "gold_safe_haven_score": 53.26,
      "oil_supply_risk_proxy_score": 49.61,
      "crypto_liquidity_score": 48.81,
      "equity_momentum_score": 47.34,
      "volatility_stress_score": 52.79,
      "narrative_confidence": 100.0,
      "asset_change_pct": 10.5473,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 48.55,
      "risk_off_score": 52.48,
      "dollar_strength_score": 49.93,
      "rate_pressure_score": 49.0,
      "gold_safe_haven_score": 53.26,
      "oil_supply_risk_proxy_score": 49.61,
      "crypto_liquidity_score": 48.81,
      "equity_momentum_score": 47.34,
      "volatility_stress_score": 52.79,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.958,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260612_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
