# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-16 07:49:37 JST
Actions実行時刻（UTC）: 2026-06-15 22:49:37 UTC
対象日: 2026-06-14
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 19.17
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 42.17
- risk_off: 44.88
- dollar: 34.86
- rate: 40.72
- volatility: 46.81
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=7, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 42.17 | 44.88 | 34.86 | 40.72 | 63.16 | 36.39 | 46.81 | 93.86 |
| DXY | 52.03 | 47.69 | 49.8 | 49.95 | 47.37 | 51.99 | 46.81 | 92.78 |
| GOLD | 52.03 | 47.69 | 49.8 | 49.95 | 47.37 | 51.99 | 46.81 | 92.78 |
| NASDAQ | 52.03 | 47.69 | 49.8 | 49.95 | 47.37 | 51.99 | 46.81 | 92.78 |
| SPX | 52.03 | 47.69 | 49.8 | 49.95 | 47.37 | 51.99 | 46.81 | 92.78 |
| US10Y | 52.03 | 47.69 | 49.8 | 49.95 | 47.37 | 51.99 | 46.81 | 92.78 |
| USDJPY | 52.03 | 47.69 | 49.8 | 49.95 | 47.37 | 51.99 | 46.81 | 92.78 |
| VIX | 52.03 | 47.69 | 49.8 | 49.95 | 47.37 | 51.99 | 46.81 | 92.78 |
| WTI | 52.03 | 47.69 | 49.8 | 49.95 | 47.37 | 51.99 | 46.81 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260614_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260614_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rr_too_low|range_middle|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260614_GOLD_NONE_NO_TRADE | GOLD | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rr_too_low|range_middle | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260614_NASDAQ_LONG_A-Pullback | NASDAQ | LONG | B | WATCH | trend_up|ma_alignment_bull|momentum_positive|atr_too_high|pullback_to_ma20 | neutral | -3 | NASDAQは株式モメンタム、金利圧力、ボラティリティで評価しました。 地政学リスクが高く、BTC/NASDAQ LONGは慎重化が必要です。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260614_SPX_LONG_A-Pullback | SPX | LONG | B | WATCH | trend_up|ma_alignment_bull|pullback_to_ma20 | neutral | -3 | SPXは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260614_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260614_WTI_SHORT_B-Watch | WTI | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative|breakout_down|overextended | neutral | -14 | WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- top_news_drivers: The Iran deal came just in time as Strategic Petroleum Reserve hits lowest level since 1983, Trump trusts Fed Chair Kevin Warsh. It matters for more than interest rates, How the Strait of Hormuz reopening could unfold if the U.S.-Iran deal is implemented, CFTC chair Selig defends decision to approve ‘perps’ in U.S., Warsh's Fed is likely to hold rates steady — what the leadership change could mean for your money

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-15T22:49:37,2026-06-16 07:49:37 JST,2026-06-15 22:49:37 UTC,2026-06-14,BTC,20260614_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rr_too_low,neutral,0,42.17,44.88,34.86,40.72,63.16,36.39,46.81,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-15T22:49:37,2026-06-16 07:49:37 JST,2026-06-15 22:49:37 UTC,2026-06-14,DXY,20260614_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rr_too_low|range_middle|pullback_to_ma20,neutral,0,42.17,44.88,34.86,40.72,63.16,36.39,46.81,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-15T22:49:37,2026-06-16 07:49:37 JST,2026-06-15 22:49:37 UTC,2026-06-14,GOLD,20260614_GOLD_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rr_too_low|range_middle,neutral,0,42.17,44.88,34.86,40.72,63.16,36.39,46.81,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。,GOLD NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-15T22:49:37,2026-06-16 07:49:37 JST,2026-06-15 22:49:37 UTC,2026-06-14,NASDAQ,20260614_NASDAQ_LONG_A-Pullback,LONG,B,WATCH,trend_up|ma_alignment_bull|momentum_positive|atr_too_high|pullback_to_ma20,neutral,-3,42.17,44.88,34.86,40.72,63.16,36.39,46.81,93.86,100.0,market_proxy_plus_news,,,context_neutral,NASDAQは株式モメンタム、金利圧力、ボラティリティで評価しました。 地政学リスクが高く、BTC/NASDAQ LONGは慎重化が必要です。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。,NASDAQ LONG は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-15T22:49:37,2026-06-16 07:49:37 JST,2026-06-15 22:49:37 UTC,2026-06-14,SPX,20260614_SPX_LONG_A-Pullback,LONG,B,WATCH,trend_up|ma_alignment_bull|pullback_to_ma20,neutral,-3,42.17,44.88,34.86,40.72,63.16,36.39,46.81,93.86,100.0,market_proxy_plus_news,,,context_neutral,SPXは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。,SPX LONG は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-15T22:49:37,2026-06-16 07:49:37 JST,2026-06-15 22:49:37 UTC,2026-06-14,USDJPY,20260614_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low,neutral,0,42.17,44.88,34.86,40.72,63.16,36.39,46.81,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-15T22:49:37,2026-06-16 07:49:37 JST,2026-06-15 22:49:37 UTC,2026-06-14,WTI,20260614_WTI_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative|breakout_down|overextended,neutral,-14,42.17,44.88,34.86,40.72,63.16,36.39,46.81,93.86,100.0,market_proxy_plus_news,,,context_neutral,WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。,WTI SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-15T22:49:37",
  "generated_at_jst": "2026-06-16 07:49:37 JST",
  "generated_at_utc": "2026-06-15 22:49:37 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-14",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
  "top_news_drivers": [
    {
      "title": "The Iran deal came just in time as Strategic Petroleum Reserve hits lowest level since 1983",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "gold_safe_haven_news_score:war|oil_supply_risk_news_score:supply disruption|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|oil_supply_risk|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/15/iran-deal-came-in-time-as-strategic-petroleum-reserve-hits-lowest-level-since-1983.html"
    },
    {
      "title": "Trump trusts Fed Chair Kevin Warsh. It matters for more than interest rates",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/15/trump-warsh-fed-reshape.html"
    },
    {
      "title": "How the Strait of Hormuz reopening could unfold if the U.S.-Iran deal is implemented",
      "source": "CNBC Markets",
      "matched_assets": "BTC|WTI",
      "matched_rules": "gold_safe_haven_news_score:war|oil_supply_risk_news_score:tanker|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|oil_supply_risk|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/15/oil-tanker-strait-hormuz-traffic-us-iran-deal.html"
    },
    {
      "title": "CFTC chair Selig defends decision to approve ‘perps’ in U.S.",
      "source": "CNBC Markets",
      "matched_assets": "VIX",
      "matched_rules": "risk_off_news_score:fear",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/15/cftc-chair-selig-defends-decision-to-approve-perps-in-us.html"
    },
    {
      "title": "Warsh's Fed is likely to hold rates steady — what the leadership change could mean for your money",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/15/warsh-fed-interest-rates.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 42.17,
      "risk_off_score": 44.88,
      "dollar_strength_score": 34.86,
      "rate_pressure_score": 40.72,
      "gold_safe_haven_score": 63.16,
      "oil_supply_risk_proxy_score": 46.44,
      "crypto_liquidity_score": 36.39,
      "equity_momentum_score": 36.92,
      "volatility_stress_score": 46.81,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 19.17,
      "risk_off_news_score": 38.33,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 19.17,
      "gold_safe_haven_news_score": 100.0,
      "oil_supply_risk_news_score": 38.33,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 100.0,
      "inflation_pressure_news_score": 19.17,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 52.03,
      "risk_off_score": 47.69,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.95,
      "gold_safe_haven_score": 47.37,
      "oil_supply_risk_proxy_score": 49.92,
      "crypto_liquidity_score": 51.99,
      "equity_momentum_score": 52.74,
      "volatility_stress_score": 46.81,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0653,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 52.03,
      "risk_off_score": 47.69,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.95,
      "gold_safe_haven_score": 47.37,
      "oil_supply_risk_proxy_score": 49.92,
      "crypto_liquidity_score": 51.99,
      "equity_momentum_score": 52.74,
      "volatility_stress_score": 46.81,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.5129,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 52.03,
      "risk_off_score": 47.69,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.95,
      "gold_safe_haven_score": 47.37,
      "oil_supply_risk_proxy_score": 49.92,
      "crypto_liquidity_score": 51.99,
      "equity_momentum_score": 52.74,
      "volatility_stress_score": 46.81,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.4514,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 52.03,
      "risk_off_score": 47.69,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.95,
      "gold_safe_haven_score": 47.37,
      "oil_supply_risk_proxy_score": 49.92,
      "crypto_liquidity_score": 51.99,
      "equity_momentum_score": 52.74,
      "volatility_stress_score": 46.81,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1939,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 52.03,
      "risk_off_score": 47.69,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.95,
      "gold_safe_haven_score": 47.37,
      "oil_supply_risk_proxy_score": 49.92,
      "crypto_liquidity_score": 51.99,
      "equity_momentum_score": 52.74,
      "volatility_stress_score": 46.81,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.313,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 52.03,
      "risk_off_score": 47.69,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.95,
      "gold_safe_haven_score": 47.37,
      "oil_supply_risk_proxy_score": 49.92,
      "crypto_liquidity_score": 51.99,
      "equity_momentum_score": 52.74,
      "volatility_stress_score": 46.81,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1586,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 52.03,
      "risk_off_score": 47.69,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.95,
      "gold_safe_haven_score": 47.37,
      "oil_supply_risk_proxy_score": 49.92,
      "crypto_liquidity_score": 51.99,
      "equity_momentum_score": 52.74,
      "volatility_stress_score": 46.81,
      "narrative_confidence": 92.78,
      "asset_change_pct": -9.3798,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 52.03,
      "risk_off_score": 47.69,
      "dollar_strength_score": 49.8,
      "rate_pressure_score": 49.95,
      "gold_safe_haven_score": 47.37,
      "oil_supply_risk_proxy_score": 49.92,
      "crypto_liquidity_score": 51.99,
      "equity_momentum_score": 52.74,
      "volatility_stress_score": 46.81,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1843,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260614_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260614_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rr_too_low|range_middle|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260614_GOLD_NONE_NO_TRADE",
      "asset": "GOLD",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rr_too_low|range_middle",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260614_NASDAQ_LONG_A-Pullback",
      "asset": "NASDAQ",
      "side": "LONG",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_high|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": -3,
      "narrative_comment": "NASDAQは株式モメンタム、金利圧力、ボラティリティで評価しました。 地政学リスクが高く、BTC/NASDAQ LONGは慎重化が必要です。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260614_SPX_LONG_A-Pullback",
      "asset": "SPX",
      "side": "LONG",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_up|ma_alignment_bull|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": -3,
      "narrative_comment": "SPXは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260614_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260614_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|breakout_down|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": -14,
      "narrative_comment": "WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
