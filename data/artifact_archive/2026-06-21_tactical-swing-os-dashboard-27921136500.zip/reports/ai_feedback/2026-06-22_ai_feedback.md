# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-22 08:37:49 JST
Actions実行時刻（UTC）: 2026-06-21 23:37:49 UTC
対象日: 2026-06-22
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立
- ニュースモード: ニュースのリスク方向は中立
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 35.2
- risk_off: 46.29
- dollar: 35.0
- rate: 34.96
- volatility: 49.52
- news_confidence: 96.0
- シグナル整合性: aligned=0, conflicted=0, neutral=1, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 35.2 | 46.29 | 35.0 | 34.96 | 39.33 | 35.21 | 49.52 | 93.26 |
| DXY | 50.29 | 49.67 | 50.0 | 49.94 | 49.6 | 50.3 | 49.52 | 92.78 |
| GOLD | 50.29 | 49.67 | 50.0 | 49.94 | 49.6 | 50.3 | 49.52 | 92.78 |
| NASDAQ | 50.29 | 49.67 | 50.0 | 49.94 | 49.6 | 50.3 | 49.52 | 92.78 |
| SPX | 50.29 | 49.67 | 50.0 | 49.94 | 49.6 | 50.3 | 49.52 | 92.78 |
| US10Y | 50.29 | 49.67 | 50.0 | 49.94 | 49.6 | 50.3 | 49.52 | 92.78 |
| USDJPY | 50.29 | 49.67 | 50.0 | 49.94 | 49.6 | 50.3 | 49.52 | 92.78 |
| VIX | 50.29 | 49.67 | 50.0 | 49.94 | 49.6 | 50.3 | 49.52 | 92.78 |
| WTI | 50.29 | 49.67 | 50.0 | 49.94 | 49.6 | 50.3 | 49.52 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260622_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立
- top_news_drivers: The best parents and leaders use a 3-step formula to help people handle uncertainty, says Dr. Becky Kennedy, The loneliness crisis has gotten so bad that lawmakers are ready to spend millions of dollars to fight it, Russia stocks lower at close of trade; MOEX Russia Index unchanged

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-21T23:37:49,2026-06-22 08:37:49 JST,2026-06-21 23:37:49 UTC,2026-06-22,USDJPY,20260622_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,35.2,46.29,35.0,34.96,39.33,35.21,49.52,93.26,96.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-21T23:37:49",
  "generated_at_jst": "2026-06-22 08:37:49 JST",
  "generated_at_utc": "2026-06-21 23:37:49 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-22",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立",
  "top_news_drivers": [
    {
      "title": "The best parents and leaders use a 3-step formula to help people handle uncertainty, says Dr. Becky Kennedy",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "risk_off_news_score:uncertainty",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/21/use-a-3-step-formula-to-help-people-handle-uncertainty-dr-becky-kennedy.html"
    },
    {
      "title": "The loneliness crisis has gotten so bad that lawmakers are ready to spend millions of dollars to fight it",
      "source": "MarketWatch Top Stories",
      "matched_assets": "USDJPY|DXY",
      "matched_rules": "risk_off_news_score:crisis",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.marketwatch.com/story/the-loneliness-crisis-has-gotten-so-bad-that-lawmakers-are-ready-to-spend-millions-of-dollars-to-fight-it-f7e7c7b7?mod=mw_rss_topstories"
    },
    {
      "title": "Russia stocks lower at close of trade; MOEX Russia Index unchanged",
      "source": "Investing.com Commodities",
      "matched_assets": "SPX",
      "matched_rules": "geopolitical_risk_news_score:russia",
      "driver_tags": "geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオフ要因",
      "link": "https://www.investing.com/news/stock-market-news/russia-stocks-lower-at-close-of-trade-moex-russia-index-unchanged-4751686"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 35.2,
      "risk_off_score": 46.29,
      "dollar_strength_score": 35.0,
      "rate_pressure_score": 34.96,
      "gold_safe_haven_score": 39.33,
      "oil_supply_risk_proxy_score": 34.74,
      "crypto_liquidity_score": 35.21,
      "equity_momentum_score": 35.27,
      "volatility_stress_score": 49.52,
      "narrative_confidence": 93.26,
      "asset_change_pct": null,
      "headline_count": 29.0,
      "risk_on_news_score": 0.0,
      "risk_off_news_score": 38.41,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 0.0,
      "oil_supply_risk_news_score": 0.0,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 19.21,
      "inflation_pressure_news_score": 0.0,
      "recession_risk_news_score": 0.0,
      "news_confidence": 96.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 50.29,
      "risk_off_score": 49.67,
      "dollar_strength_score": 50.0,
      "rate_pressure_score": 49.94,
      "gold_safe_haven_score": 49.6,
      "oil_supply_risk_proxy_score": 49.63,
      "crypto_liquidity_score": 50.3,
      "equity_momentum_score": 50.39,
      "volatility_stress_score": 49.52,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0079,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 50.29,
      "risk_off_score": 49.67,
      "dollar_strength_score": 50.0,
      "rate_pressure_score": 49.94,
      "gold_safe_haven_score": 49.6,
      "oil_supply_risk_proxy_score": 49.63,
      "crypto_liquidity_score": 50.3,
      "equity_momentum_score": 50.39,
      "volatility_stress_score": 49.52,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1705,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 50.29,
      "risk_off_score": 49.67,
      "dollar_strength_score": 50.0,
      "rate_pressure_score": 49.94,
      "gold_safe_haven_score": 49.6,
      "oil_supply_risk_proxy_score": 49.63,
      "crypto_liquidity_score": 50.3,
      "equity_momentum_score": 50.39,
      "volatility_stress_score": 49.52,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0327,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 50.29,
      "risk_off_score": 49.67,
      "dollar_strength_score": 50.0,
      "rate_pressure_score": 49.94,
      "gold_safe_haven_score": 49.6,
      "oil_supply_risk_proxy_score": 49.63,
      "crypto_liquidity_score": 50.3,
      "equity_momentum_score": 50.39,
      "volatility_stress_score": 49.52,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0066,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 50.29,
      "risk_off_score": 49.67,
      "dollar_strength_score": 50.0,
      "rate_pressure_score": 49.94,
      "gold_safe_haven_score": 49.6,
      "oil_supply_risk_proxy_score": 49.63,
      "crypto_liquidity_score": 50.3,
      "equity_momentum_score": 50.39,
      "volatility_stress_score": 49.52,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0449,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 50.29,
      "risk_off_score": 49.67,
      "dollar_strength_score": 50.0,
      "rate_pressure_score": 49.94,
      "gold_safe_haven_score": 49.6,
      "oil_supply_risk_proxy_score": 49.63,
      "crypto_liquidity_score": 50.3,
      "equity_momentum_score": 50.39,
      "volatility_stress_score": 49.52,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0967,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 50.29,
      "risk_off_score": 49.67,
      "dollar_strength_score": 50.0,
      "rate_pressure_score": 49.94,
      "gold_safe_haven_score": 49.6,
      "oil_supply_risk_proxy_score": 49.63,
      "crypto_liquidity_score": 50.3,
      "equity_momentum_score": 50.39,
      "volatility_stress_score": 49.52,
      "narrative_confidence": 92.78,
      "asset_change_pct": -1.5258,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 50.29,
      "risk_off_score": 49.67,
      "dollar_strength_score": 50.0,
      "rate_pressure_score": 49.94,
      "gold_safe_haven_score": 49.6,
      "oil_supply_risk_proxy_score": 49.63,
      "crypto_liquidity_score": 50.3,
      "equity_momentum_score": 50.39,
      "volatility_stress_score": 49.52,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.9231,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260622_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
