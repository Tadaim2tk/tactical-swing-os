# Weights Patch Proposal

## 1. 概要

- 生成日時JST: 2026-06-23 05:26:43 JST
- audit_status: blocked
- 入力提案件数: 47
- patch候補数: 0
- 除外件数: 47
- increase件数: 0
- decrease件数: 0
- add件数: 0
- update件数: 0
- weights.json更新: false
- patch適用: false
- 人間承認: 必須

## 2. patch候補

該当なし

## 3. 除外された提案

| proposal_id | category | target | exclusion_reason | audit_result | sample_count | confidence_level | proposal_direction | proposed_delta |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260623_narrative_crypto_liquidity_narrative_weight_adjustment | narrative | crypto_liquidity | audit_status_blocked | passed | 52 | high | decrease | -0.0413 |
| 20260623_narrative_dollar_strength_narrative_weight_adjustment | narrative | dollar_strength | audit_status_blocked | passed | 52 | high | decrease | -0.0413 |
| 20260623_narrative_geopolitical_risk_narrative_weight_adjustment | narrative | geopolitical_risk | audit_status_blocked | passed | 52 | high | decrease | -0.0413 |
| 20260623_narrative_oil_supply_risk_narrative_weight_adjustment | narrative | oil_supply_risk | audit_status_blocked | passed | 52 | high | decrease | -0.0413 |
| 20260623_narrative_rate_pressure_narrative_weight_adjustment | narrative | rate_pressure | audit_status_blocked | passed | 52 | high | decrease | -0.0413 |
| 20260623_narrative_risk_off_narrative_weight_adjustment | narrative | risk_off | audit_status_blocked | passed | 52 | high | decrease | -0.0413 |
| 20260623_narrative_risk_on_narrative_weight_adjustment | narrative | risk_on | audit_status_blocked | passed | 52 | high | decrease | -0.0413 |
| 20260623_rank_B_rank_confidence_adjustment | rank | B | audit_status_blocked | passed | 44 | high | decrease | -0.0409 |
| 20260623_reason_code_ma_alignment_bear_reason_code_weight_adjustment | reason_code | ma_alignment_bear | audit_status_blocked | blocked | 23 | high | decrease | -0.0456 |
| 20260623_reason_code_momentum_negative_reason_code_weight_adjustment | reason_code | momentum_negative | audit_status_blocked | blocked | 21 | high | decrease | -0.0459 |
| 20260623_reason_code_trend_down_reason_code_weight_adjustment | reason_code | trend_down | audit_status_blocked | blocked | 23 | high | decrease | -0.0456 |
| 20260623_side_LONG_side_bias_adjustment | side | LONG | audit_status_blocked | blocked | 22 | high | decrease | -0.0432 |
| 20260623_side_SHORT_side_bias_adjustment | side | SHORT | audit_status_blocked | blocked | 25 | high | decrease | -0.0453 |
| 20260623_type_B-Watch_setup_type_weight_adjustment | type | B-Watch | audit_status_blocked | blocked | 29 | high | decrease | -0.0422 |
| 20260623_asset_BTC_asset_weight_adjustment | asset | BTC | audit_status_blocked | blocked | 5 | low | decrease | -0.022 |
| 20260623_asset_GOLD_asset_weight_adjustment | asset | GOLD | audit_status_blocked | blocked | 8 | low | decrease | -0.0222 |
| 20260623_asset_NASDAQ_asset_weight_adjustment | asset | NASDAQ | audit_status_blocked | blocked | 8 | low | decrease | -0.0159 |
| 20260623_asset_SPX_asset_weight_adjustment | asset | SPX | audit_status_blocked | blocked | 8 | low | decrease | -0.016 |
| 20260623_asset_VIX_asset_weight_adjustment | asset | VIX | audit_status_blocked | blocked | 5 | low | decrease | -0.0154 |
| 20260623_asset_WTI_asset_weight_adjustment | asset | WTI | audit_status_blocked | blocked | 10 | medium | decrease | -0.0288 |
| 20260623_rank_NO_TRADE_rank_confidence_adjustment | rank | NO_TRADE | audit_status_blocked | blocked | 5 | low | decrease | -0.015 |
| 20260623_reason_code_atr_too_high_reason_code_weight_adjustment | reason_code | atr_too_high | audit_status_blocked | blocked | 11 | medium | decrease | -0.0253 |
| 20260623_reason_code_breakout_down_reason_code_weight_adjustment | reason_code | breakout_down | audit_status_blocked | blocked | 8 | low | decrease | -0.017 |
| 20260623_reason_code_ma_alignment_bull_reason_code_weight_adjustment | reason_code | ma_alignment_bull | audit_status_blocked | blocked | 19 | medium | decrease | -0.0256 |
| 20260623_reason_code_momentum_positive_reason_code_weight_adjustment | reason_code | momentum_positive | audit_status_blocked | blocked | 18 | medium | decrease | -0.0255 |
| 20260623_reason_code_overextended_reason_code_weight_adjustment | reason_code | overextended | audit_status_blocked | blocked | 12 | medium | decrease | -0.0253 |
| 20260623_reason_code_pullback_to_ma20_reason_code_weight_adjustment | reason_code | pullback_to_ma20 | audit_status_blocked | blocked | 6 | low | decrease | -0.018 |
| 20260623_reason_code_rsi_oversold_reason_code_weight_adjustment | reason_code | rsi_oversold | audit_status_blocked | blocked | 5 | low | decrease | -0.0152 |
| 20260623_reason_code_trend_up_reason_code_weight_adjustment | reason_code | trend_up | audit_status_blocked | blocked | 19 | medium | decrease | -0.0256 |
| 20260623_side_NONE_side_bias_adjustment | side | NONE | audit_status_blocked | blocked | 5 | low | decrease | -0.015 |
| 20260623_type_A-Pullback_setup_type_weight_adjustment | type | A-Pullback | audit_status_blocked | blocked | 8 | low | decrease | -0.0151 |
| 20260623_type_TREND_setup_type_weight_adjustment | type | TREND | audit_status_blocked | blocked | 7 | low | decrease | -0.0135 |
| 20260623_asset_DXY_asset_weight_adjustment | asset | DXY | audit_status_blocked | passed | 4 | insufficient_data | hold | 0.0 |
| 20260623_asset_US10Y_asset_weight_adjustment | asset | US10Y | audit_status_blocked | passed | 3 | insufficient_data | hold | 0.0 |
| 20260623_asset_USDJPY_asset_weight_adjustment | asset | USDJPY | audit_status_blocked | passed | 1 | insufficient_data | hold | 0.0 |
| 20260623_rank_A_rank_confidence_adjustment | rank | A | audit_status_blocked | passed | 3 | insufficient_data | hold | 0.0 |
| 20260623_reason_code_atr_too_low_reason_code_weight_adjustment | reason_code | atr_too_low | audit_status_blocked | passed | 0 | insufficient_data | hold | 0.0 |
| 20260623_reason_code_breakout_up_reason_code_weight_adjustment | reason_code | breakout_up | audit_status_blocked | passed | 3 | insufficient_data | hold | 0.0 |
| 20260623_reason_code_data_insufficient_reason_code_weight_adjustment | reason_code | data_insufficient | audit_status_blocked | passed | 0 | insufficient_data | hold | 0.0 |
| 20260623_reason_code_low_volatility_reason_code_weight_adjustment | reason_code | low_volatility | audit_status_blocked | passed | 0 | insufficient_data | hold | 0.0 |
| 20260623_reason_code_range_middle_reason_code_weight_adjustment | reason_code | range_middle | audit_status_blocked | passed | 2 | insufficient_data | hold | 0.0 |
| 20260623_reason_code_risk_penalty_high_reason_code_weight_adjustment | reason_code | risk_penalty_high | audit_status_blocked | passed | 1 | insufficient_data | hold | 0.0 |
| 20260623_reason_code_rr_too_low_reason_code_weight_adjustment | reason_code | rr_too_low | audit_status_blocked | passed | 0 | insufficient_data | hold | 0.0 |
| 20260623_reason_code_rsi_overbought_reason_code_weight_adjustment | reason_code | rsi_overbought | audit_status_blocked | passed | 2 | insufficient_data | hold | 0.0 |
| 20260623_side_NO_TRADE_side_bias_adjustment | side | NO_TRADE | audit_status_blocked | passed | 0 | insufficient_data | hold | 0.0 |
| 20260623_type_A-Momentum_setup_type_weight_adjustment | type | A-Momentum | audit_status_blocked | passed | 3 | insufficient_data | hold | 0.0 |
| 20260623_type_NO_TRADE_setup_type_weight_adjustment | type | NO_TRADE | audit_status_blocked | passed | 0 | insufficient_data | hold | 0.0 |

## 4. 注意

- このファイルは適用候補であり、weights.jsonを更新しない
- 自動適用は禁止
- 人間確認後、別フェーズで明示的に適用する
- 実売買・発注は行わない
