# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-23 05:26:17 JST
生成日時（UTC）: 2026-06-22 20:26:17 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.8
ニュース市場バイアス: neutral
ニュース矛盾スコア: 19.17
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立

## スコア

- risk_on_news_score: 19.17
- risk_off_news_score: 19.17
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 19.17
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 19.17
- inflation_pressure_news_score: 0.0
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 92.0

## Top News Drivers

- SpaceX stock tanks 16%, extending slump following post-IPO rally (リスクオフ要因 / リスクオン要因)
- Treasury Department authorizes Iranian oil sales through August (地政学リスク / 金安全資産需要 / リスクオフ要因)
