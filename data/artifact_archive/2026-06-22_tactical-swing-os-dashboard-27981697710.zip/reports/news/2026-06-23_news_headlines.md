# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-23 05:26:15 JST
取得日時（UTC）: 2026-06-22 20:26:15 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.8
headline件数: 30

## 見出し

- [CNBC Markets] Alphabet paces for worst day in a year on AI concerns after high-profile exits (未分類)
- [CNBC Markets] SpaceX signs computing power deal with open-source AI startup Reflection worth up to $6.3 billion (未分類)
- [CNBC Markets] Alan Greenspan, former chairman of the Fed, dies at age 100 (US10Y|DXY)
- [CNBC Markets] SpaceX stock tanks 16%, extending slump following post-IPO rally (未分類)
- [CNBC Markets] Nvidia's stock struggles as Kalshi traders bet chip prices are coming down (SPX|NASDAQ)
- [CNBC Markets] Three key AI stocks to watch this week with traders expecting giant moves (SPX|NASDAQ)
- [CNBC Markets] Treasury Department authorizes Iranian oil sales through August (WTI|US10Y|DXY)
- [CNBC Markets] Senate poised to advance housing bill to limit private equity purchases of single-family homes (未分類)
- [CNBC Markets] Companies are demanding states cut red tape. Data center-wary voters may think differently (未分類)
- [CNBC Markets] Meta's WhatsApp head to step down, will be replaced by Indian fintech founder Kunal Shah (NASDAQ)
- [CNBC Markets] Vance hails 'great progress' in U.S.-Iran talks despite 'threatening' and 'whining' (未分類)
- [CNBC Markets] SpaceX kicks off bond sale days after record IPO, discloses over $100 billion cash pile (US10Y)
- [CNBC Markets] Can anyone join Musk in the trillionaire club? Zuckerberg has best shot, according to prediction markets (未分類)
- [CNBC Markets] CNBC Elite Advisors: Top ultra-high net worth wealth management firms for 2026 (未分類)
- [CNBC Markets] Amazon Prime Day arrives earlier this year. Here's why Wall Street is watching closely (SPX)
- [CNBC Markets] Who is Andy Burnham? And 4 other things investors should know as the UK replaces its prime minister (未分類)
- [CNBC Markets] Childcare tax breaks can save families and businesses money — but few use them, congressional report finds (未分類)
- [CNBC Markets] 'Reward for failure': Investor support for Target Chair Brian Cornell falls to lowest level ever (未分類)
- [CNBC Markets] Lucid to lay off roughly 18% of U.S. workforce, COO Marc Winterhoff leaves (未分類)
- [CNBC Markets] Shipping stalls in Strait of Hormuz after Iran declares key waterway closed again (WTI)
- [CNBC Markets] How to pick up some quick income using an auto stock hitting its stride (VIX)
- [CNBC Markets] UK PM Starmer resigns as Britain faces its seventh leader in 10 years (未分類)
- [CNBC Markets] UPS to invest $48 million in temperature-controlled facilities amid healthcare boom (未分類)
- [CNBC Markets] Chevron to fuel massive Microsoft data center in Texas using natural gas (未分類)
- [CNBC Markets] China imposes trade curbs on dozens of U.S. firms in retaliation for Pentagon blacklist (NASDAQ)
- [CNBC Markets] The new arms race in wealth management: Winning the ultra-wealthy (未分類)
- [CNBC Markets] Why a 66-year-old water treaty is becoming the latest India-Pakistan flashpoint (未分類)
- [CNBC Markets] Oil prices fall after U.S. authorizes Iranian crude sales (WTI)
- [MarketWatch Top Stories] The bond market just did something unusual. Why its sudden volatility ‘is here to stay.’ (US10Y|DXY|VIX)
- [MarketWatch Top Stories] Trump may say he’s banning Wall Street from buying homes. Does the bipartisan housing bill actually do that? (SPX)
