# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-10 08:25:15 JST
取得日時（UTC）: 2026-06-09 23:25:15 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.11
headline件数: 30

## 見出し

- [CNBC Markets] SpaceX IPO explained: The price is set, but retail allocation still up in the air (SPX)
- [CNBC Markets] U.S. military launches strikes in retaliation for Iran downing helicopter (未分類)
- [CNBC Markets] Super Micro stock tumbles on $7 billion financing plans as company touts AI server orders (未分類)
- [CNBC Markets] Oil prices fall after U.S. Energy secretary says Hormuz ship traffic is increasing (WTI)
- [CNBC Markets] The May inflation numbers are due out Wednesday morning. Here's what to expect (SPX)
- [CNBC Markets] Anthropic releases Mythos-like AI model to the public two months after private rollout rocked Wall Street (SPX)
- [CNBC Markets] Kalshi rolls out whistleblower services, employment verification to curb insider trading (SPX)
- [CNBC Markets] Semiconductor shorts pile on as winning trade reverses (未分類)
- [CNBC Markets] GM eyes new battery chemistry to grow AI data center, energy storage business (未分類)
- [CNBC Markets] As LIV Golf faces a Saudi funding cliff, CEO says to take PIF 'at their word' (未分類)
- [CNBC Markets] Jim Cramer says tech stocks are losing the qualities that made them the leaders of the rally (SPX|NASDAQ)
- [CNBC Markets] Kalshi trading in 'perps' crosses $1 billion in volume within a week of launch (未分類)
- [CNBC Markets] Trump family got about $500M from crypto venture — but investors saw steep losses (BTC|SPX)
- [CNBC Markets] White House border czar Tom Homan blames New York Gov. Hochul for promised ICE surge (未分類)
- [CNBC Markets] Social Security retirement trust fund may be depleted in 2032, new trustees report finds (未分類)
- [CNBC Markets] $70 billion immigration funding package passes in U.S. House in a win for Speaker Johnson (未分類)
- [CNBC Markets] Apple shares slide after big Siri AI reveal (SPX)
- [CNBC Markets] Another jump in Boeing deliveries shows why we got into the stock and want to stay in (未分類)
- [CNBC Markets] Rivian is betting on its R2 EV to turn the automaker into a household name like Tesla (未分類)
- [CNBC Markets] JPMorgan Chase plans to deploy more powerful AI agents this year (未分類)
- [CNBC Markets] Jeffrey Epstein's former assistant Lesley Groff interviewed by House panel (未分類)
- [CNBC Markets] Home sales surged in May to the highest level since December (US10Y|DXY)
- [CNBC Markets] Bitcoin's brutal sell-off sparks a flurry of trading in related stocks, including one big bullish bet (BTC|SPX)
- [CNBC Markets] Energy Secretary Chris Wright says traffic in Strait of Hormuz is rising 'very meaningfully' (WTI)
- [CNBC Markets] 5 takeaways from airline CEOs' biggest annual gathering (未分類)
- [CNBC Markets] SpaceX employee group creates low-fee wealth management option with Choreo for post-IPO (未分類)
- [CNBC Markets] Nuvalent shares surge 39% after UK's GSK agrees to buy the cancer drugmaker for $10.6 billion (SPX|NASDAQ)
- [CNBC Markets] Upstart chipmakers keep challenging Nvidia. This time it's Microsoft-backed D-Matrix (NASDAQ)
- [CNBC Markets] The 'SaaSpocalypse' is over, says private equity giant Thoma Bravo. Here's why it sees an AI boom for software (未分類)
- [MarketWatch Top Stories] This stock-market strategy has cheap exposure to AI and points to an advantage for closed-end funds (未分類)
