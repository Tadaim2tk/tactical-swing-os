# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-10 08:25:17 JST
生成日時（UTC）: 2026-06-09 23:25:17 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.11
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 38.33
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 38.33
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 38.33
- inflation_pressure_news_score: 19.17
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 38.33
- news_confidence: 100.0

## Top News Drivers

- Oil prices fall after U.S. Energy secretary says Hormuz ship traffic is increasing (中銀ハト派)
- The May inflation numbers are due out Wednesday morning. Here's what to expect (インフレ圧力 / 金利圧力候補)
- Jim Cramer says tech stocks are losing the qualities that made them the leaders of the rally (リスクオン要因)
- Apple shares slide after big Siri AI reveal (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Home sales surged in May to the highest level since December (リスクオン要因)
- Energy Secretary Chris Wright says traffic in Strait of Hormuz is rising 'very meaningfully' (中銀ハト派)
- The 'SaaSpocalypse' is over, says private equity giant Thoma Bravo. Here's why it sees an AI boom for software (地政学リスク / 金安全資産需要 / リスクオフ要因)
