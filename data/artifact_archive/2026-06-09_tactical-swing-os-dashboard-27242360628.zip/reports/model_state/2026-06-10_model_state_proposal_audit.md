# Model State Proposal Safety Audit

## 1. 概要

- 生成日時JST: 2026-06-10 08:25:41 JST
- audit_status: passed
- total_proposals: 46
- warning_count: 0
- blocked_count: 0
- critical_count: 0
- weights_json_updated: false
- requires_human_review: true

## 2. ブロック対象

該当なし

## 3. 警告対象

該当なし

## 4. 通過対象

| proposal_id | category | target | audit_result | severity | reason | sample_count | confidence_level | proposed_delta | max_allowed_delta | apply_automatically | recommended_action |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260610_narrative_crypto_liquidity_narrative_weight_adjustment | narrative | crypto_liquidity | passed | low | safe_proposal | 20 | high | -0.0405 | 0.08 | False | human_review_required |
| 20260610_narrative_dollar_strength_narrative_weight_adjustment | narrative | dollar_strength | passed | low | safe_proposal | 20 | high | -0.0405 | 0.08 | False | human_review_required |
| 20260610_narrative_geopolitical_risk_narrative_weight_adjustment | narrative | geopolitical_risk | passed | low | safe_proposal | 20 | high | -0.0405 | 0.08 | False | human_review_required |
| 20260610_narrative_oil_supply_risk_narrative_weight_adjustment | narrative | oil_supply_risk | passed | low | safe_proposal | 20 | high | -0.0405 | 0.08 | False | human_review_required |
| 20260610_narrative_rate_pressure_narrative_weight_adjustment | narrative | rate_pressure | passed | low | safe_proposal | 20 | high | -0.0405 | 0.08 | False | human_review_required |
| 20260610_narrative_risk_off_narrative_weight_adjustment | narrative | risk_off | passed | low | safe_proposal | 20 | high | -0.0405 | 0.08 | False | human_review_required |
| 20260610_narrative_risk_on_narrative_weight_adjustment | narrative | risk_on | passed | low | safe_proposal | 20 | high | -0.0405 | 0.08 | False | human_review_required |
| 20260610_asset_GOLD_asset_weight_adjustment | asset | GOLD | passed | low | safe_proposal | 5 | low | -0.021 | 0.03 | False | human_review_required |
| 20260610_rank_B_rank_confidence_adjustment | rank | B | passed | low | safe_proposal | 15 | medium | -0.0253 | 0.05 | False | human_review_required |
| 20260610_rank_NO_TRADE_rank_confidence_adjustment | rank | NO_TRADE | passed | low | safe_proposal | 5 | low | -0.015 | 0.03 | False | human_review_required |
| 20260610_reason_code_ma_alignment_bear_reason_code_weight_adjustment | reason_code | ma_alignment_bear | passed | low | safe_proposal | 7 | low | -0.0159 | 0.03 | False | human_review_required |
| 20260610_reason_code_momentum_negative_reason_code_weight_adjustment | reason_code | momentum_negative | passed | low | safe_proposal | 7 | low | -0.0159 | 0.03 | False | human_review_required |
| 20260610_reason_code_trend_down_reason_code_weight_adjustment | reason_code | trend_down | passed | low | safe_proposal | 7 | low | -0.0159 | 0.03 | False | human_review_required |
| 20260610_side_LONG_side_bias_adjustment | side | LONG | passed | low | safe_proposal | 6 | low | -0.0151 | 0.03 | False | human_review_required |
| 20260610_side_NONE_side_bias_adjustment | side | NONE | passed | low | safe_proposal | 5 | low | -0.015 | 0.03 | False | human_review_required |
| 20260610_side_SHORT_side_bias_adjustment | side | SHORT | passed | low | safe_proposal | 9 | low | -0.0155 | 0.03 | False | human_review_required |
| 20260610_type_B-Watch_setup_type_weight_adjustment | type | B-Watch | passed | low | safe_proposal | 8 | low | -0.0153 | 0.03 | False | human_review_required |
| 20260610_type_TREND_setup_type_weight_adjustment | type | TREND | passed | low | safe_proposal | 5 | low | -0.0153 | 0.03 | False | human_review_required |
| 20260610_asset_BTC_asset_weight_adjustment | asset | BTC | passed | low | safe_proposal | 4 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_asset_DXY_asset_weight_adjustment | asset | DXY | passed | low | safe_proposal | 2 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_asset_NASDAQ_asset_weight_adjustment | asset | NASDAQ | passed | low | safe_proposal | 1 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_asset_SPX_asset_weight_adjustment | asset | SPX | passed | low | safe_proposal | 1 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_asset_US10Y_asset_weight_adjustment | asset | US10Y | passed | low | safe_proposal | 3 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_asset_USDJPY_asset_weight_adjustment | asset | USDJPY | passed | low | safe_proposal | 1 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_asset_VIX_asset_weight_adjustment | asset | VIX | passed | low | safe_proposal | 1 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_asset_WTI_asset_weight_adjustment | asset | WTI | passed | low | safe_proposal | 2 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_rank_A_rank_confidence_adjustment | rank | A | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_atr_too_high_reason_code_weight_adjustment | reason_code | atr_too_high | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_atr_too_low_reason_code_weight_adjustment | reason_code | atr_too_low | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_breakout_down_reason_code_weight_adjustment | reason_code | breakout_down | passed | low | safe_proposal | 1 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_breakout_up_reason_code_weight_adjustment | reason_code | breakout_up | passed | low | safe_proposal | 1 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_low_volatility_reason_code_weight_adjustment | reason_code | low_volatility | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_ma_alignment_bull_reason_code_weight_adjustment | reason_code | ma_alignment_bull | passed | low | safe_proposal | 3 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_momentum_positive_reason_code_weight_adjustment | reason_code | momentum_positive | passed | low | safe_proposal | 3 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_overextended_reason_code_weight_adjustment | reason_code | overextended | passed | low | safe_proposal | 1 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_pullback_to_ma20_reason_code_weight_adjustment | reason_code | pullback_to_ma20 | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_range_middle_reason_code_weight_adjustment | reason_code | range_middle | passed | low | safe_proposal | 2 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_risk_penalty_high_reason_code_weight_adjustment | reason_code | risk_penalty_high | passed | low | safe_proposal | 1 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_rr_too_low_reason_code_weight_adjustment | reason_code | rr_too_low | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_rsi_overbought_reason_code_weight_adjustment | reason_code | rsi_overbought | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_rsi_oversold_reason_code_weight_adjustment | reason_code | rsi_oversold | passed | low | safe_proposal | 3 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_reason_code_trend_up_reason_code_weight_adjustment | reason_code | trend_up | passed | low | safe_proposal | 3 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_side_NO_TRADE_side_bias_adjustment | side | NO_TRADE | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_type_A-Momentum_setup_type_weight_adjustment | type | A-Momentum | passed | low | safe_proposal | 1 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_type_A-Pullback_setup_type_weight_adjustment | type | A-Pullback | passed | low | safe_proposal | 1 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260610_type_NO_TRADE_setup_type_weight_adjustment | type | NO_TRADE | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |

## 5. 注意

- この監査は自動反映を許可するものではない
- weights.jsonは更新していない
- 人間確認が必須
- 実売買・発注は行わない
