# Weights Patch Proposal

## 1. 概要

- 生成日時JST: 2026-06-10 08:25:41 JST
- audit_status: passed
- 入力提案件数: 46
- patch候補数: 18
- 除外件数: 28
- increase件数: 0
- decrease件数: 18
- add件数: 12
- update件数: 6
- weights.json更新: false
- patch適用: false
- 人間承認: 必須

## 2. patch候補

| weight_path | current_weight | proposed_delta | proposed_value | rationale |
| --- | --- | --- | --- | --- |
| narrative_weights.crypto_liquidity | 1.0 | -0.0405 | 0.9595 | narrative=crypto_liquidity はsample_count=20, win_rate=0.00, avg_r=0.01。 判定は decrease です。 narrative_score=0.00。AI Feedback由来の補助指標として扱います。 |
| narrative_weights.dollar_strength | 1.0 | -0.0405 | 0.9595 | narrative=dollar_strength はsample_count=20, win_rate=0.00, avg_r=0.01。 判定は decrease です。 narrative_score=0.00。AI Feedback由来の補助指標として扱います。 |
| narrative_weights.geopolitical_risk | 1.0 | -0.0405 | 0.9595 | narrative=geopolitical_risk はsample_count=20, win_rate=0.00, avg_r=0.01。 判定は decrease です。 narrative_score=0.00。AI Feedback由来の補助指標として扱います。 |
| narrative_weights.oil_supply_risk | 1.0 | -0.0405 | 0.9595 | narrative=oil_supply_risk はsample_count=20, win_rate=0.00, avg_r=0.01。 判定は decrease です。 narrative_score=0.00。AI Feedback由来の補助指標として扱います。 |
| narrative_weights.rate_pressure | 1.0 | -0.0405 | 0.9595 | narrative=rate_pressure はsample_count=20, win_rate=0.00, avg_r=0.01。 判定は decrease です。 narrative_score=0.00。AI Feedback由来の補助指標として扱います。 |
| narrative_weights.risk_off | 1.0 | -0.0405 | 0.9595 | narrative=risk_off はsample_count=20, win_rate=0.00, avg_r=0.01。 判定は decrease です。 narrative_score=0.00。AI Feedback由来の補助指標として扱います。 |
| narrative_weights.risk_on | 1.0 | -0.0405 | 0.9595 | narrative=risk_on はsample_count=20, win_rate=0.00, avg_r=0.01。 判定は decrease です。 narrative_score=0.00。AI Feedback由来の補助指標として扱います。 |
| asset_weights.GOLD | 1.0 | -0.021 | 0.979 | asset=GOLD はsample_count=5, win_rate=0.00, avg_r=0.30。 判定は decrease です。 |
| rank_weights.B | 1.0 | -0.0253 | 0.9747 | rank=B はsample_count=15, win_rate=0.00, avg_r=0.01。 判定は decrease です。 |
| rank_weights.NO_TRADE | 1.0 | -0.015 | 0.985 | rank=NO_TRADE はsample_count=5, win_rate=0.00, avg_r=0.00。 判定は decrease です。 |
| reason_code_weights.ma_alignment_bear | 1.0 | -0.0159 | 0.9841 | reason_code=ma_alignment_bear はsample_count=7, win_rate=0.00, avg_r=0.04。 判定は decrease です。 reliability_label=neutral |
| reason_code_weights.momentum_negative | 1.0 | -0.0159 | 0.9841 | reason_code=momentum_negative はsample_count=7, win_rate=0.00, avg_r=0.04。 判定は decrease です。 reliability_label=neutral |
| reason_code_weights.trend_down | 1.0 | -0.0159 | 0.9841 | reason_code=trend_down はsample_count=7, win_rate=0.00, avg_r=0.04。 判定は decrease です。 reliability_label=neutral |
| side_weights.LONG | 1.0 | -0.0151 | 0.9849 | side=LONG はsample_count=6, win_rate=0.00, avg_r=-0.01。 判定は decrease です。 |
| side_weights.NONE | 1.0 | -0.015 | 0.985 | side=NONE はsample_count=5, win_rate=0.00, avg_r=0.00。 判定は decrease です。 |
| side_weights.SHORT | 1.0 | -0.0155 | 0.9845 | side=SHORT はsample_count=9, win_rate=0.00, avg_r=0.03。 判定は decrease です。 |
| setup_type_weights.B-Watch | 1.0 | -0.0153 | 0.9847 | type=B-Watch はsample_count=8, win_rate=0.00, avg_r=0.01。 判定は decrease です。 |
| setup_type_weights.TREND | 1.0 | -0.0153 | 0.9847 | type=TREND はsample_count=5, win_rate=0.00, avg_r=0.01。 判定は decrease です。 |

## 3. 除外された提案

| proposal_id | category | target | exclusion_reason | audit_result | sample_count | confidence_level | proposal_direction | proposed_delta |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260610_asset_BTC_asset_weight_adjustment | asset | BTC | insufficient_data | passed | 4 | insufficient_data | hold | 0.0 |
| 20260610_asset_DXY_asset_weight_adjustment | asset | DXY | insufficient_data | passed | 2 | insufficient_data | hold | 0.0 |
| 20260610_asset_NASDAQ_asset_weight_adjustment | asset | NASDAQ | insufficient_data | passed | 1 | insufficient_data | hold | 0.0 |
| 20260610_asset_SPX_asset_weight_adjustment | asset | SPX | insufficient_data | passed | 1 | insufficient_data | hold | 0.0 |
| 20260610_asset_US10Y_asset_weight_adjustment | asset | US10Y | insufficient_data | passed | 3 | insufficient_data | hold | 0.0 |
| 20260610_asset_USDJPY_asset_weight_adjustment | asset | USDJPY | insufficient_data | passed | 1 | insufficient_data | hold | 0.0 |
| 20260610_asset_VIX_asset_weight_adjustment | asset | VIX | insufficient_data | passed | 1 | insufficient_data | hold | 0.0 |
| 20260610_asset_WTI_asset_weight_adjustment | asset | WTI | insufficient_data | passed | 2 | insufficient_data | hold | 0.0 |
| 20260610_rank_A_rank_confidence_adjustment | rank | A | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_atr_too_high_reason_code_weight_adjustment | reason_code | atr_too_high | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_atr_too_low_reason_code_weight_adjustment | reason_code | atr_too_low | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_breakout_down_reason_code_weight_adjustment | reason_code | breakout_down | insufficient_data | passed | 1 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_breakout_up_reason_code_weight_adjustment | reason_code | breakout_up | insufficient_data | passed | 1 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_low_volatility_reason_code_weight_adjustment | reason_code | low_volatility | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_ma_alignment_bull_reason_code_weight_adjustment | reason_code | ma_alignment_bull | insufficient_data | passed | 3 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_momentum_positive_reason_code_weight_adjustment | reason_code | momentum_positive | insufficient_data | passed | 3 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_overextended_reason_code_weight_adjustment | reason_code | overextended | insufficient_data | passed | 1 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_pullback_to_ma20_reason_code_weight_adjustment | reason_code | pullback_to_ma20 | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_range_middle_reason_code_weight_adjustment | reason_code | range_middle | insufficient_data | passed | 2 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_risk_penalty_high_reason_code_weight_adjustment | reason_code | risk_penalty_high | insufficient_data | passed | 1 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_rr_too_low_reason_code_weight_adjustment | reason_code | rr_too_low | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_rsi_overbought_reason_code_weight_adjustment | reason_code | rsi_overbought | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_rsi_oversold_reason_code_weight_adjustment | reason_code | rsi_oversold | insufficient_data | passed | 3 | insufficient_data | hold | 0.0 |
| 20260610_reason_code_trend_up_reason_code_weight_adjustment | reason_code | trend_up | insufficient_data | passed | 3 | insufficient_data | hold | 0.0 |
| 20260610_side_NO_TRADE_side_bias_adjustment | side | NO_TRADE | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |
| 20260610_type_A-Momentum_setup_type_weight_adjustment | type | A-Momentum | insufficient_data | passed | 1 | insufficient_data | hold | 0.0 |
| 20260610_type_A-Pullback_setup_type_weight_adjustment | type | A-Pullback | insufficient_data | passed | 1 | insufficient_data | hold | 0.0 |
| 20260610_type_NO_TRADE_setup_type_weight_adjustment | type | NO_TRADE | insufficient_data | passed | 0 | insufficient_data | hold | 0.0 |

## 4. 注意

- このファイルは適用候補であり、weights.jsonを更新しない
- 自動適用は禁止
- 人間確認後、別フェーズで明示的に適用する
- 実売買・発注は行わない
