# Weights Patch Human Review

## 1. 概要

- 生成日時JST: 2026-06-27 16:38:09 JST
- review_status: blocked
- patch候補数: 0
- candidate件数: 0
- hold件数: 0
- reject件数: 0
- blocked件数: 0
- requires_human_approval: true
- patch_applied: false
- weights_json_updated: false

## 2. 承認候補

該当なし

## 3. 保留候補

保留候補は、データ蓄積または人間確認を待つpatchです。

該当なし

## 4. 却下候補

該当なし

## 5. 人間チェックリスト

- 対象weight pathは妥当か
- sample_countは十分か
- avg_r / win_rate は実用的か
- 提案deltaは過大ではないか
- 直近相場の一時的偏りではないか
- 同じ方向の提案が複数重なりすぎていないか
- 実売買に使う前にバックテストまたは紙上検証するか

## 6. 注意

- このレポートは承認を補助するだけ
- weights.jsonは更新しない
- 自動売買しない
- 人間承認なしに反映しない
