# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-07 08:18:11 JST
取得日時（UTC）: 2026-07-06 23:18:11 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.64
headline件数: 30

## 見出し

- [CNBC Markets] Microsoft cuts 4,800 jobs, as Xbox unit downsizes and plans to spin off four gaming studios (未分類)
- [CNBC Markets] Graham Platner denies sex assault claim as Democrats urge him to quit Maine Senate race (未分類)
- [CNBC Markets] Belgium loses appeal of Balogun eligibility after Trump defends intervention with FIFA (未分類)
- [CNBC Markets] Toyota to invest $3.6 billion to move Tacoma pickup truck production from Mexico to Texas (未分類)
- [CNBC Markets] China's Alibaba bans Anthropic AI for employees after 'distillation attack' accusation (未分類)
- [CNBC Markets] Here's how SpaceX's Nasdaq-100 inclusion might affect options pricing (NASDAQ)
- [CNBC Markets] Student loan servicers begin 90-day countdown for borrowers to leave SAVE plan (未分類)
- [CNBC Markets] Trump defends call urging Balogun red card review: 'It wasn't a foul' (未分類)
- [CNBC Markets] Trump Accounts are live. Here's how some families plan to use them (未分類)
- [CNBC Markets] Rivian, Tesla and the 'Holly Index': How to trade the new EV Main Street battle (未分類)
- [CNBC Markets] SpaceX President Gwynne Shotwell to donate stock to Trump Accounts (未分類)
- [CNBC Markets] Record heat, crowds drive offseason boom in international travel (未分類)
- [CNBC Markets] Lockheed Martin to buy naval defense firm Ultra Maritime for $3.45 billion (NASDAQ)
- [CNBC Markets] Klarna seeks U.S. bank charter in latest push beyond buy now, pay later (BTC|NASDAQ)
- [CNBC Markets] Versant agrees to buy golf simulator company Full Swing for $530 million (未分類)
- [CNBC Markets] Here's our plan for both Honeywell stocks after a divergent first week of trading (SPX)
- [CNBC Markets] NATO tensions are ‘growing pains,’ U.S. ambassador says as Trump presses allies (未分類)
- [CNBC Markets] TeraWulf shares soar after Anthropic leases data center in Kentucky (SPX)
- [CNBC Markets] Trump's calls, Ukraine's strikes and Russia's barrage on Kyiv put markets on alert (未分類)
- [CNBC Markets] 'Electronic warfare is a tech phenomenon': Why the market is rethinking defense valuations (NASDAQ)
- [CNBC Markets] Why Iran may find it difficult to clear its oil inventories even after sanctions relief (WTI)
- [CNBC Markets] Nvidia's next-gen AI rack system delayed to 2028 on manufacturing snags, SemiAnalysis says (未分類)
- [CNBC Markets] Meta’s woes deepen in India as child abuse ads on Instagram draw government ire (未分類)
- [CNBC Markets] EasyJet shares soar 10% as budget airline agrees to $7.3 billion Castlelake takeover (SPX)
- [CNBC Markets] 'NATO 3.0': Defense spending pledges face the Trump test (BTC)
- [MarketWatch Top Stories] The Nasdaq-100 has been far more volatile than the S&P 500. Now add SpaceX to the mix. (SPX|NASDAQ|VIX)
- [MarketWatch Top Stories] U.S.-Belgium match could draw record TV audience amid the Trump World Cup controversy (未分類)
- [MarketWatch Top Stories] Your data built the AI boom — but Big Tech is pocketing 100% of the equity (NASDAQ)
- [MarketWatch Top Stories] Your investing expectations are more than double the reality. Here is the tough truth. (未分類)
- [MarketWatch Top Stories] Stocks rally when Congress goes on summer break. Here’s why. (SPX|VIX)
