# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-07 08:18:12 JST
生成日時（UTC）: 2026-07-06 23:18:12 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.64
ニュース市場バイアス: neutral
ニュース矛盾スコア: 19.17
主要テーマ: geopolitical_risk
日本語要約: 地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 19.17
- risk_off_news_score: 38.33
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 0.0
- oil_supply_risk_news_score: 19.17
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 95.83
- inflation_pressure_news_score: 0.0
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- China's Alibaba bans Anthropic AI for employees after 'distillation attack' accusation (地政学リスク / リスクオフ要因)
- NATO tensions are ‘growing pains,’ U.S. ambassador says as Trump presses allies (リスクオフ要因)
- Trump's calls, Ukraine's strikes and Russia's barrage on Kyiv put markets on alert (地政学リスク / リスクオフ要因)
- Why Iran may find it difficult to clear its oil inventories even after sanctions relief (地政学リスク / 原油供給リスク / リスクオフ要因)
- Stocks rally when Congress goes on summer break. Here’s why. (リスクオフ要因 / リスクオン要因)
