# Model State Proposal Safety Audit

## 1. 概要

- 生成日時JST: 2026-07-07 08:18:39 JST
- audit_status: blocked
- total_proposals: 46
- warning_count: 0
- blocked_count: 22
- critical_count: 0
- weights_json_updated: false
- requires_human_review: true

## 2. ブロック対象

| proposal_id | category | target | audit_result | severity | reason | sample_count | confidence_level | proposed_delta | max_allowed_delta | apply_automatically | recommended_action |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260707_asset_BTC_asset_weight_adjustment | asset | BTC | blocked | high | sample_count_below_30_minimum | 11 | medium | -0.0388 | 0.05 | False | block_proposal |
| 20260707_asset_GOLD_asset_weight_adjustment | asset | GOLD | blocked | high | sample_count_below_30_minimum | 12 | medium | -0.0315 | 0.05 | False | block_proposal |
| 20260707_asset_WTI_asset_weight_adjustment | asset | WTI | blocked | high | sample_count_below_30_minimum | 18 | medium | -0.0334 | 0.05 | False | block_proposal |
| 20260707_reason_code_breakout_down_reason_code_weight_adjustment | reason_code | breakout_down | blocked | high | sample_count_below_30_minimum | 11 | medium | -0.0313 | 0.05 | False | block_proposal |
| 20260707_reason_code_momentum_positive_reason_code_weight_adjustment | reason_code | momentum_positive | blocked | high | sample_count_below_30_minimum | 23 | high | -0.044 | 0.08 | False | block_proposal |
| 20260707_reason_code_overextended_reason_code_weight_adjustment | reason_code | overextended | blocked | high | sample_count_below_30_minimum | 17 | medium | -0.0308 | 0.05 | False | block_proposal |
| 20260707_asset_DXY_asset_weight_adjustment | asset | DXY | blocked | high | sample_count_below_30_minimum | 7 | low | -0.0169 | 0.03 | False | block_proposal |
| 20260707_asset_NASDAQ_asset_weight_adjustment | asset | NASDAQ | blocked | high | sample_count_below_30_minimum | 13 | medium | -0.0294 | 0.05 | False | block_proposal |
| 20260707_asset_SPX_asset_weight_adjustment | asset | SPX | blocked | high | sample_count_below_30_minimum | 12 | medium | -0.0276 | 0.05 | False | block_proposal |
| 20260707_asset_US10Y_asset_weight_adjustment | asset | US10Y | blocked | high | sample_count_below_30_minimum | 7 | low | -0.0188 | 0.03 | False | block_proposal |
| 20260707_asset_VIX_asset_weight_adjustment | asset | VIX | blocked | high | sample_count_below_30_minimum | 6 | low | -0.0167 | 0.03 | False | block_proposal |
| 20260707_rank_NO_TRADE_rank_confidence_adjustment | rank | NO_TRADE | blocked | high | sample_count_below_30_minimum | 5 | low | -0.015 | 0.03 | False | block_proposal |
| 20260707_reason_code_atr_too_high_reason_code_weight_adjustment | reason_code | atr_too_high | blocked | high | sample_count_below_30_minimum | 17 | medium | -0.0269 | 0.05 | False | block_proposal |
| 20260707_reason_code_breakout_up_reason_code_weight_adjustment | reason_code | breakout_up | blocked | high | sample_count_below_30_minimum | 5 | low | -0.0154 | 0.03 | False | block_proposal |
| 20260707_reason_code_pullback_to_ma20_reason_code_weight_adjustment | reason_code | pullback_to_ma20 | blocked | high | sample_count_below_30_minimum | 15 | medium | -0.0267 | 0.05 | False | block_proposal |
| 20260707_reason_code_range_middle_reason_code_weight_adjustment | reason_code | range_middle | blocked | high | sample_count_below_30_minimum | 5 | low | -0.0236 | 0.03 | False | block_proposal |
| 20260707_reason_code_rsi_overbought_reason_code_weight_adjustment | reason_code | rsi_overbought | blocked | high | sample_count_below_30_minimum | 5 | low | -0.0154 | 0.03 | False | block_proposal |
| 20260707_reason_code_rsi_oversold_reason_code_weight_adjustment | reason_code | rsi_oversold | blocked | high | sample_count_below_30_minimum | 16 | medium | -0.0255 | 0.05 | False | block_proposal |
| 20260707_side_NONE_side_bias_adjustment | side | NONE | blocked | high | sample_count_below_30_minimum | 5 | low | -0.015 | 0.03 | False | block_proposal |
| 20260707_type_A-Momentum_setup_type_weight_adjustment | type | A-Momentum | blocked | high | sample_count_below_30_minimum | 5 | low | -0.0165 | 0.03 | False | block_proposal |
| 20260707_type_A-Pullback_setup_type_weight_adjustment | type | A-Pullback | blocked | high | sample_count_below_30_minimum | 17 | medium | -0.0273 | 0.05 | False | block_proposal |
| 20260707_type_TREND_setup_type_weight_adjustment | type | TREND | blocked | high | sample_count_below_30_minimum | 8 | low | -0.0135 | 0.03 | False | block_proposal |

## 3. 警告対象

該当なし

## 4. 通過対象

| proposal_id | category | target | audit_result | severity | reason | sample_count | confidence_level | proposed_delta | max_allowed_delta | apply_automatically | recommended_action |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260707_narrative_crypto_liquidity_narrative_weight_adjustment | narrative | crypto_liquidity | passed | low | safe_proposal | 87 | high | -0.0403 | 0.08 | False | human_review_required |
| 20260707_narrative_dollar_strength_narrative_weight_adjustment | narrative | dollar_strength | passed | low | safe_proposal | 87 | high | -0.0403 | 0.08 | False | human_review_required |
| 20260707_narrative_geopolitical_risk_narrative_weight_adjustment | narrative | geopolitical_risk | passed | low | safe_proposal | 87 | high | -0.0403 | 0.08 | False | human_review_required |
| 20260707_narrative_oil_supply_risk_narrative_weight_adjustment | narrative | oil_supply_risk | passed | low | safe_proposal | 87 | high | -0.0403 | 0.08 | False | human_review_required |
| 20260707_narrative_rate_pressure_narrative_weight_adjustment | narrative | rate_pressure | passed | low | safe_proposal | 87 | high | -0.0403 | 0.08 | False | human_review_required |
| 20260707_narrative_risk_off_narrative_weight_adjustment | narrative | risk_off | passed | low | safe_proposal | 87 | high | -0.0403 | 0.08 | False | human_review_required |
| 20260707_narrative_risk_on_narrative_weight_adjustment | narrative | risk_on | passed | low | safe_proposal | 87 | high | -0.0403 | 0.08 | False | human_review_required |
| 20260707_rank_B_rank_confidence_adjustment | rank | B | passed | low | safe_proposal | 78 | high | -0.0402 | 0.08 | False | human_review_required |
| 20260707_reason_code_ma_alignment_bear_reason_code_weight_adjustment | reason_code | ma_alignment_bear | passed | low | safe_proposal | 39 | high | -0.0436 | 0.08 | False | human_review_required |
| 20260707_reason_code_ma_alignment_bull_reason_code_weight_adjustment | reason_code | ma_alignment_bull | passed | low | safe_proposal | 34 | high | -0.0447 | 0.08 | False | human_review_required |
| 20260707_reason_code_momentum_negative_reason_code_weight_adjustment | reason_code | momentum_negative | passed | low | safe_proposal | 47 | high | -0.0417 | 0.08 | False | human_review_required |
| 20260707_reason_code_trend_down_reason_code_weight_adjustment | reason_code | trend_down | passed | low | safe_proposal | 39 | high | -0.0436 | 0.08 | False | human_review_required |
| 20260707_reason_code_trend_up_reason_code_weight_adjustment | reason_code | trend_up | passed | low | safe_proposal | 34 | high | -0.0447 | 0.08 | False | human_review_required |
| 20260707_side_LONG_side_bias_adjustment | side | LONG | passed | low | safe_proposal | 39 | high | -0.0434 | 0.08 | False | human_review_required |
| 20260707_side_SHORT_side_bias_adjustment | side | SHORT | passed | low | safe_proposal | 43 | high | -0.0435 | 0.08 | False | human_review_required |
| 20260707_type_B-Watch_setup_type_weight_adjustment | type | B-Watch | passed | low | safe_proposal | 52 | high | -0.0412 | 0.08 | False | human_review_required |
| 20260707_asset_USDJPY_asset_weight_adjustment | asset | USDJPY | passed | low | safe_proposal | 1 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260707_rank_A_rank_confidence_adjustment | rank | A | passed | low | safe_proposal | 4 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260707_reason_code_atr_too_low_reason_code_weight_adjustment | reason_code | atr_too_low | passed | low | safe_proposal | 1 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260707_reason_code_data_insufficient_reason_code_weight_adjustment | reason_code | data_insufficient | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260707_reason_code_low_volatility_reason_code_weight_adjustment | reason_code | low_volatility | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260707_reason_code_rr_too_low_reason_code_weight_adjustment | reason_code | rr_too_low | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260707_side_NO_TRADE_side_bias_adjustment | side | NO_TRADE | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |
| 20260707_type_NO_TRADE_setup_type_weight_adjustment | type | NO_TRADE | passed | low | safe_proposal | 0 | insufficient_data | 0.0 | 0.0 | False | human_review_required |

## 5. 注意

- この監査は自動反映を許可するものではない
- weights.jsonは更新していない
- 人間確認が必須
- 実売買・発注は行わない
