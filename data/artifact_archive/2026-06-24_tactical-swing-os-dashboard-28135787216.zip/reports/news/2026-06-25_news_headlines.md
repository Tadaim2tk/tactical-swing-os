# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-25 08:16:46 JST
取得日時（UTC）: 2026-06-24 23:16:46 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.31
headline件数: 30

## 見出し

- [CNBC Markets] Micron stock jumps 15% as soaring prices from memory crunch lead to quadrupling of revenue (SPX|NASDAQ)
- [CNBC Markets] White House requests $87.6 billion supplemental spending for Iran war, farm aid (未分類)
- [CNBC Markets] South Korea’s IPO bust clouds equity markets as Chaebol structure restrains listings (未分類)
- [CNBC Markets] Qualcomm stock pops 15% after chipmaker almost doubles projection for 2029 non-handset revenue (NASDAQ)
- [CNBC Markets] Trump meets defense CEOs as Iran operations strain U.S. missile stockpiles (未分類)
- [CNBC Markets] Trump cancels signing of bipartisan housing bill ahead of tense meeting with GOP senators (未分類)
- [CNBC Markets] Federal Reserve says U.S. banks can withstand $708 billion in losses amid overhaul of capital rules (US10Y|DXY)
- [CNBC Markets] Anthropic accuses Alibaba of campaign to 'brazenly' and 'illicitly' extract AI capabilities (未分類)
- [CNBC Markets] JPMorgan Chase unveils $50 billion buyback, Goldman Sachs raises dividend after Fed stress test (GOLD|US10Y|DXY)
- [CNBC Markets] France suffers major power outage as Europe sizzles in record-breaking heat (未分類)
- [CNBC Markets] Federal student loans have a new interest rate discount — here's who qualifies (US10Y|DXY)
- [CNBC Markets] Energy secretary says U.S. has ended Iran's ability to close Strait of Hormuz (WTI)
- [CNBC Markets] Identity theft victims face 'unconscionable' IRS delays, report says (未分類)
- [CNBC Markets] Cerebras CEO says margin forecast was 'misunderstood' as stock plummets after earnings (SPX|NASDAQ)
- [CNBC Markets] Toyota gains on General Motors in new U.S. sales forecast: 'GM may be looking over their shoulder' (未分類)
- [CNBC Markets] Bitcoin falls back under $60,000, hitting its lowest level since October 2024 (BTC|SPX|NASDAQ)
- [CNBC Markets] Micron earnings are set to send the market on a wild ride — and a new ETF may add to the volatility (BTC|SPX|NASDAQ|VIX)
- [CNBC Markets] House passes affordable housing bill, sends it to Trump's desk (未分類)
- [CNBC Markets] This industrial play has been a quiet winner in 2026. Why the stock has more room to go (未分類)
- [CNBC Markets] Traders are getting worried the chip stock bull market is cracking. How to protect yourself (BTC|SPX|NASDAQ)
- [CNBC Markets] Nvidia's Huang calls black market data centers made of smuggled parts a 'dead end' (未分類)
- [CNBC Markets] Why energy could be a great place to invest even with oil prices retreating — 5 stocks to buy (WTI|SPX)
- [CNBC Markets] Bessent sees GDP growth booming again this year. Kalshi traders see little chance of that (US10Y|DXY)
- [CNBC Markets] New meme stock Wendy's soars more than 25% with trading halted at one point (未分類)
- [CNBC Markets] U.S. crude oil briefly dips below $70 as tankers transit Strait of Hormuz (WTI)
- [CNBC Markets] Treasury Secretary Bessent says U.S. GDP growth can return to 3% before end of the year (WTI|US10Y|DXY)
- [CNBC Markets] Amazon's Zoox unveils redesigned robotaxi ahead of upcoming expansion (未分類)
- [CNBC Markets] Slate Auto says $24,950 electric truck will be profitable; targets positive cash flow next year (未分類)
- [CNBC Markets] Trump claims Iran has assured U.S. there won't be tolls on the Strait of Hormuz (未分類)
- [CNBC Markets] Kalshi CEO says prediction market thinking about IPO, but not for this year (未分類)
