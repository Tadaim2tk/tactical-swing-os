# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-16 07:42:17 JST
生成日時（UTC）: 2026-07-15 22:42:17 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.26
ニュース市場バイアス: neutral
ニュース矛盾スコア: 18.47
主要テーマ: geopolitical_risk, inflation_pressure
日本語要約: 地政学リスク、インフレ圧力はありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 36.93
- risk_off_news_score: 18.47
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 18.47
- gold_safe_haven_news_score: 18.47
- oil_supply_risk_news_score: 55.4
- crypto_liquidity_news_score: 18.47
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 100.0
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 18.47
- central_bank_dovish_score: 18.47
- news_confidence: 100.0

## Top News Drivers

- Wholesale prices unexpectedly declined 0.3% in June on big drop in gasoline (中銀ハト派)
- Trump says Iran wants to meet as U.S. fires more strikes; analysts warn of 'forever war' risk (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
- You are missing the bond deal of the decade — and it is guaranteed to beat inflation (インフレ圧力 / 金利圧力候補)
- This powerful stock-market momentum trade has hit a wall after seeing biggest unwind since 2001 (リスクオフ要因)
- Ostium suffers $18 million exploit as oracle attack wave continues to hit DeFi (地政学リスク / リスクオフ要因)
- Bitcoin rally cools as investors digest inflation data, oil clouds outlook (インフレ圧力 / リスクオン要因 / 金利圧力候補)
- Crypto steadies as Middle East tensions counter U.S. inflation report boost (地政学リスク / インフレ圧力 / 原油供給リスク / リスクオフ要因 / 金利圧力候補)
- Live updates: Bitcoin rises near $65,000 as markets get more good inflation news (インフレ圧力 / 暗号資産流動性 / 金利圧力候補)
- Bitcoin nears $65,000 as cooling U.S. inflation guts the Fed rate-hike trade (インフレ圧力 / 金利圧力候補)
- The Clarity Act isn't a ticket to sanctions evasion, actually (地政学リスク / 原油供給リスク / リスクオフ要因)
