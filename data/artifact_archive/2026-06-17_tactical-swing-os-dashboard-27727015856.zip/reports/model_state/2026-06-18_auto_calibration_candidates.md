# Auto Calibration Candidates

## 1. 概要

- 生成日時JST: 2026-06-18 08:47:02 JST
- candidate_status: active
- candidate_count: 46
- increase_count: 0
- decrease_count: 0
- hold_count: 46
- insufficient_data_count: 0
- blocked_count: 0
- recommended_next_action: wait_for_more_data
- requires_human_approval: true
- patch_applied: false
- weights_json_updated: false
- generate_signal_updated: false
- apply_automatically: false

## 2. 候補一覧

| candidate_id | asset | category | target | factor | classification | current_value | suggested_delta | suggested_value | confidence | sample_size | source | rationale |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| AC_0001_20260618_narrative_crypto_liquidity_narrative_weight_adjustment |  | narrative | crypto_liquidity | narrative_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 38 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0002_20260618_narrative_dollar_strength_narrative_weight_adjustment |  | narrative | dollar_strength | narrative_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 38 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0003_20260618_narrative_geopolitical_risk_narrative_weight_adjustment |  | narrative | geopolitical_risk | narrative_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 38 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0004_20260618_narrative_oil_supply_risk_narrative_weight_adjustment |  | narrative | oil_supply_risk | narrative_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 38 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0005_20260618_narrative_rate_pressure_narrative_weight_adjustment |  | narrative | rate_pressure | narrative_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 38 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0006_20260618_narrative_risk_off_narrative_weight_adjustment |  | narrative | risk_off | narrative_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 38 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0007_20260618_narrative_risk_on_narrative_weight_adjustment |  | narrative | risk_on | narrative_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 38 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0008_20260618_rank_B_rank_confidence_adjustment |  | rank | B | rank_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 31 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0009_20260618_side_LONG_side_bias_adjustment |  | side | LONG | side_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 15 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |
| AC_0010_20260618_type_B-Watch_setup_type_weight_adjustment |  | type | B-Watch | setup_type_weight | hold | 1.0 | 0.0 | 1.0 | 0.2 | 20 | proposal_adoption_tracking | Fallback tracking row; no calibration change is suggested. |

## 3. ブロック/保留候補

該当なし

## 4. 注意事項

- Auto Calibration Candidatesは将来の重み変更候補を作るだけです
- weights.jsonは更新しません
- patchは適用しません
- generate_signal.pyは変更しません
- Google Sheetsへの書き込みは行いません
- 実売買・発注・XM操作は行いません
- すべての候補は人間承認が必須です
