# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-18 08:46:35 JST
取得日時（UTC）: 2026-06-17 23:46:35 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.45
headline件数: 30

## 見出し

- [CNBC Markets] Here are the five big takeaways from Kevin Warsh's first meeting as Fed chairman (US10Y|DXY)
- [CNBC Markets] Trump says he likes idea of blaming Vance if Iran deal doesn't work out (未分類)
- [CNBC Markets] Jeffrey Gundlach says Fed's Warsh is not going to be the 'easy money' chairman many hoped for (US10Y|DXY)
- [CNBC Markets] Defense contractors would be barred from buying back their stock in bill approved by Senate panel (未分類)
- [CNBC Markets] Analysis: Chairman Kevin Warsh’s task forces are the key to understanding the new Fed (US10Y|DXY)
- [CNBC Markets] Chairman Warsh abstains from giving rate forecast as several members signal a hike in 2026 (US10Y|DXY)
- [CNBC Markets] 2-year Treasury yield rockets higher as many Fed officials signal possible hike this year (US10Y|DXY)
- [CNBC Markets] Chairman Warsh drastically alters Fed rate statement. Here's what's changed (US10Y|DXY)
- [CNBC Markets] CME CEO Terrence Duffy says the exchange operator will sue CFTC over perpetual futures (未分類)
- [CNBC Markets] JetBlue to reduce Newark, LaGuardia footprint as it forges ahead in Fort Lauderdale (NASDAQ)
- [CNBC Markets] Fed holds interest rates steady: Here's what that means for credit cards, savings rates, mortgages and car loans (US10Y|DXY)
- [CNBC Markets] 'Passive' investors who dodged bitcoin are now forced to own SpaceX, which is three times more volatile (BTC)
- [CNBC Markets] Fed holds rates steady, pares down statement to remove cutting bias (US10Y|DXY)
- [CNBC Markets] Trump sabotages Senate bid to fast-track Clayton as DNI, committee scuttles hearing (未分類)
- [CNBC Markets] CEOs of Anthropic and Google DeepMind call for U.S.-led AI coalition in meeting at G7 (NASDAQ)
- [CNBC Markets] Allbirds continues AI pivot with name change and CEO hire, sending stock soaring (未分類)
- [CNBC Markets] The market didn't like what it heard from the Fed and its new leader Kevin Warsh (SPX|US10Y|DXY)
- [CNBC Markets] SpaceX posts first losing day as stock sinks 5%, losing momentum after a multiday rally (未分類)
- [CNBC Markets] CarMax shares fall after used car retailer reports earnings beats, CEO details turnaround plan (SPX|NASDAQ)
- [CNBC Markets] Amazon AI exec predicts first 'commercially useful' quantum computers in 5-7 years (NASDAQ)
- [CNBC Markets] Less than one-third of global workers feel their jobs are safe, ADP survey data shows (未分類)
- [CNBC Markets] UniQure to seek FDA approval for Huntington's disease gene therapy after previous clash with agency (WTI)
- [CNBC Markets] Carvana’s new vehicle strategy turns dealership into ‘playground,’ test-drive center with sales all online (未分類)
- [CNBC Markets] Target, Walmart and Amazon among brands losing LGBTQ+ consumer spending, new survey says (未分類)
- [CNBC Markets] Strait of Hormuz threat level downgraded after Iran deal, says U.S.-led maritime security group (未分類)
- [CNBC Markets] SpaceX surge is creating a unique hedging opportunity (未分類)
- [CNBC Markets] CNBC to wade further into live sports with 11 simulcast WNBA games (未分類)
- [CNBC Markets] Making money in this market requires rigor and passion — just not in equal parts (未分類)
- [CNBC Markets] From supply shock to oil glut: IEA flags scale of demand destruction caused by Iran war (WTI)
- [CNBC Markets] CME Group's Terry Duffy to step down in 2027, CFO Lynne Fitzpatrick to become CEO (未分類)
