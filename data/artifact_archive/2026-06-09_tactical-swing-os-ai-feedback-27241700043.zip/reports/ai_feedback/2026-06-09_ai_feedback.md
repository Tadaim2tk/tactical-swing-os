# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-10 08:09:21 JST
Actions実行時刻（UTC）: 2026-06-09 23:09:21 UTC
対象日: 2026-06-09
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドルは中立 / 金利圧力は限定的 / ボラティリティは落ち着き
- ニュースモード: ニュースナラティブ未取得
- ニュース市場バイアス: insufficient_data
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_only
- 評価データソース: latest_evaluations
- latest_evaluations_available: True
- fallback_used: False
- risk_on: 47.58
- risk_off: 52.21
- dollar: 50.35
- rate: 50.41
- volatility: 53.58
- news_confidence: 0.0
- シグナル整合性: aligned=0, conflicted=1, neutral=8, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 47.58 | 52.21 | 50.35 | 50.41 | 52.24 | 47.5 | 53.58 | 100.0 |
| BTC | 47.58 | 52.21 | 50.35 | 50.41 | 52.24 | 47.5 | 53.58 | 100.0 |
| DXY | 47.58 | 52.21 | 50.35 | 50.41 | 52.24 | 47.5 | 53.58 | 100.0 |
| GOLD | 47.58 | 52.21 | 50.35 | 50.41 | 52.24 | 47.5 | 53.58 | 100.0 |
| NASDAQ | 47.58 | 52.21 | 50.35 | 50.41 | 52.24 | 47.5 | 53.58 | 100.0 |
| SPX | 47.58 | 52.21 | 50.35 | 50.41 | 52.24 | 47.5 | 53.58 | 100.0 |
| US10Y | 47.58 | 52.21 | 50.35 | 50.41 | 52.24 | 47.5 | 53.58 | 100.0 |
| USDJPY | 47.58 | 52.21 | 50.35 | 50.41 | 52.24 | 47.5 | 53.58 | 100.0 |
| VIX | 47.58 | 52.21 | 50.35 | 50.41 | 52.24 | 47.5 | 53.58 | 100.0 |
| WTI | 47.58 | 52.21 | 50.35 | 50.41 | 52.24 | 47.5 | 53.58 | 100.0 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260609_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260609_BTC_SHORT_B-Watch | BTC | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold | neutral | 4 | BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。 |
| 20260609_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260609_GOLD_SHORT_B-Watch | GOLD | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative | neutral | -4 | GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 |
| 20260609_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | NO_TRADE | atr_too_high|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260609_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | NO_TRADE | rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260609_US10Y_NONE_NO_TRADE | US10Y | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rr_too_low|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260609_VIX_NONE_NO_TRADE | VIX | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low|range_middle|overextended | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260609_WTI_SHORT_B-Watch | WTI | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold | conflicted | -13 | WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
| 20260606_BTC_SHORT_TREND | BTC | loss_sl | -1.0 | 損切り到達。Entry/SL幅またはrank判定の再確認が必要です。 | unknown | 追加サンプルで検証します。 |

## 5. 明日に向けた補正仮説

- ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: False
- news_mode_summary: ニュースナラティブ未取得
- top_news_drivers: ニュースドライバーなし

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-09T23:09:21,2026-06-10 08:09:21 JST,2026-06-09 23:09:21 UTC,2026-06-09,USDJPY,20260609_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,47.58,52.21,50.35,50.41,52.24,47.5,53.58,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-09T23:09:21,2026-06-10 08:09:21 JST,2026-06-09 23:09:21 UTC,2026-06-09,BTC,20260609_BTC_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold,neutral,4,47.58,52.21,50.35,50.41,52.24,47.5,53.58,100.0,0.0,market_proxy_only,,,context_neutral,BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。,BTC SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-09T23:09:21,2026-06-10 08:09:21 JST,2026-06-09 23:09:21 UTC,2026-06-09,DXY,20260609_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rr_too_low,neutral,0,47.58,52.21,50.35,50.41,52.24,47.5,53.58,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-09T23:09:21,2026-06-10 08:09:21 JST,2026-06-09 23:09:21 UTC,2026-06-09,GOLD,20260609_GOLD_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative,neutral,-4,47.58,52.21,50.35,50.41,52.24,47.5,53.58,100.0,0.0,market_proxy_only,,,context_neutral,GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。,GOLD SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-09T23:09:21,2026-06-10 08:09:21 JST,2026-06-09 23:09:21 UTC,2026-06-09,NASDAQ,20260609_NASDAQ_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,atr_too_high|rr_too_low,neutral,0,47.58,52.21,50.35,50.41,52.24,47.5,53.58,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,NASDAQ NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-09T23:09:21,2026-06-10 08:09:21 JST,2026-06-09 23:09:21 UTC,2026-06-09,SPX,20260609_SPX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,rr_too_low,neutral,0,47.58,52.21,50.35,50.41,52.24,47.5,53.58,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,SPX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-09T23:09:21,2026-06-10 08:09:21 JST,2026-06-09 23:09:21 UTC,2026-06-09,US10Y,20260609_US10Y_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rr_too_low|pullback_to_ma20,neutral,0,47.58,52.21,50.35,50.41,52.24,47.5,53.58,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,US10Y NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-09T23:09:21,2026-06-10 08:09:21 JST,2026-06-09 23:09:21 UTC,2026-06-09,VIX,20260609_VIX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low|range_middle|overextended,neutral,0,47.58,52.21,50.35,50.41,52.24,47.5,53.58,100.0,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,VIX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-09T23:09:21,2026-06-10 08:09:21 JST,2026-06-09 23:09:21 UTC,2026-06-09,WTI,20260609_WTI_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold,conflicted,-13,47.58,52.21,50.35,50.41,52.24,47.5,53.58,100.0,0.0,market_proxy_only,,,context_warning,WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。,WTI SHORT は市場文脈と衝突。明日はrank/entry条件を慎重化する仮説。,False,latest_evaluations,True,False

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-09T23:09:21",
  "generated_at_jst": "2026-06-10 08:09:21 JST",
  "generated_at_utc": "2026-06-09 23:09:21 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-09",
  "data_source": "Google Sheets",
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 17,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "market_mode_summary": "リスクオン/オフは中立 / ドルは中立 / 金利圧力は限定的 / ボラティリティは落ち着き",
  "news_narrative_available": false,
  "news_mode_summary": "ニュースナラティブ未取得",
  "top_news_drivers": [],
  "narrative_source_mix": "market_proxy_only",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 47.58,
      "risk_off_score": 52.21,
      "dollar_strength_score": 50.35,
      "rate_pressure_score": 50.41,
      "gold_safe_haven_score": 52.24,
      "oil_supply_risk_proxy_score": 48.89,
      "crypto_liquidity_score": 47.5,
      "equity_momentum_score": 47.05,
      "volatility_stress_score": 53.58,
      "narrative_confidence": 100.0,
      "asset_change_pct": null
    },
    {
      "asset": "BTC",
      "risk_on_score": 47.58,
      "risk_off_score": 52.21,
      "dollar_strength_score": 50.35,
      "rate_pressure_score": 50.41,
      "gold_safe_haven_score": 52.24,
      "oil_supply_risk_proxy_score": 48.89,
      "crypto_liquidity_score": 47.5,
      "equity_momentum_score": 47.05,
      "volatility_stress_score": 53.58,
      "narrative_confidence": 100.0,
      "asset_change_pct": -1.6016
    },
    {
      "asset": "DXY",
      "risk_on_score": 47.58,
      "risk_off_score": 52.21,
      "dollar_strength_score": 50.35,
      "rate_pressure_score": 50.41,
      "gold_safe_haven_score": 52.24,
      "oil_supply_risk_proxy_score": 48.89,
      "crypto_liquidity_score": 47.5,
      "equity_momentum_score": 47.05,
      "volatility_stress_score": 53.58,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.079
    },
    {
      "asset": "GOLD",
      "risk_on_score": 47.58,
      "risk_off_score": 52.21,
      "dollar_strength_score": 50.35,
      "rate_pressure_score": 50.41,
      "gold_safe_haven_score": 52.24,
      "oil_supply_risk_proxy_score": 48.89,
      "crypto_liquidity_score": 47.5,
      "equity_momentum_score": 47.05,
      "volatility_stress_score": 53.58,
      "narrative_confidence": 100.0,
      "asset_change_pct": -1.6052
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 47.58,
      "risk_off_score": 52.21,
      "dollar_strength_score": 50.35,
      "rate_pressure_score": 50.41,
      "gold_safe_haven_score": 52.24,
      "oil_supply_risk_proxy_score": 48.89,
      "crypto_liquidity_score": 47.5,
      "equity_momentum_score": 47.05,
      "volatility_stress_score": 53.58,
      "narrative_confidence": 100.0,
      "asset_change_pct": -1.0048
    },
    {
      "asset": "SPX",
      "risk_on_score": 47.58,
      "risk_off_score": 52.21,
      "dollar_strength_score": 50.35,
      "rate_pressure_score": 50.41,
      "gold_safe_haven_score": 52.24,
      "oil_supply_risk_proxy_score": 48.89,
      "crypto_liquidity_score": 47.5,
      "equity_momentum_score": 47.05,
      "volatility_stress_score": 53.58,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.3204
    },
    {
      "asset": "US10Y",
      "risk_on_score": 47.58,
      "risk_off_score": 52.21,
      "dollar_strength_score": 50.35,
      "rate_pressure_score": 50.41,
      "gold_safe_haven_score": 52.24,
      "oil_supply_risk_proxy_score": 48.89,
      "crypto_liquidity_score": 47.5,
      "equity_momentum_score": 47.05,
      "volatility_stress_score": 53.58,
      "narrative_confidence": 100.0,
      "asset_change_pct": -0.396
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 47.58,
      "risk_off_score": 52.21,
      "dollar_strength_score": 50.35,
      "rate_pressure_score": 50.41,
      "gold_safe_haven_score": 52.24,
      "oil_supply_risk_proxy_score": 48.89,
      "crypto_liquidity_score": 47.5,
      "equity_momentum_score": 47.05,
      "volatility_stress_score": 53.58,
      "narrative_confidence": 100.0,
      "asset_change_pct": 0.01
    },
    {
      "asset": "VIX",
      "risk_on_score": 47.58,
      "risk_off_score": 52.21,
      "dollar_strength_score": 50.35,
      "rate_pressure_score": 50.41,
      "gold_safe_haven_score": 52.24,
      "oil_supply_risk_proxy_score": 48.89,
      "crypto_liquidity_score": 47.5,
      "equity_momentum_score": 47.05,
      "volatility_stress_score": 53.58,
      "narrative_confidence": 100.0,
      "asset_change_pct": 9.2358
    },
    {
      "asset": "WTI",
      "risk_on_score": 47.58,
      "risk_off_score": 52.21,
      "dollar_strength_score": 50.35,
      "rate_pressure_score": 50.41,
      "gold_safe_haven_score": 52.24,
      "oil_supply_risk_proxy_score": 48.89,
      "crypto_liquidity_score": 47.5,
      "equity_momentum_score": 47.05,
      "volatility_stress_score": 53.58,
      "narrative_confidence": 100.0,
      "asset_change_pct": -2.8374
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260609_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260609_BTC_SHORT_B-Watch",
      "asset": "BTC",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 4,
      "narrative_comment": "BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。"
    },
    {
      "signal_id": "20260609_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260609_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": -4,
      "narrative_comment": "GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。"
    },
    {
      "signal_id": "20260609_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "atr_too_high|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260609_SPX_NONE_NO_TRADE",
      "asset": "SPX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260609_US10Y_NONE_NO_TRADE",
      "asset": "US10Y",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rr_too_low|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260609_VIX_NONE_NO_TRADE",
      "asset": "VIX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low|range_middle|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260609_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold",
      "narrative_alignment": "conflicted",
      "narrative_alignment_score": -13,
      "narrative_comment": "WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "signal_id": "20260606_BTC_SHORT_TREND",
      "asset": "BTC",
      "outcome": "loss_sl",
      "r_multiple": -1.0,
      "technical_view": "損切り到達。Entry/SL幅またはrank判定の再確認が必要です。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    }
  ],
  "improvement_hypotheses": [
    "ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
