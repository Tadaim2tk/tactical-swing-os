# Tactical Swing OS Weekly Review

## 1. 週次結論

次週モードは「通常」、最大日次リスクは 0.5% です。 データ不足 週次R損益は横ばいです。

## 2. 週次サマリー

| week_start | week_end | total_signals | a_signals | b_signals | no_trade_signals | closed_signals | pending_signals | skipped_signals | win_rate | profit_factor | total_r | average_r | max_win_r | max_loss_r | best_asset | worst_asset | next_week_mode | max_daily_risk_pct | rule_change_1 | rule_change_2 | rule_change_3 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-05-31 | 2026-06-06 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |  |  | 通常 | 0.5 | データ不足 |  |  |

## 3. Rank別成績

| rank | signals | closed | win_rate | total_r | average_r |
| --- | --- | --- | --- | --- | --- |
| A | 0 | 0 | 0.0 | 0.0 | 0.0 |
| B | 0 | 0 | 0.0 | 0.0 | 0.0 |
| NO_TRADE | 0 | 0 | 0.0 | 0.0 | 0.0 |
| その他 | 0 | 0 | 0.0 | 0.0 | 0.0 |

## 4. 資産別成績

_該当なし_

## 5. Side別成績

| side | signals | closed | win_rate | total_r | average_r | best_r | worst_r |
| --- | --- | --- | --- | --- | --- | --- | --- |
| LONG | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| SHORT | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| NONE | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |

## 6. エラー分類

| error_type | count |
| --- | --- |
| 未分類 | 0 |

## 7. 取り逃し監査

MFE未実装のため暫定監査不可

_該当なし_

## 8. モデル更新メモ

- データ不足
- 特記事項なし
- 特記事項なし

## 9. REVIEW_LOG CSV

```csv
week_start,week_end,total_signals,a_signals,b_signals,no_trade_signals,closed_signals,pending_signals,skipped_signals,win_rate,profit_factor,total_r,average_r,max_win_r,max_loss_r,best_asset,worst_asset,next_week_mode,max_daily_risk_pct,rule_change_1,rule_change_2,rule_change_3
2026-05-31,2026-06-06,0,0,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,,,通常,0.5,データ不足,,
```

## 10. REVIEW_LOG JSON

```json
[
  {
    "week_start":"2026-05-31",
    "week_end":"2026-06-06",
    "total_signals":0,
    "a_signals":0,
    "b_signals":0,
    "no_trade_signals":0,
    "closed_signals":0,
    "pending_signals":0,
    "skipped_signals":0,
    "win_rate":0.0,
    "profit_factor":0.0,
    "total_r":0.0,
    "average_r":0.0,
    "max_win_r":0.0,
    "max_loss_r":0.0,
    "best_asset":"",
    "worst_asset":"",
    "next_week_mode":"通常",
    "max_daily_risk_pct":0.5,
    "rule_change_1":"データ不足",
    "rule_change_2":"",
    "rule_change_3":""
  }
]
```
