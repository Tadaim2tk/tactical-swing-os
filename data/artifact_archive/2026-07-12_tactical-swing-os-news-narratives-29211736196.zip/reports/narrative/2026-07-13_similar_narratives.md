# Similar Narrative Cases（類似局面検索 v0）

## 1. 概要

- 基準日: 2026-07-13
- status: **ok**
- embedding provider: `openai:text-embedding-3-small` / 過去局面 11 日から上位 5 日を検索。

## 2. 類似局面と、その後の実リターン（5/10/20営業日）

| rank | similar_date | similarity | asset | +5d | +10d | +20d | status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 2026-07-12 | 0.8259 |  | — | — | — | no_price_data |
| 2 | 2026-07-10 | 0.8079 |  | — | — | — | no_price_data |
| 3 | 2026-07-11 | 0.7867 |  | — | — | — | no_price_data |
| 4 | 2026-07-09 | 0.7842 |  | — | — | — | no_price_data |
| 5 | 2026-07-08 | 0.7795 |  | — | — | — | no_price_data |

## 3. 注意

- allowed_for_signal=true の record のみ・基準日より前の局面のみを検索（lookahead-safe）。
- この出力は表示・記録のみで、signal score には接続していない（connected_to_signal_score=false）。
- 実売買・発注は行わない。
