# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-13 07:33:01 JST
生成日時（UTC）: 2026-07-12 22:33:01 UTC
headline件数: 57
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.92
ニュース市場バイアス: neutral
ニュース矛盾スコア: 37.23
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 37.23
- risk_off_news_score: 55.84
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 0.0
- oil_supply_risk_news_score: 18.61
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 55.84
- inflation_pressure_news_score: 37.23
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Sen. Lindsey Graham, influential lawmaker and Trump ally, dies at 71 after a brief illness (地政学リスク / リスクオフ要因)
- Here are the 3 big things we're watching in the stock market this week (インフレ圧力 / 金利圧力候補)
- Trump threatens to 'decimate' Iran if it tries to kill him, as Treasury sanctions alleged Iranian financier (地政学リスク / 原油供給リスク / リスクオフ要因)
- Oil prices rise, stock futures dip after latest flare-up of strikes between U.S. and Iran (インフレ圧力 / 金利圧力候補)
- You don’t have to be rich to be financially independent. Here’s how to take control of your money. (リスクオフ要因)
- The stock-market rally now hinges more on AI than oil (リスクオン要因)
- Crypto IPO market stalls as capital rotates to AI and macro uncertainty weighs (リスクオフ要因)
- Bitcoin analysts predict $300,000–$500,000 price in 2029. The math says no (リスクオン要因)
- Russia stocks lower at close of trade; MOEX Russia Index unchanged (地政学リスク / リスクオフ要因)
- 5 big analyst AI moves: SpaceX gets a Street-high target, Samsung selloff overdone (リスクオフ要因)
