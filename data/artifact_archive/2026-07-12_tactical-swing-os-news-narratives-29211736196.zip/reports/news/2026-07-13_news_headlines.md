# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-13 07:33:00 JST
取得日時（UTC）: 2026-07-12 22:33:00 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.92
headline件数: 57

## 見出し

- [CNBC Markets] Sen. Lindsey Graham, influential lawmaker and Trump ally, dies at 71 after a brief illness (未分類)
- [CNBC Markets] McConnell provides health update after long unexplained absence; says he suffered fall (未分類)
- [CNBC Markets] Graham’s death complicates myriad GOP goals in Congress (未分類)
- [CNBC Markets] Elon Musk and Sam Altman spar on X after Apple files OpenAI lawsuit (未分類)
- [CNBC Markets] Who will replace Lindsey Graham in the Senate? (未分類)
- [CNBC Markets] Majority of U.S. workers support an AI wealth fund as tech layoffs surge, survey finds (NASDAQ)
- [CNBC Markets] The best states to live in for 2026: No. 1 has a six-year winning streak (未分類)
- [CNBC Markets] These are America’s 10 worst states to live in for 2026 (未分類)
- [CNBC Markets] ‘Almost unlimited’: Execs says AI demand remains strong even as enterprises move to ‘valuemaxxing’ (SPX|NASDAQ)
- [CNBC Markets] 'Funflation' hits home: Why staying in isn't the cost-saver it used to be (未分類)
- [CNBC Markets] New housing law targets affordability — what it means for homebuyers and sellers (未分類)
- [CNBC Markets] Top Wall Street analysts are confident about these 3 stocks for the long haul (SPX|VIX)
- [CNBC Markets] Student loan borrowers on new RAP plan can lose key benefits if they pay even one day late (US10Y|DXY)
- [CNBC Markets] Apple sues OpenAI alleging trade secret theft, says scheme was 'at every level' (未分類)
- [CNBC Markets] Here are the 3 big things we're watching in the stock market this week (SPX|NASDAQ)
- [CNBC Markets] Trump threatens to 'decimate' Iran if it tries to kill him, as Treasury sanctions alleged Iranian financier (US10Y|DXY)
- [CNBC Markets] Burnout, frustration and heartbreak: Amazon layoffs take their toll in saturated job market (未分類)
- [CNBC Markets] I've studied more than 200 kids: Parents whose kids still confide in them as adults do 7 things early on (SPX)
- [CNBC Markets] These underperforming trades could yield big returns over next six months (BTC|SPX|US10Y)
- [CNBC Markets] Berkshire Hathaway gains ground, but still trails the S&P 500 as '26 enters second half (SPX)
- [CNBC Markets] A tiny GLP-1 implant is the latest bet to help patients maintain their weight loss (未分類)
- [CNBC Markets] AstraZeneca's trial flop raises a bigger question: Is its pipeline premium becoming more vulnerable? (未分類)
- [CNBC Markets] Trump Accounts: Who is eligible, how $1,000 deposits work and how to open one (未分類)
- [CNBC Markets] While Musk's Neuralink drills into skulls, China's BrainCo bets the future of brain tech is wearable (NASDAQ)
- [CNBC Markets] From booksmaxxing to looksmaxxing: Why the viral trends concern some mental health experts (未分類)
- [MarketWatch Top Stories] Oil prices rise, stock futures dip after latest flare-up of strikes between U.S. and Iran (WTI)
- [MarketWatch Top Stories] Why Citigroup is the one to watch when banks report earnings this week (SPX|NASDAQ)
- [MarketWatch Top Stories] You don’t have to be rich to be financially independent. Here’s how to take control of your money. (未分類)
- [MarketWatch Top Stories] Earnings estimates have been following an unusual pattern this time around (SPX|NASDAQ)
- [MarketWatch Top Stories] The No. 1 decision for aging retirees: Stay at home or move into a senior community? (未分類)
- [MarketWatch Top Stories] The stock-market rally now hinges more on AI than oil (WTI|SPX|NASDAQ)
- [MarketWatch Top Stories] My insurance company said my roof lost a few tiles. Loss adjusters found $10,000 in storm damage. How could this happen? (未分類)
- [MarketWatch Top Stories] ‘I get $1,460 in Social Security’: My millionaire ex-husband, 74, refuses to pay alimony. What can I do? (未分類)
- [MarketWatch Top Stories] ‘It’s heartbreaking’: My brother claimed Social Security at 70. He died from cancer after one payment. Why wait to claim? (未分類)
- [MarketWatch Top Stories] Is it better to spend my savings now so I can delay taking Social Security? How do I choose? (未分類)
- [CoinDesk] Signs of life?: State of Crypto (BTC)
- [CoinDesk] Stablecoin market cap has shrunk by $10 billion since May, but analyst sees no reason to panic (USDJPY|DXY)
- [CoinDesk] Bitcoin is nearing a power law support line Fidelity has tracked since 2015 (BTC)
- [CoinDesk] Bitcoin, ether little changed as U.S. launches fresh Iran strikes (BTC)
- [CoinDesk] Ripple once weighed shutting down and handing XRP to shareholders, CEO says (未分類)
- [CoinDesk] Bitcoin’s BIP 110 fork deadline nears with miner support at zero (BTC)
- [CoinDesk] Lending protocol Bonzo loses 77% of value locked as $9 million oracle exploit rattles Hedera (未分類)
- [CoinDesk] Crypto IPO market stalls as capital rotates to AI and macro uncertainty weighs (BTC)
- [CoinDesk] The UK has finally shown it’s serious about crypto (BTC)
- [CoinDesk] Bitcoin treasury company Empery Digital sold about half of its BTC stack (BTC|US10Y|DXY)
- [CoinDesk] AI found an Ethereum bug that could take validators offline, but humans had to prove it (BTC)
- [CoinDesk] Bitcoin analysts predict $300,000–$500,000 price in 2029. The math says no (BTC)
- [Investing.com Commodities] What do investors need to be watching in DC in 2026H2? (未分類)
- [Investing.com Commodities] What’s driving the sell-off in AI-related stocks? (SPX)
- [Investing.com Commodities] Russia stocks lower at close of trade; MOEX Russia Index unchanged (SPX)
