# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-08 01:01:29 JST
生成日時（UTC）: 2026-06-07 16:01:29 UTC
headline件数: 66
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 74.12
- risk_off_news_score: 74.12
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 100.0
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 18.53
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 37.06
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 37.06
- news_confidence: 100.0

## Top News Drivers

- 100 days of the Iran war: How global markets and the economy have been affected, in charts (nan)
- Inflation inside the electronics you buy may soon become a bit more sticky (nan)
- Chinese EVs may hit U.S. within a few years, one way or another (nan)
- U.S. confirms second Texas screwworm case, Canada restricts livestock imports (nan)
- Abel goes his own way with new Berkshire investments, including billions for AI (nan)
- Wall Street's 'fear gauge' punches back as the 'crash up' in chip stocks finally reverses (SPX|NASDAQ|VIX)
- Social media bans on teens risk strengthening Big Tech's grip on the sector, Bluesky exec warns (NASDAQ)
- Amazon unveils latest warehouse robot as tech giants continue AI layoffs (NASDAQ)
- Mythos rejuvenated the cybersecurity sector. Earnings put the recent rally to the test (SPX|NASDAQ)
- Iran's threats against this Red Sea choke point are a big vulnerability for the oil market (WTI)
