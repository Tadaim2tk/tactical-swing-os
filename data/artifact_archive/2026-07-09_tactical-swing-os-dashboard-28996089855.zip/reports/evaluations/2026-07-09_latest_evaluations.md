# Latest Evaluations Report

## 1. 概要

* 生成日時JST: 2026-07-09 14:23:30 JST
* 入力行数: 1689
* unique signal数: 87
* 最新評価行数: 87
* PENDING_REEVALUATIONS由来の最新評価数: 82
* EVALUATIONS由来の最新評価数: 5

## 2. 決着済み

| signal_id | asset | side | rank | outcome | r_multiple | latest_source | latest_reason |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | loss_sl | -1.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B | win_tp1 | 1.087 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | win_tp1 | 1.087 | pending_reevaluations | latest_by_reevaluation_at |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B | loss_sl | -1.0 | pending_reevaluations | latest_by_reevaluation_at |
| 20260622_US10Y_LONG_A-Pullback | US10Y | LONG | B | loss_sl | -1.0 | pending_reevaluations | latest_by_reevaluation_at |

## 3. 未決着

| signal_id | asset | side | rank | status | evaluation_status | outcome | latest_source | latest_reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B | no_entry | pending | no_entry | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_DXY_LONG_A-Momentum | DXY | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_US10Y_LONG_A-Pullback | US10Y | LONG | B | no_entry | pending | no_entry | pending_reevaluations | latest_by_reevaluation_at |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_US10Y_LONG_B-Watch | US10Y | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260609_BTC_SHORT_B-Watch | BTC | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260609_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260609_WTI_SHORT_B-Watch | WTI | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260610_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260611_WTI_SHORT_B-Watch | WTI | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260612_WTI_SHORT_B-Watch | WTI | SHORT | B | no_entry | pending | no_entry | pending_reevaluations | latest_by_reevaluation_at |
| 20260614_NASDAQ_LONG_A-Pullback | NASDAQ | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260614_SPX_LONG_A-Pullback | SPX | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260614_WTI_SHORT_B-Watch | WTI | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260615_NASDAQ_LONG_B-Watch | NASDAQ | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260615_SPX_LONG_B-Watch | SPX | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260615_VIX_SHORT_TREND | VIX | SHORT | A | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260615_WTI_SHORT_B-Watch | WTI | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260616_NASDAQ_LONG_B-Watch | NASDAQ | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260616_SPX_LONG_B-Watch | SPX | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260616_VIX_SHORT_B-Watch | VIX | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260616_WTI_SHORT_B-Watch | WTI | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |

## 4. 再評価履歴あり

| signal_id | asset | side | rank | outcome | previous_rows_count | latest_source | latest_reason |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | loss_sl | 29 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B | win_tp1 | 29 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B | no_entry | 29 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | win_tp1 | 29 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_DXY_LONG_A-Momentum | DXY | LONG | B | open_unresolved | 28 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 28 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_US10Y_LONG_A-Pullback | US10Y | LONG | B | no_entry | 28 | pending_reevaluations | latest_by_reevaluation_at |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B | loss_sl | 32 | pending_reevaluations | latest_by_reevaluation_at |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 32 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 32 | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 31 | pending_reevaluations | latest_by_reevaluation_at |
| 20260608_US10Y_LONG_B-Watch | US10Y | LONG | B | open_unresolved | 31 | pending_reevaluations | latest_by_reevaluation_at |
| 20260609_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 30 | pending_reevaluations | latest_by_reevaluation_at |
| 20260609_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 30 | pending_reevaluations | latest_by_reevaluation_at |
| 20260609_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 30 | pending_reevaluations | latest_by_reevaluation_at |
| 20260610_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 29 | pending_reevaluations | latest_by_reevaluation_at |
| 20260611_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 28 | pending_reevaluations | latest_by_reevaluation_at |
| 20260612_WTI_SHORT_B-Watch | WTI | SHORT | B | no_entry | 27 | pending_reevaluations | latest_by_reevaluation_at |
| 20260614_NASDAQ_LONG_A-Pullback | NASDAQ | LONG | B | open_unresolved | 25 | pending_reevaluations | latest_by_reevaluation_at |
| 20260614_SPX_LONG_A-Pullback | SPX | LONG | B | open_unresolved | 25 | pending_reevaluations | latest_by_reevaluation_at |
| 20260614_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 25 | pending_reevaluations | latest_by_reevaluation_at |
| 20260615_NASDAQ_LONG_B-Watch | NASDAQ | LONG | B | open_unresolved | 24 | pending_reevaluations | latest_by_reevaluation_at |
| 20260615_SPX_LONG_B-Watch | SPX | LONG | B | open_unresolved | 24 | pending_reevaluations | latest_by_reevaluation_at |
| 20260615_VIX_SHORT_TREND | VIX | SHORT | A | open_unresolved | 24 | pending_reevaluations | latest_by_reevaluation_at |
| 20260615_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 24 | pending_reevaluations | latest_by_reevaluation_at |

## 5. 注意

* append-only履歴から最新行だけを選ぶ分析用ビューです。
* 元のEVALUATIONS / PENDING_REEVALUATIONSは削除しません。
* この評価は実売買ではありません。
* 自動発注は行いません。
