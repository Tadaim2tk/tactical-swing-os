# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-09 14:23:15 JST
生成日時（UTC）: 2026-07-09 05:23:15 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.61
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: geopolitical_risk
日本語要約: 地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 57.5
- oil_supply_risk_news_score: 38.33
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 19.17
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Oil extends gains as Iran-U.S. tensions raise concerns over supply disruptions (地政学リスク / 原油供給リスク / リスクオフ要因)
- Ukraine’s drone playbook is wreaking havoc in Russia — and upending where NATO wants to invest (地政学リスク / 金安全資産需要 / リスクオフ要因)
- China consumer price growth weakens in June while producer inflation rises to near 4-year high (インフレ圧力 / 金利圧力候補)
- Jim Cramer sees a big risk to the bull market resurfacing — and it's not the Iran war (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Used EVs keep getting more expensive amid Iran war, high gas prices (地政学リスク / 金安全資産需要 / リスクオフ要因)
