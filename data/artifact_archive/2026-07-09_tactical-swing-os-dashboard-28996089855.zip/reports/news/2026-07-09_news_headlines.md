# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-09 14:23:13 JST
取得日時（UTC）: 2026-07-09 05:23:13 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.61
headline件数: 30

## 見出し

- [CNBC Markets] Oil extends gains as Iran-U.S. tensions raise concerns over supply disruptions (WTI)
- [CNBC Markets] Ukraine’s drone playbook is wreaking havoc in Russia — and upending where NATO wants to invest (未分類)
- [CNBC Markets] Trump loses appeals court bid to delay paying E. Jean Carroll $5M in damages (未分類)
- [CNBC Markets] China consumer price growth weakens in June while producer inflation rises to near 4-year high (未分類)
- [CNBC Markets] Platner quits Maine Senate race; Democrats set to pick new nominee (未分類)
- [CNBC Markets] U.S. military launches new Iran strikes as Trump says 'not sure' he wants deal (未分類)
- [CNBC Markets] AirPods maker Luxshare slides over 5% in Hong Kong debut (USDJPY|SPX|DXY)
- [CNBC Markets] Trump's European allies add distance on Iran following testy NATO summit (未分類)
- [CNBC Markets] SpaceX stock closes below debut price at $148 in two-day slide after Nasdaq-100 inclusion (NASDAQ)
- [CNBC Markets] Trump says he doesn't want anything to do with Spain: 'Cut off all trade' (未分類)
- [CNBC Markets] World Cup drives Google Search to record queries per second (未分類)
- [CNBC Markets] McConnell health update demanded by Gov. Beshear as Senate vacancy questions grow (未分類)
- [CNBC Markets] Trump announces long-shot bid to get Supreme Court to rehear birthright citizenship case (未分類)
- [CNBC Markets] Fed officials were split on direction of interest rates at last meeting, minutes show (US10Y|DXY)
- [CNBC Markets] Levi Strauss beats quarterly expectations, raises guidance and dividend (未分類)
- [CNBC Markets] Crypto still 'off the table' for Singapore's Temasek, four years after FTX flop (BTC)
- [CNBC Markets] Michael Burry bets on sportsbooks DraftKings and Flutter, sees prediction markets curbed by regulation (SPX)
- [CNBC Markets] Few bright spots in Wednesday's tough market — why Nvidia stock is one of them (未分類)
- [CNBC Markets] Jim Cramer sees a big risk to the bull market resurfacing — and it's not the Iran war (未分類)
- [CNBC Markets] Meta is building its first big Canadian data center as AI expansion crosses the border (未分類)
- [CNBC Markets] Delta launches 'basic business' fares without lounge access, seat selection (未分類)
- [CNBC Markets] Oil prices jump more than 4% after Trump threatens to bomb Iran and reimpose naval blockade (WTI)
- [CNBC Markets] Fed meeting minutes to show 'family fight' over rates. The squabble could drag on for a while (US10Y|DXY)
- [CNBC Markets] Rivian tailspin hasn't shaken one trader's resolve (未分類)
- [CNBC Markets] Trump loses latest appeals court bid to restore his name to Kennedy Center (未分類)
- [CNBC Markets] Waymo to start driverless rides in 4 more U.S. markets as expansion accelerates (US10Y|DXY)
- [CNBC Markets] Used EVs keep getting more expensive amid Iran war, high gas prices (未分類)
- [CNBC Markets] Delaying Social Security reform raises risks for bond markets and the economy, research finds (US10Y)
- [CNBC Markets] The American Dream is missing one key ingredient, says Harvard happiness expert: Without it, 'life is pretty grim' (未分類)
- [MarketWatch Top Stories] Levi’s is finding new ways to win customers — by looking toward tops and ‘denim luxury’ (SPX)
