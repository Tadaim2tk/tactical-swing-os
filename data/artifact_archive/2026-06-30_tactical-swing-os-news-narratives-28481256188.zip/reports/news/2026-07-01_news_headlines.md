# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-01 07:57:59 JST
取得日時（UTC）: 2026-06-30 22:57:59 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.31
headline件数: 75

## 見出し

- [CNBC Markets] Trump's annual financial disclosure shows more than $580M in crypto-related income (BTC|SPX)
- [CNBC Markets] Nike results top estimates even as China sales drop 12%; retailer expects $986 million tariff refund (未分類)
- [CNBC Markets] Record chip rally adds $2 trillion in combined value to Micron, Intel and AMD in second quarter (SPX|NASDAQ)
- [CNBC Markets] Palo Alto, CrowdStrike both have best quarter ever as AI threats bolster cyber demand (未分類)
- [CNBC Markets] Supreme Court upholds birthright citizenship, blocks Trump order (未分類)
- [CNBC Markets] Michael Burry says he's shorting Caterpillar for the first time after it nearly doubled in the AI-driven rally of 2026 (未分類)
- [CNBC Markets] Trump says Council of Economic Advisers head Pierre Yared is leaving (未分類)
- [CNBC Markets] Anthropic launches AI drug discovery program, joining tech giants in betting on healthcare (NASDAQ)
- [CNBC Markets] Big egg producers settle price inflation probe with DOJ for 53 million eggs — and $3.3M (未分類)
- [CNBC Markets] Do you really, really love your job? Then you're not alone, according to surprising results from this survey (未分類)
- [CNBC Markets] Trump's massive defense budget, depleted war machine, spark U.S. state battle for business and jobs (SPX)
- [CNBC Markets] AWS puts $1 billion into new AI unit to embed engineers with customers, joining growing wave (未分類)
- [CNBC Markets] American Airlines brings grab-and-go lounge to New York's JFK (未分類)
- [CNBC Markets] Private equity in youth sports draws bipartisan scrutiny in Congress (未分類)
- [CNBC Markets] FDA lets Philip Morris market Zyn nicotine pouches as less harmful than cigarettes (未分類)
- [CNBC Markets] Social Security gender gap means women receive about $4,800 less in annual benefits. What to know before claiming (未分類)
- [CNBC Markets] GOP Rep. Tom Kean says depression diagnosis caused months-long absence from Congress (未分類)
- [CNBC Markets] Blue Origin pivots to redesigned launchpad after explosion in push to fly by end of 2026 (未分類)
- [CNBC Markets] Wall Street says sell Goldman, buy Capital One. Here's where we stand (GOLD|SPX)
- [CNBC Markets] Trump administration expands list of graduate degrees subject to higher borrowing limits (US10Y|DXY)
- [CNBC Markets] Supreme Court strikes down limits on political parties' campaign spending, in win for GOP (未分類)
- [CNBC Markets] Cleveland Fed President Hammack says AI could fuel inflation, rate hikes may be necessary (US10Y|DXY)
- [CNBC Markets] Small-cap stocks enjoy their best first half in 35 years. Here's what's driving it (SPX)
- [CNBC Markets] Brent posts biggest monthly decline since March 2020 as traders monitor U.S.-Iran talks (WTI)
- [CNBC Markets] Trump administration's AI crackdown opens door for China to close gap (未分類)
- [CNBC Markets] AeroVironment skyrockets 19% as dronemaker capitalizes on defense spending surge (未分類)
- [CNBC Markets] Medicare will start covering obesity drugs for the first time. Here's what patients should know (未分類)
- [CNBC Markets] Waymo and Uber end robotaxi pilot in Phoenix (未分類)
- [CNBC Markets] Buffett delays annual donation to Gates Foundation pending review of Jeffrey Epstein ties: WSJ (未分類)
- [CNBC Markets] Digital Realty falls 5% after taking $3.5 billion stake in Blackstone's Virginia data centers (未分類)
- [MarketWatch Top Stories] Trump discloses expanding financial empire, including Apple stock, celebration coins and crypto (BTC)
- [MarketWatch Top Stories] If LeBron James goes to the Warriors, that team’s roster will be stacked with some of the most expensive players in NBA history (未分類)
- [MarketWatch Top Stories] Investors piled into ETFs at a record pace in the first half of 2026. Here’s where their money is flowing. (BTC|SPX)
- [MarketWatch Top Stories] Bitcoin ETFs were supposed to make selloffs less painful. That theory is being put to the test. (BTC|VIX)
- [MarketWatch Top Stories] Trump’s energy secretary says global warming is ‘no big deal.’ Meanwhile, a heat emergency is striking the U.S. (未分類)
- [MarketWatch Top Stories] Will the Comcast-NBCU spinoff pay off for investors? Here’s what history has to say. (未分類)
- [MarketWatch Top Stories] Oil posts largest quarterly price drop in 6 years as historic supply crunch eases (WTI)
- [MarketWatch Top Stories] The 20 best-performing stocks in the S&P 500 for the first half of 2026 (SPX)
- [MarketWatch Top Stories] 20 stocks in the S&P 500 that plunged the most in 2026’s first half (SPX)
- [MarketWatch Top Stories] ‘I don’t think I’ll make it to 80’: I’m 70 and single. Do I take out a reverse mortgage or a home-equity agreement? (未分類)
- [CoinDesk] Trump pocketed more than $1 billion from crypto ties as industry headed toward slump (BTC)
- [CoinDesk] Phantom doubles down on perpetual futures with hire of Hyperliquid market builders (BTC)
- [CoinDesk] Companies spending the most on AI are growing jobs, Ramp study finds (VIX)
- [CoinDesk] Why OpenUSD's 'real threat' that tanked Circle stock still faces a steep uphill battle for adoption (BTC)
- [CoinDesk] SEC giving novel ETFs a rethink as it opens comment period on overhauling U.S. rules (BTC)
- [CoinDesk] Chinese exile once linked to Trump strategist gets 30-year sentence in $1 billion fraud (未分類)
- [CoinDesk] Jefferies warns of crypto market volatility as Clarity Act faces Senate test (BTC|VIX)
- [CoinDesk] Circle craters 17% as Stripe, Coinbase and BlackRock back rival stablecoin network (BTC)
- [CoinDesk] MetaMask launches Money Account with stablecoin yield and spending in one wallet (US10Y)
- [CoinDesk] Tokenized securities need competition, not gatekeepers (未分類)
