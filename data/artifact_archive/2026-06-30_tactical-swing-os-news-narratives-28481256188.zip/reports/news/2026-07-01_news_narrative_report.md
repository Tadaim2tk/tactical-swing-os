# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-01 07:58:01 JST
生成日時（UTC）: 2026-06-30 22:58:01 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.31
ニュース市場バイアス: mixed
ニュース矛盾スコア: 55.4
主要テーマ: なし
日本語要約: 複数テーマが目立ち、リスクオン材料とリスクオフ材料が混在しています。強弱材料が混在しており、方向感は限定的です。
ニュースモード: ニュースは混在 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 55.4
- risk_off_news_score: 55.4
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 18.47
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 18.47
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 55.4
- inflation_pressure_news_score: 55.4
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Nike results top estimates even as China sales drop 12%; retailer expects $986 million tariff refund (インフレ圧力 / 金利圧力候補)
- Record chip rally adds $2 trillion in combined value to Micron, Intel and AMD in second quarter (リスクオン要因)
- Michael Burry says he's shorting Caterpillar for the first time after it nearly doubled in the AI-driven rally of 2026 (リスクオン要因)
- Big egg producers settle price inflation probe with DOJ for 53 million eggs — and $3.3M (インフレ圧力 / 金利圧力候補)
- Trump's massive defense budget, depleted war machine, spark U.S. state battle for business and jobs (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Cleveland Fed President Hammack says AI could fuel inflation, rate hikes may be necessary (インフレ圧力 / 金利圧力候補)
- Trump pocketed more than $1 billion from crypto ties as industry headed toward slump (リスクオフ要因)
- Jefferies warns of crypto market volatility as Clarity Act faces Senate test (リスクオフ要因)
- Live updates: bitcoin closes out weak quarter; Trump reports over $1 billion in crypto proceeds (リスクオフ要因 / リスクオン要因)
- Tether trades at 7% to 10% premium in India. Exchanges say it's just supply and demand (暗号資産流動性)
