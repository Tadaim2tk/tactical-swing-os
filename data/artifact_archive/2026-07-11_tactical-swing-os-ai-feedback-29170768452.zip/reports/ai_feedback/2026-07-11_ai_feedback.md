# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-07-12 07:36:00 JST
Actions実行時刻（UTC）: 2026-07-11 22:36:00 UTC
対象日: 2026-07-11
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドルは中立 / 金利圧力は限定的 / ボラティリティは落ち着き
- ニュースモード: ニュースナラティブ未取得
- ニュース市場バイアス: insufficient_data
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_only
- 評価データソース: latest_evaluations
- latest_evaluations_available: True
- fallback_used: False
- risk_on: 51.48
- risk_off: 48.25
- dollar: 49.92
- rate: 50.32
- volatility: 47.7
- news_confidence: 0.0
- シグナル整合性: aligned=0, conflicted=0, neutral=1, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| DXY | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| GOLD | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| NASDAQ | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| SPX | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| US10Y | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| USDJPY | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| VIX | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |
| WTI | 51.48 | 48.25 | 49.92 | 50.32 | 48.02 | 51.37 | 47.7 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260711_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
| 20260629_US10Y_NONE_NO_TRADE | US10Y | no_trade_missed | 0.0 | 見送り後に動意が出たため、見送り条件の過剰さを点検します。 | unknown | 低ボラ見送りでもbreakout兆候があれば監視強化します。 |
| 20260628_USDJPY_NONE_NO_TRADE | USDJPY | no_trade_missed | 0.0 | 見送り後に動意が出たため、見送り条件の過剰さを点検します。 | unknown | 低ボラ見送りでもbreakout兆候があれば監視強化します。 |
| 20260629_DXY_NONE_NO_TRADE | DXY | no_trade_missed | 0.0 | 見送り後に動意が出たため、見送り条件の過剰さを点検します。 | unknown | 低ボラ見送りでもbreakout兆候があれば監視強化します。 |
| 20260629_NASDAQ_NONE_NO_TRADE | NASDAQ | no_trade_missed | 0.0 | 見送り後に動意が出たため、見送り条件の過剰さを点検します。 | unknown | 低ボラ見送りでもbreakout兆候があれば監視強化します。 |
| 20260629_USDJPY_NONE_NO_TRADE | USDJPY | no_trade_missed | 0.0 | 見送り後に動意が出たため、見送り条件の過剰さを点検します。 | unknown | 低ボラ見送りでもbreakout兆候があれば監視強化します。 |
| 20260628_GOLD_NONE_NO_TRADE | GOLD | no_trade_missed | 0.0 | 見送り後に動意が出たため、見送り条件の過剰さを点検します。 | unknown | 低ボラ見送りでもbreakout兆候があれば監視強化します。 |
| 20260629_WTI_NONE_NO_TRADE | WTI | no_trade_missed | 0.0 | 見送り後に動意が出たため、見送り条件の過剰さを点検します。 | unknown | 低ボラ見送りでもbreakout兆候があれば監視強化します。 |
| 20260630_DXY_NONE_NO_TRADE | DXY | no_trade_missed | 0.0 | 見送り後に動意が出たため、見送り条件の過剰さを点検します。 | unknown | 低ボラ見送りでもbreakout兆候があれば監視強化します。 |

## 5. 明日に向けた補正仮説

- no_trade_reasonがlow_volatilityでも、breakout直前なら見送り過剰に注意。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: False
- news_mode_summary: ニュースナラティブ未取得
- top_news_drivers: ニュースドライバーなし

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-07-11T22:36:00,2026-07-12 07:36:00 JST,2026-07-11 22:36:00 UTC,2026-07-11,BTC,20260711_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,atr_too_low|rr_too_low,neutral,0,51.48,48.25,49.92,50.32,48.02,51.37,47.7,92.78,0.0,market_proxy_only,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-07-11T22:36:00",
  "generated_at_jst": "2026-07-12 07:36:00 JST",
  "generated_at_utc": "2026-07-11 22:36:00 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-07-11",
  "data_source": "Google Sheets",
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 251,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "market_mode_summary": "リスクオン/オフは中立 / ドルは中立 / 金利圧力は限定的 / ボラティリティは落ち着き",
  "news_narrative_available": false,
  "news_mode_summary": "ニュースナラティブ未取得",
  "top_news_drivers": [],
  "narrative_source_mix": "market_proxy_only",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": null
    },
    {
      "asset": "DXY",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0505
    },
    {
      "asset": "GOLD",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1572
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.4367
    },
    {
      "asset": "SPX",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.5107
    },
    {
      "asset": "US10Y",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.6166
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.425
    },
    {
      "asset": "VIX",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": -6.4134
    },
    {
      "asset": "WTI",
      "risk_on_score": 51.48,
      "risk_off_score": 48.25,
      "dollar_strength_score": 49.92,
      "rate_pressure_score": 50.32,
      "gold_safe_haven_score": 48.02,
      "oil_supply_risk_proxy_score": 49.77,
      "crypto_liquidity_score": 51.37,
      "equity_momentum_score": 52.06,
      "volatility_stress_score": 47.7,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.4871
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260711_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "signal_id": "20260629_US10Y_NONE_NO_TRADE",
      "asset": "US10Y",
      "outcome": "no_trade_missed",
      "r_multiple": 0.0,
      "technical_view": "見送り後に動意が出たため、見送り条件の過剰さを点検します。",
      "narrative_alignment": "unknown",
      "improvement": "低ボラ見送りでもbreakout兆候があれば監視強化します。"
    },
    {
      "signal_id": "20260628_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "outcome": "no_trade_missed",
      "r_multiple": 0.0,
      "technical_view": "見送り後に動意が出たため、見送り条件の過剰さを点検します。",
      "narrative_alignment": "unknown",
      "improvement": "低ボラ見送りでもbreakout兆候があれば監視強化します。"
    },
    {
      "signal_id": "20260629_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "outcome": "no_trade_missed",
      "r_multiple": 0.0,
      "technical_view": "見送り後に動意が出たため、見送り条件の過剰さを点検します。",
      "narrative_alignment": "unknown",
      "improvement": "低ボラ見送りでもbreakout兆候があれば監視強化します。"
    },
    {
      "signal_id": "20260629_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "outcome": "no_trade_missed",
      "r_multiple": 0.0,
      "technical_view": "見送り後に動意が出たため、見送り条件の過剰さを点検します。",
      "narrative_alignment": "unknown",
      "improvement": "低ボラ見送りでもbreakout兆候があれば監視強化します。"
    },
    {
      "signal_id": "20260629_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "outcome": "no_trade_missed",
      "r_multiple": 0.0,
      "technical_view": "見送り後に動意が出たため、見送り条件の過剰さを点検します。",
      "narrative_alignment": "unknown",
      "improvement": "低ボラ見送りでもbreakout兆候があれば監視強化します。"
    },
    {
      "signal_id": "20260628_GOLD_NONE_NO_TRADE",
      "asset": "GOLD",
      "outcome": "no_trade_missed",
      "r_multiple": 0.0,
      "technical_view": "見送り後に動意が出たため、見送り条件の過剰さを点検します。",
      "narrative_alignment": "unknown",
      "improvement": "低ボラ見送りでもbreakout兆候があれば監視強化します。"
    },
    {
      "signal_id": "20260629_WTI_NONE_NO_TRADE",
      "asset": "WTI",
      "outcome": "no_trade_missed",
      "r_multiple": 0.0,
      "technical_view": "見送り後に動意が出たため、見送り条件の過剰さを点検します。",
      "narrative_alignment": "unknown",
      "improvement": "低ボラ見送りでもbreakout兆候があれば監視強化します。"
    },
    {
      "signal_id": "20260630_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "outcome": "no_trade_missed",
      "r_multiple": 0.0,
      "technical_view": "見送り後に動意が出たため、見送り条件の過剰さを点検します。",
      "narrative_alignment": "unknown",
      "improvement": "低ボラ見送りでもbreakout兆候があれば監視強化します。"
    }
  ],
  "improvement_hypotheses": [
    "no_trade_reasonがlow_volatilityでも、breakout直前なら見送り過剰に注意。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
