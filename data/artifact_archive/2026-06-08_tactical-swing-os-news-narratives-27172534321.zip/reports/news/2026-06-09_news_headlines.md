# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-09 08:04:12 JST
取得日時（UTC）: 2026-06-08 23:04:12 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.85
headline件数: 75

## 見出し

- [CNBC Markets] OpenAI confidentially files for IPO, prepping Wall Street for mega AI debut (SPX)
- [CNBC Markets] Trump nominates Todd Blanche for attorney general amid controversy over DOJ fund (未分類)
- [CNBC Markets] Netanyahu says war with Iran, Hezbollah isn't over after Tehran says it's halting strikes (未分類)
- [CNBC Markets] Apple partnering with Google and Nvidia for most advanced AI model (未分類)
- [CNBC Markets] Nvidia CEO Jensen Huang declines Senate testimony on AI, China and exports (NASDAQ)
- [CNBC Markets] Convicted FTX founder Sam Bankman-Fried files formal request for Trump pardon (BTC|US10Y|DXY)
- [CNBC Markets] Judge blocks Trump's $100,000 H-1B visa fee (未分類)
- [CNBC Markets] Retirement 'underspending' is risky, advisor says. Here's why (未分類)
- [CNBC Markets] China is helping to cushion global oil prices below $100 — but analysts warn it won’t last (WTI)
- [CNBC Markets] Silicon Valley’s new buyout playbook is hitting Wall Street (SPX)
- [CNBC Markets] Chip rebound sparks hedging flurry from traders (NASDAQ)
- [CNBC Markets] Food supply 'not at risk' after new Texas screwworm cases, USDA secretary says (未分類)
- [CNBC Markets] Airlines find the grass isn't always greener with new engines (未分類)
- [CNBC Markets] Chip rebound has one trader buying protection (SPX|NASDAQ)
- [CNBC Markets] Household worries over finances hit highest level since July 2022, New York Fed survey shows (US10Y|DXY)
- [CNBC Markets] Corning strikes another multibillion-dollar AI deal. What the new Amazon pact means for the stock (USDJPY|DXY)
- [CNBC Markets] Weight loss drug maker sinks 23% after new safety data spooks investors (未分類)
- [CNBC Markets] Kalshi traders say Strait of Hormuz traffic won't return to normal before January (未分類)
- [CNBC Markets] Congress moves toward approving $70 billion for ICE and CBP through Trump's presidency (未分類)
- [CNBC Markets] Oil prices ease after Iran says military operations against Israel are over (WTI)
- [CNBC Markets] Novo and Lilly are competing to win the GLP-1 pill market as they prepare for Medicare coverage (未分類)
- [CNBC Markets] Corning shares jump 4% after company strikes deal to power Amazon AI data centers in U.S. (SPX|NASDAQ)
- [CNBC Markets] USAA to return nearly $1 billion to Florida members as legal reforms help lower insurance costs (未分類)
- [CNBC Markets] United CEO brushes off airline mergers after American rejection: 'There's nothing' (未分類)
- [CNBC Markets] This startup wants to reduce payment friction on prediction markets (未分類)
- [CNBC Markets] This popular car-buying rule isn't realistic for most Americans—here's the income needed to make it work (未分類)
- [CNBC Markets] Italian coffee giant Lavazza launches single-serve tablets to make espresso in the U.S. (未分類)
- [CNBC Markets] Marvell Technology jumps 10% after news it will join the S&P 500 index (SPX|NASDAQ)
- [CNBC Markets] Trump storms out of interview after being challenged about election fraud claims, DOJ fund (未分類)
- [CNBC Markets] 'Bring 'em on': Delta wants United's crown over the Pacific, too (未分類)
- [MarketWatch Top Stories] Elon Musk says SpaceX doesn’t need ‘magic’ to put AI data centers up in space (未分類)
- [MarketWatch Top Stories] Knicks ticket prices plunge more than 50% ahead of Game 3 at MSG — but not just because Trump’s going (USDJPY|DXY)
- [MarketWatch Top Stories] OpenAI files confidentially for IPO — but there’s a catch (未分類)
- [MarketWatch Top Stories] My golf buddy worked as a financial adviser. Here’s how I knew his friendship was fake. (未分類)
- [MarketWatch Top Stories] Your tech portfolio could be on the wrong side of the AI boom (SPX|NASDAQ)
- [MarketWatch Top Stories] An inflation storm is brewing in the Pacific Ocean — and your portfolio isn’t ready (未分類)
- [MarketWatch Top Stories] ‘I have no experience with investing’: I inherited $2,000. I’m 42 with two children. What should I do with this money? (未分類)
- [MarketWatch Top Stories] Eli Lilly stock rises after late-stage trial of next-generation weight-loss drug (SPX)
- [MarketWatch Top Stories] Micron’s stock bounces back in a big way: ‘The memory trade is alive and well’ (SPX|NASDAQ)
- [MarketWatch Top Stories] Inflation could top 4% this week. The bond market wants Fed Chair Warsh to prove he’ll fight it. (US10Y|DXY)
- [CoinDesk] Forehead tattoos and alcohol dares: Inside the dark underbelly of crypto's memecoin craze (BTC)
- [CoinDesk] Influential research firm that caused AI stock meltdown lays out Hyperliquid as 'compelling' idea (BTC|US10Y|DXY)
- [CoinDesk] Live updates: Bitcoin tops $63,000 as Strategy adds $100 million BTC in latest purchase (BTC)
- [CoinDesk] Sam Bankman-Fried officially asks Trump for a presidential pardon (BTC)
- [CoinDesk] The startup killer: Ledger CTO says the EU's crushing compliance costs are choking Web3 innovation (未分類)
- [CoinDesk] Aave chief defends protocol's 'resilience' after $8.45 billion bank run (未分類)
- [CoinDesk] Blame bitcoin's tumble on rising inflation, not Strategy, 10xResearch argues (BTC)
- [CoinDesk] CoinDesk 20 performance update: NEAR gains 12.3% as almost all assets trade higher (未分類)
- [CoinDesk] MetaMask launches AI agent wallet with built-in security for crypto trades (BTC)
- [CoinDesk] Bitmine bought the dip, making its biggest ether purchase in 2026 as prices tanked (BTC)
