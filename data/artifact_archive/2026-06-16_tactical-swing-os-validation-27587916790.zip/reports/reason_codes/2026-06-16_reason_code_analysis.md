# Tactical Swing OS Reason Code Analysis

## 1. 結論

期間内にreason_codes分析対象がありません。Phase 6以降のSIGNALS蓄積後に再確認してください。

対象期間: 2026-05-18 - 2026-06-16

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. reason_codes 上位プラス要因

_該当なし_

## 3. reason_codes 上位マイナス要因

_該当なし_

## 4. no_trade_reason 分析

_該当なし_

## 5. 取り逃し候補

_該当なし_

## 6. 改善候補

_該当なし_

## 7. データ不足の注意

reason_codeごとの評価件数が5件未満の場合は `insufficient_data` とし、weights.jsonは自動更新しません。

## 8. REASON_CODE_ANALYSIS CSV

```csv
reason_code,signals_count,evaluated_count,win_count,loss_count,no_entry_count,missed_opportunity_count,win_rate,total_r,average_r,median_r,best_r,worst_r,average_mfe_r,average_mae_r,rank_a_count,rank_b_count,no_trade_count,recommended_action_trade_count,recommended_action_watch_count,recommended_action_no_trade_count,reliability_label
```

## 9. REASON_CODE_ANALYSIS JSON

```json
{
  "start_date": "2026-05-18",
  "end_date": "2026-06-16",
  "reason_code_summary": [],
  "no_trade_reason_summary": [],
  "top_positive_reasons": [],
  "top_negative_reasons": [],
  "over_filtering_candidates": [],
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 30,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "notes": [
    "reason_code単位のweights自動更新はまだ行いません。",
    "insufficient_data reason_codes: 0",
    "reason_codes列が空、または期間内に対象データがありません。"
  ]
}
```
