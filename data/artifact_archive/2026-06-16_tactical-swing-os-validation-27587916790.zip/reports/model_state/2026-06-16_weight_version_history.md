# Weight Version History

## 1. 概要

- 生成日時JST: 2026-06-16 10:31:14 JST
- 現在Version: v1
- Version数: 1
- review_status: blocked
- history_status: tracked
- tracked_count: 40
- held_count: 0
- candidate_count: 0
- approved_count: 0
- rejected_count: 0
- blocked_count: 0
- weights_json_updated: false
- patch_applied: false
- requires_human_approval: true

## 2. Version一覧

| version_id | version_count | weights_json_updated | patch_applied | requires_human_approval |
| --- | --- | --- | --- | --- |
| v1 | 1 | False | False | True |

## 3. Proposal一覧

| version_id | source | proposal_id | review_decision | adoption_status | description | weights_json_updated | patch_applied | requires_human_approval | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| v1 | proposal_adoption_tracking | 20260616_narrative_crypto_liquidity_narrative_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_narrative_dollar_strength_narrative_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_narrative_geopolitical_risk_narrative_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_narrative_oil_supply_risk_narrative_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_narrative_rate_pressure_narrative_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_narrative_risk_off_narrative_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_narrative_risk_on_narrative_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_rank_B_rank_confidence_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_side_LONG_side_bias_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_asset_GOLD_asset_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_asset_WTI_asset_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_rank_NO_TRADE_rank_confidence_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_side_NONE_side_bias_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_side_SHORT_side_bias_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_type_B-Watch_setup_type_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_type_TREND_setup_type_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_asset_BTC_asset_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_asset_DXY_asset_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_asset_NASDAQ_asset_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_asset_SPX_asset_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_asset_US10Y_asset_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_asset_USDJPY_asset_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_asset_VIX_asset_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_rank_A_rank_confidence_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_reason_code_breakout_down_reason_code_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_reason_code_breakout_up_reason_code_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_reason_code_low_volatility_reason_code_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_reason_code_ma_alignment_bear_reason_code_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_reason_code_ma_alignment_bull_reason_code_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_reason_code_momentum_negative_reason_code_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_reason_code_momentum_positive_reason_code_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_reason_code_rr_too_low_reason_code_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_reason_code_rsi_overbought_reason_code_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_reason_code_rsi_oversold_reason_code_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_reason_code_trend_down_reason_code_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_reason_code_trend_up_reason_code_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_side_NO_TRADE_side_bias_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_type_A-Momentum_setup_type_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_type_A-Pullback_setup_type_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |
| v1 | proposal_adoption_tracking | 20260616_type_NO_TRADE_setup_type_weight_adjustment |  | tracked | no review decision available | False | False | True | history_only_no_weight_change |

## 4. 注意事項

- 実際のweight変更はしていません
- weights.jsonは更新しません
- patchは適用しません
- 人間承認が必要です
- 実売買・発注・XM操作は行いません
- この履歴はProposal/Review/Adoption Trackingを長期追跡するための研究用ビューです
