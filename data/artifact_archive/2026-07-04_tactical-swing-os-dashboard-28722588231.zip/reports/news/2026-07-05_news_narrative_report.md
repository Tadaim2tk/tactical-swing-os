# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-05 08:07:43 JST
生成日時（UTC）: 2026-07-04 23:07:43 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.64
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 0.0
- oil_supply_risk_news_score: 19.17
- crypto_liquidity_news_score: 19.17
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 57.5
- inflation_pressure_news_score: 19.17
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- UK and France agree with Oman to ensure safety of its territorial waters (地政学リスク / 原油供給リスク / リスクオフ要因)
- Why June’s jobs and inflation data are bullish for bonds (インフレ圧力 / 金利圧力候補)
- How ethical hackers with just a $3,000 server found a flaw that could've put $70 billion in crypto at risk (地政学リスク / リスクオフ要因)
- UK's bold new crypto rules promise to unlock global trading, but huge compliance hurdles still threaten the rollout (暗号資産流動性)
- Russia stocks lower at close of trade; MOEX Russia Index unchanged (地政学リスク / リスクオフ要因)
