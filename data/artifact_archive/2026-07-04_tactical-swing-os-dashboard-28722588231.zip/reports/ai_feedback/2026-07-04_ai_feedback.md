# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-07-05 08:07:45 JST
Actions実行時刻（UTC）: 2026-07-04 23:07:45 UTC
対象日: 2026-07-04
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 35.22
- risk_off: 34.94
- dollar: 34.82
- rate: 34.38
- volatility: 49.71
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=1, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 35.22 | 34.94 | 34.82 | 34.38 | 49.12 | 40.91 | 49.71 | 93.86 |
| DXY | 50.32 | 49.91 | 49.75 | 49.12 | 50.46 | 50.23 | 49.71 | 92.78 |
| GOLD | 50.32 | 49.91 | 49.75 | 49.12 | 50.46 | 50.23 | 49.71 | 92.78 |
| NASDAQ | 50.32 | 49.91 | 49.75 | 49.12 | 50.46 | 50.23 | 49.71 | 92.78 |
| SPX | 50.32 | 49.91 | 49.75 | 49.12 | 50.46 | 50.23 | 49.71 | 92.78 |
| US10Y | 50.32 | 49.91 | 49.75 | 49.12 | 50.46 | 50.23 | 49.71 | 92.78 |
| USDJPY | 50.32 | 49.91 | 49.75 | 49.12 | 50.46 | 50.23 | 49.71 | 92.78 |
| VIX | 50.32 | 49.91 | 49.75 | 49.12 | 50.46 | 50.23 | 49.71 | 92.78 |
| WTI | 50.32 | 49.91 | 49.75 | 49.12 | 50.46 | 50.23 | 49.71 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260704_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | momentum_negative|rr_too_low|range_middle | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり
- top_news_drivers: UK and France agree with Oman to ensure safety of its territorial waters, Why June’s jobs and inflation data are bullish for bonds, How ethical hackers with just a $3,000 server found a flaw that could've put $70 billion in crypto at risk, UK's bold new crypto rules promise to unlock global trading, but huge compliance hurdles still threaten the rollout, Russia stocks lower at close of trade; MOEX Russia Index unchanged

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-07-04T23:07:45,2026-07-05 08:07:45 JST,2026-07-04 23:07:45 UTC,2026-07-04,BTC,20260704_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|rr_too_low|range_middle,neutral,0,35.22,34.94,34.82,34.38,49.12,40.91,49.71,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-07-04T23:07:45",
  "generated_at_jst": "2026-07-05 08:07:45 JST",
  "generated_at_utc": "2026-07-04 23:07:45 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-07-04",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "top_news_drivers": [
    {
      "title": "UK and France agree with Oman to ensure safety of its territorial waters",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "oil_supply_risk_news_score:middle east|geopolitical_risk_news_score:middle east",
      "driver_tags": "oil_supply_risk|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 原油供給リスク / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/07/04/uk-france-agree-with-oman-to-ensure-safety-of-its-territorial-waters.html"
    },
    {
      "title": "Why June’s jobs and inflation data are bullish for bonds",
      "source": "MarketWatch Top Stories",
      "matched_assets": "US10Y",
      "matched_rules": "inflation_pressure_news_score:inflation",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.marketwatch.com/story/why-the-jobs-and-inflation-data-are-bullish-for-bonds-fcedffd2?mod=mw_rss_topstories"
    },
    {
      "title": "How ethical hackers with just a $3,000 server found a flaw that could've put $70 billion in crypto at risk",
      "source": "CoinDesk",
      "matched_assets": "BTC|USDJPY|DXY",
      "matched_rules": "geopolitical_risk_news_score:attack",
      "driver_tags": "geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオフ要因",
      "link": "https://www.coindesk.com/tech/2026/07/04/how-ethical-hackers-with-just-a-usd3-000-server-found-a-flaw-that-could-ve-put-usd70-billion-in-crypto-at-risk"
    },
    {
      "title": "UK's bold new crypto rules promise to unlock global trading, but huge compliance hurdles still threaten the rollout",
      "source": "CoinDesk",
      "matched_assets": "BTC",
      "matched_rules": "crypto_liquidity_news_score:liquidity",
      "driver_tags": "crypto_liquidity",
      "driver_summary_ja": "暗号資産流動性",
      "link": "https://www.coindesk.com/policy/2026/07/04/uk-s-bold-new-crypto-rules-promise-to-unlock-global-trading-but-huge-compliance-hurdles-still-threaten-the-rollout"
    },
    {
      "title": "Russia stocks lower at close of trade; MOEX Russia Index unchanged",
      "source": "Investing.com Commodities",
      "matched_assets": "SPX",
      "matched_rules": "geopolitical_risk_news_score:russia",
      "driver_tags": "geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオフ要因",
      "link": "https://www.investing.com/news/stock-market-news/russia-stocks-lower-at-close-of-trade-moex-russia-index-unchanged-4775384"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 35.22,
      "risk_off_score": 34.94,
      "dollar_strength_score": 34.82,
      "rate_pressure_score": 34.38,
      "gold_safe_haven_score": 49.12,
      "oil_supply_risk_proxy_score": 40.88,
      "crypto_liquidity_score": 40.91,
      "equity_momentum_score": 35.37,
      "volatility_stress_score": 49.71,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 0.0,
      "risk_off_news_score": 0.0,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 0.0,
      "oil_supply_risk_news_score": 19.17,
      "crypto_liquidity_news_score": 19.17,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 57.5,
      "inflation_pressure_news_score": 19.17,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 50.32,
      "risk_off_score": 49.91,
      "dollar_strength_score": 49.75,
      "rate_pressure_score": 49.12,
      "gold_safe_haven_score": 50.46,
      "oil_supply_risk_proxy_score": 50.18,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.53,
      "volatility_stress_score": 49.71,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0555,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 50.32,
      "risk_off_score": 49.91,
      "dollar_strength_score": 49.75,
      "rate_pressure_score": 49.12,
      "gold_safe_haven_score": 50.46,
      "oil_supply_risk_proxy_score": 50.18,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.53,
      "volatility_stress_score": 49.71,
      "narrative_confidence": 92.78,
      "asset_change_pct": 1.1914,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 50.32,
      "risk_off_score": 49.91,
      "dollar_strength_score": 49.75,
      "rate_pressure_score": 49.12,
      "gold_safe_haven_score": 50.46,
      "oil_supply_risk_proxy_score": 50.18,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.53,
      "volatility_stress_score": 49.71,
      "narrative_confidence": 92.78,
      "asset_change_pct": 1.1356,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 50.32,
      "risk_off_score": 49.91,
      "dollar_strength_score": 49.75,
      "rate_pressure_score": 49.12,
      "gold_safe_haven_score": 50.46,
      "oil_supply_risk_proxy_score": 50.18,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.53,
      "volatility_stress_score": 49.71,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.4419,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 50.32,
      "risk_off_score": 49.91,
      "dollar_strength_score": 49.75,
      "rate_pressure_score": 49.12,
      "gold_safe_haven_score": 50.46,
      "oil_supply_risk_proxy_score": 50.18,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.53,
      "volatility_stress_score": 49.71,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.3997,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 50.32,
      "risk_off_score": 49.91,
      "dollar_strength_score": 49.75,
      "rate_pressure_score": 49.12,
      "gold_safe_haven_score": 50.46,
      "oil_supply_risk_proxy_score": 50.18,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.53,
      "volatility_stress_score": 49.71,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1471,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 50.32,
      "risk_off_score": 49.91,
      "dollar_strength_score": 49.75,
      "rate_pressure_score": 49.12,
      "gold_safe_haven_score": 50.46,
      "oil_supply_risk_proxy_score": 50.18,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.53,
      "volatility_stress_score": 49.71,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1901,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 50.32,
      "risk_off_score": 49.91,
      "dollar_strength_score": 49.75,
      "rate_pressure_score": 49.12,
      "gold_safe_haven_score": 50.46,
      "oil_supply_risk_proxy_score": 50.18,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.53,
      "volatility_stress_score": 49.71,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.5115,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260704_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|rr_too_low|range_middle",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
