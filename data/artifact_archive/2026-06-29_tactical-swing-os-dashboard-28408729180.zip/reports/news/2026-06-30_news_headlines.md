# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-30 08:10:31 JST
取得日時（UTC）: 2026-06-29 23:10:31 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.78
headline件数: 30

## 見出し

- [CNBC Markets] Trump bought as much as $5 million in Axon stock before ICE sought $220 million Taser deal (NASDAQ|US10Y|DXY)
- [CNBC Markets] Eli Lilly, Regeneron among first companies selected for FDA initiative to speed review of new manufacturing facilities (未分類)
- [CNBC Markets] SpaceX bulls are back betting on huge, fast gains as Rocket Lab surges (未分類)
- [CNBC Markets] AeroVironment soars 19% on earnings beat, backlog grows to $1.2 billion (SPX|NASDAQ)
- [CNBC Markets] Industry lobbyists push House committee to block a ban on Pentagon defense contractors buying back their own stock (未分類)
- [CNBC Markets] Waymo and Uber end robotaxi pilot in Phoenix (未分類)
- [CNBC Markets] Micron's monster post-earnings rally is almost gone. Traders divided on where it goes next (SPX|NASDAQ)
- [CNBC Markets] Supreme Court lets presidents fire independent regulators, rules for Trump in FTC case (未分類)
- [CNBC Markets] Supreme Court rules Trump cannot fire Fed Governor Lisa Cook for now (US10Y|DXY)
- [CNBC Markets] Supreme Court rulings on Fed, FTC: What they mean for consumers (US10Y|DXY)
- [CNBC Markets] IRS says Trump Account contributions will not trigger annual gift tax reporting requirements (US10Y|DXY)
- [CNBC Markets] Oil prices near pre-war levels — but persistent supply risks could spark a rebound, analysts warn (WTI)
- [CNBC Markets] Trump laments 'tremendous loss' on mail-in ballots at Supreme Court, doubles down on voter-ID bill (US10Y|DXY)
- [CNBC Markets] Comcast announces it will spin off NBCUniversal and Sky from cable business (未分類)
- [CNBC Markets] Comcast's NBCUniversal spinoff raises hope for more deals. There may not be good options (未分類)
- [CNBC Markets] Oil prices rise as U.S. and Iran reach deal to halt attacks, U.S. oil above $70 per barrel again (WTI)
- [CNBC Markets] Salesforce is on an AI buying spree, but Wall Street still has its doubts (SPX)
- [CNBC Markets] This insurance stock is on an impressive run. How to ride the momentum with less risk (未分類)
- [CNBC Markets] Here's how Trump Accounts could affect women's retirement savings gap (未分類)
- [CNBC Markets] Kalshi traders expect this week's jobs report will disappoint Wall Street outlook (SPX)
- [CNBC Markets] Trump says U.S. and Iran to hold fresh talks in Qatar on Tuesday following weekend clashes (未分類)
- [CNBC Markets] Putin’s fuel shortage admission signals growing strain on Russia’s energy infrastructure (未分類)
- [CNBC Markets] SpaceX's $25 billion bond sale drives huge demand - and a potential headache for investors (US10Y)
- [CNBC Markets] Op-ed: If you think China needs to dethrone U.S. dollar, you don't understand how it is waging global currency war (USDJPY|DXY)
- [CNBC Markets] The AI boom is colliding with a new threat: Severe weather (未分類)
- [CNBC Markets] Protein coffee? Brands cash in on functional beverage boom (未分類)
- [MarketWatch Top Stories] Trump’s weekend Iran strikes keep sparking Monday stock rallies. Here’s what the data shows us. (SPX)
- [MarketWatch Top Stories] ‘I don’t think I’ll make it to 80’: I’m 70 and single. Do I take out a reverse mortgage or a home-equity agreement? (未分類)
- [MarketWatch Top Stories] ‘I claimed Social Security at 62’: At 76, I’m working at Walmart. Why do I still owe payroll taxes? (未分類)
- [MarketWatch Top Stories] Rocket Lab to take on SpaceX’s Starlink with $8 billion acquisition (未分類)
