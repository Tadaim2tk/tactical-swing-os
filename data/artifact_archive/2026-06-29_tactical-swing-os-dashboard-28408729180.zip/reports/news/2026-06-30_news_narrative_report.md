# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-30 08:10:32 JST
生成日時（UTC）: 2026-06-29 23:10:32 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.78
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: geopolitical_risk
日本語要約: 地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 57.5
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 38.33
- oil_supply_risk_news_score: 19.17
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 19.17
- geopolitical_risk_news_score: 95.83
- inflation_pressure_news_score: 19.17
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- AeroVironment soars 19% on earnings beat, backlog grows to $1.2 billion (リスクオン要因 / 株式モメンタム)
- Micron's monster post-earnings rally is almost gone. Traders divided on where it goes next (リスクオン要因)
- Oil prices near pre-war levels — but persistent supply risks could spark a rebound, analysts warn (地政学リスク / リスクオン要因 / 金安全資産需要 / リスクオフ要因)
- Oil prices rise as U.S. and Iran reach deal to halt attacks, U.S. oil above $70 per barrel again (地政学リスク / インフレ圧力 / 原油供給リスク / リスクオフ要因 / 金利圧力候補)
- Putin’s fuel shortage admission signals growing strain on Russia’s energy infrastructure (地政学リスク / リスクオフ要因)
- Op-ed: If you think China needs to dethrone U.S. dollar, you don't understand how it is waging global currency war (地政学リスク / 金安全資産需要 / リスクオフ要因)
