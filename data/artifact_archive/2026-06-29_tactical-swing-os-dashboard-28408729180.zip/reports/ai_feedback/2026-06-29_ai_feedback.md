# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-30 08:10:32 JST
Actions実行時刻（UTC）: 2026-06-29 23:10:32 UTC
対象日: 2026-06-29
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 52.98
- risk_off: 34.11
- dollar: 34.96
- rate: 34.99
- volatility: 48.36
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=1, neutral=8, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 52.98 | 34.11 | 34.96 | 34.99 | 56.92 | 35.75 | 48.36 | 93.86 |
| DXY | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| GOLD | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| NASDAQ | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| SPX | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| US10Y | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| USDJPY | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| VIX | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |
| WTI | 51.05 | 48.73 | 49.94 | 49.98 | 48.46 | 51.07 | 48.36 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260629_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260629_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260629_GOLD_SHORT_B-Watch | GOLD | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative | conflicted | -21 | GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260629_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260629_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260629_US10Y_NONE_NO_TRADE | US10Y | NONE | NO_TRADE | NO_TRADE | momentum_negative|rsi_oversold|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260629_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260629_VIX_NONE_NO_TRADE | VIX | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |
| 20260629_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり
- top_news_drivers: AeroVironment soars 19% on earnings beat, backlog grows to $1.2 billion, Micron's monster post-earnings rally is almost gone. Traders divided on where it goes next, Oil prices near pre-war levels — but persistent supply risks could spark a rebound, analysts warn, Oil prices rise as U.S. and Iran reach deal to halt attacks, U.S. oil above $70 per barrel again, Putin’s fuel shortage admission signals growing strain on Russia’s energy infrastructure

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-29T23:10:32,2026-06-30 08:10:32 JST,2026-06-29 23:10:32 UTC,2026-06-29,BTC,20260629_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low,neutral,0,52.98,34.11,34.96,34.99,56.92,35.75,48.36,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-29T23:10:32,2026-06-30 08:10:32 JST,2026-06-29 23:10:32 UTC,2026-06-29,DXY,20260629_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rr_too_low,neutral,0,52.98,34.11,34.96,34.99,56.92,35.75,48.36,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-29T23:10:32,2026-06-30 08:10:32 JST,2026-06-29 23:10:32 UTC,2026-06-29,GOLD,20260629_GOLD_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative,conflicted,-21,52.98,34.11,34.96,34.99,56.92,35.75,48.36,93.86,100.0,market_proxy_plus_news,,,context_warning,GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,GOLD SHORT は市場文脈と衝突。明日はrank/entry条件を慎重化する仮説。,False,sheets_evaluations,False,True
2026-06-29T23:10:32,2026-06-30 08:10:32 JST,2026-06-29 23:10:32 UTC,2026-06-29,NASDAQ,20260629_NASDAQ_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20,neutral,0,52.98,34.11,34.96,34.99,56.92,35.75,48.36,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,NASDAQ NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-29T23:10:32,2026-06-30 08:10:32 JST,2026-06-29 23:10:32 UTC,2026-06-29,SPX,20260629_SPX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20,neutral,0,52.98,34.11,34.96,34.99,56.92,35.75,48.36,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,SPX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-29T23:10:32,2026-06-30 08:10:32 JST,2026-06-29 23:10:32 UTC,2026-06-29,US10Y,20260629_US10Y_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|rsi_oversold|rr_too_low,neutral,0,52.98,34.11,34.96,34.99,56.92,35.75,48.36,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,US10Y NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-29T23:10:32,2026-06-30 08:10:32 JST,2026-06-29 23:10:32 UTC,2026-06-29,USDJPY,20260629_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,52.98,34.11,34.96,34.99,56.92,35.75,48.36,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-29T23:10:32,2026-06-30 08:10:32 JST,2026-06-29 23:10:32 UTC,2026-06-29,VIX,20260629_VIX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low|pullback_to_ma20,neutral,0,52.98,34.11,34.96,34.99,56.92,35.75,48.36,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,VIX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-29T23:10:32,2026-06-30 08:10:32 JST,2026-06-29 23:10:32 UTC,2026-06-29,WTI,20260629_WTI_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low,neutral,0,52.98,34.11,34.96,34.99,56.92,35.75,48.36,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,WTI NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-29T23:10:32",
  "generated_at_jst": "2026-06-30 08:10:32 JST",
  "generated_at_utc": "2026-06-29 23:10:32 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-29",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "top_news_drivers": [
    {
      "title": "AeroVironment soars 19% on earnings beat, backlog grows to $1.2 billion",
      "source": "CNBC Markets",
      "matched_assets": "SPX|NASDAQ",
      "matched_rules": "risk_on_news_score:earnings beat|equity_momentum_news_score:earnings beat",
      "driver_tags": "risk_on|equity_momentum",
      "driver_summary_ja": "リスクオン要因 / 株式モメンタム",
      "link": "https://www.cnbc.com/2026/06/29/aerovironment-stock-soars-on-earnings-beat-backlog-grows-to-1point2b.html"
    },
    {
      "title": "Micron's monster post-earnings rally is almost gone. Traders divided on where it goes next",
      "source": "CNBC Markets",
      "matched_assets": "SPX|NASDAQ",
      "matched_rules": "risk_on_news_score:rally",
      "driver_tags": "risk_on",
      "driver_summary_ja": "リスクオン要因",
      "link": "https://www.cnbc.com/2026/06/29/micron-shares-fall-how-bulls-and-bears-are-positioned-in-chip-trade.html"
    },
    {
      "title": "Oil prices near pre-war levels — but persistent supply risks could spark a rebound, analysts warn",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "risk_on_news_score:rebound|gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "risk_on|gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオン要因 / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/29/strait-of-hormuz-shipping-iran-oil-war-us.html"
    },
    {
      "title": "Oil prices rise as U.S. and Iran reach deal to halt attacks, U.S. oil above $70 per barrel again",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "oil_supply_risk_news_score:middle east|geopolitical_risk_news_score:middle east|inflation_pressure_news_score:prices rise",
      "driver_tags": "oil_supply_risk|geopolitical_risk|inflation_pressure",
      "driver_summary_ja": "地政学リスク / インフレ圧力 / 原油供給リスク / リスクオフ要因 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/06/29/oil-prices-wti-brent-crude-us-iran-strikes-strait-hormuz-talks.html"
    },
    {
      "title": "Putin’s fuel shortage admission signals growing strain on Russia’s energy infrastructure",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "geopolitical_risk_news_score:russia|geopolitical_risk_news_score:ukraine",
      "driver_tags": "geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/29/putin-russia-fuel-shortages-ukraine-drone-strikes.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 52.98,
      "risk_off_score": 34.11,
      "dollar_strength_score": 34.96,
      "rate_pressure_score": 34.99,
      "gold_safe_haven_score": 56.92,
      "oil_supply_risk_proxy_score": 40.74,
      "crypto_liquidity_score": 35.75,
      "equity_momentum_score": 41.69,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 57.5,
      "risk_off_news_score": 0.0,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 38.33,
      "oil_supply_risk_news_score": 19.17,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 19.17,
      "geopolitical_risk_news_score": 95.83,
      "inflation_pressure_news_score": 19.17,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.2535,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1265,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0317,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0367,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0914,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0352,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -5.1075,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 51.05,
      "risk_off_score": 48.73,
      "dollar_strength_score": 49.94,
      "rate_pressure_score": 49.98,
      "gold_safe_haven_score": 48.46,
      "oil_supply_risk_proxy_score": 49.98,
      "crypto_liquidity_score": 51.07,
      "equity_momentum_score": 51.34,
      "volatility_stress_score": 48.36,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1278,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260629_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260629_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260629_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative",
      "narrative_alignment": "conflicted",
      "narrative_alignment_score": -21,
      "narrative_comment": "GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260629_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260629_SPX_NONE_NO_TRADE",
      "asset": "SPX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_negative|atr_too_high|rr_too_low|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260629_US10Y_NONE_NO_TRADE",
      "asset": "US10Y",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|rsi_oversold|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260629_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260629_VIX_NONE_NO_TRADE",
      "asset": "VIX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260629_WTI_NONE_NO_TRADE",
      "asset": "WTI",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
