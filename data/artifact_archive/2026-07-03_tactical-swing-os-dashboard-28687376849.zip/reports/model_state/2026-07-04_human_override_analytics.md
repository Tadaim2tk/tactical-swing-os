# Human Override Analytics

## 1. 概要

- 生成日時JST: 2026-07-04 08:15:18 JST
- analytics_status: active
- total_overrides: 47
- accepted_count: 0
- held_count: 47
- rejected_count: 0
- blocked_count: 0
- positive_override_count: 0
- negative_override_count: 0
- unknown_outcome_count: 47
- recommended_next_action: wait_for_proposal_impact
- requires_human_approval: true
- patch_applied: false
- weights_json_updated: false
- generate_signal_updated: false
- apply_automatically: false

## 2. Analytics

- 人間採用率: 0.0
- 人間保留率: 1.0
- 人間却下率: 0.0
- 採用後改善率: 0.0
- 採用後悪化率: 0.0
- 保留後改善率: 0.0
- 保留後悪化率: 0.0
- 平均impact_score: 0.0

## 3. Positive Override

該当なし

## 4. Negative Override

該当なし

## 5. Unknown Outcome

| proposal_id | review_decision | adoption_status | override_type | override_reason | impact_status | impact_score | source | recommended_next_action |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260704_asset_BTC_asset_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_asset_GOLD_asset_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_asset_NASDAQ_asset_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_asset_WTI_asset_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_narrative_crypto_liquidity_narrative_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_narrative_dollar_strength_narrative_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_narrative_geopolitical_risk_narrative_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_narrative_oil_supply_risk_narrative_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_narrative_rate_pressure_narrative_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_narrative_risk_off_narrative_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_narrative_risk_on_narrative_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_rank_B_rank_confidence_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_reason_code_breakout_down_reason_code_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_reason_code_ma_alignment_bear_reason_code_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_reason_code_ma_alignment_bull_reason_code_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_reason_code_momentum_negative_reason_code_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_reason_code_momentum_positive_reason_code_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_reason_code_trend_down_reason_code_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_reason_code_trend_up_reason_code_weight_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |
| 20260704_side_LONG_side_bias_adjustment |  | unreviewed | held | no review decision available | unknown | 0.0 | proposal_adoption_tracking | wait_for_more_data |

## 6. 注意事項

- 人間判断を評価するだけです
- 自動修正は禁止です
- 自動適用は禁止です
- weights.jsonは更新しません
- patchは適用しません
- generate_signal.pyは変更しません
- Google Sheetsへの書き込みは行いません
- 実売買・発注・XM操作は行いません
