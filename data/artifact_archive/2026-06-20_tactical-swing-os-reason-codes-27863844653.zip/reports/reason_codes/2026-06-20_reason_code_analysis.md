# Tactical Swing OS Reason Code Analysis

## 1. 結論

reason_codesの有効性を集計しました。

対象期間: 2026-06-14 - 2026-06-20

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. reason_codes 上位プラス要因

_該当なし_

## 3. reason_codes 上位マイナス要因

_該当なし_

## 4. no_trade_reason 分析

| no_trade_reason | count | no_trade_correct_count | no_trade_missed_count | missed_opportunity_count | average_mfe_r | average_r | assessment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rr_too_low | 19 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |
| low_volatility | 5 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |

## 5. 取り逃し候補

_該当なし_

## 6. 改善候補

_該当なし_

## 7. データ不足の注意

reason_codeごとの評価件数が5件未満の場合は `insufficient_data` とし、weights.jsonは自動更新しません。

## 8. REASON_CODE_ANALYSIS CSV

```csv
reason_code,signals_count,evaluated_count,win_count,loss_count,no_entry_count,missed_opportunity_count,win_rate,total_r,average_r,median_r,best_r,worst_r,average_mfe_r,average_mae_r,rank_a_count,rank_b_count,no_trade_count,recommended_action_trade_count,recommended_action_watch_count,recommended_action_no_trade_count,reliability_label
pullback_to_ma20,9,5,0,0,0,0,0.0,0.775,0.1938,0.2096,0.3744,-0.0185,0.2601,-0.2122,1,4,4,1,4,4,neutral
rsi_overbought,5,2,0,0,0,0,0.0,0.3526,0.1763,0.1763,0.3109,0.0417,0.3285,-0.0556,1,1,3,1,1,3,insufficient_data
breakout_up,2,2,0,0,0,0,0.0,0.3526,0.1763,0.1763,0.3109,0.0417,0.3285,-0.0556,1,1,0,1,1,0,insufficient_data
momentum_positive,21,13,0,0,0,0,0.0,1.2289,0.1229,0.0912,0.3744,-0.0721,0.2038,-0.1852,1,12,8,1,12,8,neutral
ma_alignment_bull,23,14,0,0,0,0,0.0,1.3854,0.1155,0.0912,0.3744,-0.1218,0.1971,-0.1971,1,13,9,1,13,9,neutral
trend_up,23,14,0,0,0,0,0.0,1.3854,0.1155,0.0912,0.3744,-0.1218,0.1971,-0.1971,1,13,9,1,13,9,neutral
atr_too_high,9,9,0,0,0,0,0.0,0.6858,0.098,0.0241,0.3744,-0.1218,0.1581,-0.2169,0,9,0,0,9,0,neutral
breakout_down,4,4,0,0,0,0,0.0,0.3424,0.0856,0.0891,0.1923,-0.0281,0.1857,-0.0414,0,4,0,0,4,0,insufficient_data
momentum_negative,25,10,0,0,0,0,0.0,0.2561,0.032,-0.019,0.1923,-0.0281,0.1144,-0.0794,1,9,15,1,9,15,neutral
overextended,11,9,0,0,0,0,0.0,0.2268,0.0283,-0.0193,0.1923,-0.0488,0.118,-0.1183,2,7,2,2,7,2,neutral
ma_alignment_bear,22,12,0,0,0,0,0.0,0.2073,0.023,-0.0195,0.1923,-0.0488,0.112,-0.108,2,10,10,2,10,10,neutral
trend_down,22,12,0,0,0,0,0.0,0.2073,0.023,-0.0195,0.1923,-0.0488,0.112,-0.108,2,10,10,2,10,10,neutral
rr_too_low,24,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,24,0,0,24,insufficient_data
range_middle,9,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,9,0,0,9,insufficient_data
atr_too_low,5,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,5,0,0,5,insufficient_data
rsi_oversold,1,1,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,1,0,0,1,0,insufficient_data
```

## 9. REASON_CODE_ANALYSIS JSON

```json
{
  "start_date": "2026-06-14",
  "end_date": "2026-06-20",
  "reason_code_summary": [
    {
      "reason_code": "pullback_to_ma20",
      "signals_count": 9,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.775,
      "average_r": 0.1938,
      "median_r": 0.2096,
      "best_r": 0.3744,
      "worst_r": -0.0185,
      "average_mfe_r": 0.2601,
      "average_mae_r": -0.2122,
      "rank_a_count": 1,
      "rank_b_count": 4,
      "no_trade_count": 4,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 4,
      "recommended_action_no_trade_count": 4,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rsi_overbought",
      "signals_count": 5,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.3526,
      "average_r": 0.1763,
      "median_r": 0.1763,
      "best_r": 0.3109,
      "worst_r": 0.0417,
      "average_mfe_r": 0.3285,
      "average_mae_r": -0.0556,
      "rank_a_count": 1,
      "rank_b_count": 1,
      "no_trade_count": 3,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 3,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "breakout_up",
      "signals_count": 2,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.3526,
      "average_r": 0.1763,
      "median_r": 0.1763,
      "best_r": 0.3109,
      "worst_r": 0.0417,
      "average_mfe_r": 0.3285,
      "average_mae_r": -0.0556,
      "rank_a_count": 1,
      "rank_b_count": 1,
      "no_trade_count": 0,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "momentum_positive",
      "signals_count": 21,
      "evaluated_count": 13,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 1.2289,
      "average_r": 0.1229,
      "median_r": 0.0912,
      "best_r": 0.3744,
      "worst_r": -0.0721,
      "average_mfe_r": 0.2038,
      "average_mae_r": -0.1852,
      "rank_a_count": 1,
      "rank_b_count": 12,
      "no_trade_count": 8,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 12,
      "recommended_action_no_trade_count": 8,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 23,
      "evaluated_count": 14,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 1.3854,
      "average_r": 0.1155,
      "median_r": 0.0912,
      "best_r": 0.3744,
      "worst_r": -0.1218,
      "average_mfe_r": 0.1971,
      "average_mae_r": -0.1971,
      "rank_a_count": 1,
      "rank_b_count": 13,
      "no_trade_count": 9,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 13,
      "recommended_action_no_trade_count": 9,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 23,
      "evaluated_count": 14,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 1.3854,
      "average_r": 0.1155,
      "median_r": 0.0912,
      "best_r": 0.3744,
      "worst_r": -0.1218,
      "average_mfe_r": 0.1971,
      "average_mae_r": -0.1971,
      "rank_a_count": 1,
      "rank_b_count": 13,
      "no_trade_count": 9,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 13,
      "recommended_action_no_trade_count": 9,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "atr_too_high",
      "signals_count": 9,
      "evaluated_count": 9,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.6858,
      "average_r": 0.098,
      "median_r": 0.0241,
      "best_r": 0.3744,
      "worst_r": -0.1218,
      "average_mfe_r": 0.1581,
      "average_mae_r": -0.2169,
      "rank_a_count": 0,
      "rank_b_count": 9,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 9,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "breakout_down",
      "signals_count": 4,
      "evaluated_count": 4,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.3424,
      "average_r": 0.0856,
      "median_r": 0.0891,
      "best_r": 0.1923,
      "worst_r": -0.0281,
      "average_mfe_r": 0.1857,
      "average_mae_r": -0.0414,
      "rank_a_count": 0,
      "rank_b_count": 4,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 4,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "momentum_negative",
      "signals_count": 25,
      "evaluated_count": 10,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.2561,
      "average_r": 0.032,
      "median_r": -0.019,
      "best_r": 0.1923,
      "worst_r": -0.0281,
      "average_mfe_r": 0.1144,
      "average_mae_r": -0.0794,
      "rank_a_count": 1,
      "rank_b_count": 9,
      "no_trade_count": 15,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 9,
      "recommended_action_no_trade_count": 15,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "overextended",
      "signals_count": 11,
      "evaluated_count": 9,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.2268,
      "average_r": 0.0283,
      "median_r": -0.0193,
      "best_r": 0.1923,
      "worst_r": -0.0488,
      "average_mfe_r": 0.118,
      "average_mae_r": -0.1183,
      "rank_a_count": 2,
      "rank_b_count": 7,
      "no_trade_count": 2,
      "recommended_action_trade_count": 2,
      "recommended_action_watch_count": 7,
      "recommended_action_no_trade_count": 2,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "ma_alignment_bear",
      "signals_count": 22,
      "evaluated_count": 12,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.2073,
      "average_r": 0.023,
      "median_r": -0.0195,
      "best_r": 0.1923,
      "worst_r": -0.0488,
      "average_mfe_r": 0.112,
      "average_mae_r": -0.108,
      "rank_a_count": 2,
      "rank_b_count": 10,
      "no_trade_count": 10,
      "recommended_action_trade_count": 2,
      "recommended_action_watch_count": 10,
      "recommended_action_no_trade_count": 10,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_down",
      "signals_count": 22,
      "evaluated_count": 12,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.2073,
      "average_r": 0.023,
      "median_r": -0.0195,
      "best_r": 0.1923,
      "worst_r": -0.0488,
      "average_mfe_r": 0.112,
      "average_mae_r": -0.108,
      "rank_a_count": 2,
      "rank_b_count": 10,
      "no_trade_count": 10,
      "recommended_action_trade_count": 2,
      "recommended_action_watch_count": 10,
      "recommended_action_no_trade_count": 10,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rr_too_low",
      "signals_count": 24,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 24,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 24,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "range_middle",
      "signals_count": 9,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 9,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 9,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "atr_too_low",
      "signals_count": 5,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 5,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "rsi_oversold",
      "signals_count": 1,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    }
  ],
  "no_trade_reason_summary": [
    {
      "no_trade_reason": "rr_too_low",
      "count": 19,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    },
    {
      "no_trade_reason": "low_volatility",
      "count": 5,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    }
  ],
  "top_positive_reasons": [],
  "top_negative_reasons": [],
  "over_filtering_candidates": [],
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 49,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "notes": [
    "reason_code単位のweights自動更新はまだ行いません。",
    "insufficient_data reason_codes: 7"
  ]
}
```
