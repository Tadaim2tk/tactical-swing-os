# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-20 08:10:16 JST
Actions実行時刻（UTC）: 2026-06-19 23:10:16 UTC
対象日: 2026-06-19
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 35.12
- risk_off: 46.17
- dollar: 35.24
- rate: 41.02
- volatility: 49.63
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=1, neutral=7, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 35.12 | 46.17 | 35.24 | 41.02 | 58.36 | 35.16 | 49.63 | 93.86 |
| DXY | 50.17 | 49.53 | 50.34 | 50.38 | 49.08 | 50.23 | 49.63 | 92.78 |
| GOLD | 50.17 | 49.53 | 50.34 | 50.38 | 49.08 | 50.23 | 49.63 | 92.78 |
| NASDAQ | 50.17 | 49.53 | 50.34 | 50.38 | 49.08 | 50.23 | 49.63 | 92.78 |
| SPX | 50.17 | 49.53 | 50.34 | 50.38 | 49.08 | 50.23 | 49.63 | 92.78 |
| US10Y | 50.17 | 49.53 | 50.34 | 50.38 | 49.08 | 50.23 | 49.63 | 92.78 |
| USDJPY | 50.17 | 49.53 | 50.34 | 50.38 | 49.08 | 50.23 | 49.63 | 92.78 |
| VIX | 50.17 | 49.53 | 50.34 | 50.38 | 49.08 | 50.23 | 49.63 | 92.78 |
| WTI | 50.17 | 49.53 | 50.34 | 50.38 | 49.08 | 50.23 | 49.63 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260619_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。 |
| 20260619_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。 |
| 20260619_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。 |
| 20260619_GOLD_SHORT_B-Watch | GOLD | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative | conflicted | -28 | GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。 |
| 20260619_NASDAQ_LONG_B-Watch | NASDAQ | LONG | B | WATCH | trend_up|ma_alignment_bull|momentum_positive|atr_too_high | neutral | -14 | NASDAQは株式モメンタム、金利圧力、ボラティリティで評価しました。 地政学リスクが高く、BTC/NASDAQ LONGは慎重化が必要です。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。 |
| 20260619_SPX_LONG_A-Pullback | SPX | LONG | B | WATCH | trend_up|ma_alignment_bull|momentum_positive|atr_too_high | neutral | -14 | SPXは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。 |
| 20260619_VIX_SHORT_B-Watch | VIX | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_positive|pullback_to_ma20 | neutral | 4 | VIXはボラティリティストレスとリスクオフで評価しました。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。 |
| 20260619_WTI_SHORT_B-Watch | WTI | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|overextended | neutral | -12 | WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- top_news_drivers: Oil tanker traffic in Strait of Hormuz jumps after U.S. and Iran implement deal to open sea lane, Memory crisis hits such extremes that 'even Apple can't be safe', Trump claims Iran deal is 'unconditional surrender,' says his power has 'no limits': Axios, Russia threatens escalation after Ukraine hits Moscow with largest-ever drone attack, Fedspeak vs. war deal: Here are the things that drove this week's stock market

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-19T23:10:16,2026-06-20 08:10:16 JST,2026-06-19 23:10:16 UTC,2026-06-19,USDJPY,20260619_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,35.12,46.17,35.24,41.02,58.36,35.16,49.63,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-19T23:10:16,2026-06-20 08:10:16 JST,2026-06-19 23:10:16 UTC,2026-06-19,BTC,20260619_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rr_too_low,neutral,0,35.12,46.17,35.24,41.02,58.36,35.16,49.63,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-19T23:10:16,2026-06-20 08:10:16 JST,2026-06-19 23:10:16 UTC,2026-06-19,DXY,20260619_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|rr_too_low,neutral,0,35.12,46.17,35.24,41.02,58.36,35.16,49.63,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-19T23:10:16,2026-06-20 08:10:16 JST,2026-06-19 23:10:16 UTC,2026-06-19,GOLD,20260619_GOLD_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative,conflicted,-28,35.12,46.17,35.24,41.02,58.36,35.16,49.63,93.86,100.0,market_proxy_plus_news,,,context_warning,GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。,GOLD SHORT は市場文脈と衝突。明日はrank/entry条件を慎重化する仮説。,False,sheets_evaluations,False,True
2026-06-19T23:10:16,2026-06-20 08:10:16 JST,2026-06-19 23:10:16 UTC,2026-06-19,NASDAQ,20260619_NASDAQ_LONG_B-Watch,LONG,B,WATCH,trend_up|ma_alignment_bull|momentum_positive|atr_too_high,neutral,-14,35.12,46.17,35.24,41.02,58.36,35.16,49.63,93.86,100.0,market_proxy_plus_news,,,context_neutral,NASDAQは株式モメンタム、金利圧力、ボラティリティで評価しました。 地政学リスクが高く、BTC/NASDAQ LONGは慎重化が必要です。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。,NASDAQ LONG は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-19T23:10:16,2026-06-20 08:10:16 JST,2026-06-19 23:10:16 UTC,2026-06-19,SPX,20260619_SPX_LONG_A-Pullback,LONG,B,WATCH,trend_up|ma_alignment_bull|momentum_positive|atr_too_high,neutral,-14,35.12,46.17,35.24,41.02,58.36,35.16,49.63,93.86,100.0,market_proxy_plus_news,,,context_neutral,SPXは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。,SPX LONG は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-19T23:10:16,2026-06-20 08:10:16 JST,2026-06-19 23:10:16 UTC,2026-06-19,VIX,20260619_VIX_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_positive|pullback_to_ma20,neutral,4,35.12,46.17,35.24,41.02,58.36,35.16,49.63,93.86,100.0,market_proxy_plus_news,,,context_neutral,VIXはボラティリティストレスとリスクオフで評価しました。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。,VIX SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-06-19T23:10:16,2026-06-20 08:10:16 JST,2026-06-19 23:10:16 UTC,2026-06-19,WTI,20260619_WTI_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|overextended,neutral,-12,35.12,46.17,35.24,41.02,58.36,35.16,49.63,93.86,100.0,market_proxy_plus_news,,,context_neutral,WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。,WTI SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-19T23:10:16",
  "generated_at_jst": "2026-06-20 08:10:16 JST",
  "generated_at_utc": "2026-06-19 23:10:16 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-19",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオフ優勢 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
  "top_news_drivers": [
    {
      "title": "Oil tanker traffic in Strait of Hormuz jumps after U.S. and Iran implement deal to open sea lane",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "oil_supply_risk_news_score:tanker",
      "driver_tags": "oil_supply_risk",
      "driver_summary_ja": "原油供給リスク",
      "link": "https://www.cnbc.com/2026/06/19/iran-oil-tanker-traffic-strait-hormuz-gulf-vlcc.html"
    },
    {
      "title": "Memory crisis hits such extremes that 'even Apple can't be safe'",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "risk_off_news_score:crisis",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/19/memory-crisis-hits-such-extremes-that-even-apple-cant-be-safe-.html"
    },
    {
      "title": "Trump claims Iran deal is 'unconditional surrender,' says his power has 'no limits': Axios",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "gold_safe_haven_news_score:conflict",
      "driver_tags": "gold_safe_haven",
      "driver_summary_ja": "金安全資産需要",
      "link": "https://www.cnbc.com/2026/06/19/trump-claims-iran-deal-is-unconditional-surrender-axios-.html"
    },
    {
      "title": "Russia threatens escalation after Ukraine hits Moscow with largest-ever drone attack",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "geopolitical_risk_news_score:attack|geopolitical_risk_news_score:russia|geopolitical_risk_news_score:ukraine",
      "driver_tags": "geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/19/russia-ukraine-moscow-drone-attack-trump.html"
    },
    {
      "title": "Fedspeak vs. war deal: Here are the things that drove this week's stock market",
      "source": "CNBC Markets",
      "matched_assets": "SPX|US10Y|DXY",
      "matched_rules": "gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/06/19/fedspeak-vs-war-deal-here-are-the-things-that-drove-this-weeks-stock-market.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 35.12,
      "risk_off_score": 46.17,
      "dollar_strength_score": 35.24,
      "rate_pressure_score": 41.02,
      "gold_safe_haven_score": 58.36,
      "oil_supply_risk_proxy_score": 46.93,
      "crypto_liquidity_score": 35.16,
      "equity_momentum_score": 35.14,
      "volatility_stress_score": 49.63,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 0.0,
      "risk_off_news_score": 38.33,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 19.17,
      "gold_safe_haven_news_score": 76.67,
      "oil_supply_risk_news_score": 38.33,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 100.0,
      "inflation_pressure_news_score": 38.33,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 50.17,
      "risk_off_score": 49.53,
      "dollar_strength_score": 50.34,
      "rate_pressure_score": 50.38,
      "gold_safe_haven_score": 49.08,
      "oil_supply_risk_proxy_score": 50.62,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.2,
      "volatility_stress_score": 49.63,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0357,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 50.17,
      "risk_off_score": 49.53,
      "dollar_strength_score": 50.34,
      "rate_pressure_score": 50.38,
      "gold_safe_haven_score": 49.08,
      "oil_supply_risk_proxy_score": 50.62,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.2,
      "volatility_stress_score": 49.63,
      "narrative_confidence": 92.78,
      "asset_change_pct": -1.3779,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 50.17,
      "risk_off_score": 49.53,
      "dollar_strength_score": 50.34,
      "rate_pressure_score": 50.38,
      "gold_safe_haven_score": 49.08,
      "oil_supply_risk_proxy_score": 50.62,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.2,
      "volatility_stress_score": 49.63,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.3025,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 50.17,
      "risk_off_score": 49.53,
      "dollar_strength_score": 50.34,
      "rate_pressure_score": 50.38,
      "gold_safe_haven_score": 49.08,
      "oil_supply_risk_proxy_score": 50.62,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.2,
      "volatility_stress_score": 49.63,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.2706,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 50.17,
      "risk_off_score": 49.53,
      "dollar_strength_score": 50.34,
      "rate_pressure_score": 50.38,
      "gold_safe_haven_score": 49.08,
      "oil_supply_risk_proxy_score": 50.62,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.2,
      "volatility_stress_score": 49.63,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0449,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 50.17,
      "risk_off_score": 49.53,
      "dollar_strength_score": 50.34,
      "rate_pressure_score": 50.38,
      "gold_safe_haven_score": 49.08,
      "oil_supply_risk_proxy_score": 50.62,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.2,
      "volatility_stress_score": 49.63,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0136,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 50.17,
      "risk_off_score": 49.53,
      "dollar_strength_score": 50.34,
      "rate_pressure_score": 50.38,
      "gold_safe_haven_score": 49.08,
      "oil_supply_risk_proxy_score": 50.62,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.2,
      "volatility_stress_score": 49.63,
      "narrative_confidence": 92.78,
      "asset_change_pct": -1.5258,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 50.17,
      "risk_off_score": 49.53,
      "dollar_strength_score": 50.34,
      "rate_pressure_score": 50.38,
      "gold_safe_haven_score": 49.08,
      "oil_supply_risk_proxy_score": 50.62,
      "crypto_liquidity_score": 50.23,
      "equity_momentum_score": 50.2,
      "volatility_stress_score": 49.63,
      "narrative_confidence": 92.78,
      "asset_change_pct": 1.5119,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260619_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260619_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260619_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260619_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative",
      "narrative_alignment": "conflicted",
      "narrative_alignment_score": -28,
      "narrative_comment": "GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260619_NASDAQ_LONG_B-Watch",
      "asset": "NASDAQ",
      "side": "LONG",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_high",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": -14,
      "narrative_comment": "NASDAQは株式モメンタム、金利圧力、ボラティリティで評価しました。 地政学リスクが高く、BTC/NASDAQ LONGは慎重化が必要です。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260619_SPX_LONG_A-Pullback",
      "asset": "SPX",
      "side": "LONG",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_high",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": -14,
      "narrative_comment": "SPXは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260619_VIX_SHORT_B-Watch",
      "asset": "VIX",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_positive|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 4,
      "narrative_comment": "VIXはボラティリティストレスとリスクオフで評価しました。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260619_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": -12,
      "narrative_comment": "WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 ニュース要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
