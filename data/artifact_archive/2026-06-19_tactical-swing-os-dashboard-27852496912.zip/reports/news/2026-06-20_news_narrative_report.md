# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-20 08:10:16 JST
生成日時（UTC）: 2026-06-19 23:10:16 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.73
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: geopolitical_risk, gold_safe_haven
日本語要約: 地政学リスク、金安全資産需要はありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 38.33
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 19.17
- gold_safe_haven_news_score: 76.67
- oil_supply_risk_news_score: 38.33
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 38.33
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 19.17
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Oil tanker traffic in Strait of Hormuz jumps after U.S. and Iran implement deal to open sea lane (原油供給リスク)
- Memory crisis hits such extremes that 'even Apple can't be safe' (リスクオフ要因)
- Trump claims Iran deal is 'unconditional surrender,' says his power has 'no limits': Axios (金安全資産需要)
- Russia threatens escalation after Ukraine hits Moscow with largest-ever drone attack (地政学リスク / リスクオフ要因)
- Fedspeak vs. war deal: Here are the things that drove this week's stock market (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Why Japan's $70 billion-plus intervention and a rate hike didn't prop up the yen more (金利圧力候補 / 中銀タカ派)
- U.S. opens tariff probe targeting Germany’s drug pricing policies (インフレ圧力 / 金利圧力候補)
- U.S.-Iran deal in photos: ships in the Strait of Hormuz, daily life in Tehran (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
- Indian IT stocks slump up to 7% as Accenture cuts revenue outlook, fueling fresh concerns over sector growth (リスクオフ要因)
- Japan core inflation holds steady in May, matching expectations despite energy price concerns (インフレ圧力 / 金利圧力候補)
