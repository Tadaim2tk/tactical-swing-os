# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-20 08:10:15 JST
取得日時（UTC）: 2026-06-19 23:10:15 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.73
headline件数: 30

## 見出し

- [CNBC Markets] Oil tanker traffic in Strait of Hormuz jumps after U.S. and Iran implement deal to open sea lane (WTI)
- [CNBC Markets] Musk's SpaceX stake is worth over $1 trillion. Here are the other billionaire shareholders (SPX)
- [CNBC Markets] Memory crisis hits such extremes that 'even Apple can't be safe' (未分類)
- [CNBC Markets] DOJ rebuffs judge's request to put in writing it won't move forward with 'anti-weaponization' fund (未分類)
- [CNBC Markets] The riskiest SpaceX stock trade of all had a big first week (BTC)
- [CNBC Markets] NetJets' first fatal crash kills influential Texas VC founder (NASDAQ)
- [CNBC Markets] Struggling to find a job? Try looking in Nevada (未分類)
- [CNBC Markets] In photos: Star-studded crowd gathers to celebrate the Obama Presidential Center dedication (未分類)
- [CNBC Markets] Trump claims Iran deal is 'unconditional surrender,' says his power has 'no limits': Axios (未分類)
- [CNBC Markets] Bob Iger reflects on 10 years of Shanghai Disneyland as it defies the Chinese pullback (未分類)
- [CNBC Markets] Homeowners tapped $47 billion in equity in the first quarter. What to consider before you borrow (未分類)
- [CNBC Markets] Russia threatens escalation after Ukraine hits Moscow with largest-ever drone attack (未分類)
- [CNBC Markets] Fedspeak vs. war deal: Here are the things that drove this week's stock market (SPX|US10Y|DXY)
- [CNBC Markets] India's largest telecom and digital service Jio Platforms files for IPO (未分類)
- [CNBC Markets] Jio Platforms eyes low-orbit satellite rollout as Starlink awaits India launch (未分類)
- [CNBC Markets] Why Japan's $70 billion-plus intervention and a rate hike didn't prop up the yen more (USDJPY)
- [CNBC Markets] U.S. opens tariff probe targeting Germany’s drug pricing policies (未分類)
- [CNBC Markets] 29-year-old making $250k in tech went 'undercover' at a coffee chain before opening her own matcha cafe (NASDAQ)
- [CNBC Markets] UK gilt yields jump as borrowing rises and PM Starmer faces leadership challenge (US10Y|DXY)
- [CNBC Markets] What this biotech's volatile stock price tells you about the weight loss market right now (NASDAQ)
- [CNBC Markets] U.S.-Iran deal in photos: ships in the Strait of Hormuz, daily life in Tehran (未分類)
- [CNBC Markets] Yen slides past 161 against the dollar, nearing 40-year low and reviving intervention bets (USDJPY|DXY)
- [CNBC Markets] Indian IT stocks slump up to 7% as Accenture cuts revenue outlook, fueling fresh concerns over sector growth (SPX)
- [CNBC Markets] MSCI isn't done with Indonesia yet: new report signals continued concerns over market transparency (未分類)
- [CNBC Markets] Japan core inflation holds steady in May, matching expectations despite energy price concerns (未分類)
- [MarketWatch Top Stories] My two sons will inherit a $30,000 annuity from their grandmother. What should I do with the money? (未分類)
- [MarketWatch Top Stories] Employers to college students: Never mind that 4.0 GPA. Go out and get a summer job. (未分類)
- [MarketWatch Top Stories] ‘We are habitually frugal’: My wife and I have money. How do we help our children without ruining their independence? (未分類)
- [MarketWatch Top Stories] ‘I’ll probably be working until I die’: I’m 60, work as a waiter and have $2,000 in a Roth IRA. What will happen to me? (未分類)
- [MarketWatch Top Stories] Warsh’s new task forces give the Fed wiggle room to put off changing rates until December (US10Y|DXY)
