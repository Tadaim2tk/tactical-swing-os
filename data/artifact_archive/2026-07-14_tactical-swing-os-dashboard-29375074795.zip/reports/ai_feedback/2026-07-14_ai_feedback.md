# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-07-15 08:06:02 JST
Actions実行時刻（UTC）: 2026-07-14 23:06:02 UTC
対象日: 2026-07-14
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立
- ニュースモード: ニュースのリスク方向は中立
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 41.36
- risk_off: 34.27
- dollar: 34.92
- rate: 34.73
- volatility: 48.66
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=9, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 41.36 | 34.27 | 34.92 | 34.73 | 34.15 | 35.62 | 48.66 | 93.86 |
| DXY | 50.87 | 48.96 | 49.88 | 49.61 | 48.79 | 50.89 | 48.66 | 92.78 |
| GOLD | 50.87 | 48.96 | 49.88 | 49.61 | 48.79 | 50.89 | 48.66 | 92.78 |
| NASDAQ | 50.87 | 48.96 | 49.88 | 49.61 | 48.79 | 50.89 | 48.66 | 92.78 |
| SPX | 50.87 | 48.96 | 49.88 | 49.61 | 48.79 | 50.89 | 48.66 | 92.78 |
| US10Y | 50.87 | 48.96 | 49.88 | 49.61 | 48.79 | 50.89 | 48.66 | 92.78 |
| USDJPY | 50.87 | 48.96 | 49.88 | 49.61 | 48.79 | 50.89 | 48.66 | 92.78 |
| VIX | 50.87 | 48.96 | 49.88 | 49.61 | 48.79 | 50.89 | 48.66 | 92.78 |
| WTI | 50.87 | 48.96 | 49.88 | 49.61 | 48.79 | 50.89 | 48.66 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260714_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。 |
| 20260714_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rr_too_low|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。 |
| 20260714_GOLD_NONE_NO_TRADE | GOLD | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。 |
| 20260714_NASDAQ_NONE_NO_TRADE | NASDAQ | NONE | NO_TRADE | NO_TRADE | momentum_positive|atr_too_high|rr_too_low|range_middle|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。 |
| 20260714_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。 |
| 20260714_US10Y_NONE_NO_TRADE | US10Y | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。 |
| 20260714_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。 |
| 20260714_VIX_NONE_NO_TRADE | VIX | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rr_too_low|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。 |
| 20260714_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | NO_TRADE | momentum_negative|rr_too_low|overextended | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立
- top_news_drivers: Here’s the inflation breakdown for June 2026 — in one chart, Warsh pledges Fed policy 'regime change' to rid inflation 'tax' on American people, Social Security cost-of-living adjustment estimate for 2027 falls as inflation cools, Oil prices rise as U.S. launches new Iran airstrikes, while Trump abandons Strait of Hormuz fee, Cybersecurity stocks rally on AI spending change comments from IBM's Krishna

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-07-14T23:06:02,2026-07-15 08:06:02 JST,2026-07-14 23:06:02 UTC,2026-07-14,BTC,20260714_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low,neutral,0,41.36,34.27,34.92,34.73,34.15,35.62,48.66,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-14T23:06:02,2026-07-15 08:06:02 JST,2026-07-14 23:06:02 UTC,2026-07-14,DXY,20260714_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rr_too_low|pullback_to_ma20,neutral,0,41.36,34.27,34.92,34.73,34.15,35.62,48.66,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-14T23:06:02,2026-07-15 08:06:02 JST,2026-07-14 23:06:02 UTC,2026-07-14,GOLD,20260714_GOLD_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rr_too_low,neutral,0,41.36,34.27,34.92,34.73,34.15,35.62,48.66,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。,GOLD NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-14T23:06:02,2026-07-15 08:06:02 JST,2026-07-14 23:06:02 UTC,2026-07-14,NASDAQ,20260714_NASDAQ_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|atr_too_high|rr_too_low|range_middle|pullback_to_ma20,neutral,0,41.36,34.27,34.92,34.73,34.15,35.62,48.66,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。,NASDAQ NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-14T23:06:02,2026-07-15 08:06:02 JST,2026-07-14 23:06:02 UTC,2026-07-14,SPX,20260714_SPX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rr_too_low,neutral,0,41.36,34.27,34.92,34.73,34.15,35.62,48.66,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。,SPX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-14T23:06:02,2026-07-15 08:06:02 JST,2026-07-14 23:06:02 UTC,2026-07-14,US10Y,20260714_US10Y_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low,neutral,0,41.36,34.27,34.92,34.73,34.15,35.62,48.66,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。,US10Y NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-14T23:06:02,2026-07-15 08:06:02 JST,2026-07-14 23:06:02 UTC,2026-07-14,USDJPY,20260714_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low,neutral,0,41.36,34.27,34.92,34.73,34.15,35.62,48.66,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-14T23:06:02,2026-07-15 08:06:02 JST,2026-07-14 23:06:02 UTC,2026-07-14,VIX,20260714_VIX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rr_too_low|pullback_to_ma20,neutral,0,41.36,34.27,34.92,34.73,34.15,35.62,48.66,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。,VIX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-14T23:06:02,2026-07-15 08:06:02 JST,2026-07-14 23:06:02 UTC,2026-07-14,WTI,20260714_WTI_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|rr_too_low|overextended,neutral,0,41.36,34.27,34.92,34.73,34.15,35.62,48.66,93.86,100.0,market_proxy_plus_news,no_trade,0.0,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。,WTI NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-07-14T23:06:02",
  "generated_at_jst": "2026-07-15 08:06:02 JST",
  "generated_at_utc": "2026-07-14 23:06:02 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-07-14",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 84,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立",
  "top_news_drivers": [
    {
      "title": "Here’s the inflation breakdown for June 2026 — in one chart",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "inflation_pressure_news_score:inflation",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/07/14/inflation-cpi-june-2026-in-one-chart.html"
    },
    {
      "title": "Warsh pledges Fed policy 'regime change' to rid inflation 'tax' on American people",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "inflation_pressure_news_score:inflation",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/07/14/warsh-promises-inflation-will-be-a-thing-of-the-past-cites-benefits-of-ai-investment-boom.html"
    },
    {
      "title": "Social Security cost-of-living adjustment estimate for 2027 falls as inflation cools",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "inflation_pressure_news_score:inflation",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/07/14/social-security-cola-in-2027-cooling-inflation-lowers-estimate.html"
    },
    {
      "title": "Oil prices rise as U.S. launches new Iran airstrikes, while Trump abandons Strait of Hormuz fee",
      "source": "CNBC Markets",
      "matched_assets": "WTI",
      "matched_rules": "inflation_pressure_news_score:prices rise",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/07/14/oil-prices-today-brent-wti-hormuz-trump-toll-iran.html"
    },
    {
      "title": "Cybersecurity stocks rally on AI spending change comments from IBM's Krishna",
      "source": "CNBC Markets",
      "matched_assets": "SPX",
      "matched_rules": "risk_on_news_score:rally",
      "driver_tags": "risk_on",
      "driver_summary_ja": "リスクオン要因",
      "link": "https://www.cnbc.com/2026/07/14/cybersecurity-stocks-ai-spending-mythos.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 41.36,
      "risk_off_score": 34.27,
      "dollar_strength_score": 34.92,
      "rate_pressure_score": 34.73,
      "gold_safe_haven_score": 34.15,
      "oil_supply_risk_proxy_score": 35.08,
      "crypto_liquidity_score": 35.62,
      "equity_momentum_score": 35.76,
      "volatility_stress_score": 48.66,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 19.17,
      "risk_off_news_score": 0.0,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 0.0,
      "oil_supply_risk_news_score": 0.0,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 0.0,
      "inflation_pressure_news_score": 95.83,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 50.87,
      "risk_off_score": 48.96,
      "dollar_strength_score": 49.88,
      "rate_pressure_score": 49.61,
      "gold_safe_haven_score": 48.79,
      "oil_supply_risk_proxy_score": 50.11,
      "crypto_liquidity_score": 50.89,
      "equity_momentum_score": 51.09,
      "volatility_stress_score": 48.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.3357,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 50.87,
      "risk_off_score": 48.96,
      "dollar_strength_score": 49.88,
      "rate_pressure_score": 49.61,
      "gold_safe_haven_score": 48.79,
      "oil_supply_risk_proxy_score": 50.11,
      "crypto_liquidity_score": 50.89,
      "equity_momentum_score": 51.09,
      "volatility_stress_score": 48.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0542,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 50.87,
      "risk_off_score": 48.96,
      "dollar_strength_score": 49.88,
      "rate_pressure_score": 49.61,
      "gold_safe_haven_score": 48.79,
      "oil_supply_risk_proxy_score": 50.11,
      "crypto_liquidity_score": 50.89,
      "equity_momentum_score": 51.09,
      "volatility_stress_score": 48.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0445,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 50.87,
      "risk_off_score": 48.96,
      "dollar_strength_score": 49.88,
      "rate_pressure_score": 49.61,
      "gold_safe_haven_score": 48.79,
      "oil_supply_risk_proxy_score": 50.11,
      "crypto_liquidity_score": 50.89,
      "equity_momentum_score": 51.09,
      "volatility_stress_score": 48.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0198,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 50.87,
      "risk_off_score": 48.96,
      "dollar_strength_score": 49.88,
      "rate_pressure_score": 49.61,
      "gold_safe_haven_score": 48.79,
      "oil_supply_risk_proxy_score": 50.11,
      "crypto_liquidity_score": 50.89,
      "equity_momentum_score": 51.09,
      "volatility_stress_score": 48.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.6285,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 50.87,
      "risk_off_score": 48.96,
      "dollar_strength_score": 49.88,
      "rate_pressure_score": 49.61,
      "gold_safe_haven_score": 48.79,
      "oil_supply_risk_proxy_score": 50.11,
      "crypto_liquidity_score": 50.89,
      "equity_momentum_score": 51.09,
      "volatility_stress_score": 48.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0136,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 50.87,
      "risk_off_score": 48.96,
      "dollar_strength_score": 49.88,
      "rate_pressure_score": 49.61,
      "gold_safe_haven_score": 48.79,
      "oil_supply_risk_proxy_score": 50.11,
      "crypto_liquidity_score": 50.89,
      "equity_momentum_score": 51.09,
      "volatility_stress_score": 48.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": -4.1255,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 50.87,
      "risk_off_score": 48.96,
      "dollar_strength_score": 49.88,
      "rate_pressure_score": 49.61,
      "gold_safe_haven_score": 48.79,
      "oil_supply_risk_proxy_score": 50.11,
      "crypto_liquidity_score": 50.89,
      "equity_momentum_score": 51.09,
      "volatility_stress_score": 48.66,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1881,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260714_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|breakout_up|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260714_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rr_too_low|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260714_GOLD_NONE_NO_TRADE",
      "asset": "GOLD",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260714_NASDAQ_NONE_NO_TRADE",
      "asset": "NASDAQ",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|atr_too_high|rr_too_low|range_middle|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260714_SPX_NONE_NO_TRADE",
      "asset": "SPX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260714_US10Y_NONE_NO_TRADE",
      "asset": "US10Y",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260714_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260714_VIX_NONE_NO_TRADE",
      "asset": "VIX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rr_too_low|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260714_WTI_NONE_NO_TRADE",
      "asset": "WTI",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|rr_too_low|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: インフレ圧力はありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
