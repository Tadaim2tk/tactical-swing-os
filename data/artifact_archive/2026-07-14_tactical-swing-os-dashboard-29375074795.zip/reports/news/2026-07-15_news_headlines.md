# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-15 08:05:58 JST
取得日時（UTC）: 2026-07-14 23:05:58 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.63
headline件数: 30

## 見出し

- [CNBC Markets] The AI boom just found two new winners: Goldman Sachs and JPMorgan Chase (GOLD|SPX)
- [CNBC Markets] Here’s the inflation breakdown for June 2026 — in one chart (未分類)
- [CNBC Markets] Warsh pledges Fed policy 'regime change' to rid inflation 'tax' on American people (US10Y|DXY)
- [CNBC Markets] U.S. strikes Iran before Hormuz Strait blockade restarts (未分類)
- [CNBC Markets] SK Hynix options begin trading. But another group of stocks is stealing its thunder (BTC|SPX)
- [CNBC Markets] Current and former employees sue Meta, alleging discrimination in using AI to conduct layoffs (未分類)
- [CNBC Markets] United Airlines' new upsell: Keeping other travelers out of the middle seat (未分類)
- [CNBC Markets] Social Security cost-of-living adjustment estimate for 2027 falls as inflation cools (未分類)
- [CNBC Markets] Jim Cramer says concerns about AI market froth are overblown. Here's why (未分類)
- [CNBC Markets] New York becomes first U.S. state to impose AI data center ban (未分類)
- [CNBC Markets] Bipartisan group of senators propose Social Security reform process ahead of funding shortfall (未分類)
- [CNBC Markets] Lucid dismisses report that it is weighing filing for bankruptcy or going private after shares plunge (SPX)
- [CNBC Markets] Zipline adds ex-Tesla, Uber, Waymo execs to make drone delivery mainstream across U.S. (未分類)
- [CNBC Markets] Oil prices rise as U.S. launches new Iran airstrikes, while Trump abandons Strait of Hormuz fee (WTI)
- [CNBC Markets] Cybersecurity stocks rally on AI spending change comments from IBM's Krishna (SPX)
- [CNBC Markets] Johnson & Johnson has a chance to show it's more than just a rotation winner (SPX|NASDAQ)
- [CNBC Markets] U.S. trade official says 'very few' Nvidia H200 AI chips have been shipped to China (NASDAQ)
- [CNBC Markets] IBM stock craters 25%, the worst day on record, after company issues second-quarter earnings warning (SPX|NASDAQ)
- [CNBC Markets] Supreme Court Justice Barrett says the threat level against judges 'is really high' (未分類)
- [CNBC Markets] T. rex sells for $50 million, becoming the most expensive dinosaur fossil ever auctioned (未分類)
- [CNBC Markets] Warren Buffett is accelerating his charitable donations with aim to give away Berkshire wealth by 2034 (SPX)
- [CNBC Markets] Apple in talks with startup that shrinks AI models to run on an iPhone (未分類)
- [CNBC Markets] E. Jean Carroll receives $5.6M from Trump in sex abuse, defamation case (US10Y|DXY)
- [CNBC Markets] Chamath Palihapitiya says soaring AI token spend will hit companies' earnings (SPX|NASDAQ)
- [CNBC Markets] Paramount still plans to close WBD merger by end of September despite lawsuit (未分類)
- [CNBC Markets] Consumer prices rose 3.5% annually in June, less than expected as energy prices eased (未分類)
- [CNBC Markets] Sen. Tim Scott wants to hear from Warsh on data centers and artificial intelligence (US10Y|DXY)
- [CNBC Markets] Google DeepMind chief Demis Hassabis calls for U.S. to spearhead AI standards body (NASDAQ)
- [CNBC Markets] SpaceX alumni building remote-controlled construction equipment land $115 million fund round (未分類)
- [CNBC Markets] Warren Buffett excludes Gates Foundation from his annual donations of Berkshire stock (未分類)
