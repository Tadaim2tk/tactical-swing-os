# Adversarial Review

## 1. 概要

提案・要約レイヤー(Rule/Model State/Weights Patch/Auto Calibration/AI Feedback)を
横断レビューし、危険な兆候を検出する敵対的監査です。自動適用はせず、警告のみ提示します。

## 2. レビューステータス

- review_status: **passed**
- max_severity: none
- recommended_next_action: continue_monitoring
- requires_human_approval: True / weights_json_updated: False / generate_signal_updated: False

## 3. 件数

- total_sources_checked: 5 / total_findings: 0
- blocked: 0 / high_risk: 0 / warning: 0 / info: 0
- 自動適用違反: 0 / weights更新違反: 0 / 矛盾: 0

## 4. blocked / high_risk 詳細

_該当なし_

## 5. warning 詳細

_該当なし_

## 6. finding_category 別集計

- なし

## 7. 注意事項

- この監査は自動売買判断ではありません。提案の危険兆候を人間に提示する補助です。
- weights.json / generate_signal.py は一切変更しません。
- 最終判断は人間が行います。
