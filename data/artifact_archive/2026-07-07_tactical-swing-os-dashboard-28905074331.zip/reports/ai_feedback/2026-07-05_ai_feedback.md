# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-07-08 08:10:54 JST
Actions実行時刻（UTC）: 2026-07-07 23:10:54 UTC
対象日: 2026-07-05
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 19.17
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 46.5
- risk_off: 40.79
- dollar: 34.96
- rate: 34.74
- volatility: 50.03
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=7, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 46.5 | 40.79 | 34.96 | 34.74 | 44.31 | 34.99 | 50.03 | 93.86 |
| DXY | 50.0 | 50.06 | 49.95 | 49.63 | 50.16 | 49.99 | 50.03 | 92.78 |
| GOLD | 50.0 | 50.06 | 49.95 | 49.63 | 50.16 | 49.99 | 50.03 | 92.78 |
| NASDAQ | 50.0 | 50.06 | 49.95 | 49.63 | 50.16 | 49.99 | 50.03 | 92.78 |
| SPX | 50.0 | 50.06 | 49.95 | 49.63 | 50.16 | 49.99 | 50.03 | 92.78 |
| US10Y | 50.0 | 50.06 | 49.95 | 49.63 | 50.16 | 49.99 | 50.03 | 92.78 |
| USDJPY | 50.0 | 50.06 | 49.95 | 49.63 | 50.16 | 49.99 | 50.03 | 92.78 |
| VIX | 50.0 | 50.06 | 49.95 | 49.63 | 50.16 | 49.99 | 50.03 | 92.78 |
| WTI | 50.0 | 50.06 | 49.95 | 49.63 | 50.16 | 49.99 | 50.03 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260705_BTC_NONE_NO_TRADE | BTC | NONE | NO_TRADE | NO_TRADE | momentum_negative|rr_too_low|overextended | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260705_DXY_NONE_NO_TRADE | DXY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260705_GOLD_NONE_NO_TRADE | GOLD | NONE | NO_TRADE | NO_TRADE | momentum_negative|rr_too_low|range_middle|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260705_NASDAQ_LONG_A-Pullback | NASDAQ | LONG | B | WATCH | trend_up|ma_alignment_bull|momentum_negative|atr_too_high|pullback_to_ma20 | neutral | 1 | NASDAQは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260705_SPX_LONG_B-Watch | SPX | LONG | B | WATCH | trend_up|ma_alignment_bull|momentum_negative | neutral | 1 | SPXは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260705_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low|range_middle|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |
| 20260705_WTI_NONE_NO_TRADE | WTI | NONE | NO_TRADE | NO_TRADE | trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり
- top_news_drivers: U.S. revokes Iran oil sales authorization after tanker attacks, Trump renews Greenland threats at NATO summit, says U.S. could remove troops from Europe, Traders on Kalshi think the Nasdaq-100 will end 2026 above 30,000, predicting a cooler second half of the year, As chip sector takes it on the chin, traders bet on a big Nvidia rally

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-07-07T23:10:54,2026-07-08 08:10:54 JST,2026-07-07 23:10:54 UTC,2026-07-05,BTC,20260705_BTC_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|rr_too_low|overextended,neutral,0,46.5,40.79,34.96,34.74,44.31,34.99,50.03,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,BTC NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-07T23:10:54,2026-07-08 08:10:54 JST,2026-07-07 23:10:54 UTC,2026-07-05,DXY,20260705_DXY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rr_too_low,neutral,0,46.5,40.79,34.96,34.74,44.31,34.99,50.03,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,DXY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-07T23:10:54,2026-07-08 08:10:54 JST,2026-07-07 23:10:54 UTC,2026-07-05,GOLD,20260705_GOLD_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|rr_too_low|range_middle|pullback_to_ma20,neutral,0,46.5,40.79,34.96,34.74,44.31,34.99,50.03,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,GOLD NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-07T23:10:54,2026-07-08 08:10:54 JST,2026-07-07 23:10:54 UTC,2026-07-05,NASDAQ,20260705_NASDAQ_LONG_A-Pullback,LONG,B,WATCH,trend_up|ma_alignment_bull|momentum_negative|atr_too_high|pullback_to_ma20,neutral,1,46.5,40.79,34.96,34.74,44.31,34.99,50.03,93.86,100.0,market_proxy_plus_news,,,context_neutral,NASDAQは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,NASDAQ LONG は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-07T23:10:54,2026-07-08 08:10:54 JST,2026-07-07 23:10:54 UTC,2026-07-05,SPX,20260705_SPX_LONG_B-Watch,LONG,B,WATCH,trend_up|ma_alignment_bull|momentum_negative,neutral,1,46.5,40.79,34.96,34.74,44.31,34.99,50.03,93.86,100.0,market_proxy_plus_news,,,context_neutral,SPXは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,SPX LONG は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-07T23:10:54,2026-07-08 08:10:54 JST,2026-07-07 23:10:54 UTC,2026-07-05,USDJPY,20260705_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low|range_middle|pullback_to_ma20,neutral,0,46.5,40.79,34.96,34.74,44.31,34.99,50.03,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True
2026-07-07T23:10:54,2026-07-08 08:10:54 JST,2026-07-07 23:10:54 UTC,2026-07-05,WTI,20260705_WTI_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low,neutral,0,46.5,40.79,34.96,34.74,44.31,34.99,50.03,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,WTI NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-07-07T23:10:54",
  "generated_at_jst": "2026-07-08 08:10:54 JST",
  "generated_at_utc": "2026-07-07 23:10:54 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-07-05",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
  "top_news_drivers": [
    {
      "title": "U.S. revokes Iran oil sales authorization after tanker attacks",
      "source": "CNBC Markets",
      "matched_assets": "WTI|US10Y|DXY",
      "matched_rules": "oil_supply_risk_news_score:sanctions|oil_supply_risk_news_score:tanker|geopolitical_risk_news_score:sanctions",
      "driver_tags": "oil_supply_risk|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / 原油供給リスク / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/07/07/us-revokes-iran-oil-sanctions-waiver-tanker-attacks.html"
    },
    {
      "title": "Trump renews Greenland threats at NATO summit, says U.S. could remove troops from Europe",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "risk_off_news_score:crisis",
      "driver_tags": "risk_off",
      "driver_summary_ja": "リスクオフ要因",
      "link": "https://www.cnbc.com/2026/07/07/trump-nato-summit-greenland-us-troops-europe.html"
    },
    {
      "title": "Traders on Kalshi think the Nasdaq-100 will end 2026 above 30,000, predicting a cooler second half of the year",
      "source": "CNBC Markets",
      "matched_assets": "NASDAQ",
      "matched_rules": "risk_on_news_score:rally|gold_safe_haven_news_score:war|geopolitical_risk_news_score:war",
      "driver_tags": "risk_on|gold_safe_haven|geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオン要因 / 金安全資産需要 / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/07/07/traders-on-kalshi-think-the-nasdaq-100-will-end-2026-above-30000.html"
    },
    {
      "title": "As chip sector takes it on the chin, traders bet on a big Nvidia rally",
      "source": "CNBC Markets",
      "matched_assets": "BTC|SPX|NASDAQ",
      "matched_rules": "risk_on_news_score:rally",
      "driver_tags": "risk_on",
      "driver_summary_ja": "リスクオン要因",
      "link": "https://www.cnbc.com/2026/07/07/as-chip-sector-takes-it-on-the-chin-traders-bet-on-a-big-nvidia-rally-.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 46.5,
      "risk_off_score": 40.79,
      "dollar_strength_score": 34.96,
      "rate_pressure_score": 34.74,
      "gold_safe_haven_score": 44.31,
      "oil_supply_risk_proxy_score": 46.37,
      "crypto_liquidity_score": 34.99,
      "equity_momentum_score": 35.01,
      "volatility_stress_score": 50.03,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 38.33,
      "risk_off_news_score": 19.17,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 19.17,
      "oil_supply_risk_news_score": 38.33,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 38.33,
      "inflation_pressure_news_score": 0.0,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 50.0,
      "risk_off_score": 50.06,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.63,
      "gold_safe_haven_score": 50.16,
      "oil_supply_risk_proxy_score": 49.82,
      "crypto_liquidity_score": 49.99,
      "equity_momentum_score": 50.01,
      "volatility_stress_score": 50.03,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0089,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 50.0,
      "risk_off_score": 50.06,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.63,
      "gold_safe_haven_score": 50.16,
      "oil_supply_risk_proxy_score": 49.82,
      "crypto_liquidity_score": 49.99,
      "equity_momentum_score": 50.01,
      "volatility_stress_score": 50.03,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.2985,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 50.0,
      "risk_off_score": 50.06,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.63,
      "gold_safe_haven_score": 50.16,
      "oil_supply_risk_proxy_score": 49.82,
      "crypto_liquidity_score": 49.99,
      "equity_momentum_score": 50.01,
      "volatility_stress_score": 50.03,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1236,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 50.0,
      "risk_off_score": 50.06,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.63,
      "gold_safe_haven_score": 50.16,
      "oil_supply_risk_proxy_score": 49.82,
      "crypto_liquidity_score": 49.99,
      "equity_momentum_score": 50.01,
      "volatility_stress_score": 50.03,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0364,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 50.0,
      "risk_off_score": 50.06,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.63,
      "gold_safe_haven_score": 50.16,
      "oil_supply_risk_proxy_score": 49.82,
      "crypto_liquidity_score": 49.99,
      "equity_momentum_score": 50.01,
      "volatility_stress_score": 50.03,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.3997,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 50.0,
      "risk_off_score": 50.06,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.63,
      "gold_safe_haven_score": 50.16,
      "oil_supply_risk_proxy_score": 49.82,
      "crypto_liquidity_score": 49.99,
      "equity_momentum_score": 50.01,
      "volatility_stress_score": 50.03,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0409,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 50.0,
      "risk_off_score": 50.06,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.63,
      "gold_safe_haven_score": 50.16,
      "oil_supply_risk_proxy_score": 49.82,
      "crypto_liquidity_score": 49.99,
      "equity_momentum_score": 50.01,
      "volatility_stress_score": 50.03,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1901,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 50.0,
      "risk_off_score": 50.06,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.63,
      "gold_safe_haven_score": 50.16,
      "oil_supply_risk_proxy_score": 49.82,
      "crypto_liquidity_score": 49.99,
      "equity_momentum_score": 50.01,
      "volatility_stress_score": 50.03,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.4368,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260705_BTC_NONE_NO_TRADE",
      "asset": "BTC",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|rr_too_low|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260705_DXY_NONE_NO_TRADE",
      "asset": "DXY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260705_GOLD_NONE_NO_TRADE",
      "asset": "GOLD",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|rr_too_low|range_middle|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260705_NASDAQ_LONG_A-Pullback",
      "asset": "NASDAQ",
      "side": "LONG",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_negative|atr_too_high|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 1,
      "narrative_comment": "NASDAQは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260705_SPX_LONG_B-Watch",
      "asset": "SPX",
      "side": "LONG",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_negative",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 1,
      "narrative_comment": "SPXは株式モメンタム、金利圧力、ボラティリティで評価しました。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260705_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low|range_middle|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    },
    {
      "signal_id": "20260705_WTI_NONE_NO_TRADE",
      "asset": "WTI",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|rsi_oversold|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
