# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-08 08:10:50 JST
取得日時（UTC）: 2026-07-07 23:10:50 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.2
headline件数: 30

## 見出し

- [CNBC Markets] U.S. revokes Iran oil sales authorization after tanker attacks (WTI|US10Y|DXY)
- [CNBC Markets] U.S. resumes 'powerful strikes' on Iran after Hormuz Strait ship attacks, CENTCOM says (WTI)
- [CNBC Markets] Maine Senate race replacements circle amid pressure on Platner to drop out (未分類)
- [CNBC Markets] Netflix, Disney and YouTube interested in FIFA World Cup U.S. rights; package could reach $2 billion (BTC)
- [CNBC Markets] Trump renews Greenland threats at NATO summit, says U.S. could remove troops from Europe (未分類)
- [CNBC Markets] Meta enters AI image model race in bid to court advertisers and subscribers (未分類)
- [CNBC Markets] Mitch McConnell's health concerns grow amid 4th week in hospital with few details from aides (未分類)
- [CNBC Markets] Traders on Kalshi think the Nasdaq-100 will end 2026 above 30,000, predicting a cooler second half of the year (NASDAQ)
- [CNBC Markets] DeSantis-backed 'Stop WOKE' law meets appeals court block, teeing up possible Supreme Court fight (未分類)
- [CNBC Markets] Supreme Court's Kagan, Barrett to testify to House for budget request, a first since 2019 (未分類)
- [CNBC Markets] Judge blocks DOJ subpoena for names of 2020 Fulton County, Georgia, election workers (未分類)
- [CNBC Markets] As chip sector takes it on the chin, traders bet on a big Nvidia rally (BTC|SPX|NASDAQ)
- [CNBC Markets] Rivian stock falls 18% as company sells 75 million shares to raise capital (SPX)
- [CNBC Markets] Chinese lidar maker with Nvidia ties accused of being cyber risk for U.S. (NASDAQ)
- [CNBC Markets] Stellantis to sell small Fiat Topolino EV for $13,995 in U.S. (未分類)
- [CNBC Markets] Chip stocks sell off after Samsung earnings fall short of high AI bar (SPX|NASDAQ)
- [CNBC Markets] The implications of Amazon's $25B bond sale, and Microsoft's evolving AI model strategy (US10Y)
- [CNBC Markets] Trump ally Nigel Farage quits UK parliament amid finance scandal to fight special election (未分類)
- [CNBC Markets] Don't rely on AI for personal finance advice, study finds (未分類)
- [CNBC Markets] Amazon raising at least $25 billion in bond sale, won't issue more debt in 2026 (US10Y)
- [CNBC Markets] Trump arrives in Turkey as NATO is strained by Russian attacks, U.S. impatience (未分類)
- [CNBC Markets] Buy these quality, low-stress stocks for the summer, says Jefferies (SPX)
- [CNBC Markets] Billionaires John and Laura Arnold commit $2.6 million to study online sports betting risk (未分類)
- [CNBC Markets] Far more real estate agents now report seeing a balanced market, CNBC Housing Market Survey finds (未分類)
- [CNBC Markets] Graham Platner denies sex assault claim as Democrats urge him to quit Maine Senate race (未分類)
- [CNBC Markets] World Cup in photos: Belgium beats U.S. 4-1 after Balogun controversy, Ronaldo exits (未分類)
- [CNBC Markets] Hanwha Ocean shares sink 23% as it loses bid to build Canada's next fleet of submarines (SPX)
- [CNBC Markets] Google backs nuclear fusion startup targeting Europe’s first commercial power plant (NASDAQ)
- [MarketWatch Top Stories] ‘Our family is broken beyond repair’: My brother took over my parents’ finances. What can I do? (未分類)
- [MarketWatch Top Stories] Micron’s stock falls as investors wonder if the memory market is near the top (未分類)
