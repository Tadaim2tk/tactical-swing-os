# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-17 08:43:43 JST
Actions実行時刻（UTC）: 2026-06-16 23:43:43 UTC
対象日: 2026-06-17
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立
- ニュースモード: ニュースのリスク方向は中立
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: sheets_evaluations
- latest_evaluations_available: False
- fallback_used: True
- risk_on: 34.88
- risk_off: 35.17
- dollar: 34.96
- rate: 34.8
- volatility: 50.35
- news_confidence: 86.0
- シグナル整合性: aligned=0, conflicted=0, neutral=1, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 34.88 | 35.17 | 34.96 | 34.8 | 35.3 | 34.86 | 50.35 | 92.78 |
| DXY | 49.83 | 50.24 | 49.95 | 49.71 | 50.43 | 49.8 | 50.35 | 92.78 |
| GOLD | 49.83 | 50.24 | 49.95 | 49.71 | 50.43 | 49.8 | 50.35 | 92.78 |
| NASDAQ | 49.83 | 50.24 | 49.95 | 49.71 | 50.43 | 49.8 | 50.35 | 92.78 |
| SPX | 49.83 | 50.24 | 49.95 | 49.71 | 50.43 | 49.8 | 50.35 | 92.78 |
| US10Y | 49.83 | 50.24 | 49.95 | 49.71 | 50.43 | 49.8 | 50.35 | 92.78 |
| USDJPY | 49.83 | 50.24 | 49.95 | 49.71 | 50.43 | 49.8 | 50.35 | 92.78 |
| VIX | 49.83 | 50.24 | 49.95 | 49.71 | 50.43 | 49.8 | 50.35 | 92.78 |
| WTI | 49.83 | 50.24 | 49.95 | 49.71 | 50.43 | 49.8 | 50.35 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260617_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立
- top_news_drivers: Kevin Warsh's Fed is not expected to make any change to rates for a while, according to CNBC Fed Survey

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-16T23:43:43,2026-06-17 08:43:43 JST,2026-06-16 23:43:43 UTC,2026-06-17,USDJPY,20260617_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low,neutral,0,34.88,35.17,34.96,34.8,35.3,34.86,50.35,92.78,86.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,sheets_evaluations,False,True

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-16T23:43:43",
  "generated_at_jst": "2026-06-17 08:43:43 JST",
  "generated_at_utc": "2026-06-16 23:43:43 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-17",
  "data_source": "Google Sheets",
  "evaluation_source": "sheets_evaluations",
  "evaluation_rows": 108,
  "latest_evaluations_available": false,
  "fallback_used": true,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立",
  "top_news_drivers": [
    {
      "title": "Kevin Warsh's Fed is not expected to make any change to rates for a while, according to CNBC Fed Survey",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "central_bank_dovish_score:easing",
      "driver_tags": "central_bank_dovish",
      "driver_summary_ja": "中銀ハト派",
      "link": "https://www.cnbc.com/2026/06/16/kevin-warshs-fed-is-not-expected-to-make-any-change-to-rates-for-a-while-according-to-cnbc-fed-survey.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 34.88,
      "risk_off_score": 35.17,
      "dollar_strength_score": 34.96,
      "rate_pressure_score": 34.8,
      "gold_safe_haven_score": 35.3,
      "oil_supply_risk_proxy_score": 35.04,
      "crypto_liquidity_score": 34.86,
      "equity_momentum_score": 34.84,
      "volatility_stress_score": 50.35,
      "narrative_confidence": 92.78,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 0.0,
      "risk_off_news_score": 0.0,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 0.0,
      "oil_supply_risk_news_score": 0.0,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 0.0,
      "inflation_pressure_news_score": 0.0,
      "recession_risk_news_score": 0.0,
      "news_confidence": 86.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 49.83,
      "risk_off_score": 50.24,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.71,
      "gold_safe_haven_score": 50.43,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.8,
      "equity_momentum_score": 49.77,
      "volatility_stress_score": 50.35,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1024,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 49.83,
      "risk_off_score": 50.24,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.71,
      "gold_safe_haven_score": 50.43,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.8,
      "equity_momentum_score": 49.77,
      "volatility_stress_score": 50.35,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0781,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 49.83,
      "risk_off_score": 50.24,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.71,
      "gold_safe_haven_score": 50.43,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.8,
      "equity_momentum_score": 49.77,
      "volatility_stress_score": 50.35,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1625,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 49.83,
      "risk_off_score": 50.24,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.71,
      "gold_safe_haven_score": 50.43,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.8,
      "equity_momentum_score": 49.77,
      "volatility_stress_score": 50.35,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1682,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 49.83,
      "risk_off_score": 50.24,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.71,
      "gold_safe_haven_score": 50.43,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.8,
      "equity_momentum_score": 49.77,
      "volatility_stress_score": 50.35,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.3376,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 49.83,
      "risk_off_score": 50.24,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.71,
      "gold_safe_haven_score": 50.43,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.8,
      "equity_momentum_score": 49.77,
      "volatility_stress_score": 50.35,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0069,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 49.83,
      "risk_off_score": 50.24,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.71,
      "gold_safe_haven_score": 50.43,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.8,
      "equity_momentum_score": 49.77,
      "volatility_stress_score": 50.35,
      "narrative_confidence": 92.78,
      "asset_change_pct": 1.2963,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 49.83,
      "risk_off_score": 50.24,
      "dollar_strength_score": 49.95,
      "rate_pressure_score": 49.71,
      "gold_safe_haven_score": 50.43,
      "oil_supply_risk_proxy_score": 50.06,
      "crypto_liquidity_score": 49.8,
      "equity_momentum_score": 49.77,
      "volatility_stress_score": 50.35,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1585,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260617_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 主要テーマはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "type": "no_recent_closed",
      "summary": "直近で反省対象となる決着データはありません。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
