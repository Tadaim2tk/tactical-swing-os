# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-17 08:43:41 JST
取得日時（UTC）: 2026-06-16 23:43:41 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.04
headline件数: 30

## 見出し

- [CNBC Markets] Fed Chair Warsh expected to withhold 'dot' from central bank's interest rate outlook (US10Y|DXY)
- [CNBC Markets] Carvana is expanding into new vehicles. The implications could reshape the U.S. automotive retail market (未分類)
- [CNBC Markets] Michael Burry says he's tempted to bet against SpaceX, but passes on expensive options (未分類)
- [CNBC Markets] Bill limiting investors from buying homes set to speed through Congress (未分類)
- [CNBC Markets] Databricks sales growth tops 80%, but margin are shrinking from swarm of AI agents (未分類)
- [CNBC Markets] Anthropic's Fable shutdown is a big moment for open-source AI (未分類)
- [CNBC Markets] Intel begins production of most-advanced chip, inching closer to possible Apple deal (NASDAQ)
- [CNBC Markets] India's solution to entrance exam fraud: A temporary ban on Telegram (未分類)
- [CNBC Markets] New Wharton forecast puts Social Security trust fund depletion later than official projections (未分類)
- [CNBC Markets] 'Godfather' of options sees SpaceX surpassing Nvidia, Tesla as early trades come in (未分類)
- [CNBC Markets] Technical factors are adding fuel to SpaceX's meme stock fire (BTC|NASDAQ)
- [CNBC Markets] Jim Cramer says SpaceX investors aren't buying earnings — they're buying Elon Musk (SPX|NASDAQ)
- [CNBC Markets] SpaceX rises 4% to leapfrog Amazon in market cap, closes short of Microsoft (未分類)
- [CNBC Markets] How Roku fits into Fox's future — and what investors are missing about the deal (未分類)
- [CNBC Markets] Cramer's lightning round: Buy Cava (未分類)
- [CNBC Markets] DOJ assists Musk's xAI in NAACP air pollution suit, asks court to toss case (US10Y|DXY)
- [CNBC Markets] Snap unveils $2,195 AR glasses as CEO Evan Spiegel bets on post-smartphone future (未分類)
- [CNBC Markets] Veteran traders stunned as SpaceX fans bet on 80% overnight gains: 'I've never seen anything like it' (未分類)
- [CNBC Markets] SpaceX's blistering start still faces key tests that will determine the stock's true value (未分類)
- [CNBC Markets] Trump signals he could send details of Iran deal to Congress (未分類)
- [CNBC Markets] The new oil? Inside the effort to turn AI computing power into a tradeable commodity (WTI)
- [CNBC Markets] Odds that a proposed billionaire tax appears on California ballots plunge on prediction markets (未分類)
- [CNBC Markets] FBI says it disrupted alleged plot targeting UFC event at White House (未分類)
- [CNBC Markets] Prediction market traders speculate Anthropic will restore access quickly to AI model after Trump admin directed it to limit reach (未分類)
- [CNBC Markets] SpaceX to acquire the AI coding startup Cursor for $60 billion (未分類)
- [CNBC Markets] Self-driving tech supplier Mobileye targets U.S. robotaxi launch in 2027 (NASDAQ)
- [CNBC Markets] Novig wins CFTC approval as competition intensifies in sports prediction markets (未分類)
- [CNBC Markets] Kevin Warsh's Fed is not expected to make any change to rates for a while, according to CNBC Fed Survey (US10Y|DXY)
- [CNBC Markets] Brent falls below $80 per barrel on report U.S. will allow Iran to sell oil immediately (WTI)
- [CNBC Markets] Student loan borrowers face glitches and misinformation ahead of major July 1 changes, advocates say (NASDAQ)
