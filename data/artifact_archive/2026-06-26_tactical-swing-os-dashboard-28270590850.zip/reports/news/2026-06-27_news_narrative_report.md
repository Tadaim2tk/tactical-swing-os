# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-27 08:17:56 JST
生成日時（UTC）: 2026-06-26 23:17:56 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.78
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 19.17
- gold_safe_haven_news_score: 19.17
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 38.33
- inflation_pressure_news_score: 57.5
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 19.17
- central_bank_dovish_score: 19.17
- news_confidence: 100.0

## Top News Drivers

- U.S. strikes Iran after Trump accuses Tehran of ceasefire violation in Strait of Hormuz (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Trump eases pressure on Fed Chairman Kevin Warsh as inflation tops 4% (インフレ圧力 / 金利圧力候補)
- Trump threatens 100% tariffs on countries putting 'Digital Services Tax on American Companies' (インフレ圧力 / 金利圧力候補)
- Minneapolis Fed President Neel Kashkari says he expects a rate hike this year (インフレ圧力 / 金利圧力候補 / 中銀タカ派)
- ON Semiconductor records worst day since 2020 as CEO defends Synaptics deal (中銀ハト派)
