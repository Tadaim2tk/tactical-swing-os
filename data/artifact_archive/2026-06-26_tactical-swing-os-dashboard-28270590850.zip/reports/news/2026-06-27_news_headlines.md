# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-27 08:17:55 JST
取得日時（UTC）: 2026-06-26 23:17:55 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.78
headline件数: 30

## 見出し

- [CNBC Markets] U.S. strikes Iran after Trump accuses Tehran of ceasefire violation in Strait of Hormuz (未分類)
- [CNBC Markets] Trump admin allows Anthropic to release Mythos AI model to some companies, government agencies: Reports (未分類)
- [CNBC Markets] Trump eases pressure on Fed Chairman Kevin Warsh as inflation tops 4% (US10Y|DXY)
- [CNBC Markets] Oracle stock has worst week since 2001 dot-com bust as AI financing concerns escalate (未分類)
- [CNBC Markets] Jeremy Grantham says this is the most expensive market in 'American history' (未分類)
- [CNBC Markets] China's Zhipu is closing in on top U.S. AI models with Anthropic and OpenAI held back (USDJPY|DXY)
- [CNBC Markets] Rubio says Israel, Lebanon reach framework agreement aimed at 'lasting peace and security' (未分類)
- [CNBC Markets] Walmart heir Lukas Walton buys minority stake in the Chicago Bulls and United Center (未分類)
- [CNBC Markets] OpenAI hasn't held pre-IPO investor meetings or set timeline yet, sources say (未分類)
- [CNBC Markets] OpenAI limits new AI models to 'trusted partners' at request of U.S. government (未分類)
- [CNBC Markets] Gavin Newsom calls for national billionaires tax: 'It's time for an economic reset' (未分類)
- [CNBC Markets] Trump threatens 100% tariffs on countries putting 'Digital Services Tax on American Companies' (BTC)
- [CNBC Markets] Minneapolis Fed President Neel Kashkari says he expects a rate hike this year (US10Y|DXY)
- [CNBC Markets] Billionaire investor Jeremy Grantham says bitcoin will 'dwindle away with a whimper' (BTC)
- [CNBC Markets] Leon Black refuses to answer questions on NDAs at Jeffrey Epstein hearing, Rep. Comer says (未分類)
- [CNBC Markets] Healthcare stocks have caught fire, sending all 3 of our names to record highs (SPX)
- [CNBC Markets] Ex-Trump advisor John Bolton pleads guilty to retaining national defense information (未分類)
- [CNBC Markets] Red Lobster's Ultimate Endless Shrimp promotion described as a 'car crash' for the company, lawsuit says (未分類)
- [CNBC Markets] OpenAI and Anthropic face new AI reality as users shift from 'tokenmaxxing' to efficiency (US10Y|DXY)
- [CNBC Markets] OpenAI is reportedly delaying its IPO. Here's when Kalshi traders think it will announce (未分類)
- [CNBC Markets] ON Semiconductor records worst day since 2020 as CEO defends Synaptics deal (未分類)
- [CNBC Markets] One factor that may be partly behind the S&P 500's curious action this week (SPX)
- [CNBC Markets] The brands winning with World Cup advertising may not be the sponsors (未分類)
- [CNBC Markets] Volkswagen plans to cut 15% of its workforce and close four German plants, report says (未分類)
- [CNBC Markets] Micron sinks 6%, wrapping a wild week of trading that saw big swings (SPX|NASDAQ)
- [CNBC Markets] Polymarket annualized revenue surpasses $1 billion six weeks after its U.S. exchange launch (未分類)
- [CNBC Markets] Rise in memory chip costs puts pressure on retailers of laptops and smartphones (NASDAQ)
- [CNBC Markets] Why breakthrough GLP-1 weight loss pills may be a bad thing for employer insurance coverage (未分類)
- [CNBC Markets] 'The cult of Elon': SpaceX investors grapple with volatility amid big swings (VIX)
- [CNBC Markets] Imposter scams led fraud reports to the FTC for fifth straight year in 2025, causing $3.5 billion in losses (US10Y|DXY)
