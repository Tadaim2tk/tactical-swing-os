# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-09 08:23:22 JST
取得日時（UTC）: 2026-06-08 23:23:22 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.39
headline件数: 30

## 見出し

- [CNBC Markets] OpenAI confidentially files for IPO, prepping Wall Street for mega AI debut (SPX)
- [CNBC Markets] Trump nominates Todd Blanche for attorney general amid controversy over DOJ fund (未分類)
- [CNBC Markets] Netanyahu says war with Iran, Hezbollah isn't over after Tehran says it's halting strikes (未分類)
- [CNBC Markets] USDA Secretary Rollins calls Texas ag chief 'unserious' amid screwworm threat (未分類)
- [CNBC Markets] Apple partnering with Google and Nvidia for most advanced AI model (未分類)
- [CNBC Markets] Nvidia CEO Jensen Huang declines Senate testimony on AI, China and exports (NASDAQ)
- [CNBC Markets] Convicted FTX founder Sam Bankman-Fried files formal request for Trump pardon (BTC|US10Y|DXY)
- [CNBC Markets] Judge blocks Trump's $100,000 H-1B visa fee (未分類)
- [CNBC Markets] Retirement 'underspending' is risky, advisor says. Here's why (未分類)
- [CNBC Markets] China is helping to cushion global oil prices below $100 — but analysts warn it won’t last (WTI)
- [CNBC Markets] Jim Cramer warns key pillars of the bull market are beginning to crumble (SPX)
- [CNBC Markets] Silicon Valley’s new buyout playbook is hitting Wall Street (SPX)
- [CNBC Markets] Chip rebound sparks hedging flurry from traders (NASDAQ)
- [CNBC Markets] Food supply 'not at risk' after new Texas screwworm cases, USDA secretary says (未分類)
- [CNBC Markets] Airlines find the grass isn't always greener with new engines (未分類)
- [CNBC Markets] Corning strikes another multibillion-dollar AI deal. What the new Amazon pact means for the stock (USDJPY|DXY)
- [CNBC Markets] Chip rebound has one trader buying protection (SPX|NASDAQ)
- [CNBC Markets] Household worries over finances hit highest level since July 2022, New York Fed survey shows (US10Y|DXY)
- [CNBC Markets] Weight loss drug maker sinks 23% after new safety data spooks investors (未分類)
- [CNBC Markets] Kalshi traders say Strait of Hormuz traffic won't return to normal before January (未分類)
- [CNBC Markets] Congress moves toward approving $70 billion for ICE and CBP through Trump's presidency (未分類)
- [CNBC Markets] Oil prices ease after Iran says military operations against Israel are over (WTI)
- [CNBC Markets] Novo and Lilly are competing to win the GLP-1 pill market as they prepare for Medicare coverage (未分類)
- [CNBC Markets] Corning shares jump 4% after company strikes deal to power Amazon AI data centers in U.S. (SPX|NASDAQ)
- [CNBC Markets] USAA to return nearly $1 billion to Florida members as legal reforms help lower insurance costs (未分類)
- [CNBC Markets] United CEO brushes off airline mergers after American rejection: 'There's nothing' (未分類)
- [CNBC Markets] This startup wants to reduce payment friction on prediction markets (未分類)
- [CNBC Markets] This popular car-buying rule isn't realistic for most Americans—here's the income needed to make it work (未分類)
- [CNBC Markets] Italian coffee giant Lavazza launches single-serve tablets to make espresso in the U.S. (未分類)
- [CNBC Markets] Marvell Technology jumps 10% after news it will join the S&P 500 index (SPX|NASDAQ)
