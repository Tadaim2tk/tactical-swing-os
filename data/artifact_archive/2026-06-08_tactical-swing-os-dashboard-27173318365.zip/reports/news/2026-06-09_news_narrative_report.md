# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-09 08:23:23 JST
生成日時（UTC）: 2026-06-08 23:23:23 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.39
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: gold_safe_haven, geopolitical_risk
日本語要約: 金安全資産需要、地政学リスクはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり / 原油供給リスク材料あり

## スコア

- risk_on_news_score: 38.33
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 100.0
- oil_supply_risk_news_score: 38.33
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 19.17
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 19.17
- news_confidence: 100.0

## Top News Drivers

- Netanyahu says war with Iran, Hezbollah isn't over after Tehran says it's halting strikes (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Nvidia CEO Jensen Huang declines Senate testimony on AI, China and exports (地政学リスク / 金安全資産需要 / リスクオフ要因)
- China is helping to cushion global oil prices below $100 — but analysts warn it won’t last (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Jim Cramer warns key pillars of the bull market are beginning to crumble (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Chip rebound sparks hedging flurry from traders (リスクオン要因)
- Food supply 'not at risk' after new Texas screwworm cases, USDA secretary says (中銀ハト派)
- Chip rebound has one trader buying protection (リスクオン要因)
- Household worries over finances hit highest level since July 2022, New York Fed survey shows (インフレ圧力 / 金利圧力候補)
- Congress moves toward approving $70 billion for ICE and CBP through Trump's presidency (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Oil prices ease after Iran says military operations against Israel are over (地政学リスク / 原油供給リスク / 金安全資産需要 / リスクオフ要因)
