# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-16 08:26:11 JST
取得日時（UTC）: 2026-06-15 23:26:11 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 3.23
headline件数: 74

## 見出し

- [CNBC Markets] SpaceX stock jumps 20% in first full day of trading after record debut (未分類)
- [CNBC Markets] Gavin Newsom says Trump ordered DOJ to investigate him and his wife (未分類)
- [CNBC Markets] Nvidia plans to raise at least $20 billion in its first debt sale since start of AI boom (NASDAQ)
- [CNBC Markets] The Iran deal came just in time as Strategic Petroleum Reserve hits lowest level since 1983 (WTI)
- [CNBC Markets] Trump trusts Fed Chair Kevin Warsh. It matters for more than interest rates (US10Y|DXY)
- [CNBC Markets] CNBC's The China Connection newsletter: Waiting for AI to lift the whole market (未分類)
- [CNBC Markets] Vance says 'a lot' of Iran deal details to figure out, but U.S. has 'all the cards' (未分類)
- [CNBC Markets] How the Strait of Hormuz reopening could unfold if the U.S.-Iran deal is implemented (BTC|WTI)
- [CNBC Markets] Warsh's Fed is likely to hold rates steady — what the leadership change could mean for your money (US10Y|DXY)
- [CNBC Markets] Sen. Warren asks Trump if administration plans to raise Social Security retirement age (未分類)
- [CNBC Markets] CFTC chair Selig defends decision to approve ‘perps’ in U.S. (VIX)
- [CNBC Markets] Wall Street's fear gauge tumbles as traders bid up SpaceX shares (SPX|VIX)
- [CNBC Markets] Centene to offer buyouts to some employees as health insurer cuts costs (未分類)
- [CNBC Markets] Fox to buy streaming device maker Roku for $22 billion (未分類)
- [CNBC Markets] Anthropic to meet with Trump administration over Mythos dispute (未分類)
- [CNBC Markets] Oil tumbles on US-Iran deal framework: How one trader is playing the move (BTC|WTI|SPX)
- [CNBC Markets] I want people to be millionaires — Jim Cramer's blueprint to make money in any market (SPX)
- [CNBC Markets] U.S.-Iran deal explained: What we know — and what remains unresolved (SPX)
- [CNBC Markets] Dick's Sporting Goods expanding Lids shops to 100 locations (未分類)
- [CNBC Markets] Vance says U.S. expects Strait of Hormuz to be open 'toll free' long term (未分類)
- [CNBC Markets] Ron Baron bought $1 billion of SpaceX shares in IPO, lifting stake to $25 billion (USDJPY|SPX|DXY)
- [CNBC Markets] Electronic Arts launches EA Advertising, a new way for brands to advertise 'directly into gameplay' (未分類)
- [CNBC Markets] Oil prices fall about 5% as Iran deal is set to open Hormuz Strait (WTI)
- [CNBC Markets] SpaceX doesn't have a timeline for its human missions to Mars. Kalshi traders say don't expect it this decade (未分類)
- [CNBC Markets] KFC leans into boneless chicken, new drinks as chain tries to regain market share (未分類)
- [CNBC Markets] Salesforce to buy AI customer service platform Fin for $3.6 billion to boost agentic offerings (未分類)
- [CNBC Markets] Charlie Javice reportedly seeking a pardon from Trump (未分類)
- [CNBC Markets] Trump says France must scrap tech 'sales tax' or face 100% wine tariffs: NY Post (NASDAQ)
- [CNBC Markets] A year after Meta tapped Alexandr Wang to build a new AI model, Zuckerberg has to sell it (未分類)
- [CNBC Markets] 10-year Treasury yield slides as Iran deal drives rethink on Fed interest rate hikes (US10Y|DXY)
- [MarketWatch Top Stories] Need a credit-score boost? Call your credit-card company and ask for this — but proceed with caution. (未分類)
- [MarketWatch Top Stories] Roku’s sale to Fox for $22 billion raises a big question (未分類)
- [MarketWatch Top Stories] Here’s when gas prices will come down if the U.S. deal to end the Iran war pans out (未分類)
- [MarketWatch Top Stories] Options traders are bracing for a very busy week, with June ‘triple witching’ and launch of SpaceX contracts on deck (未分類)
- [MarketWatch Top Stories] I’m 55 and earn $100,000. Should I take a $2,900 monthly pension — or $2,200 with 3% annual hikes? (未分類)
- [MarketWatch Top Stories] ‘We own our home outright’: I am 67 and earn $100,000. Do I take my $30,000 Social Security now or wait? (US10Y)
- [MarketWatch Top Stories] Why Western Digital’s stock was the S&P 500’s biggest gainer on Monday (SPX)
- [MarketWatch Top Stories] I’m spending $170,000 to upgrade my home for my aging parents. Can I get tax breaks? (未分類)
- [MarketWatch Top Stories] The biggest risk to your retirement isn’t a market crash — it’s a crisis you probably haven’t planned for (未分類)
- [MarketWatch Top Stories] Even Nvidia is joining the AI borrowing spree, with a historic $20 billion bond deal (US10Y)
- [CoinDesk] Hyperliquid loses Anthropic, OpenAI markets as creator shuts down project (未分類)
- [CoinDesk] If America wants to lead in crypto, it must protect the people who build it (BTC)
- [CoinDesk] ‘Crypto spring’ is here, says one analyst after bitcoin's key signals turn bullish (BTC|WTI)
- [CoinDesk] Kraken debuts U.S. perpetual futures as crypto derivatives move onshore (BTC)
- [CoinDesk] Coinbase's Brian Armstrong says bitcoin may have bottomed at $60,000 (BTC)
- [CoinDesk] XRP rockets 8% above $1.20 in first major breakout since June selloff (BTC|VIX)
- [CoinDesk] CoinDesk 20 performance update: Bittensor (TAO) surges 31.9%, leading index higher (未分類)
- [CoinDesk] Bitmine adds another $136 million of ether after raising $274 million in preferred stock sale (BTC|US10Y|DXY)
- [CoinDesk] Michael Saylor's Strategy acquires another 1,587 bitcoin for $100 million (BTC)
- [CoinDesk] Markets cheer U.S.-Iran Breakthrough though Middle East risks, Fed remain in focus (US10Y|DXY)
