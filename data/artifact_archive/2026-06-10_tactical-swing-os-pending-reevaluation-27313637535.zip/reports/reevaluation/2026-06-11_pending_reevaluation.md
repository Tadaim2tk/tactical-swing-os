# Pending Signal Re-evaluation Report

## 1. 概要

* 生成日時JST: 2026-06-11 08:43:16 JST
* データソース: sheets
* 対象SIGNALS件数: 57
* 再評価対象件数: 20
* closed化した件数: 3
* no_entry継続件数: 2
* open継続件数: 15
* missed_opportunity件数: 0
* Sheets保存: 実行
* Sheets保存成功件数: 16
* Sheets重複スキップ件数: 4
* Sheets保存warning: なし

## 2. 決着したシグナル

| signal_id | asset | side | rank | previous_outcome | outcome | r_multiple | error_type |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B |  | win_tp1 | 1.087 | target_reached |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B |  | win_tp1 | 1.087 | target_reached |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B |  | loss_sl | -1.0 | stop_loss |

## 3. 未決着継続

| signal_id | asset | side | rank | outcome | mfe_r | mae_r | bars_checked |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | open_unresolved | 0.3188 | -0.7235 | 3 |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B | open_unresolved | 0.3678 | -0.2673 | 3 |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | open_unresolved | 0.55 | -0.6772 | 4 |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | open_unresolved | 0.3188 | -0.7235 | 3 |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B | open_unresolved | 0.3678 | -0.2673 | 3 |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | open_unresolved | 0.55 | -0.6772 | 4 |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 0.0295 | -0.1728 | 4 |
| 20260605_DXY_LONG_A-Momentum | DXY | LONG | B | open_unresolved | 0.0822 | -0.1544 | 3 |
| 20260605_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.6969 | 0.0001 | 3 |
| 20260605_US10Y_LONG_A-Pullback | US10Y | LONG | B | open_unresolved | 0.1602 | -0.0872 | 3 |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.7471 | 0.0297 | 3 |
| 20260608_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.755 | 0.0343 | 2 |
| 20260608_US10Y_LONG_B-Watch | US10Y | LONG | B | open_unresolved | 0.0821 | -0.188 | 2 |
| 20260609_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 0.0889 | -0.028 | 1 |
| 20260609_GOLD_SHORT_B-Watch | GOLD | SHORT | B | no_entry | 0.5138 | 0.4135 | 1 |
| 20260609_WTI_SHORT_B-Watch | WTI | SHORT | B | no_entry | -0.1279 | -0.2116 | 1 |
| 20260610_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved |  |  | 0 |

## 4. 取り逃し候補

取り逃し候補はありません。

## 5. No Trade再評価

No Trade再評価は実行していません。

## 6. 注意

* このレポートは実売買ではありません。
* Tactical Swing OS が過去に出した判断の仮想評価です。
* 価格データの欠損や市場休場により、評価が遅れる場合があります。
* append-only運用でEVALUATIONSへ追記する場合、分析側では最新評価行を採用する必要があります。
