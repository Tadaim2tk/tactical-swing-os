# Pending Signal Re-evaluation Report

## 1. 概要

* 生成日時JST: 2026-06-12 08:47:25 JST
* データソース: sheets
* 対象SIGNALS件数: 65
* 再評価対象件数: 21
* closed化した件数: 5
* no_entry継続件数: 2
* open継続件数: 14
* missed_opportunity件数: 0
* Sheets保存: 実行
* Sheets保存成功件数: 17
* Sheets重複スキップ件数: 4
* Sheets保存warning: なし

## 2. 決着したシグナル

| signal_id | asset | side | rank | previous_outcome | outcome | r_multiple | error_type |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B |  | win_tp1 | 1.087 | target_reached |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B |  | win_tp1 | 1.087 | target_reached |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B |  | loss_sl | -1.0 | stop_loss |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B |  | loss_sl | -1.0 | stop_loss |

## 3. 未決着継続

| signal_id | asset | side | rank | outcome | mfe_r | mae_r | bars_checked |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | open_unresolved | 0.5234 | -0.9084 | 4 |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | open_unresolved | 0.5891 | -0.694 | 5 |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | open_unresolved | 0.5234 | -0.9084 | 4 |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | open_unresolved | 0.5891 | -0.694 | 5 |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 0.0295 | -0.1728 | 5 |
| 20260605_DXY_LONG_A-Momentum | DXY | LONG | B | open_unresolved | 0.1287 | -0.1963 | 4 |
| 20260605_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.5713 | 0.0001 | 4 |
| 20260605_US10Y_LONG_A-Pullback | US10Y | LONG | B | open_unresolved | 0.1602 | -0.3819 | 4 |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.6177 | 0.0297 | 4 |
| 20260608_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.625 | 0.0343 | 3 |
| 20260608_US10Y_LONG_B-Watch | US10Y | LONG | B | open_unresolved | 0.0821 | -0.5098 | 3 |
| 20260609_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 0.0965 | -0.085 | 2 |
| 20260609_GOLD_SHORT_B-Watch | GOLD | SHORT | B | no_entry | 0.4018 | 0.0525 | 2 |
| 20260609_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved | 0.1979 | -0.1264 | 2 |
| 20260610_GOLD_SHORT_B-Watch | GOLD | SHORT | B | no_entry | -0.2302 | -0.2936 | 1 |
| 20260611_WTI_SHORT_B-Watch | WTI | SHORT | B | open_unresolved |  |  | 0 |

## 4. 取り逃し候補

取り逃し候補はありません。

## 5. No Trade再評価

No Trade再評価は実行していません。

## 6. 注意

* このレポートは実売買ではありません。
* Tactical Swing OS が過去に出した判断の仮想評価です。
* 価格データの欠損や市場休場により、評価が遅れる場合があります。
* append-only運用でEVALUATIONSへ追記する場合、分析側では最新評価行を採用する必要があります。
