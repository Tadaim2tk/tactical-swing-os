# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-10 08:05:31 JST
取得日時（UTC）: 2026-06-09 23:05:31 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.31
headline件数: 75

## 見出し

- [CNBC Markets] SpaceX IPO explained: The price is set, but retail allocation still up in the air (SPX)
- [CNBC Markets] U.S. military launches strikes in retaliation for Iran downing helicopter (未分類)
- [CNBC Markets] Oil prices fall after U.S. Energy secretary says Hormuz ship traffic is increasing (WTI)
- [CNBC Markets] The May inflation numbers are due out Wednesday morning. Here's what to expect (SPX)
- [CNBC Markets] Anthropic releases Mythos-like AI model to the public two months after private rollout rocked Wall Street (SPX)
- [CNBC Markets] Kalshi rolls out whistleblower services, employment verification to curb insider trading (SPX)
- [CNBC Markets] Semiconductor shorts pile on as winning trade reverses (未分類)
- [CNBC Markets] GM eyes new battery chemistry to grow AI data center, energy storage business (未分類)
- [CNBC Markets] Kalshi trading in 'perps' crosses $1 billion in volume within a week of launch (未分類)
- [CNBC Markets] As LIV Golf faces a Saudi funding cliff, CEO says to take PIF 'at their word' (未分類)
- [CNBC Markets] Jim Cramer says tech stocks are losing the qualities that made them the leaders of the rally (SPX|NASDAQ)
- [CNBC Markets] Trump family got about $500M from crypto venture — but investors saw steep losses (BTC|SPX)
- [CNBC Markets] White House border czar Tom Homan blames New York Gov. Hochul for promised ICE surge (未分類)
- [CNBC Markets] Social Security retirement trust fund may be depleted in 2032, new trustees report finds (未分類)
- [CNBC Markets] $70 billion immigration funding package passes in U.S. House in a win for Speaker Johnson (未分類)
- [CNBC Markets] Apple shares slide after big Siri AI reveal (SPX)
- [CNBC Markets] Rivian is betting on its R2 EV to turn the automaker into a household name like Tesla (未分類)
- [CNBC Markets] Another jump in Boeing deliveries shows why we got into the stock and want to stay in (未分類)
- [CNBC Markets] JPMorgan Chase plans to deploy more powerful AI agents this year (未分類)
- [CNBC Markets] Jeffrey Epstein's former assistant Lesley Groff interviewed by House panel (未分類)
- [CNBC Markets] Home sales surged in May to the highest level since December (US10Y|DXY)
- [CNBC Markets] Bitcoin's brutal sell-off sparks a flurry of trading in related stocks, including one big bullish bet (BTC|SPX)
- [CNBC Markets] Energy Secretary Chris Wright says traffic in Strait of Hormuz is rising 'very meaningfully' (WTI)
- [CNBC Markets] USDA Secretary Rollins calls Texas ag chief 'unserious' amid screwworm threat (未分類)
- [CNBC Markets] 5 takeaways from airline CEOs' biggest annual gathering (未分類)
- [CNBC Markets] SpaceX employee group creates low-fee wealth management option with Choreo for post-IPO (未分類)
- [CNBC Markets] Nuvalent shares surge 39% after UK's GSK agrees to buy the cancer drugmaker for $10.6 billion (SPX|NASDAQ)
- [CNBC Markets] Upstart chipmakers keep challenging Nvidia. This time it's Microsoft-backed D-Matrix (NASDAQ)
- [CNBC Markets] The 'SaaSpocalypse' is over, says private equity giant Thoma Bravo. Here's why it sees an AI boom for software (未分類)
- [CNBC Markets] 36-year-old's fitness company was 'a week away' from bankruptcy—now it's valued at $10.1 billion (未分類)
- [MarketWatch Top Stories] Super Micro stock plunges as $7 billion equity raise overshadows booming backlog (未分類)
- [MarketWatch Top Stories] Apple’s AI could usher in a historic upgrade cycle that investors are overlooking (未分類)
- [MarketWatch Top Stories] Micron and other memory makers are driving a ‘supercycle’ for this corner of the chip sector (NASDAQ)
- [MarketWatch Top Stories] AST SpaceMobile’s stock experiences rocky trading as SpaceX plans to launch its satellites into orbit (未分類)
- [MarketWatch Top Stories] GM follows Ford by making a big energy bet — this time with an unconventional approach (SPX)
- [MarketWatch Top Stories] Angst over SpaceX IPO adds to dive in tech stocks (SPX|NASDAQ)
- [MarketWatch Top Stories] A powerful inflation storm is brewing — and your portfolio isn’t ready (未分類)
- [MarketWatch Top Stories] Adobe needs a new CEO to make bold AI moves, and its choice could be revealed on Thursday (USDJPY)
- [MarketWatch Top Stories] Your tech portfolio could be on the wrong side of the AI boom (SPX|NASDAQ)
- [MarketWatch Top Stories] Fund a grandchild’s retirement tax-free from birth — if you can trust an 18-year-old with the money (未分類)
- [CoinDesk] Crypto tax bills a work-in-progress as U.S. House lawmakers pose concerns (BTC)
- [CoinDesk] Securitize CEO says tokenized stocks could unlock a $5 trillion crypto market (BTC|SPX)
- [CoinDesk] UK financial regulator moves to allow mutual funds 10% exposure to crypto ETNs (BTC)
- [CoinDesk] 5 corruption gaps Congress must close in the Clarity Act (BTC)
- [CoinDesk] Trad.Fi, W3 target $650 million in onchain private credit using AI evaluation (未分類)
- [CoinDesk] Ethena lands Janus Henderson backing as asset manager invests in ENA, eyes USDe distribution (未分類)
- [CoinDesk] Come back after the summer, says one analyst on crypto markets (BTC|SPX|NASDAQ)
- [CoinDesk] A16z, Paradigm lead $175 million bet to move global credit markets onchain (BTC)
- [CoinDesk] CoinDesk 20 performance update: AAVE Drops 2.6% as all constituents trade lower (未分類)
- [CoinDesk] Bitcoin inflows slow sharply in 2026 as investors chase AI, Bernstein says (BTC)
