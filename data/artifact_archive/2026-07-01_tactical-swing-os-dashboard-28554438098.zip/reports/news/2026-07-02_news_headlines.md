# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-02 08:25:27 JST
取得日時（UTC）: 2026-07-01 23:25:27 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.0
headline件数: 30

## 見出し

- [CNBC Markets] U.S. won’t renew USMCA, opening door for negotiations with Canada and Mexico (未分類)
- [CNBC Markets] Trump got $15,000 in FIFA tickets from Gianni Infantino. Next up: Presenting the World Cup trophy (未分類)
- [CNBC Markets] Trump Accounts for kids launch July 4: What parents need to know (未分類)
- [CNBC Markets] Chip stocks that notched record rallies in second quarter start Q3 with a dud (SPX|NASDAQ)
- [CNBC Markets] Prolific tech analyst Dan Ives is exiting Wedbush for a new venture (NASDAQ)
- [CNBC Markets] Trump says outside funds 'run my money' after disclosure shows billions in 2025 revenue (SPX)
- [CNBC Markets] Automakers report mixed U.S. sales results as hybrid vehicles drive market (未分類)
- [CNBC Markets] Lamborghini reveals new Urus performance hybrid SUV after ditching EVs (未分類)
- [CNBC Markets] Employers who laid off workers citing AI are already starting to regret it (未分類)
- [CNBC Markets] Jim Cramer says to use Wednesday's market rotation to your advantage. Here's how he'd play it (未分類)
- [CNBC Markets] Trump administration's limits on student loan forgiveness program are blocked. What to know (US10Y|DXY)
- [CNBC Markets] World Cup could boost the June jobs report by 40,000, Goldman estimates (GOLD)
- [CNBC Markets] Bitcoin's summer swoon creates unique trade in Strategy (BTC)
- [CNBC Markets] Trump wants delay but E. Jean Carroll wants to gets paid — now: Court filing (未分類)
- [CNBC Markets] Palantir's Karp bashes OpenAI, Anthropic token model: 'Something has gone completely wrong' (未分類)
- [CNBC Markets] Meta's plan to launch a cloud business eases the biggest overhang on the stock (未分類)
- [CNBC Markets] Healthy Returns: Walmart, CVS step in to help seniors navigate Medicare coverage of obesity drugs (未分類)
- [CNBC Markets] Meta pops 9% as company makes cloud push to sell excess AI compute power capacity (未分類)
- [CNBC Markets] Inflation peaked in May as energy prices fell in June, Kalshi traders think (未分類)
- [CNBC Markets] U.S. auto industry faces increased uncertainty without extension of USMCA trade deal (未分類)
- [CNBC Markets] PlayStation will end physical disc production for new games in 2028 (未分類)
- [CNBC Markets] The $20,000 new vehicle is all but extinct—what the most affordable new car looks like now (未分類)
- [CNBC Markets] Private payrolls rose by 98,000 in June, less than expected, ADP reports (未分類)
- [CNBC Markets] Tech leads first half stock gains — but the biggest winners weren't in the U.S. (SPX|NASDAQ)
- [CNBC Markets] South Korean government discriminated against Coupang, U.S. companies, House report finds (未分類)
- [CNBC Markets] Bulls are betting big on this global ETF that's deep in a bear market (BTC|SPX|NASDAQ)
- [CNBC Markets] More than one-third of employees still work from home, new research shows (未分類)
- [CNBC Markets] Anthropic says Trump admin has lifted export controls on Claude Fable 5 and Mythos 5 (未分類)
- [CNBC Markets] Demand for riskier mortgages drops, as their advantages shrink (未分類)
- [CNBC Markets] Trump's annual financial disclosure shows more than $580M in crypto-related income (BTC|SPX)
