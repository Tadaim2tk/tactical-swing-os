# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-02 21:21:46 JST
取得日時（UTC）: 2026-07-02 12:21:46 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.9
headline件数: 30

## 見出し

- [CNBC Markets] World Cup could boost the June jobs report by 40,000, Goldman estimates (GOLD)
- [CNBC Markets] Ford CEO wants level playing field with Toyota, GM imports as USMCA trade talks reopen (未分類)
- [CNBC Markets] Meta’s push into cloud computing means Wall Street has to prepare for lower margins (SPX)
- [CNBC Markets] Americans are paying record prices for steak. Here's why demand isn't cracking (未分類)
- [CNBC Markets] OpenAI proposes 5% stake to Trump administration to ease Washington pressure: Report (未分類)
- [CNBC Markets] Apple plans five new iPhones through 2027, eyes Chinese-made chips amid foldable push, reports say (NASDAQ)
- [CNBC Markets] AI agents will soon be able to match human traders, Robinhood CEO tells CNBC (未分類)
- [CNBC Markets] Russia launches massive strike on Ukraine as Poland scrambles jets, Finland restricts airspace (未分類)
- [CNBC Markets] Brookfield wants to build AI data centers in London’s answer to Wall Street (SPX)
- [CNBC Markets] Nvidia offers start-up customers chance to swap compute power for revenue share (未分類)
- [CNBC Markets] SpaceX may emerge as ultimate blueprint for new wave of mega-cap IPOs (NASDAQ)
- [CNBC Markets] Russia’s neighbor Lithuania scraps constitutional ban on nuclear weapons. Here's why (未分類)
- [CNBC Markets] Google loses fight over record $4.7 billion EU antitrust fine (未分類)
- [CNBC Markets] Automakers report mixed U.S. sales results as hybrid vehicles drive market (未分類)
- [CNBC Markets] Warsh faces multiple alternative inflation signs as Fed charts new course (US10Y|DXY)
- [CNBC Markets] Europe wants to rebalance trade with Beijing, but can't quit Chinese air conditioners (未分類)
- [CNBC Markets] Meta's plan to launch a cloud business eases the biggest overhang on the stock (未分類)
- [CNBC Markets] Volkswagen braces for boardroom showdown over historic cost-cutting plan (未分類)
- [CNBC Markets] Trump administration's limits on student loan forgiveness program are blocked. What to know (US10Y|DXY)
- [CNBC Markets] Amazon is designing its own AI chips for Echo, Fire TV and future devices, exec tells CNBC (NASDAQ)
- [CNBC Markets] Trump got $15,000 in FIFA tickets from Gianni Infantino. Next up: Presenting the World Cup trophy (未分類)
- [CNBC Markets] Oil prices on pace for fourth straight weekly loss as Trump sees progress in U.S.-Iran talks (WTI)
- [CNBC Markets] Meta says WhatsApp usernames are safeguarded against scams after India flags cybersecurity risks (未分類)
- [CNBC Markets] Alibaba-affiliate Ant Group rushes into humanoid robots with a dozen deals in 18 months (未分類)
- [CNBC Markets] M&A is ‘on fire’ as large-cap firms simplify, Citi UK CEO says (未分類)
- [CNBC Markets] Inside India newsletter: Amazon, Walmart-owned Flipkart get ready to shake up India's delivery-in-minutes sector (未分類)
- [CNBC Markets] Shares of BYD and Xiaomi surge as June delivery figures fuel optimism (SPX)
- [CNBC Markets] Samsung Electronics, SK Hynix shares tumble over 9% as chip rout spreads from Wall Street (SPX|NASDAQ)
- [CNBC Markets] Employers who laid off workers citing AI are already starting to regret it (未分類)
- [MarketWatch Top Stories] Want to live longer in retirement? This one money move could add years to your life. (未分類)
