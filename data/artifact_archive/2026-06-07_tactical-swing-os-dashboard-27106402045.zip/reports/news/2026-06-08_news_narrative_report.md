# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-08 07:14:37 JST
生成日時（UTC）: 2026-06-07 22:14:37 UTC
headline件数: 58
ニュース市場バイアス: mixed
ニュース矛盾スコア: 55.81
主要テーマ: gold_safe_haven, geopolitical_risk, risk_off
日本語要約: 金安全資産需要、地政学リスク、リスクオフ要因が目立ち、リスクオン材料とリスクオフ材料が混在しています。強弱材料が混在しており、方向感は限定的です。
ニュースモード: ニュースは混在 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 55.81
- risk_off_news_score: 74.41
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 100.0
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 100.0
- inflation_pressure_news_score: 37.21
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Fragile ceasefire in jeopardy as Iran reportedly fires missiles at Israel (地政学リスク / リスクオフ要因)
- Inflation inside the electronics you buy may soon become a bit more sticky (インフレ圧力 / 金利圧力候補)
- Chinese EVs may hit U.S. within a few years, one way or another (インフレ圧力 / 金利圧力候補)
- U.S. confirms second Texas screwworm case, Canada restricts livestock imports (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Abel goes his own way with new Berkshire investments, including billions for AI (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Wall Street's 'fear gauge' punches back as the 'crash up' in chip stocks finally reverses (リスクオフ要因 / リスクオン要因)
- Social media bans on teens risk strengthening Big Tech's grip on the sector, Bluesky exec warns (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Amazon unveils latest warehouse robot as tech giants continue AI layoffs (地政学リスク / 金安全資産需要 / リスクオフ要因)
- S&P 500 sees $1.8 trillion wipeout, Nasdaq tallies biggest point drop on record: What investors need to know about Friday’s selloff (リスクオフ要因)
- ‘This would be a one-time event’: How can I take extra money from my 401(k) without triggering higher Medicare premiums? (リスクオン要因)
