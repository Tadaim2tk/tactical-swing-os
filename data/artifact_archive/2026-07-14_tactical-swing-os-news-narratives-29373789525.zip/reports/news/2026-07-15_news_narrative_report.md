# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-15 07:41:22 JST
生成日時（UTC）: 2026-07-14 22:41:22 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.99
ニュース市場バイアス: neutral
ニュース矛盾スコア: 18.47
主要テーマ: inflation_pressure
日本語要約: インフレ圧力はありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 18.47
- risk_off_news_score: 18.47
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 18.47
- gold_safe_haven_news_score: 0.0
- oil_supply_risk_news_score: 18.47
- crypto_liquidity_news_score: 55.4
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 36.93
- inflation_pressure_news_score: 100.0
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 18.47
- central_bank_dovish_score: 18.47
- news_confidence: 100.0

## Top News Drivers

- Here’s the inflation breakdown for June 2026 — in one chart (インフレ圧力 / 金利圧力候補)
- Warsh pledges Fed policy 'regime change' to rid inflation 'tax' on American people (インフレ圧力 / 金利圧力候補)
- Social Security cost-of-living adjustment estimate for 2027 falls as inflation cools (インフレ圧力 / 金利圧力候補)
- Oil prices rise as U.S. launches new Iran airstrikes, while Trump abandons Strait of Hormuz fee (インフレ圧力 / 金利圧力候補)
- Cybersecurity stocks rally on AI spending change comments from IBM's Krishna (リスクオン要因)
- Consumer prices rose 3.5% annually in June, less than expected as energy prices eased (インフレ圧力 / 金利圧力候補)
- The Clarity Act isn't a ticket to sanctions evasion, actually (地政学リスク / 原油供給リスク / リスクオフ要因)
- For pension funds, tokenization’s real play is balance-sheet management, Fidelity’s Lai says (暗号資産流動性)
- Hut 8 price target hiked to $165 at Benchmark as AI pivot reshapes valuation (中銀ハト派)
- U.S. June CPI fell 0.4%, likely cooling move toward Fed rate hikes (インフレ圧力 / 金利圧力候補)
