# Tactical Swing OS News Headlines

取得日時（JST）: 2026-07-15 07:41:21 JST
取得日時（UTC）: 2026-07-14 22:41:21 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 0.99
headline件数: 75

## 見出し

- [CNBC Markets] The AI boom just found two new winners: Goldman Sachs and JPMorgan Chase (GOLD|SPX)
- [CNBC Markets] Here’s the inflation breakdown for June 2026 — in one chart (未分類)
- [CNBC Markets] Warsh pledges Fed policy 'regime change' to rid inflation 'tax' on American people (US10Y|DXY)
- [CNBC Markets] U.S. strikes Iran before Hormuz Strait blockade restarts (未分類)
- [CNBC Markets] SK Hynix options begin trading. But another group of stocks is stealing its thunder (BTC|SPX)
- [CNBC Markets] Current and former employees sue Meta, alleging discrimination in using AI to conduct layoffs (未分類)
- [CNBC Markets] United Airlines' new upsell: Keeping other travelers out of the middle seat (未分類)
- [CNBC Markets] Social Security cost-of-living adjustment estimate for 2027 falls as inflation cools (未分類)
- [CNBC Markets] Jim Cramer says concerns about AI market froth are overblown. Here's why (未分類)
- [CNBC Markets] New York becomes first U.S. state to impose AI data center ban (未分類)
- [CNBC Markets] Bipartisan group of senators propose Social Security reform process ahead of funding shortfall (未分類)
- [CNBC Markets] Lucid dismisses report that it is weighing filing for bankruptcy or going private after shares plunge (SPX)
- [CNBC Markets] Zipline adds ex-Tesla, Uber, Waymo execs to make drone delivery mainstream across U.S. (未分類)
- [CNBC Markets] Oil prices rise as U.S. launches new Iran airstrikes, while Trump abandons Strait of Hormuz fee (WTI)
- [CNBC Markets] Cybersecurity stocks rally on AI spending change comments from IBM's Krishna (SPX)
- [CNBC Markets] Johnson & Johnson has a chance to show it's more than just a rotation winner (SPX|NASDAQ)
- [CNBC Markets] U.S. trade official says 'very few' Nvidia H200 AI chips have been shipped to China (NASDAQ)
- [CNBC Markets] IBM stock craters 25%, the worst day on record, after company issues second-quarter earnings warning (SPX|NASDAQ)
- [CNBC Markets] Supreme Court Justice Barrett says the threat level against judges 'is really high' (未分類)
- [CNBC Markets] T. rex sells for $50 million, becoming the most expensive dinosaur fossil ever auctioned (未分類)
- [CNBC Markets] Warren Buffett is accelerating his charitable donations with aim to give away Berkshire wealth by 2034 (SPX)
- [CNBC Markets] Apple in talks with startup that shrinks AI models to run on an iPhone (未分類)
- [CNBC Markets] E. Jean Carroll receives $5.6M from Trump in sex abuse, defamation case (US10Y|DXY)
- [CNBC Markets] Chamath Palihapitiya says soaring AI token spend will hit companies' earnings (SPX|NASDAQ)
- [CNBC Markets] Paramount still plans to close WBD merger by end of September despite lawsuit (未分類)
- [CNBC Markets] Consumer prices rose 3.5% annually in June, less than expected as energy prices eased (未分類)
- [CNBC Markets] Sen. Tim Scott wants to hear from Warsh on data centers and artificial intelligence (US10Y|DXY)
- [CNBC Markets] Google DeepMind chief Demis Hassabis calls for U.S. to spearhead AI standards body (NASDAQ)
- [CNBC Markets] SpaceX alumni building remote-controlled construction equipment land $115 million fund round (未分類)
- [CNBC Markets] Warren Buffett excludes Gates Foundation from his annual donations of Berkshire stock (未分類)
- [MarketWatch Top Stories] ‘It’s heartbreaking’: My brother claimed Social Security at 70. He died from cancer after one payment. Why wait to claim? (未分類)
- [MarketWatch Top Stories] Your monthly Netflix bill is up 29% in just over a year. Critics say Washington needs to fix it. (BTC|SPX)
- [MarketWatch Top Stories] Three powerful forces are draining family wealth — and your estate plan is completely unprepared (未分類)
- [MarketWatch Top Stories] What IBM’s profit warning means: Hardware is ‘eating everyone’s lunch’ (未分類)
- [MarketWatch Top Stories] Taco Bell reportedly being investigated by health officials, as cyclosporiasis outbreak spreads (SPX)
- [MarketWatch Top Stories] Wall Street has set a sky-high bar for companies to clear this earnings season. They just might pull it off. (SPX|NASDAQ)
- [MarketWatch Top Stories] Your stock portfolio is tied to the Japanese yen — and a looming intervention is flashing a major warning sign (USDJPY|SPX)
- [MarketWatch Top Stories] Skip the lettuce, cook your other greens and more advice on avoiding cyclosporiasis (未分類)
- [MarketWatch Top Stories] IBM’s stock just had its worst day ever after the surprise release of an earnings miss (SPX|NASDAQ)
- [MarketWatch Top Stories] Lucid denies bankruptcy talk, but the stock still sinks to a record low (未分類)
- [CoinDesk] U.S. CFTC moves to stop Kalshi from canceling trades as ordered by Michigan court (US10Y|DXY)
- [CoinDesk] Some U.S. Senate Democrats come out against Clarity Act, calling it a 'corrupt' bill (BTC)
- [CoinDesk] Binance bets on becoming a crypto 'super app' as stablecoins reshape growth (BTC)
- [CoinDesk] The Clarity Act isn't a ticket to sanctions evasion, actually (未分類)
- [CoinDesk] Mizuho downgrades Circle to underperform, cuts price target to $50 on Open USD threat (US10Y)
- [CoinDesk] Wikipedia blackout could hurt how AI engines like ChatGPT understand crypto (BTC)
- [CoinDesk] U.S., UK move to align rules for tokenized finance across world's largest financial markets (未分類)
- [CoinDesk] JPMorgan says Hyperliquid's rise threatens Circle's USDC economics (BTC|USDJPY|SPX|NASDAQ|DXY)
- [CoinDesk] Ethereum Foundation spinout EthSystems targets banks with blockchain privacy technology (BTC|NASDAQ)
- [CoinDesk] For pension funds, tokenization’s real play is balance-sheet management, Fidelity’s Lai says (未分類)
