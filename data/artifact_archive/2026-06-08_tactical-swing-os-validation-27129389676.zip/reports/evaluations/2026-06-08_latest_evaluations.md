# Latest Evaluations Report

## 1. 概要

* 生成日時JST: 2026-06-08 18:47:13 JST
* 入力行数: 49
* unique signal数: 15
* 最新評価行数: 15
* PENDING_REEVALUATIONS由来の最新評価数: 10
* EVALUATIONS由来の最新評価数: 5

## 2. 決着済み

決着済みの最新評価はありません。

## 3. 未決着

| signal_id | asset | side | rank | status | evaluation_status | outcome | latest_source | latest_reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B | pending | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B | no_entry | pending | no_entry | pending_reevaluations | latest_by_reevaluation_at |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | no_entry | pending | no_entry | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_DXY_LONG_A-Momentum | DXY | LONG | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_US10Y_LONG_A-Pullback | US10Y | LONG | B | pending | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | pending | pending | open_unresolved | pending_reevaluations | latest_by_reevaluation_at |

## 4. 再評価履歴あり

| signal_id | asset | side | rank | outcome | previous_rows_count | latest_source | latest_reason |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | open_unresolved | 2 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B | open_unresolved | 2 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B | open_unresolved | 2 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | open_unresolved | 2 | pending_reevaluations | latest_by_reevaluation_at |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B | no_entry | 1 | pending_reevaluations | latest_by_reevaluation_at |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | no_entry | 1 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_DXY_LONG_A-Momentum | DXY | LONG | B | open_unresolved | 1 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 1 | pending_reevaluations | latest_by_reevaluation_at |
| 20260605_US10Y_LONG_A-Pullback | US10Y | LONG | B | open_unresolved | 1 | pending_reevaluations | latest_by_reevaluation_at |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 1 | pending_reevaluations | latest_by_reevaluation_at |

## 5. 注意

* append-only履歴から最新行だけを選ぶ分析用ビューです。
* 元のEVALUATIONS / PENDING_REEVALUATIONSは削除しません。
* この評価は実売買ではありません。
* 自動発注は行いません。
