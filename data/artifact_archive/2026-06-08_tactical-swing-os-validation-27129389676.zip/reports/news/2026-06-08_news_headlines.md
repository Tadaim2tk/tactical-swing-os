# Tactical Swing OS News Headlines

取得日時（JST）: 2026-06-08 18:47:07 JST
取得日時（UTC）: 2026-06-08 09:47:07 UTC
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
スキップソース数: 0
総所要秒数: 1.45
headline件数: 30

## 見出し

- [CNBC Markets] Oil prices spike over 4% as Iran and Israel trade strikes (WTI)
- [CNBC Markets] Weight loss drug maker sinks 25% after new safety data spooks investors (未分類)
- [CNBC Markets] Tech stock sell-off accelerates; SoftBank drops 6% as investors sour on AI-linked names (SPX|NASDAQ|US10Y|DXY)
- [CNBC Markets] Trump storms out of interview after being challenged about election fraud claims, DOJ fund (未分類)
- [CNBC Markets] Bidding war erupts for world’s oldest bank as Italy’s Intesa gatecrashes BPM offer (未分類)
- [CNBC Markets] 'Bring 'em on': Delta wants United's crown over the Pacific, too (未分類)
- [CNBC Markets] Harry's and Coterie owner Mammoth Brands has ambitions to be the next CPG giant (未分類)
- [CNBC Markets] Foreign investors have dumped billions of dollars of Korean stocks this year despite record rally. Here's why (USDJPY|SPX|DXY)
- [CNBC Markets] China's Xi to visit North Korea for first time in seven years as Beijing tests its influence over Kim (未分類)
- [CNBC Markets] Women often outlive men. Here's how they should approach their long-term care needs (未分類)
- [CNBC Markets] Inflation inside the electronics you buy may soon become a bit more sticky (未分類)
- [CNBC Markets] 100 days of the Iran war: How global markets and the economy have been affected, in charts (未分類)
- [CNBC Markets] U.S. confirms second Texas screwworm case, Canada restricts livestock imports (未分類)
- [CNBC Markets] Why AI hyperscalers are now the epicenter of a bear case for stocks (SPX)
- [CNBC Markets] Bitcoin is cratering, but a new Wall Street crypto hype is on the rise (BTC|SPX)
- [CNBC Markets] Hong Kong's IPO boom is developing a performance problem (SPX)
- [MarketWatch Top Stories] What nine different indicators say about market exuberance, according to Goldman Sachs (GOLD|US10Y|DXY)
- [MarketWatch Top Stories] ‘I have no experience with investing’: I inherited $2,000. I’m 42 with two children. What should I do with this money? (未分類)
- [MarketWatch Top Stories] Serena Williams is making a comeback; these are the properties that built her $35 million real estate portfolio (未分類)
- [MarketWatch Top Stories] Alanis Morissette quickly sells her Bay Area estate in lucrative $9.6 million sale (未分類)
- [MarketWatch Top Stories] Zealand Pharma loses a fifth of its value as many users gave up taking weight-loss drug during trial (SPX)
- [MarketWatch Top Stories] Nvidia strikes a new memory-chip deal as SK Hynix and Samsung shares close with big losses (SPX|NASDAQ)
- [MarketWatch Top Stories] Oil prices jump by the most in over a month as fresh attacks threaten the ceasefire with Iran (WTI|SPX|NASDAQ|VIX)
- [MarketWatch Top Stories] The Wegovy pill is still dominating the GLP-1 pill market (未分類)
- [MarketWatch Top Stories] S&P 500 companies can’t stop talking about higher oil prices. But few say they’ll actually hurt profits. (WTI|SPX)
- [MarketWatch Top Stories] These are the market’s new hot stocks as investors flee from tech (SPX|NASDAQ)
- [CoinDesk] U.S. inflation, European Central Bank rate decision: Crypto Week Ahead (BTC)
- [CoinDesk] CME is letting traders bet on bitcoin volatility, not price, and two firms have already placed bets (BTC|VIX)
- [CoinDesk] Zcash bounces 45% as developers propose new Ironwood upgrade (未分類)
- [CoinDesk] XRP steadies above $1.10 to bounce from four-month lows (BTC)
