# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-06-26 08:06:38 JST
Actions実行時刻（UTC）: 2026-06-25 23:06:38 UTC
対象日: 2026-06-24
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドルは中立 / 金利圧力は限定的 / ボラティリティは落ち着き
- ニュースモード: ニュースナラティブ未取得
- ニュース市場バイアス: insufficient_data
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_only
- 評価データソース: latest_evaluations
- latest_evaluations_available: True
- fallback_used: False
- risk_on: 50.44
- risk_off: 49.43
- dollar: 50.11
- rate: 49.29
- volatility: 49.2
- news_confidence: 0.0
- シグナル整合性: aligned=1, conflicted=1, neutral=7, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 50.44 | 49.43 | 50.11 | 49.29 | 49.16 | 50.45 | 49.2 | 92.78 |
| DXY | 50.44 | 49.43 | 50.11 | 49.29 | 49.16 | 50.45 | 49.2 | 92.78 |
| GOLD | 50.44 | 49.43 | 50.11 | 49.29 | 49.16 | 50.45 | 49.2 | 92.78 |
| NASDAQ | 50.44 | 49.43 | 50.11 | 49.29 | 49.16 | 50.45 | 49.2 | 92.78 |
| SPX | 50.44 | 49.43 | 50.11 | 49.29 | 49.16 | 50.45 | 49.2 | 92.78 |
| US10Y | 50.44 | 49.43 | 50.11 | 49.29 | 49.16 | 50.45 | 49.2 | 92.78 |
| USDJPY | 50.44 | 49.43 | 50.11 | 49.29 | 49.16 | 50.45 | 49.2 | 92.78 |
| VIX | 50.44 | 49.43 | 50.11 | 49.29 | 49.16 | 50.45 | 49.2 | 92.78 |
| WTI | 50.44 | 49.43 | 50.11 | 49.29 | 49.16 | 50.45 | 49.2 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260624_BTC_SHORT_TREND | BTC | SHORT | A | TRADE | trend_down|ma_alignment_bear|momentum_negative|atr_too_low | neutral | -1 | BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。 |
| 20260624_DXY_LONG_A-Momentum | DXY | LONG | B | WATCH | trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought | neutral | 0 | DXYはドル高圧力を中心に評価しました。 |
| 20260624_GOLD_SHORT_B-Watch | GOLD | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative|breakout_down|rsi_oversold|overextended | neutral | 1 | GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。 |
| 20260624_NASDAQ_LONG_A-Pullback | NASDAQ | LONG | B | WATCH | trend_up|ma_alignment_bull|momentum_positive|atr_too_high|pullback_to_ma20 | aligned | 12 | NASDAQは株式モメンタム、金利圧力、ボラティリティで評価しました。 |
| 20260624_SPX_NONE_NO_TRADE | SPX | NONE | NO_TRADE | NO_TRADE | atr_too_high|rr_too_low|range_middle|pullback_to_ma20 | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260624_US10Y_NONE_NO_TRADE | US10Y | NONE | NO_TRADE | NO_TRADE | momentum_negative|breakout_down|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260624_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260624_VIX_NONE_NO_TRADE | VIX | NONE | NO_TRADE | NO_TRADE | momentum_positive|rr_too_low|range_middle|pullback_to_ma20|overextended | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 |
| 20260624_WTI_SHORT_B-Watch | WTI | SHORT | B | WATCH | trend_down|ma_alignment_bear|momentum_negative|breakout_down|rsi_oversold|overextended | conflicted | -15 | WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
| 20260622_US10Y_LONG_A-Pullback | US10Y | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260623_GOLD_SHORT_B-Watch | GOLD | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260623_US10Y_LONG_A-Pullback | US10Y | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260623_WTI_SHORT_B-Watch | WTI | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260605_US10Y_LONG_TREND | US10Y | loss_sl | -1.0 | 損切り到達。Entry/SL幅またはrank判定の再確認が必要です。 | unknown | 追加サンプルで検証します。 |
| 20260612_WTI_SHORT_B-Watch | WTI | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260605_GOLD_SHORT_TREND | GOLD | win_tp1 | 1.087 | エントリー/方向判断は一定程度機能しました。 | unknown | 追加サンプルで検証します。 |
| 20260605_DXY_LONG_TREND | DXY | loss_sl | -1.0 | 損切り到達。Entry/SL幅またはrank判定の再確認が必要です。 | unknown | 追加サンプルで検証します。 |

## 5. 明日に向けた補正仮説

- ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: False
- news_mode_summary: ニュースナラティブ未取得
- top_news_drivers: ニュースドライバーなし

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-06-25T23:06:38,2026-06-26 08:06:38 JST,2026-06-25 23:06:38 UTC,2026-06-24,BTC,20260624_BTC_SHORT_TREND,SHORT,A,TRADE,trend_down|ma_alignment_bear|momentum_negative|atr_too_low,neutral,-1,50.44,49.43,50.11,49.29,49.16,50.45,49.2,92.78,0.0,market_proxy_only,open_unresolved,,context_neutral,BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。,BTC SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-25T23:06:38,2026-06-26 08:06:38 JST,2026-06-25 23:06:38 UTC,2026-06-24,DXY,20260624_DXY_LONG_A-Momentum,LONG,B,WATCH,trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought,neutral,0,50.44,49.43,50.11,49.29,49.16,50.45,49.2,92.78,0.0,market_proxy_only,open_unresolved,,context_neutral,DXYはドル高圧力を中心に評価しました。,DXY LONG は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-25T23:06:38,2026-06-26 08:06:38 JST,2026-06-25 23:06:38 UTC,2026-06-24,GOLD,20260624_GOLD_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative|breakout_down|rsi_oversold|overextended,neutral,1,50.44,49.43,50.11,49.29,49.16,50.45,49.2,92.78,0.0,market_proxy_only,open_unresolved,,context_neutral,GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。,GOLD SHORT は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-25T23:06:38,2026-06-26 08:06:38 JST,2026-06-25 23:06:38 UTC,2026-06-24,NASDAQ,20260624_NASDAQ_LONG_A-Pullback,LONG,B,WATCH,trend_up|ma_alignment_bull|momentum_positive|atr_too_high|pullback_to_ma20,aligned,12,50.44,49.43,50.11,49.29,49.16,50.45,49.2,92.78,0.0,market_proxy_only,open_unresolved,,context_support,NASDAQは株式モメンタム、金利圧力、ボラティリティで評価しました。,NASDAQ LONG は市場文脈と整合。既存ルールを維持し、過剰強化はしない。,False,latest_evaluations,True,False
2026-06-25T23:06:38,2026-06-26 08:06:38 JST,2026-06-25 23:06:38 UTC,2026-06-24,SPX,20260624_SPX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,atr_too_high|rr_too_low|range_middle|pullback_to_ma20,neutral,0,50.44,49.43,50.11,49.29,49.16,50.45,49.2,92.78,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,SPX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-25T23:06:38,2026-06-26 08:06:38 JST,2026-06-25 23:06:38 UTC,2026-06-24,US10Y,20260624_US10Y_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_negative|breakout_down|rr_too_low,neutral,0,50.44,49.43,50.11,49.29,49.16,50.45,49.2,92.78,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,US10Y NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-25T23:06:38,2026-06-26 08:06:38 JST,2026-06-25 23:06:38 UTC,2026-06-24,USDJPY,20260624_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,50.44,49.43,50.11,49.29,49.16,50.45,49.2,92.78,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-25T23:06:38,2026-06-26 08:06:38 JST,2026-06-25 23:06:38 UTC,2026-06-24,VIX,20260624_VIX_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,momentum_positive|rr_too_low|range_middle|pullback_to_ma20|overextended,neutral,0,50.44,49.43,50.11,49.29,49.16,50.45,49.2,92.78,0.0,market_proxy_only,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。,VIX NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False
2026-06-25T23:06:38,2026-06-26 08:06:38 JST,2026-06-25 23:06:38 UTC,2026-06-24,WTI,20260624_WTI_SHORT_B-Watch,SHORT,B,WATCH,trend_down|ma_alignment_bear|momentum_negative|breakout_down|rsi_oversold|overextended,conflicted,-15,50.44,49.43,50.11,49.29,49.16,50.45,49.2,92.78,0.0,market_proxy_only,open_unresolved,,context_warning,WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。,WTI SHORT は市場文脈と衝突。明日はrank/entry条件を慎重化する仮説。,False,latest_evaluations,True,False

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-06-25T23:06:38",
  "generated_at_jst": "2026-06-26 08:06:38 JST",
  "generated_at_utc": "2026-06-25 23:06:38 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-06-24",
  "data_source": "Google Sheets",
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 66,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "market_mode_summary": "リスクオン/オフは中立 / ドルは中立 / 金利圧力は限定的 / ボラティリティは落ち着き",
  "news_narrative_available": false,
  "news_mode_summary": "ニュースナラティブ未取得",
  "top_news_drivers": [],
  "narrative_source_mix": "market_proxy_only",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 50.44,
      "risk_off_score": 49.43,
      "dollar_strength_score": 50.11,
      "rate_pressure_score": 49.29,
      "gold_safe_haven_score": 49.16,
      "oil_supply_risk_proxy_score": 49.94,
      "crypto_liquidity_score": 50.45,
      "equity_momentum_score": 50.61,
      "volatility_stress_score": 49.2,
      "narrative_confidence": 92.78,
      "asset_change_pct": null
    },
    {
      "asset": "DXY",
      "risk_on_score": 50.44,
      "risk_off_score": 49.43,
      "dollar_strength_score": 50.11,
      "rate_pressure_score": 49.29,
      "gold_safe_haven_score": 49.16,
      "oil_supply_risk_proxy_score": 49.94,
      "crypto_liquidity_score": 50.45,
      "equity_momentum_score": 50.61,
      "volatility_stress_score": 49.2,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.2111
    },
    {
      "asset": "GOLD",
      "risk_on_score": 50.44,
      "risk_off_score": 49.43,
      "dollar_strength_score": 50.11,
      "rate_pressure_score": 49.29,
      "gold_safe_haven_score": 49.16,
      "oil_supply_risk_proxy_score": 49.94,
      "crypto_liquidity_score": 50.45,
      "equity_momentum_score": 50.61,
      "volatility_stress_score": 49.2,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.0871
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 50.44,
      "risk_off_score": 49.43,
      "dollar_strength_score": 50.11,
      "rate_pressure_score": 49.29,
      "gold_safe_haven_score": 49.16,
      "oil_supply_risk_proxy_score": 49.94,
      "crypto_liquidity_score": 50.45,
      "equity_momentum_score": 50.61,
      "volatility_stress_score": 49.2,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.108
    },
    {
      "asset": "SPX",
      "risk_on_score": 50.44,
      "risk_off_score": 49.43,
      "dollar_strength_score": 50.11,
      "rate_pressure_score": 49.29,
      "gold_safe_haven_score": 49.16,
      "oil_supply_risk_proxy_score": 49.94,
      "crypto_liquidity_score": 50.45,
      "equity_momentum_score": 50.61,
      "volatility_stress_score": 49.2,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1137
    },
    {
      "asset": "US10Y",
      "risk_on_score": 50.44,
      "risk_off_score": 49.43,
      "dollar_strength_score": 50.11,
      "rate_pressure_score": 49.29,
      "gold_safe_haven_score": 49.16,
      "oil_supply_risk_proxy_score": 49.94,
      "crypto_liquidity_score": 50.45,
      "equity_momentum_score": 50.61,
      "volatility_stress_score": 49.2,
      "narrative_confidence": 92.78,
      "asset_change_pct": -1.1453
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 50.44,
      "risk_off_score": 49.43,
      "dollar_strength_score": 50.11,
      "rate_pressure_score": 49.29,
      "gold_safe_haven_score": 49.16,
      "oil_supply_risk_proxy_score": 49.94,
      "crypto_liquidity_score": 50.45,
      "equity_momentum_score": 50.61,
      "volatility_stress_score": 49.2,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0117
    },
    {
      "asset": "VIX",
      "risk_on_score": 50.44,
      "risk_off_score": 49.43,
      "dollar_strength_score": 50.11,
      "rate_pressure_score": 49.29,
      "gold_safe_haven_score": 49.16,
      "oil_supply_risk_proxy_score": 49.94,
      "crypto_liquidity_score": 50.45,
      "equity_momentum_score": 50.61,
      "volatility_stress_score": 49.2,
      "narrative_confidence": 92.78,
      "asset_change_pct": -2.6137
    },
    {
      "asset": "WTI",
      "risk_on_score": 50.44,
      "risk_off_score": 49.43,
      "dollar_strength_score": 50.11,
      "rate_pressure_score": 49.29,
      "gold_safe_haven_score": 49.16,
      "oil_supply_risk_proxy_score": 49.94,
      "crypto_liquidity_score": 50.45,
      "equity_momentum_score": 50.61,
      "volatility_stress_score": 49.2,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1287
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260624_BTC_SHORT_TREND",
      "asset": "BTC",
      "side": "SHORT",
      "rank": "A",
      "recommended_action": "TRADE",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|atr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": -1,
      "narrative_comment": "BTCはリスクオン、流動性、ドル圧力、ボラティリティの組み合わせで評価しました。"
    },
    {
      "signal_id": "20260624_DXY_LONG_A-Momentum",
      "asset": "DXY",
      "side": "LONG",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|breakout_up|rsi_overbought",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "DXYはドル高圧力を中心に評価しました。"
    },
    {
      "signal_id": "20260624_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|breakout_down|rsi_oversold|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 1,
      "narrative_comment": "GOLDは安全資産需要とドル高/金利上昇圧力の綱引きで評価しました。"
    },
    {
      "signal_id": "20260624_NASDAQ_LONG_A-Pullback",
      "asset": "NASDAQ",
      "side": "LONG",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|atr_too_high|pullback_to_ma20",
      "narrative_alignment": "aligned",
      "narrative_alignment_score": 12,
      "narrative_comment": "NASDAQは株式モメンタム、金利圧力、ボラティリティで評価しました。"
    },
    {
      "signal_id": "20260624_SPX_NONE_NO_TRADE",
      "asset": "SPX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "atr_too_high|rr_too_low|range_middle|pullback_to_ma20",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260624_US10Y_NONE_NO_TRADE",
      "asset": "US10Y",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_negative|breakout_down|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260624_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260624_VIX_NONE_NO_TRADE",
      "asset": "VIX",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "momentum_positive|rr_too_low|range_middle|pullback_to_ma20|overextended",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。"
    },
    {
      "signal_id": "20260624_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "side": "SHORT",
      "rank": "B",
      "recommended_action": "WATCH",
      "reason_codes": "trend_down|ma_alignment_bear|momentum_negative|breakout_down|rsi_oversold|overextended",
      "narrative_alignment": "conflicted",
      "narrative_alignment_score": -15,
      "narrative_comment": "WTIは供給リスクproxyとリスク選好、ドル圧力で評価しました。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "signal_id": "20260622_US10Y_LONG_A-Pullback",
      "asset": "US10Y",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260623_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260623_US10Y_LONG_A-Pullback",
      "asset": "US10Y",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260623_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260605_US10Y_LONG_TREND",
      "asset": "US10Y",
      "outcome": "loss_sl",
      "r_multiple": -1.0,
      "technical_view": "損切り到達。Entry/SL幅またはrank判定の再確認が必要です。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    },
    {
      "signal_id": "20260612_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260605_GOLD_SHORT_TREND",
      "asset": "GOLD",
      "outcome": "win_tp1",
      "r_multiple": 1.087,
      "technical_view": "エントリー/方向判断は一定程度機能しました。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    },
    {
      "signal_id": "20260605_DXY_LONG_TREND",
      "asset": "DXY",
      "outcome": "loss_sl",
      "r_multiple": -1.0,
      "technical_view": "損切り到達。Entry/SL幅またはrank判定の再確認が必要です。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    }
  ],
  "improvement_hypotheses": [
    "ナラティブ衝突シグナルは、翌日のrankまたはrisk_pctを下げる仮説として監視。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
