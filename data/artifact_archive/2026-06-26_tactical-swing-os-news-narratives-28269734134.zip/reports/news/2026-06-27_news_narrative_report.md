# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-27 07:53:22 JST
生成日時（UTC）: 2026-06-26 22:53:22 UTC
headline件数: 75
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.08
ニュース市場バイアス: neutral
ニュース矛盾スコア: 18.47
主要テーマ: geopolitical_risk, inflation_pressure
日本語要約: 地政学リスク、インフレ圧力はありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 金利圧力材料あり / 地政学リスク材料あり

## スコア

- risk_on_news_score: 55.4
- risk_off_news_score: 18.47
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 55.4
- gold_safe_haven_news_score: 36.93
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 18.47
- geopolitical_risk_news_score: 73.87
- inflation_pressure_news_score: 73.87
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 36.93
- central_bank_dovish_score: 18.47
- news_confidence: 100.0

## Top News Drivers

- U.S. strikes Iran after Trump accuses Tehran of ceasefire violation in Strait of Hormuz (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Trump eases pressure on Fed Chairman Kevin Warsh as inflation tops 4% (インフレ圧力 / 金利圧力候補)
- Trump threatens 100% tariffs on countries putting 'Digital Services Tax on American Companies' (インフレ圧力 / 金利圧力候補)
- Minneapolis Fed President Neel Kashkari says he expects a rate hike this year (インフレ圧力 / 金利圧力候補 / 中銀タカ派)
- ON Semiconductor records worst day since 2020 as CEO defends Synaptics deal (中銀ハト派)
- ServiceNow, Salesforce and other software stocks surge as the OpenAI threat weakens (リスクオン要因)
- Iran’s ship attack tests the shipping-insurance market just as war-risk premiums had plunged (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Bond yields are falling as inflation pops. The Fed’s tough talk under Warsh is helping. (インフレ圧力 / 金利圧力候補)
- Fed’s Kashkari now projects one interest-rate hike this year. Here’s what changed his mind. (金利圧力候補 / 中銀タカ派)
- Aave, Solana ecosystem tokens lead crypto rebound as bitcoin steadies near $60,000 (リスクオン要因)
