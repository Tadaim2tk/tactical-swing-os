# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-22 07:50:09 JST
生成日時（UTC）: 2026-06-21 22:50:09 UTC
headline件数: 41
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.69
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立

## スコア

- risk_on_news_score: 0.0
- risk_off_news_score: 37.71
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 0.0
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 18.85
- inflation_pressure_news_score: 18.85
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- The best parents and leaders use a 3-step formula to help people handle uncertainty, says Dr. Becky Kennedy (リスクオフ要因)
- Massive bonuses for South Korea's chip workers puts central bank on inflation alert (インフレ圧力 / 金利圧力候補)
- The loneliness crisis has gotten so bad that lawmakers are ready to spend millions of dollars to fight it (リスクオフ要因)
- Russia stocks lower at close of trade; MOEX Russia Index unchanged (地政学リスク / リスクオフ要因)
