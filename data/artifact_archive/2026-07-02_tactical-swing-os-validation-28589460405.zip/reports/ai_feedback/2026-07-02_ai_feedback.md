# Tactical Swing OS AI Feedback Report

生成日時（JST）: 2026-07-02 21:20:11 JST
Actions実行時刻（UTC）: 2026-07-02 12:20:11 UTC
対象日: 2026-07-02
データソース: Google Sheets

## 1. 今日の総合判断

- 今日の市場モード: リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり
- ニュース市場バイアス: neutral
- ニュース矛盾スコア: 0.0
- ナラティブ入力: market_proxy_plus_news
- 評価データソース: latest_evaluations
- latest_evaluations_available: True
- fallback_used: False
- risk_on: 41.16
- risk_off: 34.52
- dollar: 35.03
- rate: 34.89
- volatility: 49.01
- news_confidence: 100.0
- シグナル整合性: aligned=0, conflicted=0, neutral=1, insufficient_data=0

## 2. 資産別ナラティブスコア

| asset | risk_on_score | risk_off_score | dollar_strength_score | rate_pressure_score | gold_safe_haven_score | crypto_liquidity_score | volatility_stress_score | narrative_confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBAL | 41.16 | 34.52 | 35.03 | 34.89 | 52.78 | 35.39 | 49.01 | 93.86 |
| DXY | 50.58 | 49.32 | 50.04 | 49.84 | 49.12 | 50.56 | 49.01 | 92.78 |
| GOLD | 50.58 | 49.32 | 50.04 | 49.84 | 49.12 | 50.56 | 49.01 | 92.78 |
| NASDAQ | 50.58 | 49.32 | 50.04 | 49.84 | 49.12 | 50.56 | 49.01 | 92.78 |
| SPX | 50.58 | 49.32 | 50.04 | 49.84 | 49.12 | 50.56 | 49.01 | 92.78 |
| US10Y | 50.58 | 49.32 | 50.04 | 49.84 | 49.12 | 50.56 | 49.01 | 92.78 |
| USDJPY | 50.58 | 49.32 | 50.04 | 49.84 | 49.12 | 50.56 | 49.01 | 92.78 |
| VIX | 50.58 | 49.32 | 50.04 | 49.84 | 49.12 | 50.56 | 49.01 | 92.78 |
| WTI | 50.58 | 49.32 | 50.04 | 49.84 | 49.12 | 50.56 | 49.01 | 92.78 |

## 3. シグナル別ナラティブ整合性

| signal_id | asset | side | rank | recommended_action | reason_codes | narrative_alignment | narrative_alignment_score | narrative_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20260702_USDJPY_NONE_NO_TRADE | USDJPY | NONE | NO_TRADE | NO_TRADE | trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low | neutral | 0 | 見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。 |

## 4. 前回評価からの反省

| signal_id | asset | outcome | r_multiple | technical_view | narrative_alignment | improvement |
| --- | --- | --- | --- | --- | --- | --- |
| 20260623_GOLD_SHORT_B-Watch | GOLD | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260622_US10Y_LONG_A-Pullback | US10Y | loss_sl | -1.0 | 損切り到達。Entry/SL幅またはrank判定の再確認が必要です。 | unknown | 追加サンプルで検証します。 |
| 20260630_NASDAQ_LONG_B-Watch | NASDAQ | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260630_WTI_SHORT_B-Watch | WTI | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260612_WTI_SHORT_B-Watch | WTI | no_entry | 0.0 | 未約定。entry帯が保守的すぎた可能性があります。 | unknown | MFEが大きい場合はentry帯の柔軟化候補です。 |
| 20260605_US10Y_LONG_TREND | US10Y | loss_sl | -1.0 | 損切り到達。Entry/SL幅またはrank判定の再確認が必要です。 | unknown | 追加サンプルで検証します。 |
| 20260605_GOLD_SHORT_TREND | GOLD | win_tp1 | 1.087 | エントリー/方向判断は一定程度機能しました。 | unknown | 追加サンプルで検証します。 |
| 20260605_DXY_LONG_TREND | DXY | loss_sl | -1.0 | 損切り到達。Entry/SL幅またはrank判定の再確認が必要です。 | unknown | 追加サンプルで検証します。 |

## 5. 明日に向けた補正仮説

- データ不足のため、明日の補正仮説は現行ルール維持を基本とします。

## 6. rule_update_proposalsとの照合

| proposal_id | target_name | proposal_strength | proposed_change | narrative_crosscheck | apply_automatically |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. ニュースナラティブ補助入力

- news_narrative_available: True
- news_mode_summary: ニュースのリスク方向は中立 / 地政学リスク材料あり
- top_news_drivers: Russia launches massive strike on Ukraine as Poland scrambles jets, Finland restricts airspace, Russia’s neighbor Lithuania scraps constitutional ban on nuclear weapons. Here's why, Warsh faces multiple alternative inflation signs as Fed charts new course, Shares of BYD and Xiaomi surge as June delivery figures fuel optimism

## 8. 今日の注意点

- ニュース分類はRSS見出しのキーワード分類であり、本文読解やLLM評価ではありません。
- データ不足の可能性があります。
- 評価件数不足の場合、結論は仮説扱いです。
- LLM未使用のためニュース本文は未評価です。
- 実売買には使いません。
- 自動発注、weights.json自動更新、generate_signal.py自動変更は行いません。

## 9. AI_FEEDBACK_LOG CSV

```csv
generated_at,generated_at_jst,generated_at_utc,date,asset,signal_id,side,rank,recommended_action,reason_codes,narrative_alignment,narrative_alignment_score,risk_on_score,risk_off_score,dollar_strength_score,rate_pressure_score,gold_safe_haven_score,crypto_liquidity_score,volatility_stress_score,narrative_confidence,news_confidence,narrative_source_mix,latest_outcome,latest_r_multiple,feedback_type,feedback_summary,proposed_next_action,apply_automatically,evaluation_source,latest_evaluations_available,fallback_used
2026-07-02T12:20:11,2026-07-02 21:20:11 JST,2026-07-02 12:20:11 UTC,2026-07-02,USDJPY,20260702_USDJPY_NONE_NO_TRADE,NONE,NO_TRADE,NO_TRADE,trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low,neutral,0,41.16,34.52,35.03,34.89,52.78,35.39,49.01,93.86,100.0,market_proxy_plus_news,,,context_neutral,見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。,USDJPY NONE は中立。テクニカル優先だが、文脈変化を監視。,False,latest_evaluations,True,False

```

## 10. AI_FEEDBACK_LOG JSON

```json
{
  "generated_at": "2026-07-02T12:20:11",
  "generated_at_jst": "2026-07-02 21:20:11 JST",
  "generated_at_utc": "2026-07-02 12:20:11 UTC",
  "timezone": "Asia/Tokyo",
  "date": "2026-07-02",
  "data_source": "Google Sheets",
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 81,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "market_mode_summary": "リスクオン/オフは中立 / ドル高圧力は限定的 / 金利圧力は限定的 / ボラティリティは落ち着き / ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "news_narrative_available": true,
  "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
  "top_news_drivers": [
    {
      "title": "Russia launches massive strike on Ukraine as Poland scrambles jets, Finland restricts airspace",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "geopolitical_risk_news_score:attack|geopolitical_risk_news_score:russia|geopolitical_risk_news_score:ukraine",
      "driver_tags": "geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/07/02/russia-launches-missile-drone-strikes-ukraine-kyiv.html"
    },
    {
      "title": "Russia’s neighbor Lithuania scraps constitutional ban on nuclear weapons. Here's why",
      "source": "CNBC Markets",
      "matched_assets": "",
      "matched_rules": "geopolitical_risk_news_score:russia",
      "driver_tags": "geopolitical_risk",
      "driver_summary_ja": "地政学リスク / リスクオフ要因",
      "link": "https://www.cnbc.com/2026/07/02/russia-ukraine-nato-lithuania-nuclear-weapons.html"
    },
    {
      "title": "Warsh faces multiple alternative inflation signs as Fed charts new course",
      "source": "CNBC Markets",
      "matched_assets": "US10Y|DXY",
      "matched_rules": "inflation_pressure_news_score:inflation",
      "driver_tags": "inflation_pressure",
      "driver_summary_ja": "インフレ圧力 / 金利圧力候補",
      "link": "https://www.cnbc.com/2026/07/01/warsh-faces-multiple-alternative-inflation-signs-as-fed-charts-new-course.html"
    },
    {
      "title": "Shares of BYD and Xiaomi surge as June delivery figures fuel optimism",
      "source": "CNBC Markets",
      "matched_assets": "SPX",
      "matched_rules": "risk_on_news_score:optimism",
      "driver_tags": "risk_on",
      "driver_summary_ja": "リスクオン要因",
      "link": "https://www.cnbc.com/2026/07/02/china-ev-stocks-xiaomi-byd-june-deliveries-production.html"
    }
  ],
  "narrative_source_mix": "market_proxy_plus_news",
  "narrative_scores": [
    {
      "asset": "GLOBAL",
      "risk_on_score": 41.16,
      "risk_off_score": 34.52,
      "dollar_strength_score": 35.03,
      "rate_pressure_score": 34.89,
      "gold_safe_haven_score": 52.78,
      "oil_supply_risk_proxy_score": 34.99,
      "crypto_liquidity_score": 35.39,
      "equity_momentum_score": 35.57,
      "volatility_stress_score": 49.01,
      "narrative_confidence": 93.86,
      "asset_change_pct": null,
      "headline_count": 30.0,
      "risk_on_news_score": 19.17,
      "risk_off_news_score": 0.0,
      "dollar_strength_news_score": 0.0,
      "rate_pressure_news_score": 0.0,
      "gold_safe_haven_news_score": 0.0,
      "oil_supply_risk_news_score": 0.0,
      "crypto_liquidity_news_score": 0.0,
      "equity_momentum_news_score": 0.0,
      "geopolitical_risk_news_score": 76.67,
      "inflation_pressure_news_score": 19.17,
      "recession_risk_news_score": 0.0,
      "news_confidence": 100.0,
      "news_narrative_available": true,
      "news_mode_summary": "ニュースのリスク方向は中立 / 地政学リスク材料あり",
      "narrative_source_mix": "market_proxy_plus_news"
    },
    {
      "asset": "DXY",
      "risk_on_score": 50.58,
      "risk_off_score": 49.32,
      "dollar_strength_score": 50.04,
      "rate_pressure_score": 49.84,
      "gold_safe_haven_score": 49.12,
      "oil_supply_risk_proxy_score": 49.99,
      "crypto_liquidity_score": 50.56,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 49.01,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1927,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "GOLD",
      "risk_on_score": 50.58,
      "risk_off_score": 49.32,
      "dollar_strength_score": 50.04,
      "rate_pressure_score": 49.84,
      "gold_safe_haven_score": 49.12,
      "oil_supply_risk_proxy_score": 49.99,
      "crypto_liquidity_score": 50.56,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 49.01,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.1679,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "NASDAQ",
      "risk_on_score": 50.58,
      "risk_off_score": 49.32,
      "dollar_strength_score": 50.04,
      "rate_pressure_score": 49.84,
      "gold_safe_haven_score": 49.12,
      "oil_supply_risk_proxy_score": 49.99,
      "crypto_liquidity_score": 50.56,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 49.01,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.005,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "SPX",
      "risk_on_score": 50.58,
      "risk_off_score": 49.32,
      "dollar_strength_score": 50.04,
      "rate_pressure_score": 49.84,
      "gold_safe_haven_score": 49.12,
      "oil_supply_risk_proxy_score": 49.99,
      "crypto_liquidity_score": 50.56,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 49.01,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0166,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "US10Y",
      "risk_on_score": 50.58,
      "risk_off_score": 49.32,
      "dollar_strength_score": 50.04,
      "rate_pressure_score": 49.84,
      "gold_safe_haven_score": 49.12,
      "oil_supply_risk_proxy_score": 49.99,
      "crypto_liquidity_score": 50.56,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 49.01,
      "narrative_confidence": 92.78,
      "asset_change_pct": -0.1785,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "USDJPY",
      "risk_on_score": 50.58,
      "risk_off_score": 49.32,
      "dollar_strength_score": 50.04,
      "rate_pressure_score": 49.84,
      "gold_safe_haven_score": 49.12,
      "oil_supply_risk_proxy_score": 49.99,
      "crypto_liquidity_score": 50.56,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 49.01,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0197,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "VIX",
      "risk_on_score": 50.58,
      "risk_off_score": 49.32,
      "dollar_strength_score": 50.04,
      "rate_pressure_score": 49.84,
      "gold_safe_haven_score": 49.12,
      "oil_supply_risk_proxy_score": 49.99,
      "crypto_liquidity_score": 50.56,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 49.01,
      "narrative_confidence": 92.78,
      "asset_change_pct": -3.0392,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    },
    {
      "asset": "WTI",
      "risk_on_score": 50.58,
      "risk_off_score": 49.32,
      "dollar_strength_score": 50.04,
      "rate_pressure_score": 49.84,
      "gold_safe_haven_score": 49.12,
      "oil_supply_risk_proxy_score": 49.99,
      "crypto_liquidity_score": 50.56,
      "equity_momentum_score": 50.82,
      "volatility_stress_score": 49.01,
      "narrative_confidence": 92.78,
      "asset_change_pct": 0.0147,
      "headline_count": null,
      "risk_on_news_score": null,
      "risk_off_news_score": null,
      "dollar_strength_news_score": null,
      "rate_pressure_news_score": null,
      "gold_safe_haven_news_score": null,
      "oil_supply_risk_news_score": null,
      "crypto_liquidity_news_score": null,
      "equity_momentum_news_score": null,
      "geopolitical_risk_news_score": null,
      "inflation_pressure_news_score": null,
      "recession_risk_news_score": null,
      "news_confidence": null,
      "news_narrative_available": null,
      "news_mode_summary": null,
      "narrative_source_mix": null
    }
  ],
  "signal_alignment": [
    {
      "signal_id": "20260702_USDJPY_NONE_NO_TRADE",
      "asset": "USDJPY",
      "side": "NONE",
      "rank": "NO_TRADE",
      "recommended_action": "NO_TRADE",
      "reason_codes": "trend_up|ma_alignment_bull|momentum_positive|rsi_overbought|atr_too_low|rr_too_low",
      "narrative_alignment": "neutral",
      "narrative_alignment_score": 0,
      "narrative_comment": "見送りシグナルのため、ナラティブは参考情報として扱います。 ニュース要約: 地政学リスクはありますが、ニュース面の方向感は中立です。"
    }
  ],
  "recent_evaluation_reflection": [
    {
      "signal_id": "20260623_GOLD_SHORT_B-Watch",
      "asset": "GOLD",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260622_US10Y_LONG_A-Pullback",
      "asset": "US10Y",
      "outcome": "loss_sl",
      "r_multiple": -1.0,
      "technical_view": "損切り到達。Entry/SL幅またはrank判定の再確認が必要です。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    },
    {
      "signal_id": "20260630_NASDAQ_LONG_B-Watch",
      "asset": "NASDAQ",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260630_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260612_WTI_SHORT_B-Watch",
      "asset": "WTI",
      "outcome": "no_entry",
      "r_multiple": 0.0,
      "technical_view": "未約定。entry帯が保守的すぎた可能性があります。",
      "narrative_alignment": "unknown",
      "improvement": "MFEが大きい場合はentry帯の柔軟化候補です。"
    },
    {
      "signal_id": "20260605_US10Y_LONG_TREND",
      "asset": "US10Y",
      "outcome": "loss_sl",
      "r_multiple": -1.0,
      "technical_view": "損切り到達。Entry/SL幅またはrank判定の再確認が必要です。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    },
    {
      "signal_id": "20260605_GOLD_SHORT_TREND",
      "asset": "GOLD",
      "outcome": "win_tp1",
      "r_multiple": 1.087,
      "technical_view": "エントリー/方向判断は一定程度機能しました。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    },
    {
      "signal_id": "20260605_DXY_LONG_TREND",
      "asset": "DXY",
      "outcome": "loss_sl",
      "r_multiple": -1.0,
      "technical_view": "損切り到達。Entry/SL幅またはrank判定の再確認が必要です。",
      "narrative_alignment": "unknown",
      "improvement": "追加サンプルで検証します。"
    }
  ],
  "improvement_hypotheses": [
    "データ不足のため、明日の補正仮説は現行ルール維持を基本とします。"
  ],
  "rule_proposal_crosscheck": [
    {
      "summary": "rule_update_proposals がないため照合は未実施です。"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動発注しない",
    "weights.jsonを自動更新しない",
    "generate_signal.pyを自動変更しない",
    "ナラティブ評価は仮説であり、人間レビューが必要",
    "ニュース本文/LLM評価は今後の拡張"
  ]
}
```
