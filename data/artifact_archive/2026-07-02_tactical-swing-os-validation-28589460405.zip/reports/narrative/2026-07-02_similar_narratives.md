# Similar Narrative Cases（類似局面検索 v0）

## 1. 概要

- 基準日: 2026-07-02
- status: **insufficient_data**
- **insufficient_data**: 過去の局面文書が 1 日分しか無く、最低 5 日に満たない。 データが溜まれば自動で結果が出る（実装はデータを待たない）。

## 2. 類似局面と、その後の実リターン（5/10/20営業日）

_類似局面なし_

## 3. 注意

- allowed_for_signal=true の record のみ・基準日より前の局面のみを検索（lookahead-safe）。
- この出力は表示・記録のみで、signal score には接続していない（connected_to_signal_score=false）。
- 実売買・発注は行わない。
