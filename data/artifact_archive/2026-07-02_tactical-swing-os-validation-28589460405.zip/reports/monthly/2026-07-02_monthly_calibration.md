# Tactical Swing OS Monthly Calibration

## 1. 月次結論

翌月モードは「通常」、最大日次リスクは 0.5% です。データ不足。

## 2. 月次サマリー

| month_start | month_end | total_signals | closed_signals | pending_signals | skipped_signals | win_rate | profit_factor | total_r | average_r | max_win_r | max_loss_r | best_asset | worst_asset | best_rank | worst_rank | best_side | worst_side | next_month_mode | max_daily_risk_pct | weight_change_summary | rule_change_1 | rule_change_2 | rule_change_3 | evaluation_source | latest_evaluations_available | fallback_used |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-03 | 2026-07-02 | 212 | 6 | 70 | 5 | 0.3333 | 0.5435 | -1.826 | -0.3043 | 1.087 | -1.0 | GOLD | US10Y | A | B | SHORT | LONG | 通常 | 0.5 | 変更提案なし | closed評価10件未満のため自動適用しない | Entry/SL/Rank判定の見直し | データ不足 | latest_evaluations | True | False |

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 3. 資産別較正

| asset | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BTC | 28 | 1 | 0.0 | -1.0 | -1.0 | -1.0 | 0.88 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=1 < 30) |
| DXY | 24 | 1 | 0.0 | -1.0 | -1.0 | -1.0 | 0.93 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=1 < 30) |
| GOLD | 25 | 1 | 1.0 | 1.087 | 1.087 | 1.087 | 0.93 | False | 1.087 | 1.087 | 0.0 | データ不足 (n=1 < 30) |
| NASDAQ | 24 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| SPX | 24 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| US10Y | 20 | 2 | 0.0 | -2.0 | -1.0 | -1.0 | 1.92 | False | -1.0 | -1.0 | 0.0 | データ不足 (n=2 < 30) |
| USDJPY | 24 | 1 | 1.0 | 1.087 | 1.087 | 1.087 | 0.9 | False | 1.087 | 1.087 | 0.0 | データ不足 (n=1 < 30) |
| VIX | 19 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| WTI | 24 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

## 4. Rank別較正

| rank | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | 4 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| B | 76 | 6 | 0.3333 | -1.826 | -0.3043 | -0.3127 | 5.56 | False | 1.087 | -1.0 | 0.0 | データ不足 (n=6 < 30) |
| NO_TRADE | 132 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

## 5. Side別較正

| side | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| LONG | 37 | 4 | 0.25 | -1.913 | -0.4783 | -0.4963 | 3.75 | False | 1.087 | -1.0 | 0.0 | データ不足 (n=4 < 30) |
| SHORT | 43 | 2 | 0.5 | 0.087 | 0.0435 | 0.0676 | 1.81 | False | 1.087 | -1.0 | 0.0 | データ不足 (n=2 < 30) |
| NONE | 132 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

## 6. レジーム別較正 (SPEC-RD-001)

| regime | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| UPTREND | 82 | 4 | 0.25 | -1.913 | -0.4783 | -0.4963 | 3.75 | False | 1.087 | -1.0 | 0.0 | データ不足 (n=4 < 30) |
| DOWNTREND | 80 | 2 | 0.5 | 0.087 | 0.0435 | 0.0676 | 1.81 | False | 1.087 | -1.0 | 0.0 | データ不足 (n=2 < 30) |
| RANGE | 49 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| UNKNOWN | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

- decayed_avg_r: 半減期90日の指数減衰加重平均R(直近の成績ほど重い)
- effective_n: 減衰後の実効サンプル数
- decay_divergence: True = 全期間平均と直近加重平均の符号が逆。レジームシフトの兆候として人間が確認すること

decay_divergenceは検出されていません。

## 7. ナラティブ信頼性 (SPEC-NQ-001)

| narrative_alignment | signals | closed | win_rate | total_r | average_r | decayed_avg_r | effective_n | decay_divergence | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| aligned | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| conflicted | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| neutral | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |
| insufficient_data | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | False | 0.0 | 0.0 | 0.0 | データ不足 (n=0 < 30) |

- 整合判定はシグナル発生時点に記録された値のみを使用(追記専用・後知恵バイアス防止)
- 重み変更提案はSPEC-SG-001と同一ゲート(n>=30, p<0.05, 増加はSharpe>0.5)に従う

ナラティブ優位性検定: データ不足 (aligned n=0, conflicted n=0, 必要数: 各30)。判定保留。

## 8. 翌月の暫定モード

- next_month_mode: 通常
- max_daily_risk_pct: 0.5

## 9. 重み変更案

変更提案なし

## 10. 据え置き理由

weights.jsonは初期値のまま据え置きます。今回の出力は提案のみで、自動更新は行いません。

## 11. データ不足の注意

closed評価が30件未満、または統計的有意性(p < 0.05)が確認できない区分には、重み変更を提案しません。weights.jsonの自動適用は引き続き行いません。(SPEC-SG-001)

## 12. Reason Code較正メモ

reason_code分析は未生成です。別artifact生成後に月次較正メモへ反映されます。

### strong_positive reason_codes

_該当なし_

### strong_negative reason_codes

_該当なし_

## 13. MONTHLY_CALIBRATION_LOG CSV

```csv
month_start,month_end,total_signals,closed_signals,pending_signals,skipped_signals,win_rate,profit_factor,total_r,average_r,max_win_r,max_loss_r,best_asset,worst_asset,best_rank,worst_rank,best_side,worst_side,next_month_mode,max_daily_risk_pct,weight_change_summary,rule_change_1,rule_change_2,rule_change_3,evaluation_source,latest_evaluations_available,fallback_used
2026-06-03,2026-07-02,212,6,70,5,0.3333,0.5435,-1.826,-0.3043,1.087,-1.0,GOLD,US10Y,A,B,SHORT,LONG,通常,0.5,変更提案なし,closed評価10件未満のため自動適用しない,Entry/SL/Rank判定の見直し,データ不足,latest_evaluations,True,False
```

## 14. MONTHLY_CALIBRATION_LOG JSON

```json
[
  {
    "month_start": "2026-06-03",
    "month_end": "2026-07-02",
    "total_signals": 212,
    "closed_signals": 6,
    "pending_signals": 70,
    "skipped_signals": 5,
    "win_rate": 0.3333,
    "profit_factor": 0.5435,
    "total_r": -1.826,
    "average_r": -0.3043,
    "max_win_r": 1.087,
    "max_loss_r": -1.0,
    "best_asset": "GOLD",
    "worst_asset": "US10Y",
    "best_rank": "A",
    "worst_rank": "B",
    "best_side": "SHORT",
    "worst_side": "LONG",
    "next_month_mode": "通常",
    "max_daily_risk_pct": 0.5,
    "weight_change_summary": "変更提案なし",
    "rule_change_1": "closed評価10件未満のため自動適用しない",
    "rule_change_2": "Entry/SL/Rank判定の見直し",
    "rule_change_3": "データ不足",
    "evaluation_source": "latest_evaluations",
    "latest_evaluations_available": true,
    "fallback_used": false,
    "asset_calibration": [
      {
        "asset": "BTC",
        "signals": 28,
        "closed": 1,
        "win_rate": 0.0,
        "total_r": -1.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 0.88,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "asset": "DXY",
        "signals": 24,
        "closed": 1,
        "win_rate": 0.0,
        "total_r": -1.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 0.93,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "asset": "GOLD",
        "signals": 25,
        "closed": 1,
        "win_rate": 1.0,
        "total_r": 1.087,
        "average_r": 1.087,
        "decayed_avg_r": 1.087,
        "effective_n": 0.93,
        "decay_divergence": false,
        "best_r": 1.087,
        "worst_r": 1.087,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "asset": "NASDAQ",
        "signals": 24,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "SPX",
        "signals": 24,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "US10Y",
        "signals": 20,
        "closed": 2,
        "win_rate": 0.0,
        "total_r": -2.0,
        "average_r": -1.0,
        "decayed_avg_r": -1.0,
        "effective_n": 1.92,
        "decay_divergence": false,
        "best_r": -1.0,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=2 < 30)"
      },
      {
        "asset": "USDJPY",
        "signals": 24,
        "closed": 1,
        "win_rate": 1.0,
        "total_r": 1.087,
        "average_r": 1.087,
        "decayed_avg_r": 1.087,
        "effective_n": 0.9,
        "decay_divergence": false,
        "best_r": 1.087,
        "worst_r": 1.087,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=1 < 30)"
      },
      {
        "asset": "VIX",
        "signals": 19,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "asset": "WTI",
        "signals": 24,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "rank_calibration": [
      {
        "rank": "A",
        "signals": 4,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "rank": "B",
        "signals": 76,
        "closed": 6,
        "win_rate": 0.3333,
        "total_r": -1.826,
        "average_r": -0.3043,
        "decayed_avg_r": -0.3127,
        "effective_n": 5.56,
        "decay_divergence": false,
        "best_r": 1.087,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=6 < 30)"
      },
      {
        "rank": "NO_TRADE",
        "signals": 132,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "side_calibration": [
      {
        "side": "LONG",
        "signals": 37,
        "closed": 4,
        "win_rate": 0.25,
        "total_r": -1.913,
        "average_r": -0.4783,
        "decayed_avg_r": -0.4963,
        "effective_n": 3.75,
        "decay_divergence": false,
        "best_r": 1.087,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=4 < 30)"
      },
      {
        "side": "SHORT",
        "signals": 43,
        "closed": 2,
        "win_rate": 0.5,
        "total_r": 0.087,
        "average_r": 0.0435,
        "decayed_avg_r": 0.0676,
        "effective_n": 1.81,
        "decay_divergence": false,
        "best_r": 1.087,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=2 < 30)"
      },
      {
        "side": "NONE",
        "signals": 132,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "regime_calibration": [
      {
        "regime": "UPTREND",
        "signals": 82,
        "closed": 4,
        "win_rate": 0.25,
        "total_r": -1.913,
        "average_r": -0.4783,
        "decayed_avg_r": -0.4963,
        "effective_n": 3.75,
        "decay_divergence": false,
        "best_r": 1.087,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=4 < 30)"
      },
      {
        "regime": "DOWNTREND",
        "signals": 80,
        "closed": 2,
        "win_rate": 0.5,
        "total_r": 0.087,
        "average_r": 0.0435,
        "decayed_avg_r": 0.0676,
        "effective_n": 1.81,
        "decay_divergence": false,
        "best_r": 1.087,
        "worst_r": -1.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=2 < 30)"
      },
      {
        "regime": "RANGE",
        "signals": 49,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "regime": "UNKNOWN",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "narrative_calibration": [
      {
        "narrative_alignment": "aligned",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "narrative_alignment": "conflicted",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "narrative_alignment": "neutral",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      },
      {
        "narrative_alignment": "insufficient_data",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "decayed_avg_r": 0.0,
        "effective_n": 0.0,
        "decay_divergence": false,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足 (n=0 < 30)"
      }
    ],
    "narrative_edge": {
      "aligned_n": 0,
      "conflicted_n": 0,
      "aligned_avg_r": 0.0,
      "conflicted_avg_r": 0.0,
      "mean_diff": 0.0,
      "t_stat": 0.0,
      "p_value": 1.0,
      "welch_df": 0.0,
      "verdict": "insufficient_data"
    },
    "decay_half_life_days": 90,
    "proposed_weight_changes": {
      "asset": [
        {
          "asset": "BTC",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=1 < 30)"
        },
        {
          "asset": "DXY",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=1 < 30)"
        },
        {
          "asset": "GOLD",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=1 < 30)"
        },
        {
          "asset": "NASDAQ",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "SPX",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "US10Y",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=2 < 30)"
        },
        {
          "asset": "USDJPY",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=1 < 30)"
        },
        {
          "asset": "VIX",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "asset": "WTI",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        }
      ],
      "rank": [
        {
          "rank": "A",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        },
        {
          "rank": "B",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=6 < 30)"
        },
        {
          "rank": "NO_TRADE",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        }
      ],
      "side": [
        {
          "side": "LONG",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=4 < 30)"
        },
        {
          "side": "SHORT",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=2 < 30)"
        },
        {
          "side": "NONE",
          "proposed_weight_change": 0.0,
          "reason": "データ不足 (n=0 < 30)"
        }
      ]
    }
  }
]
```
