# Tactical Swing OS Weekly Review

## 1. 週次結論

次週モードは「通常」、最大日次リスクは 0.5% です。 データ不足 週次R損益は横ばいです。

## 2. 週次サマリー

| week_start | week_end | total_signals | a_signals | b_signals | no_trade_signals | closed_signals | pending_signals | skipped_signals | win_rate | profit_factor | total_r | average_r | max_win_r | max_loss_r | best_asset | worst_asset | next_week_mode | max_daily_risk_pct | rule_change_1 | rule_change_2 | rule_change_3 | evaluation_source | latest_evaluations_available | fallback_used |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-26 | 2026-07-02 | 45 | 0 | 12 | 33 | 0 | 12 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | BTC | BTC | 通常 | 0.5 | 評価期間またはentry条件の見直し | データ不足 |  | latest_evaluations | True | False |

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 3. Rank別成績

| rank | signals | closed | win_rate | total_r | average_r |
| --- | --- | --- | --- | --- | --- |
| A | 0 | 0 | 0.0 | 0.0 | 0.0 |
| B | 12 | 0 | 0.0 | 0.0 | 0.0 |
| NO_TRADE | 33 | 0 | 0.0 | 0.0 | 0.0 |
| その他 | 0 | 0 | 0.0 | 0.0 | 0.0 |

## 4. 資産別成績

| asset | signals | closed | win_rate | total_r | average_r | best_r | worst_r |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BTC | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| DXY | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| GOLD | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| NASDAQ | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| SPX | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| US10Y | 4 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| USDJPY | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| VIX | 4 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| WTI | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |

## 5. Side別成績

| side | signals | closed | win_rate | total_r | average_r | best_r | worst_r |
| --- | --- | --- | --- | --- | --- | --- | --- |
| LONG | 3 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| SHORT | 9 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| NONE | 33 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |

## 6. エラー分類

| error_type | count |
| --- | --- |
| unresolved | 8 |
| no_entry | 2 |
| awaiting_horizon | 2 |

## 7. 取り逃し監査

| missed_candidate | asset | count | note |
| --- | --- | --- | --- |
| pending_or_skipped_ab | BTC | 4 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | GOLD | 1 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | NASDAQ | 1 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | SPX | 1 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | US10Y | 1 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | WTI | 4 | A/B候補の未完了評価が多い可能性 |
| large_mfe_review | BTC | 1 | MFE=2157.9567 のためentry/約定条件を確認 |
| large_mfe_review | WTI | 1 | MFE=2.7546 のためentry/約定条件を確認 |
| large_mfe_review | BTC | 1 | MFE=2282.5295 のためentry/約定条件を確認 |
| large_mfe_review | BTC | 1 | MFE=1042.7085 のためentry/約定条件を確認 |
| large_mfe_review | WTI | 1 | MFE=2.6508 のためentry/約定条件を確認 |
| large_mfe_review | GOLD | 1 | MFE=75.1878 のためentry/約定条件を確認 |
| large_mfe_review | BTC | 1 | MFE=685.1487 のためentry/約定条件を確認 |
| large_mfe_review | SPX | 1 | MFE=9.6005 のためentry/約定条件を確認 |
| large_mfe_review | WTI | 1 | MFE=2.3983 のためentry/約定条件を確認 |

## 8. モデル更新メモ

- 評価期間またはentry条件の見直し
- データ不足
- 特記事項なし

## 9. Reason Code分析メモ

reason code analysisは別artifact参照。現時点では分析結果が未生成です。

### reason_code 上位プラス3件

_該当なし_

### reason_code 上位マイナス3件

_該当なし_

### no_trade_reason 取り逃し候補

_該当なし_

## 10. REVIEW_LOG CSV

```csv
week_start,week_end,total_signals,a_signals,b_signals,no_trade_signals,closed_signals,pending_signals,skipped_signals,win_rate,profit_factor,total_r,average_r,max_win_r,max_loss_r,best_asset,worst_asset,next_week_mode,max_daily_risk_pct,rule_change_1,rule_change_2,rule_change_3,evaluation_source,latest_evaluations_available,fallback_used
2026-06-26,2026-07-02,45,0,12,33,0,12,0,0.0,0.0,0.0,0.0,0.0,0.0,BTC,BTC,通常,0.5,評価期間またはentry条件の見直し,データ不足,,latest_evaluations,True,False
```

## 11. REVIEW_LOG JSON

```json
[
  {
    "week_start":"2026-06-26",
    "week_end":"2026-07-02",
    "total_signals":45,
    "a_signals":0,
    "b_signals":12,
    "no_trade_signals":33,
    "closed_signals":0,
    "pending_signals":12,
    "skipped_signals":0,
    "win_rate":0.0,
    "profit_factor":0.0,
    "total_r":0.0,
    "average_r":0.0,
    "max_win_r":0.0,
    "max_loss_r":0.0,
    "best_asset":"BTC",
    "worst_asset":"BTC",
    "next_week_mode":"通常",
    "max_daily_risk_pct":0.5,
    "rule_change_1":"評価期間またはentry条件の見直し",
    "rule_change_2":"データ不足",
    "rule_change_3":"",
    "evaluation_source":"latest_evaluations",
    "latest_evaluations_available":true,
    "fallback_used":false
  }
]
```
