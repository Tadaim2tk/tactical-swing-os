# Tactical Swing OS Reason Code Analysis

## 1. 結論

reason_codesの有効性を集計しました。

対象期間: 2026-06-03 - 2026-07-02

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. reason_codes 上位プラス要因

_該当なし_

## 3. reason_codes 上位マイナス要因

| reason_code | signals_count | evaluated_count | win_count | loss_count | no_entry_count | missed_opportunity_count | win_rate | total_r | average_r | median_r | best_r | worst_r | average_mfe_r | average_mae_r | rank_a_count | rank_b_count | no_trade_count | recommended_action_trade_count | recommended_action_watch_count | recommended_action_no_trade_count | reliability_label |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| range_middle | 34 | 6 | 0 | 1 | 0 | 0 | 0.0 | -2.1289 | -0.4258 | -0.303 | -0.1082 | -1.0 | 0.1927 | -0.8023 | 0 | 6 | 28 | 0 | 6 | 28 | strong_negative |
| pullback_to_ma20 | 37 | 12 | 0 | 1 | 0 | 0 | 0.0 | -1.3394 | -0.1218 | 0.0468 | 0.0703 | -1.0 | 0.2719 | -0.6237 | 1 | 11 | 25 | 1 | 11 | 25 | negative |

## 4. no_trade_reason 分析

| no_trade_reason | count | no_trade_correct_count | no_trade_missed_count | missed_opportunity_count | average_mfe_r | average_r | assessment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rr_too_low | 93 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |
| low_volatility | 28 | 0 | 0 | 0 | 0.0 | 0.0 | neutral |
| data_insufficient | 1 | 0 | 0 | 0 | 0.0 | 0.0 | insufficient_data |

## 5. 取り逃し候補

_該当なし_

## 6. 改善候補

| reason_code | signals_count | evaluated_count | win_count | loss_count | no_entry_count | missed_opportunity_count | win_rate | total_r | average_r | median_r | best_r | worst_r | average_mfe_r | average_mae_r | rank_a_count | rank_b_count | no_trade_count | recommended_action_trade_count | recommended_action_watch_count | recommended_action_no_trade_count | reliability_label |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| pullback_to_ma20 | 37 | 12 | 0 | 1 | 0 | 0 | 0.0 | -1.3394 | -0.1218 | 0.0468 | 0.0703 | -1.0 | 0.2719 | -0.6237 | 1 | 11 | 25 | 1 | 11 | 25 | negative |
| range_middle | 34 | 6 | 0 | 1 | 0 | 0 | 0.0 | -2.1289 | -0.4258 | -0.303 | -0.1082 | -1.0 | 0.1927 | -0.8023 | 0 | 6 | 28 | 0 | 6 | 28 | strong_negative |

## 7. データ不足の注意

reason_codeごとの評価件数が5件未満の場合は `insufficient_data` とし、weights.jsonは自動更新しません。

## 8. REASON_CODE_ANALYSIS CSV

```csv
reason_code,signals_count,evaluated_count,win_count,loss_count,no_entry_count,missed_opportunity_count,win_rate,total_r,average_r,median_r,best_r,worst_r,average_mfe_r,average_mae_r,rank_a_count,rank_b_count,no_trade_count,recommended_action_trade_count,recommended_action_watch_count,recommended_action_no_trade_count,reliability_label
breakout_up,11,6,0,0,0,0,0.0,1.6078,0.268,0.2614,0.6552,-0.042,0.4161,-0.1078,1,5,5,1,5,5,neutral
breakout_down,16,12,0,0,1,0,0.0,2.7859,0.2533,0.2495,0.7216,-0.0416,0.3804,-0.0794,0,12,4,0,12,4,neutral
rsi_overbought,31,5,0,0,0,0,0.0,1.164,0.2328,0.2078,0.6552,-0.042,0.4051,-0.0717,1,4,26,1,4,26,neutral
ma_alignment_bear,73,40,0,0,3,0,0.0,6.9598,0.1785,0.0969,0.9097,-0.2554,0.3308,-0.1493,3,37,33,3,37,33,neutral
trend_down,73,40,0,0,3,0,0.0,6.9598,0.1785,0.0969,0.9097,-0.2554,0.3308,-0.1493,3,37,33,3,37,33,neutral
overextended,30,18,0,0,0,0,0.0,3.2122,0.1785,0.1632,0.7216,-0.2554,0.2411,-0.1821,2,16,12,2,16,12,neutral
momentum_negative,102,43,0,1,4,0,0.0,5.7329,0.1398,0.0859,0.9097,-1.0,0.3096,-0.1664,2,41,59,2,41,59,neutral
atr_too_low,29,1,0,0,0,0,0.0,0.1296,0.1296,0.1296,0.1296,0.1296,0.455,-0.1366,1,0,28,1,0,28,insufficient_data
rsi_oversold,27,16,0,0,1,0,0.0,1.4887,0.0992,0.0678,0.9097,-0.2554,0.1991,-0.1368,0,16,11,0,16,11,neutral
rr_too_low,121,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,121,0,0,121,insufficient_data
data_insufficient,1,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,1,0,0,1,insufficient_data
momentum_positive,81,25,0,0,0,0,0.0,-0.2638,-0.0106,-0.0415,0.6552,-0.5421,0.2739,-0.4578,1,24,56,1,24,56,neutral
ma_alignment_bull,76,31,0,1,1,0,0.0,-1.5712,-0.0524,-0.0418,0.6552,-1.0,0.2389,-0.4723,1,30,45,1,30,45,neutral
trend_up,76,31,0,1,1,0,0.0,-1.5712,-0.0524,-0.0418,0.6552,-1.0,0.2389,-0.4723,1,30,45,1,30,45,neutral
atr_too_high,30,15,0,0,1,0,0.0,-1.0689,-0.0713,-0.0506,0.0533,-0.2169,0.1933,-0.5248,0,15,15,0,15,15,neutral
pullback_to_ma20,37,12,0,1,0,0,0.0,-1.3394,-0.1218,0.0468,0.0703,-1.0,0.2719,-0.6237,1,11,25,1,11,25,negative
risk_penalty_high,1,1,0,0,0,0,0.0,-0.2554,-0.2554,-0.2554,-0.2554,-0.2554,0.0295,-0.3517,0,1,0,0,1,0,insufficient_data
range_middle,34,6,0,1,0,0,0.0,-2.1289,-0.4258,-0.303,-0.1082,-1.0,0.1927,-0.8023,0,6,28,0,6,28,strong_negative
```

## 9. REASON_CODE_ANALYSIS JSON

```json
{
  "start_date": "2026-06-03",
  "end_date": "2026-07-02",
  "reason_code_summary": [
    {
      "reason_code": "breakout_up",
      "signals_count": 11,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 1.6078,
      "average_r": 0.268,
      "median_r": 0.2614,
      "best_r": 0.6552,
      "worst_r": -0.042,
      "average_mfe_r": 0.4161,
      "average_mae_r": -0.1078,
      "rank_a_count": 1,
      "rank_b_count": 5,
      "no_trade_count": 5,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 5,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "breakout_down",
      "signals_count": 16,
      "evaluated_count": 12,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 2.7859,
      "average_r": 0.2533,
      "median_r": 0.2495,
      "best_r": 0.7216,
      "worst_r": -0.0416,
      "average_mfe_r": 0.3804,
      "average_mae_r": -0.0794,
      "rank_a_count": 0,
      "rank_b_count": 12,
      "no_trade_count": 4,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 12,
      "recommended_action_no_trade_count": 4,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rsi_overbought",
      "signals_count": 31,
      "evaluated_count": 5,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 1.164,
      "average_r": 0.2328,
      "median_r": 0.2078,
      "best_r": 0.6552,
      "worst_r": -0.042,
      "average_mfe_r": 0.4051,
      "average_mae_r": -0.0717,
      "rank_a_count": 1,
      "rank_b_count": 4,
      "no_trade_count": 26,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 4,
      "recommended_action_no_trade_count": 26,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "ma_alignment_bear",
      "signals_count": 73,
      "evaluated_count": 40,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 3,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 6.9598,
      "average_r": 0.1785,
      "median_r": 0.0969,
      "best_r": 0.9097,
      "worst_r": -0.2554,
      "average_mfe_r": 0.3308,
      "average_mae_r": -0.1493,
      "rank_a_count": 3,
      "rank_b_count": 37,
      "no_trade_count": 33,
      "recommended_action_trade_count": 3,
      "recommended_action_watch_count": 37,
      "recommended_action_no_trade_count": 33,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_down",
      "signals_count": 73,
      "evaluated_count": 40,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 3,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 6.9598,
      "average_r": 0.1785,
      "median_r": 0.0969,
      "best_r": 0.9097,
      "worst_r": -0.2554,
      "average_mfe_r": 0.3308,
      "average_mae_r": -0.1493,
      "rank_a_count": 3,
      "rank_b_count": 37,
      "no_trade_count": 33,
      "recommended_action_trade_count": 3,
      "recommended_action_watch_count": 37,
      "recommended_action_no_trade_count": 33,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "overextended",
      "signals_count": 30,
      "evaluated_count": 18,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 3.2122,
      "average_r": 0.1785,
      "median_r": 0.1632,
      "best_r": 0.7216,
      "worst_r": -0.2554,
      "average_mfe_r": 0.2411,
      "average_mae_r": -0.1821,
      "rank_a_count": 2,
      "rank_b_count": 16,
      "no_trade_count": 12,
      "recommended_action_trade_count": 2,
      "recommended_action_watch_count": 16,
      "recommended_action_no_trade_count": 12,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "momentum_negative",
      "signals_count": 102,
      "evaluated_count": 43,
      "win_count": 0,
      "loss_count": 1,
      "no_entry_count": 4,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 5.7329,
      "average_r": 0.1398,
      "median_r": 0.0859,
      "best_r": 0.9097,
      "worst_r": -1.0,
      "average_mfe_r": 0.3096,
      "average_mae_r": -0.1664,
      "rank_a_count": 2,
      "rank_b_count": 41,
      "no_trade_count": 59,
      "recommended_action_trade_count": 2,
      "recommended_action_watch_count": 41,
      "recommended_action_no_trade_count": 59,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "atr_too_low",
      "signals_count": 29,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.1296,
      "average_r": 0.1296,
      "median_r": 0.1296,
      "best_r": 0.1296,
      "worst_r": 0.1296,
      "average_mfe_r": 0.455,
      "average_mae_r": -0.1366,
      "rank_a_count": 1,
      "rank_b_count": 0,
      "no_trade_count": 28,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 28,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "rsi_oversold",
      "signals_count": 27,
      "evaluated_count": 16,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 1.4887,
      "average_r": 0.0992,
      "median_r": 0.0678,
      "best_r": 0.9097,
      "worst_r": -0.2554,
      "average_mfe_r": 0.1991,
      "average_mae_r": -0.1368,
      "rank_a_count": 0,
      "rank_b_count": 16,
      "no_trade_count": 11,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 16,
      "recommended_action_no_trade_count": 11,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "rr_too_low",
      "signals_count": 121,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 121,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 121,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "data_insufficient",
      "signals_count": 1,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 1,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 1,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "momentum_positive",
      "signals_count": 81,
      "evaluated_count": 25,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.2638,
      "average_r": -0.0106,
      "median_r": -0.0415,
      "best_r": 0.6552,
      "worst_r": -0.5421,
      "average_mfe_r": 0.2739,
      "average_mae_r": -0.4578,
      "rank_a_count": 1,
      "rank_b_count": 24,
      "no_trade_count": 56,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 24,
      "recommended_action_no_trade_count": 56,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 76,
      "evaluated_count": 31,
      "win_count": 0,
      "loss_count": 1,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.5712,
      "average_r": -0.0524,
      "median_r": -0.0418,
      "best_r": 0.6552,
      "worst_r": -1.0,
      "average_mfe_r": 0.2389,
      "average_mae_r": -0.4723,
      "rank_a_count": 1,
      "rank_b_count": 30,
      "no_trade_count": 45,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 30,
      "recommended_action_no_trade_count": 45,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 76,
      "evaluated_count": 31,
      "win_count": 0,
      "loss_count": 1,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.5712,
      "average_r": -0.0524,
      "median_r": -0.0418,
      "best_r": 0.6552,
      "worst_r": -1.0,
      "average_mfe_r": 0.2389,
      "average_mae_r": -0.4723,
      "rank_a_count": 1,
      "rank_b_count": 30,
      "no_trade_count": 45,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 30,
      "recommended_action_no_trade_count": 45,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "atr_too_high",
      "signals_count": 30,
      "evaluated_count": 15,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.0689,
      "average_r": -0.0713,
      "median_r": -0.0506,
      "best_r": 0.0533,
      "worst_r": -0.2169,
      "average_mfe_r": 0.1933,
      "average_mae_r": -0.5248,
      "rank_a_count": 0,
      "rank_b_count": 15,
      "no_trade_count": 15,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 15,
      "recommended_action_no_trade_count": 15,
      "reliability_label": "neutral"
    },
    {
      "reason_code": "pullback_to_ma20",
      "signals_count": 37,
      "evaluated_count": 12,
      "win_count": 0,
      "loss_count": 1,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.3394,
      "average_r": -0.1218,
      "median_r": 0.0468,
      "best_r": 0.0703,
      "worst_r": -1.0,
      "average_mfe_r": 0.2719,
      "average_mae_r": -0.6237,
      "rank_a_count": 1,
      "rank_b_count": 11,
      "no_trade_count": 25,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 11,
      "recommended_action_no_trade_count": 25,
      "reliability_label": "negative"
    },
    {
      "reason_code": "risk_penalty_high",
      "signals_count": 1,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -0.2554,
      "average_r": -0.2554,
      "median_r": -0.2554,
      "best_r": -0.2554,
      "worst_r": -0.2554,
      "average_mfe_r": 0.0295,
      "average_mae_r": -0.3517,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "range_middle",
      "signals_count": 34,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 1,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -2.1289,
      "average_r": -0.4258,
      "median_r": -0.303,
      "best_r": -0.1082,
      "worst_r": -1.0,
      "average_mfe_r": 0.1927,
      "average_mae_r": -0.8023,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 28,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 28,
      "reliability_label": "strong_negative"
    }
  ],
  "no_trade_reason_summary": [
    {
      "no_trade_reason": "rr_too_low",
      "count": 93,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    },
    {
      "no_trade_reason": "low_volatility",
      "count": 28,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "neutral"
    },
    {
      "no_trade_reason": "data_insufficient",
      "count": 1,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "insufficient_data"
    }
  ],
  "top_positive_reasons": [],
  "top_negative_reasons": [
    {
      "reason_code": "range_middle",
      "signals_count": 34,
      "evaluated_count": 6,
      "win_count": 0,
      "loss_count": 1,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -2.1289,
      "average_r": -0.4258,
      "median_r": -0.303,
      "best_r": -0.1082,
      "worst_r": -1.0,
      "average_mfe_r": 0.1927,
      "average_mae_r": -0.8023,
      "rank_a_count": 0,
      "rank_b_count": 6,
      "no_trade_count": 28,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 6,
      "recommended_action_no_trade_count": 28,
      "reliability_label": "strong_negative"
    },
    {
      "reason_code": "pullback_to_ma20",
      "signals_count": 37,
      "evaluated_count": 12,
      "win_count": 0,
      "loss_count": 1,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": -1.3394,
      "average_r": -0.1218,
      "median_r": 0.0468,
      "best_r": 0.0703,
      "worst_r": -1.0,
      "average_mfe_r": 0.2719,
      "average_mae_r": -0.6237,
      "rank_a_count": 1,
      "rank_b_count": 11,
      "no_trade_count": 25,
      "recommended_action_trade_count": 1,
      "recommended_action_watch_count": 11,
      "recommended_action_no_trade_count": 25,
      "reliability_label": "negative"
    }
  ],
  "over_filtering_candidates": [],
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 81,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "notes": [
    "reason_code単位のweights自動更新はまだ行いません。",
    "insufficient_data reason_codes: 4"
  ]
}
```
