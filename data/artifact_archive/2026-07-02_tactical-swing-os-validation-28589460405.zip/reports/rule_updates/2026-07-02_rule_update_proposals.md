# Tactical Swing OS Rule Update Proposals

## 1. 結論

ルール改善候補を生成しました。自動反映は行いません。

対象期間: 2026-06-03 - 2026-07-02

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. 高優先度の改善候補

_該当なし_

## 3. reason_codeを強める候補

_該当なし_

## 4. reason_codeを弱める候補

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_reason_code_range_middle_weaken_reason_code | weaken_reason_code | reason_code | range_middle | MEDIUM | 6 | 0.0 | -0.4258 | -2.1289 | 0 | range_middle は負の期待値 | risk_penalty_scoreを +3〜+8、またはrankを一段階下げる条件を検討 | 低期待値シグナルの抑制 | 相場環境依存の可能性あり | False | 2 | strong_negative |

## 5. no_trade_reasonの見直し候補

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_no_trade_reason_data_insufficient_data_insufficient | data_insufficient | no_trade_reason | data_insufficient | DATA_INSUFFICIENT | 1 | 0.0 | 0.0 | 0.0 | 0 | data_insufficient: correct=0, missed=0, avg_mfe_r=0.00 | 見送り理由の件数が少ないため監視継続 | 誤ったフィルター調整を避ける | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | insufficient_data |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_no_trade_reason_low_volatility_data_insufficient | data_insufficient | no_trade_reason | low_volatility | DATA_INSUFFICIENT | 28 | 0.0 | 0.0 | 0.0 | 0 | low_volatility: correct=0, missed=0, avg_mfe_r=0.00 | 追加データを待つ | 判断保留 | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | neutral |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_no_trade_reason_rr_too_low_data_insufficient | data_insufficient | no_trade_reason | rr_too_low | DATA_INSUFFICIENT | 93 | 0.0 | 0.0 | 0.0 | 0 | rr_too_low: correct=0, missed=0, avg_mfe_r=0.00 | 追加データを待つ | 判断保留 | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | neutral |

## 6. asset / side / rank の見直し候補

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_asset_GOLD_increase_asset_weight | increase_asset_weight | asset | GOLD | MEDIUM | 13 | 0.1538 | 0.3687 | 4.7935 | 0 | asset=GOLD avg_r=0.3687 | asset=GOLD の条件をやや優遇する候補 | 高期待値カテゴリの活用 | カテゴリ単位の調整は相場環境依存に注意 | False | 2 | group performance review |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_asset_WTI_increase_asset_weight | increase_asset_weight | asset | WTI | MEDIUM | 16 | 0.0 | 0.2953 | 4.4294 | 0 | asset=WTI avg_r=0.2953 | asset=WTI の条件をやや優遇する候補 | 高期待値カテゴリの活用 | カテゴリ単位の調整は相場環境依存に注意 | False | 2 | group performance review |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_asset_US10Y_reduce_asset_weight | reduce_asset_weight | asset | US10Y | MEDIUM | 7 | 0.0 | -0.5978 | -3.5868 | 0 | asset=US10Y avg_r=-0.5978 | asset=US10Y の条件を抑制または閾値見直し | 低期待値カテゴリの抑制 | カテゴリ単位の調整は相場環境依存に注意 | False | 2 | group performance review |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_asset_USDJPY_data_insufficient | data_insufficient | asset | USDJPY | DATA_INSUFFICIENT | 2 | 1.0 | 1.087 | 2.174 | 0 | asset=USDJPY avg_r=1.0870 | 評価件数不足のため監視継続 | 過剰調整を避ける | カテゴリ単位の調整は相場環境依存に注意 | False | 4 | group performance review |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_rank_A_data_insufficient | data_insufficient | rank | A | DATA_INSUFFICIENT | 4 | 0.0 | 0.1978 | 0.7911 | 0 | rank=A avg_r=0.1978 | 評価件数不足のため監視継続 | 過剰調整を避ける | カテゴリ単位の調整は相場環境依存に注意 | False | 4 | group performance review |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_rank_NO_TRADE_data_insufficient | data_insufficient | rank | NO_TRADE | DATA_INSUFFICIENT | 0 | 0.0 | 0.0 | 0.0 | 0 | rank=NO_TRADE avg_r=0.0000 | 評価件数不足のため監視継続 | 過剰調整を避ける | カテゴリ単位の調整は相場環境依存に注意 | False | 4 | group performance review |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_side_NONE_data_insufficient | data_insufficient | side | NONE | DATA_INSUFFICIENT | 0 | 0.0 | 0.0 | 0.0 | 0 | side=NONE avg_r=0.0000 | 評価件数不足のため監視継続 | 過剰調整を避ける | カテゴリ単位の調整は相場環境依存に注意 | False | 4 | group performance review |

## 7. データ不足の項目

| generated_at | period_start | period_end | proposal_id | proposal_type | target_type | target_name | proposal_strength | evidence_count | win_rate | average_r | total_r | missed_opportunity_count | current_behavior | proposed_change | expected_effect | risk_note | apply_automatically | priority | notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_asset_USDJPY_data_insufficient | data_insufficient | asset | USDJPY | DATA_INSUFFICIENT | 2 | 1.0 | 1.087 | 2.174 | 0 | asset=USDJPY avg_r=1.0870 | 評価件数不足のため監視継続 | 過剰調整を避ける | カテゴリ単位の調整は相場環境依存に注意 | False | 4 | group performance review |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_no_trade_reason_data_insufficient_data_insufficient | data_insufficient | no_trade_reason | data_insufficient | DATA_INSUFFICIENT | 1 | 0.0 | 0.0 | 0.0 | 0 | data_insufficient: correct=0, missed=0, avg_mfe_r=0.00 | 見送り理由の件数が少ないため監視継続 | 誤ったフィルター調整を避ける | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | insufficient_data |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_no_trade_reason_low_volatility_data_insufficient | data_insufficient | no_trade_reason | low_volatility | DATA_INSUFFICIENT | 28 | 0.0 | 0.0 | 0.0 | 0 | low_volatility: correct=0, missed=0, avg_mfe_r=0.00 | 追加データを待つ | 判断保留 | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | neutral |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_no_trade_reason_rr_too_low_data_insufficient | data_insufficient | no_trade_reason | rr_too_low | DATA_INSUFFICIENT | 93 | 0.0 | 0.0 | 0.0 | 0 | rr_too_low: correct=0, missed=0, avg_mfe_r=0.00 | 追加データを待つ | 判断保留 | NO_TRADE緩和はノイズ取引増加に注意 | False | 4 | neutral |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_rank_A_data_insufficient | data_insufficient | rank | A | DATA_INSUFFICIENT | 4 | 0.0 | 0.1978 | 0.7911 | 0 | rank=A avg_r=0.1978 | 評価件数不足のため監視継続 | 過剰調整を避ける | カテゴリ単位の調整は相場環境依存に注意 | False | 4 | group performance review |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_rank_NO_TRADE_data_insufficient | data_insufficient | rank | NO_TRADE | DATA_INSUFFICIENT | 0 | 0.0 | 0.0 | 0.0 | 0 | rank=NO_TRADE avg_r=0.0000 | 評価件数不足のため監視継続 | 過剰調整を避ける | カテゴリ単位の調整は相場環境依存に注意 | False | 4 | group performance review |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_reason_code_atr_too_low_data_insufficient | data_insufficient | reason_code | atr_too_low | DATA_INSUFFICIENT | 1 | 0.0 | 0.1296 | 0.1296 | 0 | atr_too_low は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_reason_code_data_insufficient_data_insufficient | data_insufficient | reason_code | data_insufficient | DATA_INSUFFICIENT | 0 | 0.0 | 0.0 | 0.0 | 0 | data_insufficient は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_reason_code_risk_penalty_high_data_insufficient | data_insufficient | reason_code | risk_penalty_high | DATA_INSUFFICIENT | 1 | 0.0 | -0.2554 | -0.2554 | 0 | risk_penalty_high は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_reason_code_rr_too_low_data_insufficient | data_insufficient | reason_code | rr_too_low | DATA_INSUFFICIENT | 0 | 0.0 | 0.0 | 0.0 | 0 | rr_too_low は評価件数不足 | 自動変更せず監視継続 | 誤ったルール変更を避ける | 評価件数5件未満 | False | 4 | insufficient_data |
| 2026-07-02T12:20:21 | 2026-06-03 | 2026-07-02 | 20260702_side_NONE_data_insufficient | data_insufficient | side | NONE | DATA_INSUFFICIENT | 0 | 0.0 | 0.0 | 0.0 | 0 | side=NONE avg_r=0.0000 | 評価件数不足のため監視継続 | 過剰調整を避ける | カテゴリ単位の調整は相場環境依存に注意 | False | 4 | group performance review |

## 8. 自動反映しない理由

- 実売買には使わない
- weights.jsonは自動更新しない
- generate_signal.pyは自動変更しない
- closed評価が30〜50件以上溜まるまでは提案のみ

## 9. 次に人間が確認すべき点

- HIGH / MEDIUM の提案が特定assetやsideに偏っていないか
- no_trade_reason緩和で低品質シグナルが増えないか
- reason_codeの成績が一時的な相場環境に依存していないか

## 10. RULE_UPDATE_PROPOSALS CSV

```csv
generated_at,period_start,period_end,proposal_id,proposal_type,target_type,target_name,proposal_strength,evidence_count,win_rate,average_r,total_r,missed_opportunity_count,current_behavior,proposed_change,expected_effect,risk_note,apply_automatically,priority,notes
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_asset_GOLD_increase_asset_weight,increase_asset_weight,asset,GOLD,MEDIUM,13,0.1538,0.3687,4.7935,0,asset=GOLD avg_r=0.3687,asset=GOLD の条件をやや優遇する候補,高期待値カテゴリの活用,カテゴリ単位の調整は相場環境依存に注意,False,2,group performance review
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_asset_WTI_increase_asset_weight,increase_asset_weight,asset,WTI,MEDIUM,16,0.0,0.2953,4.4294,0,asset=WTI avg_r=0.2953,asset=WTI の条件をやや優遇する候補,高期待値カテゴリの活用,カテゴリ単位の調整は相場環境依存に注意,False,2,group performance review
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_breakout_down_monitor_reason_code,monitor_reason_code,reason_code,breakout_down,MEDIUM,12,0.0,0.2533,2.7859,0,breakout_down は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,2,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_breakout_up_monitor_reason_code,monitor_reason_code,reason_code,breakout_up,MEDIUM,6,0.0,0.268,1.6078,0,breakout_up は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,2,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_rsi_overbought_monitor_reason_code,monitor_reason_code,reason_code,rsi_overbought,MEDIUM,5,0.0,0.2328,1.164,0,rsi_overbought は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,2,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_asset_US10Y_reduce_asset_weight,reduce_asset_weight,asset,US10Y,MEDIUM,7,0.0,-0.5978,-3.5868,0,asset=US10Y avg_r=-0.5978,asset=US10Y の条件を抑制または閾値見直し,低期待値カテゴリの抑制,カテゴリ単位の調整は相場環境依存に注意,False,2,group performance review
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_range_middle_weaken_reason_code,weaken_reason_code,reason_code,range_middle,MEDIUM,6,0.0,-0.4258,-2.1289,0,range_middle は負の期待値,risk_penalty_scoreを +3〜+8、またはrankを一段階下げる条件を検討,低期待値シグナルの抑制,相場環境依存の可能性あり,False,2,strong_negative
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_atr_too_high_monitor_reason_code,monitor_reason_code,reason_code,atr_too_high,LOW,15,0.0,-0.0713,-1.0689,0,atr_too_high は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_ma_alignment_bear_monitor_reason_code,monitor_reason_code,reason_code,ma_alignment_bear,LOW,40,0.0,0.1785,6.9598,0,ma_alignment_bear は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_ma_alignment_bull_monitor_reason_code,monitor_reason_code,reason_code,ma_alignment_bull,LOW,31,0.0,-0.0524,-1.5712,0,ma_alignment_bull は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_momentum_negative_monitor_reason_code,monitor_reason_code,reason_code,momentum_negative,LOW,43,0.0,0.1398,5.7329,0,momentum_negative は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_momentum_positive_monitor_reason_code,monitor_reason_code,reason_code,momentum_positive,LOW,25,0.0,-0.0106,-0.2638,0,momentum_positive は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_overextended_monitor_reason_code,monitor_reason_code,reason_code,overextended,LOW,18,0.0,0.1785,3.2122,0,overextended は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_pullback_to_ma20_monitor_reason_code,monitor_reason_code,reason_code,pullback_to_ma20,LOW,12,0.0,-0.1218,-1.3394,0,pullback_to_ma20 は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,negative
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_rsi_oversold_monitor_reason_code,monitor_reason_code,reason_code,rsi_oversold,LOW,16,0.0,0.0992,1.4887,0,rsi_oversold は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_trend_down_monitor_reason_code,monitor_reason_code,reason_code,trend_down,LOW,40,0.0,0.1785,6.9598,0,trend_down は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_trend_up_monitor_reason_code,monitor_reason_code,reason_code,trend_up,LOW,31,0.0,-0.0524,-1.5712,0,trend_up は中立,変更せず監視継続,安定性を確認,明確な改善根拠なし,False,3,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_asset_USDJPY_data_insufficient,data_insufficient,asset,USDJPY,DATA_INSUFFICIENT,2,1.0,1.087,2.174,0,asset=USDJPY avg_r=1.0870,評価件数不足のため監視継続,過剰調整を避ける,カテゴリ単位の調整は相場環境依存に注意,False,4,group performance review
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_no_trade_reason_data_insufficient_data_insufficient,data_insufficient,no_trade_reason,data_insufficient,DATA_INSUFFICIENT,1,0.0,0.0,0.0,0,"data_insufficient: correct=0, missed=0, avg_mfe_r=0.00",見送り理由の件数が少ないため監視継続,誤ったフィルター調整を避ける,NO_TRADE緩和はノイズ取引増加に注意,False,4,insufficient_data
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_no_trade_reason_low_volatility_data_insufficient,data_insufficient,no_trade_reason,low_volatility,DATA_INSUFFICIENT,28,0.0,0.0,0.0,0,"low_volatility: correct=0, missed=0, avg_mfe_r=0.00",追加データを待つ,判断保留,NO_TRADE緩和はノイズ取引増加に注意,False,4,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_no_trade_reason_rr_too_low_data_insufficient,data_insufficient,no_trade_reason,rr_too_low,DATA_INSUFFICIENT,93,0.0,0.0,0.0,0,"rr_too_low: correct=0, missed=0, avg_mfe_r=0.00",追加データを待つ,判断保留,NO_TRADE緩和はノイズ取引増加に注意,False,4,neutral
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_rank_A_data_insufficient,data_insufficient,rank,A,DATA_INSUFFICIENT,4,0.0,0.1978,0.7911,0,rank=A avg_r=0.1978,評価件数不足のため監視継続,過剰調整を避ける,カテゴリ単位の調整は相場環境依存に注意,False,4,group performance review
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_rank_NO_TRADE_data_insufficient,data_insufficient,rank,NO_TRADE,DATA_INSUFFICIENT,0,0.0,0.0,0.0,0,rank=NO_TRADE avg_r=0.0000,評価件数不足のため監視継続,過剰調整を避ける,カテゴリ単位の調整は相場環境依存に注意,False,4,group performance review
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_atr_too_low_data_insufficient,data_insufficient,reason_code,atr_too_low,DATA_INSUFFICIENT,1,0.0,0.1296,0.1296,0,atr_too_low は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_data_insufficient_data_insufficient,data_insufficient,reason_code,data_insufficient,DATA_INSUFFICIENT,0,0.0,0.0,0.0,0,data_insufficient は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_risk_penalty_high_data_insufficient,data_insufficient,reason_code,risk_penalty_high,DATA_INSUFFICIENT,1,0.0,-0.2554,-0.2554,0,risk_penalty_high は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_reason_code_rr_too_low_data_insufficient,data_insufficient,reason_code,rr_too_low,DATA_INSUFFICIENT,0,0.0,0.0,0.0,0,rr_too_low は評価件数不足,自動変更せず監視継続,誤ったルール変更を避ける,評価件数5件未満,False,4,insufficient_data
2026-07-02T12:20:21,2026-06-03,2026-07-02,20260702_side_NONE_data_insufficient,data_insufficient,side,NONE,DATA_INSUFFICIENT,0,0.0,0.0,0.0,0,side=NONE avg_r=0.0000,評価件数不足のため監視継続,過剰調整を避ける,カテゴリ単位の調整は相場環境依存に注意,False,4,group performance review
```

## 11. RULE_UPDATE_PROPOSALS JSON

```json
{
  "generated_at": "2026-07-02T12:20:21",
  "period_start": "2026-06-03",
  "period_end": "2026-07-02",
  "summary": {
    "proposal_count": 28,
    "high_priority_count": 0,
    "data_insufficient_count": 11,
    "apply_automatically": false
  },
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 81,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "proposals": [
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_asset_GOLD_increase_asset_weight",
      "proposal_type": "increase_asset_weight",
      "target_type": "asset",
      "target_name": "GOLD",
      "proposal_strength": "MEDIUM",
      "evidence_count": 13,
      "win_rate": 0.1538,
      "average_r": 0.3687,
      "total_r": 4.7935,
      "missed_opportunity_count": 0,
      "current_behavior": "asset=GOLD avg_r=0.3687",
      "proposed_change": "asset=GOLD の条件をやや優遇する候補",
      "expected_effect": "高期待値カテゴリの活用",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 2,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_asset_WTI_increase_asset_weight",
      "proposal_type": "increase_asset_weight",
      "target_type": "asset",
      "target_name": "WTI",
      "proposal_strength": "MEDIUM",
      "evidence_count": 16,
      "win_rate": 0.0,
      "average_r": 0.2953,
      "total_r": 4.4294,
      "missed_opportunity_count": 0,
      "current_behavior": "asset=WTI avg_r=0.2953",
      "proposed_change": "asset=WTI の条件をやや優遇する候補",
      "expected_effect": "高期待値カテゴリの活用",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 2,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_breakout_down_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "breakout_down",
      "proposal_strength": "MEDIUM",
      "evidence_count": 12,
      "win_rate": 0.0,
      "average_r": 0.2533,
      "total_r": 2.7859,
      "missed_opportunity_count": 0,
      "current_behavior": "breakout_down は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 2,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_breakout_up_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "breakout_up",
      "proposal_strength": "MEDIUM",
      "evidence_count": 6,
      "win_rate": 0.0,
      "average_r": 0.268,
      "total_r": 1.6078,
      "missed_opportunity_count": 0,
      "current_behavior": "breakout_up は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 2,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_rsi_overbought_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "rsi_overbought",
      "proposal_strength": "MEDIUM",
      "evidence_count": 5,
      "win_rate": 0.0,
      "average_r": 0.2328,
      "total_r": 1.164,
      "missed_opportunity_count": 0,
      "current_behavior": "rsi_overbought は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 2,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_asset_US10Y_reduce_asset_weight",
      "proposal_type": "reduce_asset_weight",
      "target_type": "asset",
      "target_name": "US10Y",
      "proposal_strength": "MEDIUM",
      "evidence_count": 7,
      "win_rate": 0.0,
      "average_r": -0.5978,
      "total_r": -3.5868,
      "missed_opportunity_count": 0,
      "current_behavior": "asset=US10Y avg_r=-0.5978",
      "proposed_change": "asset=US10Y の条件を抑制または閾値見直し",
      "expected_effect": "低期待値カテゴリの抑制",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 2,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_range_middle_weaken_reason_code",
      "proposal_type": "weaken_reason_code",
      "target_type": "reason_code",
      "target_name": "range_middle",
      "proposal_strength": "MEDIUM",
      "evidence_count": 6,
      "win_rate": 0.0,
      "average_r": -0.4258,
      "total_r": -2.1289,
      "missed_opportunity_count": 0,
      "current_behavior": "range_middle は負の期待値",
      "proposed_change": "risk_penalty_scoreを +3〜+8、またはrankを一段階下げる条件を検討",
      "expected_effect": "低期待値シグナルの抑制",
      "risk_note": "相場環境依存の可能性あり",
      "apply_automatically": false,
      "priority": 2,
      "notes": "strong_negative"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_atr_too_high_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "atr_too_high",
      "proposal_strength": "LOW",
      "evidence_count": 15,
      "win_rate": 0.0,
      "average_r": -0.0713,
      "total_r": -1.0689,
      "missed_opportunity_count": 0,
      "current_behavior": "atr_too_high は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_ma_alignment_bear_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "ma_alignment_bear",
      "proposal_strength": "LOW",
      "evidence_count": 40,
      "win_rate": 0.0,
      "average_r": 0.1785,
      "total_r": 6.9598,
      "missed_opportunity_count": 0,
      "current_behavior": "ma_alignment_bear は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_ma_alignment_bull_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "ma_alignment_bull",
      "proposal_strength": "LOW",
      "evidence_count": 31,
      "win_rate": 0.0,
      "average_r": -0.0524,
      "total_r": -1.5712,
      "missed_opportunity_count": 0,
      "current_behavior": "ma_alignment_bull は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_momentum_negative_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "momentum_negative",
      "proposal_strength": "LOW",
      "evidence_count": 43,
      "win_rate": 0.0,
      "average_r": 0.1398,
      "total_r": 5.7329,
      "missed_opportunity_count": 0,
      "current_behavior": "momentum_negative は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_momentum_positive_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "momentum_positive",
      "proposal_strength": "LOW",
      "evidence_count": 25,
      "win_rate": 0.0,
      "average_r": -0.0106,
      "total_r": -0.2638,
      "missed_opportunity_count": 0,
      "current_behavior": "momentum_positive は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_overextended_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "overextended",
      "proposal_strength": "LOW",
      "evidence_count": 18,
      "win_rate": 0.0,
      "average_r": 0.1785,
      "total_r": 3.2122,
      "missed_opportunity_count": 0,
      "current_behavior": "overextended は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_pullback_to_ma20_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "pullback_to_ma20",
      "proposal_strength": "LOW",
      "evidence_count": 12,
      "win_rate": 0.0,
      "average_r": -0.1218,
      "total_r": -1.3394,
      "missed_opportunity_count": 0,
      "current_behavior": "pullback_to_ma20 は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "negative"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_rsi_oversold_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "rsi_oversold",
      "proposal_strength": "LOW",
      "evidence_count": 16,
      "win_rate": 0.0,
      "average_r": 0.0992,
      "total_r": 1.4887,
      "missed_opportunity_count": 0,
      "current_behavior": "rsi_oversold は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_trend_down_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "trend_down",
      "proposal_strength": "LOW",
      "evidence_count": 40,
      "win_rate": 0.0,
      "average_r": 0.1785,
      "total_r": 6.9598,
      "missed_opportunity_count": 0,
      "current_behavior": "trend_down は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_trend_up_monitor_reason_code",
      "proposal_type": "monitor_reason_code",
      "target_type": "reason_code",
      "target_name": "trend_up",
      "proposal_strength": "LOW",
      "evidence_count": 31,
      "win_rate": 0.0,
      "average_r": -0.0524,
      "total_r": -1.5712,
      "missed_opportunity_count": 0,
      "current_behavior": "trend_up は中立",
      "proposed_change": "変更せず監視継続",
      "expected_effect": "安定性を確認",
      "risk_note": "明確な改善根拠なし",
      "apply_automatically": false,
      "priority": 3,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_asset_USDJPY_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "asset",
      "target_name": "USDJPY",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 1.0,
      "average_r": 1.087,
      "total_r": 2.174,
      "missed_opportunity_count": 0,
      "current_behavior": "asset=USDJPY avg_r=1.0870",
      "proposed_change": "評価件数不足のため監視継続",
      "expected_effect": "過剰調整を避ける",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_no_trade_reason_data_insufficient_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "data_insufficient",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "data_insufficient: correct=0, missed=0, avg_mfe_r=0.00",
      "proposed_change": "見送り理由の件数が少ないため監視継続",
      "expected_effect": "誤ったフィルター調整を避ける",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_no_trade_reason_low_volatility_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "low_volatility",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 28,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "low_volatility: correct=0, missed=0, avg_mfe_r=0.00",
      "proposed_change": "追加データを待つ",
      "expected_effect": "判断保留",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_no_trade_reason_rr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "rr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 93,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low: correct=0, missed=0, avg_mfe_r=0.00",
      "proposed_change": "追加データを待つ",
      "expected_effect": "判断保留",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_rank_A_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "rank",
      "target_name": "A",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 4,
      "win_rate": 0.0,
      "average_r": 0.1978,
      "total_r": 0.7911,
      "missed_opportunity_count": 0,
      "current_behavior": "rank=A avg_r=0.1978",
      "proposed_change": "評価件数不足のため監視継続",
      "expected_effect": "過剰調整を避ける",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_rank_NO_TRADE_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "rank",
      "target_name": "NO_TRADE",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rank=NO_TRADE avg_r=0.0000",
      "proposed_change": "評価件数不足のため監視継続",
      "expected_effect": "過剰調整を避ける",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_atr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "atr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": 0.1296,
      "total_r": 0.1296,
      "missed_opportunity_count": 0,
      "current_behavior": "atr_too_low は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_data_insufficient_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "data_insufficient",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "data_insufficient は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_risk_penalty_high_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "risk_penalty_high",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": -0.2554,
      "total_r": -0.2554,
      "missed_opportunity_count": 0,
      "current_behavior": "risk_penalty_high は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_rr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "rr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_side_NONE_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "side",
      "target_name": "NONE",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "side=NONE avg_r=0.0000",
      "proposed_change": "評価件数不足のため監視継続",
      "expected_effect": "過剰調整を避ける",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "group performance review"
    }
  ],
  "high_priority_proposals": [],
  "data_insufficient_items": [
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_asset_USDJPY_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "asset",
      "target_name": "USDJPY",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 2,
      "win_rate": 1.0,
      "average_r": 1.087,
      "total_r": 2.174,
      "missed_opportunity_count": 0,
      "current_behavior": "asset=USDJPY avg_r=1.0870",
      "proposed_change": "評価件数不足のため監視継続",
      "expected_effect": "過剰調整を避ける",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_no_trade_reason_data_insufficient_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "data_insufficient",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "data_insufficient: correct=0, missed=0, avg_mfe_r=0.00",
      "proposed_change": "見送り理由の件数が少ないため監視継続",
      "expected_effect": "誤ったフィルター調整を避ける",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_no_trade_reason_low_volatility_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "low_volatility",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 28,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "low_volatility: correct=0, missed=0, avg_mfe_r=0.00",
      "proposed_change": "追加データを待つ",
      "expected_effect": "判断保留",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_no_trade_reason_rr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "no_trade_reason",
      "target_name": "rr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 93,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low: correct=0, missed=0, avg_mfe_r=0.00",
      "proposed_change": "追加データを待つ",
      "expected_effect": "判断保留",
      "risk_note": "NO_TRADE緩和はノイズ取引増加に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "neutral"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_rank_A_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "rank",
      "target_name": "A",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 4,
      "win_rate": 0.0,
      "average_r": 0.1978,
      "total_r": 0.7911,
      "missed_opportunity_count": 0,
      "current_behavior": "rank=A avg_r=0.1978",
      "proposed_change": "評価件数不足のため監視継続",
      "expected_effect": "過剰調整を避ける",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_rank_NO_TRADE_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "rank",
      "target_name": "NO_TRADE",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rank=NO_TRADE avg_r=0.0000",
      "proposed_change": "評価件数不足のため監視継続",
      "expected_effect": "過剰調整を避ける",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "group performance review"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_atr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "atr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": 0.1296,
      "total_r": 0.1296,
      "missed_opportunity_count": 0,
      "current_behavior": "atr_too_low は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_data_insufficient_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "data_insufficient",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "data_insufficient は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_risk_penalty_high_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "risk_penalty_high",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 1,
      "win_rate": 0.0,
      "average_r": -0.2554,
      "total_r": -0.2554,
      "missed_opportunity_count": 0,
      "current_behavior": "risk_penalty_high は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_reason_code_rr_too_low_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "reason_code",
      "target_name": "rr_too_low",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "rr_too_low は評価件数不足",
      "proposed_change": "自動変更せず監視継続",
      "expected_effect": "誤ったルール変更を避ける",
      "risk_note": "評価件数5件未満",
      "apply_automatically": false,
      "priority": 4,
      "notes": "insufficient_data"
    },
    {
      "generated_at": "2026-07-02T12:20:21",
      "period_start": "2026-06-03",
      "period_end": "2026-07-02",
      "proposal_id": "20260702_side_NONE_data_insufficient",
      "proposal_type": "data_insufficient",
      "target_type": "side",
      "target_name": "NONE",
      "proposal_strength": "DATA_INSUFFICIENT",
      "evidence_count": 0,
      "win_rate": 0.0,
      "average_r": 0.0,
      "total_r": 0.0,
      "missed_opportunity_count": 0,
      "current_behavior": "side=NONE avg_r=0.0000",
      "proposed_change": "評価件数不足のため監視継続",
      "expected_effect": "過剰調整を避ける",
      "risk_note": "カテゴリ単位の調整は相場環境依存に注意",
      "apply_automatically": false,
      "priority": 4,
      "notes": "group performance review"
    }
  ],
  "safety_notes": [
    "実売買には使わない",
    "自動反映しない",
    "closed評価が30〜50件以上溜まるまでは提案のみ",
    "人間レビュー後に必要なら実装"
  ]
}
```
