# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-07-01 08:22:57 JST
生成日時（UTC）: 2026-06-30 23:22:57 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 0.85
ニュース市場バイアス: neutral
ニュース矛盾スコア: 0.0
主要テーマ: なし
日本語要約: 主要テーマはありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立

## スコア

- risk_on_news_score: 38.33
- risk_off_news_score: 0.0
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 19.17
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 0.0
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 19.17
- inflation_pressure_news_score: 57.5
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Nike results top estimates even as China sales drop 12%; retailer expects $986 million tariff refund (インフレ圧力 / 金利圧力候補)
- Record chip rally adds $2 trillion in combined value to Micron, Intel and AMD in second quarter (リスクオン要因)
- Michael Burry says he's shorting Caterpillar for the first time after it nearly doubled in the AI-driven rally of 2026 (リスクオン要因)
- Big egg producers settle price inflation probe with DOJ for 53 million eggs — and $3.3M (インフレ圧力 / 金利圧力候補)
- Trump's massive defense budget, depleted war machine, spark U.S. state battle for business and jobs (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Cleveland Fed President Hammack says AI could fuel inflation, rate hikes may be necessary (インフレ圧力 / 金利圧力候補)
