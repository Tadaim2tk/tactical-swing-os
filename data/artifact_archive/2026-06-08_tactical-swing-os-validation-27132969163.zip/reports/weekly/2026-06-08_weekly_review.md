# Tactical Swing OS Weekly Review

## 1. 週次結論

次週モードは「通常」、最大日次リスクは 0.5% です。 データ不足 週次R損益は横ばいです。

## 2. 週次サマリー

| week_start | week_end | total_signals | a_signals | b_signals | no_trade_signals | closed_signals | pending_signals | skipped_signals | win_rate | profit_factor | total_r | average_r | max_win_r | max_loss_r | best_asset | worst_asset | next_week_mode | max_daily_risk_pct | rule_change_1 | rule_change_2 | rule_change_3 | evaluation_source | latest_evaluations_available | fallback_used |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-02 | 2026-06-08 | 31 | 0 | 14 | 17 | 0 | 10 | 5 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | BTC | BTC | 通常 | 0.5 | 評価期間またはentry条件の見直し | データ不足 |  | latest_evaluations | True | False |

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 3. Rank別成績

| rank | signals | closed | win_rate | total_r | average_r |
| --- | --- | --- | --- | --- | --- |
| A | 0 | 0 | 0.0 | 0.0 | 0.0 |
| B | 14 | 0 | 0.0 | 0.0 | 0.0 |
| NO_TRADE | 17 | 0 | 0.0 | 0.0 | 0.0 |
| その他 | 0 | 0 | 0.0 | 0.0 | 0.0 |

## 4. 資産別成績

| asset | signals | closed | win_rate | total_r | average_r | best_r | worst_r |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BTC | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| DXY | 4 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| GOLD | 4 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| NASDAQ | 3 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| SPX | 3 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| US10Y | 3 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| USDJPY | 4 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| VIX | 2 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| WTI | 3 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |

## 5. Side別成績

| side | signals | closed | win_rate | total_r | average_r | best_r | worst_r |
| --- | --- | --- | --- | --- | --- | --- | --- |
| LONG | 8 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| SHORT | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| NONE | 17 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |

## 6. エラー分類

| error_type | count |
| --- | --- |
| 未分類 | 5 |
| unresolved | 5 |
| data_missing | 3 |
| no_entry | 2 |

## 7. 取り逃し監査

| missed_candidate | asset | count | note |
| --- | --- | --- | --- |
| pending_or_skipped_ab | BTC | 2 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | DXY | 2 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | GOLD | 3 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | US10Y | 2 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | USDJPY | 1 | A/B候補の未完了評価が多い可能性 |
| large_mfe_review | GOLD | 1 | MFE=17.2318 のためentry/約定条件を確認 |
| large_mfe_review | GOLD | 1 | MFE=20.9636 のためentry/約定条件を確認 |

## 8. モデル更新メモ

- 評価期間またはentry条件の見直し
- データ不足
- 特記事項なし

## 9. Reason Code分析メモ

reason code analysisは別artifact参照。現時点では分析結果が未生成です。

### reason_code 上位プラス3件

_該当なし_

### reason_code 上位マイナス3件

_該当なし_

### no_trade_reason 取り逃し候補

_該当なし_

## 10. REVIEW_LOG CSV

```csv
week_start,week_end,total_signals,a_signals,b_signals,no_trade_signals,closed_signals,pending_signals,skipped_signals,win_rate,profit_factor,total_r,average_r,max_win_r,max_loss_r,best_asset,worst_asset,next_week_mode,max_daily_risk_pct,rule_change_1,rule_change_2,rule_change_3,evaluation_source,latest_evaluations_available,fallback_used
2026-06-02,2026-06-08,31,0,14,17,0,10,5,0.0,0.0,0.0,0.0,0.0,0.0,BTC,BTC,通常,0.5,評価期間またはentry条件の見直し,データ不足,,latest_evaluations,True,False
```

## 11. REVIEW_LOG JSON

```json
[
  {
    "week_start":"2026-06-02",
    "week_end":"2026-06-08",
    "total_signals":31,
    "a_signals":0,
    "b_signals":14,
    "no_trade_signals":17,
    "closed_signals":0,
    "pending_signals":10,
    "skipped_signals":5,
    "win_rate":0.0,
    "profit_factor":0.0,
    "total_r":0.0,
    "average_r":0.0,
    "max_win_r":0.0,
    "max_loss_r":0.0,
    "best_asset":"BTC",
    "worst_asset":"BTC",
    "next_week_mode":"通常",
    "max_daily_risk_pct":0.5,
    "rule_change_1":"評価期間またはentry条件の見直し",
    "rule_change_2":"データ不足",
    "rule_change_3":"",
    "evaluation_source":"latest_evaluations",
    "latest_evaluations_available":true,
    "fallback_used":false
  }
]
```
