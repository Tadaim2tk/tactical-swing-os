# Tactical Swing OS Monthly Calibration

## 1. 月次結論

翌月モードは「通常」、最大日次リスクは 0.5% です。データ不足。

## 2. 月次サマリー

| month_start | month_end | total_signals | closed_signals | pending_signals | skipped_signals | win_rate | profit_factor | total_r | average_r | max_win_r | max_loss_r | best_asset | worst_asset | best_rank | worst_rank | best_side | worst_side | next_month_mode | max_daily_risk_pct | weight_change_summary | rule_change_1 | rule_change_2 | rule_change_3 | evaluation_source | latest_evaluations_available | fallback_used |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-05-10 | 2026-06-08 | 31 | 0 | 10 | 5 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | BTC | BTC | A | A | LONG | LONG | 通常 | 0.5 | 変更提案なし | closed評価10件未満のため自動適用しない | データ不足 |  | latest_evaluations | True | False |

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 3. 資産別較正

| asset | signals | closed | win_rate | total_r | average_r | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BTC | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |
| DXY | 4 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |
| GOLD | 4 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |
| NASDAQ | 3 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |
| SPX | 3 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |
| US10Y | 3 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |
| USDJPY | 4 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |
| VIX | 2 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |
| WTI | 3 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |

## 4. Rank別較正

| rank | signals | closed | win_rate | total_r | average_r | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | 0 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |
| B | 14 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |
| NO_TRADE | 17 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |

## 5. Side別較正

| side | signals | closed | win_rate | total_r | average_r | best_r | worst_r | proposed_weight_change | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| LONG | 8 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |
| SHORT | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |
| NONE | 17 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | データ不足 |

## 6. 翌月の暫定モード

- next_month_mode: 通常
- max_daily_risk_pct: 0.5

## 7. 重み変更案

変更提案なし

## 8. 据え置き理由

weights.jsonは初期値のまま据え置きます。今回の出力は提案のみで、自動更新は行いません。

## 9. データ不足の注意

closed評価が30〜50件以上たまるまでは、変更案を自動適用しません。

## 10. Reason Code較正メモ

reason_code分析は未生成です。別artifact生成後に月次較正メモへ反映されます。

### strong_positive reason_codes

_該当なし_

### strong_negative reason_codes

_該当なし_

## 11. MONTHLY_CALIBRATION_LOG CSV

```csv
month_start,month_end,total_signals,closed_signals,pending_signals,skipped_signals,win_rate,profit_factor,total_r,average_r,max_win_r,max_loss_r,best_asset,worst_asset,best_rank,worst_rank,best_side,worst_side,next_month_mode,max_daily_risk_pct,weight_change_summary,rule_change_1,rule_change_2,rule_change_3,evaluation_source,latest_evaluations_available,fallback_used
2026-05-10,2026-06-08,31,0,10,5,0.0,0.0,0.0,0.0,0.0,0.0,BTC,BTC,A,A,LONG,LONG,通常,0.5,変更提案なし,closed評価10件未満のため自動適用しない,データ不足,,latest_evaluations,True,False
```

## 12. MONTHLY_CALIBRATION_LOG JSON

```json
[
  {
    "month_start": "2026-05-10",
    "month_end": "2026-06-08",
    "total_signals": 31,
    "closed_signals": 0,
    "pending_signals": 10,
    "skipped_signals": 5,
    "win_rate": 0.0,
    "profit_factor": 0.0,
    "total_r": 0.0,
    "average_r": 0.0,
    "max_win_r": 0.0,
    "max_loss_r": 0.0,
    "best_asset": "BTC",
    "worst_asset": "BTC",
    "best_rank": "A",
    "worst_rank": "A",
    "best_side": "LONG",
    "worst_side": "LONG",
    "next_month_mode": "通常",
    "max_daily_risk_pct": 0.5,
    "weight_change_summary": "変更提案なし",
    "rule_change_1": "closed評価10件未満のため自動適用しない",
    "rule_change_2": "データ不足",
    "rule_change_3": "",
    "evaluation_source": "latest_evaluations",
    "latest_evaluations_available": true,
    "fallback_used": false,
    "asset_calibration": [
      {
        "asset": "BTC",
        "signals": 5,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      },
      {
        "asset": "DXY",
        "signals": 4,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      },
      {
        "asset": "GOLD",
        "signals": 4,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      },
      {
        "asset": "NASDAQ",
        "signals": 3,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      },
      {
        "asset": "SPX",
        "signals": 3,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      },
      {
        "asset": "US10Y",
        "signals": 3,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      },
      {
        "asset": "USDJPY",
        "signals": 4,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      },
      {
        "asset": "VIX",
        "signals": 2,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      },
      {
        "asset": "WTI",
        "signals": 3,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      }
    ],
    "rank_calibration": [
      {
        "rank": "A",
        "signals": 0,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      },
      {
        "rank": "B",
        "signals": 14,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      },
      {
        "rank": "NO_TRADE",
        "signals": 17,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      }
    ],
    "side_calibration": [
      {
        "side": "LONG",
        "signals": 8,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      },
      {
        "side": "SHORT",
        "signals": 6,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      },
      {
        "side": "NONE",
        "signals": 17,
        "closed": 0,
        "win_rate": 0.0,
        "total_r": 0.0,
        "average_r": 0.0,
        "best_r": 0.0,
        "worst_r": 0.0,
        "proposed_weight_change": 0.0,
        "reason": "データ不足"
      }
    ],
    "proposed_weight_changes": {
      "asset": [
        {
          "asset": "BTC",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        },
        {
          "asset": "DXY",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        },
        {
          "asset": "GOLD",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        },
        {
          "asset": "NASDAQ",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        },
        {
          "asset": "SPX",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        },
        {
          "asset": "US10Y",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        },
        {
          "asset": "USDJPY",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        },
        {
          "asset": "VIX",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        },
        {
          "asset": "WTI",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        }
      ],
      "rank": [
        {
          "rank": "A",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        },
        {
          "rank": "B",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        },
        {
          "rank": "NO_TRADE",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        }
      ],
      "side": [
        {
          "side": "LONG",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        },
        {
          "side": "SHORT",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        },
        {
          "side": "NONE",
          "proposed_weight_change": 0.0,
          "reason": "データ不足"
        }
      ]
    }
  }
]
```
