# Tactical Swing OS Reason Code Analysis

## 1. 結論

reason_codesの有効性を集計しました。

対象期間: 2026-05-10 - 2026-06-08

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 2. reason_codes 上位プラス要因

_該当なし_

## 3. reason_codes 上位マイナス要因

_該当なし_

## 4. no_trade_reason 分析

| no_trade_reason | count | no_trade_correct_count | no_trade_missed_count | missed_opportunity_count | average_mfe_r | average_r | assessment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rr_too_low | 4 | 0 | 0 | 0 | 0.0 | 0.0 | insufficient_data |
| low_volatility | 3 | 0 | 0 | 0 | 0.0 | 0.0 | insufficient_data |

## 5. 取り逃し候補

_該当なし_

## 6. 改善候補

_該当なし_

## 7. データ不足の注意

reason_codeごとの評価件数が5件未満の場合は `insufficient_data` とし、weights.jsonは自動更新しません。

## 8. REASON_CODE_ANALYSIS CSV

```csv
reason_code,signals_count,evaluated_count,win_count,loss_count,no_entry_count,missed_opportunity_count,win_rate,total_r,average_r,median_r,best_r,worst_r,average_mfe_r,average_mae_r,rank_a_count,rank_b_count,no_trade_count,recommended_action_trade_count,recommended_action_watch_count,recommended_action_no_trade_count,reliability_label
breakout_down,1,1,0,0,0,0,0.0,0.0193,0.0193,0.0193,0.0193,0.0193,0.049,-0.0769,0,1,0,0,1,0,insufficient_data
momentum_positive,7,2,0,0,0,0,0.0,0.0135,0.0135,0.0135,0.0135,0.0135,0.0662,-0.0169,0,2,5,0,2,5,insufficient_data
ma_alignment_bull,5,2,0,0,0,0,0.0,0.0135,0.0135,0.0135,0.0135,0.0135,0.0662,-0.0169,0,2,3,0,2,3,insufficient_data
trend_up,5,2,0,0,0,0,0.0,0.0135,0.0135,0.0135,0.0135,0.0135,0.0662,-0.0169,0,2,3,0,2,3,insufficient_data
breakout_up,4,1,0,0,0,0,0.0,0.0135,0.0135,0.0135,0.0135,0.0135,0.0662,-0.0169,0,1,3,0,1,3,insufficient_data
ma_alignment_bear,5,3,0,0,1,0,0.0,0.0193,0.0097,0.0097,0.0193,0.0,-0.0214,-0.1128,0,3,2,0,3,2,insufficient_data
momentum_negative,5,3,0,0,1,0,0.0,0.0193,0.0097,0.0097,0.0193,0.0,-0.0214,-0.1128,0,3,2,0,3,2,insufficient_data
trend_down,5,3,0,0,1,0,0.0,0.0193,0.0097,0.0097,0.0193,0.0,-0.0214,-0.1128,0,3,2,0,3,2,insufficient_data
rr_too_low,7,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,7,0,0,7,insufficient_data
atr_too_low,3,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,3,0,0,3,insufficient_data
rsi_overbought,3,0,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0,3,0,0,3,insufficient_data
rsi_oversold,3,1,0,0,1,0,0.0,0.0,0.0,0.0,0.0,0.0,-0.0918,-0.1488,0,1,2,0,1,2,insufficient_data
overextended,1,1,0,0,1,0,0.0,0.0,0.0,0.0,0.0,0.0,-0.0918,-0.1488,0,1,0,0,1,0,insufficient_data
range_middle,1,1,0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,1,0,0,1,0,insufficient_data
risk_penalty_high,1,1,0,0,1,0,0.0,0.0,0.0,0.0,0.0,0.0,-0.0918,-0.1488,0,1,0,0,1,0,insufficient_data
```

## 9. REASON_CODE_ANALYSIS JSON

```json
{
  "start_date": "2026-05-10",
  "end_date": "2026-06-08",
  "reason_code_summary": [
    {
      "reason_code": "breakout_down",
      "signals_count": 1,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0193,
      "average_r": 0.0193,
      "median_r": 0.0193,
      "best_r": 0.0193,
      "worst_r": 0.0193,
      "average_mfe_r": 0.049,
      "average_mae_r": -0.0769,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "momentum_positive",
      "signals_count": 7,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0135,
      "average_r": 0.0135,
      "median_r": 0.0135,
      "best_r": 0.0135,
      "worst_r": 0.0135,
      "average_mfe_r": 0.0662,
      "average_mae_r": -0.0169,
      "rank_a_count": 0,
      "rank_b_count": 2,
      "no_trade_count": 5,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 2,
      "recommended_action_no_trade_count": 5,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "ma_alignment_bull",
      "signals_count": 5,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0135,
      "average_r": 0.0135,
      "median_r": 0.0135,
      "best_r": 0.0135,
      "worst_r": 0.0135,
      "average_mfe_r": 0.0662,
      "average_mae_r": -0.0169,
      "rank_a_count": 0,
      "rank_b_count": 2,
      "no_trade_count": 3,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 2,
      "recommended_action_no_trade_count": 3,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "trend_up",
      "signals_count": 5,
      "evaluated_count": 2,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0135,
      "average_r": 0.0135,
      "median_r": 0.0135,
      "best_r": 0.0135,
      "worst_r": 0.0135,
      "average_mfe_r": 0.0662,
      "average_mae_r": -0.0169,
      "rank_a_count": 0,
      "rank_b_count": 2,
      "no_trade_count": 3,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 2,
      "recommended_action_no_trade_count": 3,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "breakout_up",
      "signals_count": 4,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0135,
      "average_r": 0.0135,
      "median_r": 0.0135,
      "best_r": 0.0135,
      "worst_r": 0.0135,
      "average_mfe_r": 0.0662,
      "average_mae_r": -0.0169,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 3,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 3,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "ma_alignment_bear",
      "signals_count": 5,
      "evaluated_count": 3,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0193,
      "average_r": 0.0097,
      "median_r": 0.0097,
      "best_r": 0.0193,
      "worst_r": 0.0,
      "average_mfe_r": -0.0214,
      "average_mae_r": -0.1128,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 2,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 2,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "momentum_negative",
      "signals_count": 5,
      "evaluated_count": 3,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0193,
      "average_r": 0.0097,
      "median_r": 0.0097,
      "best_r": 0.0193,
      "worst_r": 0.0,
      "average_mfe_r": -0.0214,
      "average_mae_r": -0.1128,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 2,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 2,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "trend_down",
      "signals_count": 5,
      "evaluated_count": 3,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0193,
      "average_r": 0.0097,
      "median_r": 0.0097,
      "best_r": 0.0193,
      "worst_r": 0.0,
      "average_mfe_r": -0.0214,
      "average_mae_r": -0.1128,
      "rank_a_count": 0,
      "rank_b_count": 3,
      "no_trade_count": 2,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 3,
      "recommended_action_no_trade_count": 2,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "rr_too_low",
      "signals_count": 7,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 7,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 7,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "atr_too_low",
      "signals_count": 3,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 3,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 3,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "rsi_overbought",
      "signals_count": 3,
      "evaluated_count": 0,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 0,
      "no_trade_count": 3,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 0,
      "recommended_action_no_trade_count": 3,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "rsi_oversold",
      "signals_count": 3,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": -0.0918,
      "average_mae_r": -0.1488,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 2,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 2,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "overextended",
      "signals_count": 1,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": -0.0918,
      "average_mae_r": -0.1488,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "range_middle",
      "signals_count": 1,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 0,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": 0.0,
      "average_mae_r": 0.0,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    },
    {
      "reason_code": "risk_penalty_high",
      "signals_count": 1,
      "evaluated_count": 1,
      "win_count": 0,
      "loss_count": 0,
      "no_entry_count": 1,
      "missed_opportunity_count": 0,
      "win_rate": 0.0,
      "total_r": 0.0,
      "average_r": 0.0,
      "median_r": 0.0,
      "best_r": 0.0,
      "worst_r": 0.0,
      "average_mfe_r": -0.0918,
      "average_mae_r": -0.1488,
      "rank_a_count": 0,
      "rank_b_count": 1,
      "no_trade_count": 0,
      "recommended_action_trade_count": 0,
      "recommended_action_watch_count": 1,
      "recommended_action_no_trade_count": 0,
      "reliability_label": "insufficient_data"
    }
  ],
  "no_trade_reason_summary": [
    {
      "no_trade_reason": "rr_too_low",
      "count": 4,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "insufficient_data"
    },
    {
      "no_trade_reason": "low_volatility",
      "count": 3,
      "no_trade_correct_count": 0,
      "no_trade_missed_count": 0,
      "missed_opportunity_count": 0,
      "average_mfe_r": 0.0,
      "average_r": 0.0,
      "assessment": "insufficient_data"
    }
  ],
  "top_positive_reasons": [],
  "top_negative_reasons": [],
  "over_filtering_candidates": [],
  "evaluation_source": "latest_evaluations",
  "evaluation_rows": 15,
  "latest_evaluations_available": true,
  "fallback_used": false,
  "notes": [
    "reason_code単位のweights自動更新はまだ行いません。",
    "insufficient_data reason_codes: 15"
  ]
}
```
