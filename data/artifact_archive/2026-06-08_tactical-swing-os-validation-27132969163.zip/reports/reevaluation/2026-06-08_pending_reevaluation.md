# Pending Signal Re-evaluation Report

## 1. 概要

* 生成日時JST: 2026-06-08 19:57:17 JST
* データソース: sheets
* 対象SIGNALS件数: 31
* 再評価対象件数: 14
* closed化した件数: 1
* no_entry継続件数: 0
* open継続件数: 13
* missed_opportunity件数: 0
* Sheets保存: 未実行
* Sheets保存成功件数: 0
* Sheets重複スキップ件数: 0
* Sheets保存warning: なし

## 2. 決着したシグナル

| signal_id | asset | side | rank | previous_outcome | outcome | r_multiple | error_type |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260606_BTC_SHORT_TREND | BTC | SHORT | B |  | loss_sl | -1.0 | stop_loss |

## 3. 未決着継続

| signal_id | asset | side | rank | outcome | mfe_r | mae_r | bars_checked |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | open_unresolved | 0.3267 | -0.1611 | 1 |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B | open_unresolved | 0.5573 | -0.4272 | 1 |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B | open_unresolved |  |  | 0 |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | open_unresolved | 0.2316 | -0.8001 | 1 |
| 20260605_DXY_LONG_TREND | DXY | LONG | B | open_unresolved | 0.3267 | -0.1611 | 1 |
| 20260605_GOLD_SHORT_TREND | GOLD | SHORT | B | open_unresolved | 0.5573 | -0.4272 | 1 |
| 20260605_US10Y_LONG_TREND | US10Y | LONG | B | open_unresolved |  |  | 0 |
| 20260605_USDJPY_LONG_TREND | USDJPY | LONG | B | open_unresolved | 0.2316 | -0.8001 | 1 |
| 20260606_BTC_SHORT_B-Watch | BTC | SHORT | B | open_unresolved | 0.0295 | -0.1694 | 2 |
| 20260605_DXY_LONG_A-Momentum | DXY | LONG | B | open_unresolved | 0.084 | -0.0267 | 1 |
| 20260605_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.1204 | -0.0769 | 1 |
| 20260605_US10Y_LONG_A-Pullback | US10Y | LONG | B | open_unresolved |  |  | 0 |
| 20260607_GOLD_SHORT_B-Watch | GOLD | SHORT | B | open_unresolved | 0.1535 | -0.0497 | 1 |

## 4. 取り逃し候補

取り逃し候補はありません。

## 5. No Trade再評価

No Trade再評価は実行していません。

## 6. 注意

* このレポートは実売買ではありません。
* Tactical Swing OS が過去に出した判断の仮想評価です。
* 価格データの欠損や市場休場により、評価が遅れる場合があります。
* append-only運用でEVALUATIONSへ追記する場合、分析側では最新評価行を採用する必要があります。
