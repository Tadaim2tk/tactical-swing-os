# Tactical Swing OS Weekly Review

## 1. 週次結論

次週モードは「通常」、最大日次リスクは 0.5% です。 データ不足 週次R損益は横ばいです。

## 2. 週次サマリー

| week_start | week_end | total_signals | a_signals | b_signals | no_trade_signals | closed_signals | pending_signals | skipped_signals | win_rate | profit_factor | total_r | average_r | max_win_r | max_loss_r | best_asset | worst_asset | next_week_mode | max_daily_risk_pct | rule_change_1 | rule_change_2 | rule_change_3 | evaluation_source | latest_evaluations_available | fallback_used |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-07 | 2026-06-13 | 49 | 0 | 9 | 40 | 0 | 9 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | BTC | BTC | 通常 | 0.5 | 評価期間またはentry条件の見直し | データ不足 |  | latest_evaluations | True | False |

評価データソース: latest_evaluations / latest_evaluations_available: True / fallback_used: False

## 3. Rank別成績

| rank | signals | closed | win_rate | total_r | average_r |
| --- | --- | --- | --- | --- | --- |
| A | 0 | 0 | 0.0 | 0.0 | 0.0 |
| B | 9 | 0 | 0.0 | 0.0 | 0.0 |
| NO_TRADE | 40 | 0 | 0.0 | 0.0 | 0.0 |
| その他 | 0 | 0 | 0.0 | 0.0 | 0.0 |

## 4. 資産別成績

| asset | signals | closed | win_rate | total_r | average_r | best_r | worst_r |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BTC | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| DXY | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| GOLD | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| NASDAQ | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| SPX | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| US10Y | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| USDJPY | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| VIX | 4 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| WTI | 6 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |

## 5. Side別成績

| side | signals | closed | win_rate | total_r | average_r | best_r | worst_r |
| --- | --- | --- | --- | --- | --- | --- | --- |
| LONG | 1 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| SHORT | 8 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| NONE | 40 | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |

## 6. エラー分類

| error_type | count |
| --- | --- |
| unresolved | 7 |
| no_entry | 1 |
| data_missing | 1 |

## 7. 取り逃し監査

| missed_candidate | asset | count | note |
| --- | --- | --- | --- |
| pending_or_skipped_ab | BTC | 1 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | GOLD | 4 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | US10Y | 1 | A/B候補の未完了評価が多い可能性 |
| pending_or_skipped_ab | WTI | 3 | A/B候補の未完了評価が多い可能性 |
| large_mfe_review | GOLD | 1 | MFE=325.8413 のためentry/約定条件を確認 |
| large_mfe_review | GOLD | 1 | MFE=327.6912 のためentry/約定条件を確認 |
| large_mfe_review | BTC | 1 | MFE=1547.3921 のためentry/約定条件を確認 |
| large_mfe_review | GOLD | 1 | MFE=262.0276 のためentry/約定条件を確認 |
| large_mfe_review | WTI | 1 | MFE=6.0429 のためentry/約定条件を確認 |
| large_mfe_review | GOLD | 1 | MFE=44.015 のためentry/約定条件を確認 |
| large_mfe_review | WTI | 1 | MFE=3.1033 のためentry/約定条件を確認 |

## 8. モデル更新メモ

- 評価期間またはentry条件の見直し
- データ不足
- 特記事項なし

## 9. Reason Code分析メモ

reason code analysisは別artifact参照。現時点では分析結果が未生成です。

### reason_code 上位プラス3件

_該当なし_

### reason_code 上位マイナス3件

_該当なし_

### no_trade_reason 取り逃し候補

_該当なし_

## 10. REVIEW_LOG CSV

```csv
week_start,week_end,total_signals,a_signals,b_signals,no_trade_signals,closed_signals,pending_signals,skipped_signals,win_rate,profit_factor,total_r,average_r,max_win_r,max_loss_r,best_asset,worst_asset,next_week_mode,max_daily_risk_pct,rule_change_1,rule_change_2,rule_change_3,evaluation_source,latest_evaluations_available,fallback_used
2026-06-07,2026-06-13,49,0,9,40,0,9,0,0.0,0.0,0.0,0.0,0.0,0.0,BTC,BTC,通常,0.5,評価期間またはentry条件の見直し,データ不足,,latest_evaluations,True,False
```

## 11. REVIEW_LOG JSON

```json
[
  {
    "week_start":"2026-06-07",
    "week_end":"2026-06-13",
    "total_signals":49,
    "a_signals":0,
    "b_signals":9,
    "no_trade_signals":40,
    "closed_signals":0,
    "pending_signals":9,
    "skipped_signals":0,
    "win_rate":0.0,
    "profit_factor":0.0,
    "total_r":0.0,
    "average_r":0.0,
    "max_win_r":0.0,
    "max_loss_r":0.0,
    "best_asset":"BTC",
    "worst_asset":"BTC",
    "next_week_mode":"通常",
    "max_daily_risk_pct":0.5,
    "rule_change_1":"評価期間またはentry条件の見直し",
    "rule_change_2":"データ不足",
    "rule_change_3":"",
    "evaluation_source":"latest_evaluations",
    "latest_evaluations_available":true,
    "fallback_used":false
  }
]
```
