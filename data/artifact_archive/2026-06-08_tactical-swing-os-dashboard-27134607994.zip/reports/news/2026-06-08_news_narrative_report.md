# Tactical Swing OS News Narrative Report

生成日時（JST）: 2026-06-08 20:30:24 JST
生成日時（UTC）: 2026-06-08 11:30:24 UTC
headline件数: 30
ニュース取得ステータス: partial
取得成功ソース数: 4
取得失敗ソース数: 1
最終ニュース取得所要秒数: 1.15
ニュース市場バイアス: neutral
ニュース矛盾スコア: 19.17
主要テーマ: gold_safe_haven
日本語要約: 金安全資産需要はありますが、ニュース面の方向感は中立です。
ニュースモード: ニュースのリスク方向は中立 / 地政学リスク材料あり

## スコア

- risk_on_news_score: 19.17
- risk_off_news_score: 38.33
- dollar_strength_news_score: 0.0
- rate_pressure_news_score: 0.0
- gold_safe_haven_news_score: 76.67
- oil_supply_risk_news_score: 0.0
- crypto_liquidity_news_score: 19.17
- equity_momentum_news_score: 0.0
- geopolitical_risk_news_score: 57.5
- inflation_pressure_news_score: 19.17
- recession_risk_news_score: 0.0
- central_bank_hawkish_score: 0.0
- central_bank_dovish_score: 0.0
- news_confidence: 100.0

## Top News Drivers

- Bidding war erupts for world’s oldest bank as Italy’s Intesa gatecrashes BPM offer (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Foreign investors have dumped billions of dollars of Korean stocks this year despite record rally. Here's why (リスクオン要因)
- U.S. confirms second Texas screwworm case, Canada restricts livestock imports (地政学リスク / 金安全資産需要 / リスクオフ要因)
- 100 days of the Iran war: How global markets and the economy have been affected, in charts (地政学リスク / 金安全資産需要 / リスクオフ要因)
- Inflation inside the electronics you buy may soon become a bit more sticky (インフレ圧力 / 金利圧力候補)
- Gold just had its worst selloff since March. A floor may be $4,000, says one veteran strategist (リスクオフ要因)
- Crypto's recovery remains unsecure as SpaceX, Anthropic IPOs loom. Stronger ETF inflows would help. (暗号資産流動性)
